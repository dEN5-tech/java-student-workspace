@echo off
chcp 65001 > nul
title Tortotoro Backend (Django REST API)

echo ===================================================
echo     Кафе «Tortotoro» — Бэкенд сервер (Django)
echo ===================================================
echo.

echo Применение миграций базы данных...
python manage.py makemigrations api
python manage.py migrate

echo.
echo Заполнение начальными данными...
python manage.py seed_data

echo.
echo ===================================================
echo   Сервер запускается на http://127.0.0.1:8080/
echo   API доступно по адресу http://127.0.0.1:8080/api/
echo   Админка: http://127.0.0.1:8080/admin/
echo ===================================================
echo.

python manage.py runserver 127.0.0.1:8080
pause
