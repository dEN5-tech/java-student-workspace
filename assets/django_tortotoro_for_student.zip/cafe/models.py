from django.db import models


class Role(models.Model):
    """
    Справочник ролей:
    1 - Администратор
    2 - Официант
    3 - Повар
    """
    name = models.CharField(max_length=50, verbose_name="Название роли")

    def __str__(self):
        return f"{self.id} - {self.name}"


class User(models.Model):
    """
    Модель сотрудника кафе «Tortotoro».
    """
    STATUS_CHOICES = [
        ('active', 'Работает'),
        ('dismissed', 'Уволен'),
    ]

    name = models.CharField(max_length=150, verbose_name="ФИО сотрудника")
    login = models.CharField(max_length=100, unique=True, verbose_name="Логин")
    password = models.CharField(max_length=128, verbose_name="Пароль")
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='users', verbose_name="Роль")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active', verbose_name="Статус")

    def __str__(self):
        return f"{self.name} ({self.login}) - {self.role.name}"


class WorkShift(models.Model):
    """
    Модель рабочей смены.
    """
    start = models.CharField(max_length=10, default="08:00", verbose_name="Начало смены")
    end = models.CharField(max_length=10, default="20:00", verbose_name="Конец смены")
    active = models.BooleanField(default=False, verbose_name="Открыта")
    closed = models.BooleanField(default=False, verbose_name="Закрыта")
    employees = models.ManyToManyField(User, blank=True, related_name='shifts', verbose_name="Сотрудники смены")

    def __str__(self):
        status_name = "Закрыта" if self.closed else ("Открыта" if self.active else "Создана")
        return f"Смена #{self.id} ({self.start} - {self.end}) [{status_name}]"


class Order(models.Model):
    """
    Модель заказа столика.
    Статусы:
    1 - Принят
    2 - Готовится (Повар)
    3 - Готов (Повар)
    4 - Оплачен (Официант)
    5 - Отменен (Официант / Администратор)
    """
    STATUS_CHOICES = [
        (1, 'Принят'),
        (2, 'Готовится'),
        (3, 'Готов'),
        (4, 'Оплачен'),
        (5, 'Отменен'),
    ]

    table = models.CharField(max_length=100, verbose_name="Столик")
    status = models.IntegerField(choices=STATUS_CHOICES, default=1, verbose_name="Статус заказа")
    price = models.IntegerField(default=0, verbose_name="Общая сумма (руб)")
    shift = models.ForeignKey(WorkShift, on_delete=models.SET_NULL, null=True, blank=True, related_name='orders', verbose_name="Смена")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")

    def recalculate_price(self):
        total = sum(item.price * item.count for item in self.positions.all())
        self.price = total
        self.save()
        return total

    def __str__(self):
        return f"Заказ #{self.id} ({self.table}) - {self.get_status_display()}"


class OrderPosition(models.Model):
    """
    Позиция (блюдо/напиток) внутри заказа.
    """
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='positions', verbose_name="Заказ")
    name = models.CharField(max_length=150, verbose_name="Наименование блюда")
    price = models.IntegerField(default=0, verbose_name="Цена за шт (руб)")
    count = models.IntegerField(default=1, verbose_name="Количество")

    def __str__(self):
        return f"{self.name} x{self.count} в заказе #{self.order_id}"
