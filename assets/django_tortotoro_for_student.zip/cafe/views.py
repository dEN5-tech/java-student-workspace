from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Role, User, WorkShift, Order, OrderPosition


def get_session_user(request):
    """
    Вспомогательная функция: получает авторизованного пользователя из сессии Django.
    """
    user_id = request.session.get('user_id')
    if not user_id:
        return None
    try:
        return User.objects.get(id=user_id, status='active')
    except User.DoesNotExist:
        return None


# ==========================================
# 1. Авторизация и выход
# ==========================================

def login_view(request):
    """
    Страница входа: проверка логина и пароля, сохранение в сессию.
    """
    if request.method == 'POST':
        login_val = request.POST.get('login', '').strip()
        password_val = request.POST.get('password', '').strip()

        if not login_val or not password_val:
            messages.error(request, 'Пожалуйста, введите логин и пароль')
            return render(request, 'cafe/login.html')

        try:
            user = User.objects.get(login=login_val, password=password_val)
        except User.DoesNotExist:
            messages.error(request, 'Неверный логин или пароль')
            return render(request, 'cafe/login.html')

        if user.status == 'dismissed':
            messages.error(request, 'Сотрудник заблокирован (уволен)')
            return render(request, 'cafe/login.html')

        # Сохраняем ID пользователя в стандартной сессии Django
        request.session['user_id'] = user.id

        # Перенаправляем на соответствующую панель в зависимости от роли
        if user.role_id == 1:
            return redirect('admin_dashboard')
        elif user.role_id == 2:
            return redirect('waiter_dashboard')
        elif user.role_id == 3:
            return redirect('cook_dashboard')
        else:
            return redirect('login')

    return render(request, 'cafe/login.html')


def logout_view(request):
    """
    Выход из системы: очистка сессии и перенаправление на страницу входа.
    """
    request.session.flush()
    messages.success(request, 'Вы успешно вышли из системы')
    return redirect('login')


# ==========================================
# 2. Панель Администратора
# ==========================================

def admin_dashboard_view(request):
    """
    Панель администратора: управление сотрудниками, сменами и просмотр всех заказов.
    """
    user = get_session_user(request)
    if not user or user.role_id != 1:
        messages.error(request, 'Требуются права администратора')
        return redirect('login')

    # Обработка действий (POST запросов с HTML-форм)
    if request.method == 'POST':
        action = request.POST.get('action')

        # 1. Добавление нового сотрудника
        if action == 'add_user':
            name = request.POST.get('name', '').strip()
            login_val = request.POST.get('login', '').strip()
            password_val = request.POST.get('password', '').strip()
            role_id = request.POST.get('role_id', '2')

            if not name or not login_val or not password_val:
                messages.error(request, 'Все поля обязательны для заполнения')
            elif User.objects.filter(login=login_val).exists():
                messages.error(request, 'Пользователь с таким логином уже существует')
            else:
                User.objects.create(
                    name=name,
                    login=login_val,
                    password=password_val,
                    role_id=int(role_id)
                )
                messages.success(request, f'Сотрудник «{name}» успешно добавлен')

        # 2. Увольнение сотрудника
        elif action == 'dismiss_user':
            user_id = request.POST.get('user_id')
            emp = get_object_or_404(User, id=user_id)
            if emp.id != user.id:
                emp.status = 'dismissed'
                emp.save()
                messages.success(request, f'Сотрудник «{emp.name}» уволен')

        # 3. Создание новой смены
        elif action == 'add_shift':
            start = request.POST.get('start', '08:00').strip()
            end = request.POST.get('end', '20:00').strip()
            WorkShift.objects.create(start=start, end=end)
            messages.success(request, f'Смена ({start} - {end}) создана')

        # 4. Открытие смены
        elif action == 'open_shift':
            shift_id = request.POST.get('shift_id')
            shift = get_object_or_404(WorkShift, id=shift_id)
            if shift.closed:
                messages.error(request, 'Нельзя открыть уже закрытую смену')
            else:
                WorkShift.objects.filter(active=True).update(active=False)
                shift.active = True
                shift.save()
                messages.success(request, f'Смена #{shift.id} открыта')

        # 5. Закрытие смены
        elif action == 'close_shift':
            shift_id = request.POST.get('shift_id')
            shift = get_object_or_404(WorkShift, id=shift_id)
            shift.active = False
            shift.closed = True
            shift.save()
            messages.success(request, f'Смена #{shift.id} закрыта')

        # 6. Назначение сотрудника на смену
        elif action == 'assign_user':
            shift_id = request.POST.get('shift_id')
            assign_user_id = request.POST.get('user_id')
            shift = get_object_or_404(WorkShift, id=shift_id)
            emp = get_object_or_404(User, id=assign_user_id)
            shift.employees.add(emp)
            messages.success(request, f'Сотрудник {emp.name} добавлен на смену #{shift.id}')

        # 7. Снятие сотрудника со смены
        elif action == 'remove_user':
            shift_id = request.POST.get('shift_id')
            rem_user_id = request.POST.get('user_id')
            shift = get_object_or_404(WorkShift, id=shift_id)
            emp = get_object_or_404(User, id=rem_user_id)
            shift.employees.remove(emp)
            messages.success(request, f'Сотрудник {emp.name} снят со смены #{shift.id}')

        return redirect('admin_dashboard')

    # Загружаем данные для шаблона
    employees = User.objects.all().order_by('id')
    active_employees = User.objects.filter(status='active')
    shifts = WorkShift.objects.all().order_by('-id')
    orders = Order.objects.all().order_by('-id')

    context = {
        'user': user,
        'employees': employees,
        'active_employees': active_employees,
        'shifts': shifts,
        'orders': orders,
        'roles': Role.objects.all(),
    }
    return render(request, 'cafe/admin_dashboard.html', context)


# ==========================================
# 3. Панель Официанта
# ==========================================

def waiter_dashboard_view(request):
    """
    Панель официанта: создание заказов, добавление блюд, расчет и отмена.
    """
    user = get_session_user(request)
    if not user or user.role_id != 2:
        messages.error(request, 'Доступ открыт только для официантов')
        return redirect('login')

    if request.method == 'POST':
        action = request.POST.get('action')

        # 1. Создание нового заказа
        if action == 'create_order':
            table = request.POST.get('table', '').strip()
            item_name = request.POST.get('item_name', '').strip()
            item_price = int(request.POST.get('item_price', 0))
            item_count = int(request.POST.get('item_count', 1))

            if not table or not item_name:
                messages.error(request, 'Заполните столик и название первого блюда')
            else:
                active_shift = WorkShift.objects.filter(active=True).first()
                order = Order.objects.create(table=table, status=1, shift=active_shift)
                OrderPosition.objects.create(
                    order=order,
                    name=item_name,
                    price=item_price,
                    count=item_count
                )
                order.recalculate_price()
                messages.success(request, f'Заказ #{order.id} на {table} успешно создан!')

        # 2. Добавление блюда в существующий заказ
        elif action == 'add_position':
            order_id = request.POST.get('order_id')
            name = request.POST.get('name', '').strip()
            price = int(request.POST.get('price', 0))
            count = int(request.POST.get('count', 1))

            order = get_object_or_404(Order, id=order_id)
            if name:
                OrderPosition.objects.create(order=order, name=name, price=price, count=count)
                order.recalculate_price()
                messages.success(request, f'Блюдо «{name}» добавлено в заказ #{order.id}')

        # 3. Удаление блюда из заказа
        elif action == 'remove_position':
            pos_id = request.POST.get('position_id')
            pos = get_object_or_404(OrderPosition, id=pos_id)
            order = pos.order
            pos.delete()
            order.recalculate_price()
            messages.success(request, 'Блюдо удалено из заказа')

        # 4. Оплата заказа (только если статус Готов / status=3)
        elif action == 'pay_order':
            order_id = request.POST.get('order_id')
            order = get_object_or_404(Order, id=order_id)
            if order.status != 3:
                messages.error(request, 'Оплатить можно только готовый к выдаче заказ')
            else:
                order.status = 4  # Оплачен
                order.save()
                messages.success(request, f'Заказ #{order.id} успешно оплачен и закрыт!')

        # 5. Отмена заказа
        elif action == 'cancel_order':
            order_id = request.POST.get('order_id')
            order = get_object_or_404(Order, id=order_id)
            order.status = 5  # Отменен
            order.save()
            messages.success(request, f'Заказ #{order.id} отменен')

        return redirect('waiter_dashboard')

    orders = Order.objects.all().order_by('-id')
    active_shift = WorkShift.objects.filter(active=True).first()

    context = {
        'user': user,
        'orders': orders,
        'active_shift': active_shift
    }
    return render(request, 'cafe/waiter_dashboard.html', context)


# ==========================================
# 4. Панель Повара (Кухня)
# ==========================================

def cook_dashboard_view(request):
    """
    Панель повара: просмотр заказов кухни и смена статусов («Принят» ➔ «Готовится» ➔ «Готов»).
    """
    user = get_session_user(request)
    if not user or user.role_id != 3:
        messages.error(request, 'Доступ открыт только для поваров')
        return redirect('login')

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'set_status':
            order_id = request.POST.get('order_id')
            next_status = int(request.POST.get('status', 1))
            order = get_object_or_404(Order, id=order_id)
            order.status = next_status
            order.save()
            messages.success(request, f'Статус заказа #{order.id} обновлен')

        return redirect('cook_dashboard')

    # Повар видит только активные кухонные заказы: 1 (Принят), 2 (Готовится), 3 (Готов)
    kitchen_orders = Order.objects.filter(status__in=[1, 2, 3]).order_by('id')

    context = {
        'user': user,
        'kitchen_orders': kitchen_orders
    }
    return render(request, 'cafe/cook_dashboard.html', context)
