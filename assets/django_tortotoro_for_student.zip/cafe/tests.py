from django.test import TestCase, Client
from django.urls import reverse
from cafe.models import Role, User, WorkShift, Order, OrderPosition


class CafeSSRTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.r_admin = Role.objects.create(id=1, name='Администратор')
        self.r_waiter = Role.objects.create(id=2, name='Официант')
        self.r_cook = Role.objects.create(id=3, name='Повар')

        self.u_admin = User.objects.create(name='Админ', login='admin', password='123', role=self.r_admin)
        self.u_waiter = User.objects.create(name='Официант', login='waiter1', password='123', role=self.r_waiter)
        self.u_cook = User.objects.create(name='Повар', login='cook1', password='123', role=self.r_cook)

        self.shift = WorkShift.objects.create(start='08:00', end='20:00', active=True)
        self.shift.employees.add(self.u_waiter, self.u_cook)

    def test_login_flow(self):
        # 1. GET login page
        res = self.client.get(reverse('login'))
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'Вход в систему')

        # 2. POST valid admin login -> redirects to admin panel
        res_post = self.client.post(reverse('login'), {'login': 'admin', 'password': '123'})
        self.assertRedirects(res_post, reverse('admin_dashboard'))

        # 3. Verify session
        self.assertEqual(self.client.session['user_id'], self.u_admin.id)

    def test_admin_dashboard_actions(self):
        # Login as admin in session
        session = self.client.session
        session['user_id'] = self.u_admin.id
        session.save()

        # View dashboard
        res = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'Панель Администратора')

        # Add employee
        res_add = self.client.post(reverse('admin_dashboard'), {
            'action': 'add_user',
            'name': 'Новый Повар',
            'login': 'cook_new',
            'password': 'password123',
            'role_id': '3'
        })
        self.assertRedirects(res_add, reverse('admin_dashboard'))
        self.assertTrue(User.objects.filter(login='cook_new').exists())

    def test_waiter_dashboard_flow(self):
        # Login as waiter
        session = self.client.session
        session['user_id'] = self.u_waiter.id
        session.save()

        # View waiter panel
        res = self.client.get(reverse('waiter_dashboard'))
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'Панель Официанта')

        # Create order
        res_order = self.client.post(reverse('waiter_dashboard'), {
            'action': 'create_order',
            'table': 'Столик #10',
            'item_name': 'Латте',
            'item_price': '180',
            'item_count': '2'
        })
        self.assertRedirects(res_order, reverse('waiter_dashboard'))
        order = Order.objects.get(table='Столик #10')
        self.assertEqual(order.price, 360)
        self.assertEqual(order.status, 1)

    def test_cook_dashboard_flow(self):
        # Create order
        order = Order.objects.create(table='Столик #2', status=1, shift=self.shift)
        OrderPosition.objects.create(order=order, name='Суп', price=200, count=1)

        # Login as cook
        session = self.client.session
        session['user_id'] = self.u_cook.id
        session.save()

        # View cook panel
        res = self.client.get(reverse('cook_dashboard'))
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'Панель Повара (Кухня)')

        # Change status 1 -> 2 (Готовится)
        res_status = self.client.post(reverse('cook_dashboard'), {
            'action': 'set_status',
            'order_id': order.id,
            'status': '2'
        })
        self.assertRedirects(res_status, reverse('cook_dashboard'))
        order.refresh_from_db()
        self.assertEqual(order.status, 2)
