from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('admin-panel/', views.admin_dashboard_view, name='admin_dashboard'),
    path('waiter/', views.waiter_dashboard_view, name='waiter_dashboard'),
    path('cook/', views.cook_dashboard_view, name='cook_dashboard'),
]
