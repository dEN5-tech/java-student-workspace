from django.contrib import admin
from .models import Role, User, WorkShift, Order, OrderPosition

admin.site.register(Role)
admin.site.register(User)
admin.site.register(WorkShift)
admin.site.register(Order)
admin.site.register(OrderPosition)
