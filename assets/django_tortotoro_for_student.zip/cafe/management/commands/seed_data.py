from django.core.management.base import BaseCommand
from cafe.models import Role, User, WorkShift, Order, OrderPosition


class Command(BaseCommand):
    help = 'Заполняет базу данных тестовыми данными для демонстрации и экзамена'

    def handle(self, *args, **options):
        r_admin, _ = Role.objects.get_or_create(id=1, defaults={'name': 'Администратор'})
        r_waiter, _ = Role.objects.get_or_create(id=2, defaults={'name': 'Официант'})
        r_cook, _ = Role.objects.get_or_create(id=3, defaults={'name': 'Повар'})

        u_admin, _ = User.objects.get_or_create(
            login='admin',
            defaults={
                'name': 'Главный Администратор',
                'password': 'admin123',
                'role': r_admin,
                'status': 'active'
            }
        )
        u_waiter, _ = User.objects.get_or_create(
            login='waiter1',
            defaults={
                'name': 'Сергей Волков',
                'password': 'waiter123',
                'role': r_waiter,
                'status': 'active'
            }
        )
        u_cook, _ = User.objects.get_or_create(
            login='cook1',
            defaults={
                'name': 'Анна Смирнова',
                'password': 'cook123',
                'role': r_cook,
                'status': 'active'
            }
        )

        shift, _ = WorkShift.objects.get_or_create(
            id=1,
            defaults={
                'start': '08:00',
                'end': '20:00',
                'active': True,
                'closed': False
            }
        )
        shift.employees.add(u_waiter, u_cook)

        if not Order.objects.exists():
            order1 = Order.objects.create(table='Столик №1', status=1, shift=shift)
            OrderPosition.objects.create(order=order1, name='Чизкейк Нью-Йорк', price=220, count=1)
            OrderPosition.objects.create(order=order1, name='Эспрессо', price=150, count=1)
            order1.recalculate_price()

            order2 = Order.objects.create(table='Столик №3', status=2, shift=shift)
            OrderPosition.objects.create(order=order2, name='Капучино Большой', price=220, count=2)
            OrderPosition.objects.create(order=order2, name='Круассан с шоколадом', price=160, count=2)
            order2.recalculate_price()

        self.stdout.write(self.style.SUCCESS('[OK] Baza dannyh uspeshno zapolnena!'))
