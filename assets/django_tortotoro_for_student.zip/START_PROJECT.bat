@echo off
chcp 65001 >nul
title Кафе «Tortotoro» — Django Monolith SSR
echo ===================================================
echo   Кафе «Tortotoro» — Информационная система (Django SSR)
echo ===================================================
echo.
echo [1/2] Проверка миграций базы данных...
python manage.py migrate --noinput
python manage.py seed_data

echo.
echo [2/2] Запуск Django сервера на http://127.0.0.1:8000 ...
start http://127.0.0.1:8000
python manage.py runserver 127.0.0.1:8000
pause
