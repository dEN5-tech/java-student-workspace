import json
from django.test import TestCase, Client
from .models import Role, User, WorkShift, Order, OrderPosition


class TortotoroApiTestCase(TestCase):
    def setUp(self):
        self.client = Client()

        # Создание ролей
        self.role_admin = Role.objects.create(id=1, name='Администратор')
        self.role_waiter = Role.objects.create(id=2, name='Официант')
        self.role_cook = Role.objects.create(id=3, name='Повар')

        # Создание пользователей
        self.admin = User.objects.create(
            name='Главный Администратор',
            login='admin',
            password='admin123',
            role=self.role_admin,
            status='active'
        )
        self.waiter = User.objects.create(
            name='Сергей Волков',
            login='waiter1',
            password='waiter123',
            role=self.role_waiter,
            status='active'
        )
        self.cook = User.objects.create(
            name='Анна Смирнова',
            login='cook1',
            password='cook123',
            role=self.role_cook,
            status='active'
        )

    def test_cors_preflight(self):
        """Проверка CORS preflight (OPTIONS) запроса"""
        response = self.client.options('/api/login')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers.get('Access-Control-Allow-Origin'), '*')
        self.assertIn('POST', response.headers.get('Access-Control-Allow-Methods'))

    def test_login_success_and_current_user(self):
        """Проверка успешной авторизации и получения текущего профиля"""
        # 1. Логин админа
        res = self.client.post('/api/login', data=json.dumps({
            'login': 'admin',
            'password': 'admin123'
        }), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn('token', data['data'])
        self.assertEqual(data['data']['user']['login'], 'admin')
        self.assertEqual(data['data']['user']['role_id'], 1)
        token = data['data']['token']

        # 2. Получение текущего пользователя через Bearer token
        res_user = self.client.get('/api/user', HTTP_AUTHORIZATION=f'Bearer {token}')
        self.assertEqual(res_user.status_code, 200)
        user_data = res_user.json()['data']
        self.assertEqual(user_data['name'], 'Главный Администратор')
        self.assertEqual(user_data['role_id'], 1)

        # 3. Выход из системы
        res_logout = self.client.get('/api/logout', HTTP_AUTHORIZATION=f'Bearer {token}')
        self.assertEqual(res_logout.status_code, 200)

        # 4. Проверка, что после логаута старый токен невалиден
        res_after_logout = self.client.get('/api/user', HTTP_AUTHORIZATION=f'Bearer {token}')
        self.assertEqual(res_after_logout.status_code, 401)

    def test_login_failure(self):
        """Проверка неверного пароля и несуществующего логина"""
        res_wrong_pass = self.client.post('/api/login', data=json.dumps({
            'login': 'admin',
            'password': 'wrong_password'
        }), content_type='application/json')
        self.assertEqual(res_wrong_pass.status_code, 401)

        res_wrong_user = self.client.post('/api/login', data=json.dumps({
            'login': 'non_existent',
            'password': '123'
        }), content_type='application/json')
        self.assertEqual(res_wrong_user.status_code, 401)

    def test_employees_crud_and_dismiss(self):
        """Проверка работы с сотрудниками: список, создание, увольнение"""
        # 1. Список пользователей
        res = self.client.get('/api/users')
        self.assertEqual(res.status_code, 200)
        users = res.json()['data']
        self.assertEqual(len(users), 3)

        # 2. Создание нового сотрудника
        res_create = self.client.post('/api/users', data=json.dumps({
            'name': 'Иван Петров',
            'login': 'ivan_waiter',
            'password': 'password123',
            'role_id': 2
        }), content_type='application/json')
        self.assertEqual(res_create.status_code, 201)
        new_emp = res_create.json()['data']
        self.assertEqual(new_emp['login'], 'ivan_waiter')
        self.assertEqual(new_emp['role_id'], 2)
        new_id = new_emp['id']

        # 3. Попытка создать дубликат логина
        res_dup = self.client.post('/api/users', data=json.dumps({
            'name': 'Другой Иван',
            'login': 'ivan_waiter',
            'password': 'pass',
            'role_id': 2
        }), content_type='application/json')
        self.assertEqual(res_dup.status_code, 400)

        # 4. Увольнение сотрудника
        res_dismiss = self.client.delete(f'/api/users/{new_id}')
        self.assertEqual(res_dismiss.status_code, 200)
        dismissed_user = User.objects.get(id=new_id)
        self.assertEqual(dismissed_user.status, 'dismissed')

        # 5. Уволенный не может войти в систему
        res_login_dismissed = self.client.post('/api/login', data=json.dumps({
            'login': 'ivan_waiter',
            'password': 'password123'
        }), content_type='application/json')
        self.assertEqual(res_login_dismissed.status_code, 403)

    def test_work_shifts_lifecycle(self):
        """Проверка жизненного цикла смен: создание, открытие, назначение, снятие, закрытие"""
        # 1. Создание смены
        res_create = self.client.post('/api/work-shifts', data=json.dumps({
            'start': '09:00',
            'end': '21:00'
        }), content_type='application/json')
        self.assertEqual(res_create.status_code, 201)
        shift_id = res_create.json()['data']['id']

        # 2. Назначение сотрудника на смену
        res_assign = self.client.post(f'/api/work-shifts/{shift_id}/user', data=json.dumps({
            'user_id': self.waiter.id
        }), content_type='application/json')
        self.assertEqual(res_assign.status_code, 200)
        self.assertEqual(len(res_assign.json()['data']['employees']), 1)

        # 3. Открытие смены
        res_open = self.client.get(f'/api/work-shifts/{shift_id}/open')
        self.assertEqual(res_open.status_code, 200)
        self.assertTrue(res_open.json()['data']['active'])
        self.assertFalse(res_open.json()['data']['closed'])

        # 4. Снятие сотрудника со смены
        res_unassign = self.client.delete(f'/api/work-shifts/{shift_id}/user/{self.waiter.id}')
        self.assertEqual(res_unassign.status_code, 200)
        self.assertEqual(len(res_unassign.json()['data']['employees']), 0)

        # 5. Закрытие смены
        res_close = self.client.get(f'/api/work-shifts/{shift_id}/close')
        self.assertEqual(res_close.status_code, 200)
        self.assertFalse(res_close.json()['data']['active'])
        self.assertTrue(res_close.json()['data']['closed'])

        # 6. Попытка повторно открыть закрытую смену
        res_reopen = self.client.get(f'/api/work-shifts/{shift_id}/open')
        self.assertEqual(res_reopen.status_code, 400)

    def test_orders_full_flow(self):
        """Проверка работы с заказами: создание, позиции, расчет суммы, смена статусов"""
        # 1. Создание заказа
        res_order = self.client.post('/api/orders', data=json.dumps({
            'table': 'Столик №5',
            'items': [
                {'name': 'Капучино', 'price': 200, 'count': 2},
                {'name': 'Тирамису', 'price': 250, 'count': 1}
            ]
        }), content_type='application/json')
        self.assertEqual(res_order.status_code, 201)
        order_data = res_order.json()['data']
        order_id = order_data['id']
        # 200*2 + 250*1 = 650
        self.assertEqual(order_data['price'], 650)
        self.assertEqual(len(order_data['positions']), 2)
        self.assertEqual(order_data['status'], 1)

        # 2. Добавление новой позиции в заказ
        res_pos = self.client.post(f'/api/orders/{order_id}/position', data=json.dumps({
            'name': 'Лимонад',
            'price': 150,
            'count': 1
        }), content_type='application/json')
        self.assertEqual(res_pos.status_code, 201)
        # Сумма: 650 + 150 = 800
        self.assertEqual(res_pos.json()['data']['price'], 800)
        pos_id = res_pos.json()['data']['positions'][-1]['id']

        # 3. Удаление добавленной позиции
        res_del_pos = self.client.delete(f'/api/orders/{order_id}/position/{pos_id}')
        self.assertEqual(res_del_pos.status_code, 200)
        # Сумма вернулась к 650
        self.assertEqual(res_del_pos.json()['data']['price'], 650)

        # 4. Смена статуса: 1 -> 2 (Готовится)
        res_st2 = self.client.patch(f'/api/orders/{order_id}/status', data=json.dumps({
            'status': 2
        }), content_type='application/json')
        self.assertEqual(res_st2.status_code, 200)
        self.assertEqual(res_st2.json()['data']['status'], 2)

        # 5. Смена статуса: 2 -> 3 (Готов)
        res_st3 = self.client.patch(f'/api/orders/{order_id}/status', data=json.dumps({
            'status': 3
        }), content_type='application/json')
        self.assertEqual(res_st3.status_code, 200)
        self.assertEqual(res_st3.json()['data']['status'], 3)

        # 6. Оплата заказа: 3 -> 4 (Оплачен)
        res_st4 = self.client.patch(f'/api/orders/{order_id}/status', data=json.dumps({
            'status': 4
        }), content_type='application/json')
        self.assertEqual(res_st4.status_code, 200)
        self.assertEqual(res_st4.json()['data']['status'], 4)

        # 7. Проверка общего списка заказов
        res_all_orders = self.client.get('/api/orders')
        self.assertEqual(res_all_orders.status_code, 200)
        self.assertTrue(len(res_all_orders.json()['data']) >= 1)
