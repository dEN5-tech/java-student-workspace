from django.http import HttpResponse


class SimpleCorsMiddleware:
    """
    Простой и надежный middleware для автоматической обработки CORS запросов
    (включая OPTIONS preflight) от Vue.js / SPA фронтенда.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Обработка preflight запроса OPTIONS
        if request.method == 'OPTIONS':
            response = HttpResponse()
            response['Access-Control-Allow-Origin'] = '*'
            response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With'
            response['Access-Control-Max-Age'] = '86400'
            return response

        response = self.get_response(request)
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With'
        return response
