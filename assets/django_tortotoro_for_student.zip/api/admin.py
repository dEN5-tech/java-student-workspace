from django.contrib import admin
from .models import Role, User, WorkShift, Order, OrderPosition


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    ordering = ('id',)


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'login', 'role', 'status')
    list_filter = ('role', 'status')
    search_fields = ('name', 'login')


class OrderPositionInline(admin.TabularInline):
    model = OrderPosition
    extra = 1


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'table', 'status', 'price', 'shift', 'created_at')
    list_filter = ('status', 'shift')
    search_fields = ('table',)
    inlines = [OrderPositionInline]


@admin.register(WorkShift)
class WorkShiftAdmin(admin.ModelAdmin):
    list_display = ('id', 'start', 'end', 'active', 'closed')
    list_filter = ('active', 'closed')


@admin.register(OrderPosition)
class OrderPositionAdmin(admin.ModelAdmin):
    list_display = ('id', 'order', 'name', 'price', 'count')
