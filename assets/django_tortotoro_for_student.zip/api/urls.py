from django.urls import path
from . import views

urlpatterns = [
    # 1. Авторизация и профиль
    path('login', views.login_view, name='login'),
    path('user', views.current_user_view, name='current_user'),
    path('logout', views.logout_view, name='logout'),

    # 2. Сотрудники
    path('users', views.users_view, name='users'),
    path('users/<int:user_id>', views.dismiss_user_view, name='dismiss_user'),

    # 3. Рабочие смены
    path('work-shifts', views.work_shifts_view, name='work_shifts'),
    path('work-shifts/<int:shift_id>/open', views.open_shift_view, name='open_shift'),
    path('work-shifts/<int:shift_id>/close', views.close_shift_view, name='close_shift'),
    path('work-shifts/<int:shift_id>/user', views.add_user_to_shift_view, name='add_user_to_shift'),
    path('work-shifts/<int:shift_id>/user/<int:user_id>', views.remove_user_from_shift_view, name='remove_user_from_shift'),

    # 4. Заказы
    path('orders', views.orders_view, name='orders'),
    path('orders/<int:order_id>/position', views.order_add_position_view, name='order_add_position'),
    path('orders/<int:order_id>/position/<int:pos_id>', views.order_remove_position_view, name='order_remove_position'),
    path('orders/<int:order_id>/status', views.order_change_status_view, name='order_change_status'),
]
