from django.core.management.base import BaseCommand
from api.models import Role, User, WorkShift, Order, OrderPosition


class Command(BaseCommand):
    help = 'Заполняет базу данных начальными данными для кафе «Tortotoro»'

    def handle(self, *args, **kwargs):
        self.stdout.write("Создание ролей...")
        role_admin, _ = Role.objects.get_or_create(id=1, defaults={'name': 'Администратор'})
        role_waiter, _ = Role.objects.get_or_create(id=2, defaults={'name': 'Официант'})
        role_cook, _ = Role.objects.get_or_create(id=3, defaults={'name': 'Повар'})

        self.stdout.write("Создание стандартных пользователей...")
        admin_user, _ = User.objects.get_or_create(
            login='admin',
            defaults={
                'name': 'Главный Администратор',
                'password': 'admin123',
                'role': role_admin,
                'status': 'active'
            }
        )
        waiter_user, _ = User.objects.get_or_create(
            login='waiter1',
            defaults={
                'name': 'Сергей Волков',
                'password': 'waiter123',
                'role': role_waiter,
                'status': 'active'
            }
        )
        cook_user, _ = User.objects.get_or_create(
            login='cook1',
            defaults={
                'name': 'Анна Смирнова',
                'password': 'cook123',
                'role': role_cook,
                'status': 'active'
            }
        )

        self.stdout.write("Создание тестовой рабочей смены...")
        shift, created = WorkShift.objects.get_or_create(
            id=1,
            defaults={
                'start': '08:00',
                'end': '20:00',
                'active': True,
                'closed': False
            }
        )
        shift.employees.add(waiter_user, cook_user)

        self.stdout.write("Создание тестовых заказов...")
        if not Order.objects.exists():
            # Заказ 1: Новый (Принят)
            order1 = Order.objects.create(
                table='Столик №1',
                status=1,
                price=0,
                shift=shift
            )
            OrderPosition.objects.create(order=order1, name='Чизкейк Нью-Йорк', price=220, count=1)
            OrderPosition.objects.create(order=order1, name='Эспрессо', price=150, count=1)
            order1.recalculate_price()

            # Заказ 2: На кухне (Готовится)
            order2 = Order.objects.create(
                table='Столик №3',
                status=2,
                price=0,
                shift=shift
            )
            OrderPosition.objects.create(order=order2, name='Капучино Большой', price=220, count=2)
            OrderPosition.objects.create(order=order2, name='Круассан с шоколадом', price=160, count=2)
            order2.recalculate_price()

        self.stdout.write(self.style.SUCCESS("[OK] База данных успешно заполнена начальными данными!"))
