from django.db import models


class Role(models.Model):
    """
    Роли сотрудников:
    1 - Администратор
    2 - Официант
    3 - Повар
    """
    name = models.CharField(max_length=50, verbose_name="Название роли")

    def __str__(self):
        return f"{self.id} - {self.name}"


class User(models.Model):
    """
    Модель сотрудника кафе «Tortotoro».
    """
    STATUS_CHOICES = [
        ('active', 'Работает'),
        ('dismissed', 'Уволен'),
    ]

    name = models.CharField(max_length=150, verbose_name="ФИО сотрудника")
    login = models.CharField(max_length=100, unique=True, verbose_name="Логин")
    password = models.CharField(max_length=128, verbose_name="Пароль")
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='users', verbose_name="Роль")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active', verbose_name="Статус")
    token = models.CharField(max_length=128, null=True, blank=True, verbose_name="API Токен")

    def __str__(self):
        return f"{self.name} ({self.login}) - {self.role.name if self.role else 'Без роли'}"

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'login': self.login,
            'role_id': self.role_id,
            'role': self.role.name if self.role else '',
            'status': self.status
        }


class WorkShift(models.Model):
    """
    Модель рабочей смены.
    """
    start = models.CharField(max_length=10, default="08:00", verbose_name="Начало смены")
    end = models.CharField(max_length=10, default="20:00", verbose_name="Конец смены")
    active = models.BooleanField(default=False, verbose_name="Активна ли смена")
    closed = models.BooleanField(default=False, verbose_name="Закрыта ли смена")
    employees = models.ManyToManyField(User, blank=True, related_name='shifts', verbose_name="Сотрудники смены")

    def __str__(self):
        status_text = "Закрыта" if self.closed else ("Открыта" if self.active else "Создана")
        return f"Смена #{self.id} ({self.start} - {self.end}) [{status_text}]"

    def to_dict(self):
        return {
            'id': self.id,
            'start': self.start,
            'end': self.end,
            'active': self.active,
            'closed': self.closed,
            'employees': [
                {
                    'id': emp.id,
                    'name': emp.name,
                    'login': emp.login,
                    'role_id': emp.role_id,
                    'role': emp.role.name if emp.role else ''
                }
                for emp in self.employees.all()
            ]
        }


class Order(models.Model):
    """
    Модель заказа столика.
    Статусы:
    1 - Принят
    2 - Готовится (Повар)
    3 - Готов (Повар)
    4 - Оплачен (Официант)
    5 - Отменен (Официант / Администратор)
    """
    STATUS_CHOICES = [
        (1, 'Принят'),
        (2, 'Готовится'),
        (3, 'Готов'),
        (4, 'Оплачен'),
        (5, 'Отменен'),
    ]

    table = models.CharField(max_length=100, verbose_name="Столик / Место")
    status = models.IntegerField(choices=STATUS_CHOICES, default=1, verbose_name="Статус заказа")
    price = models.IntegerField(default=0, verbose_name="Общая сумма (руб)")
    shift = models.ForeignKey(WorkShift, on_delete=models.SET_NULL, null=True, blank=True, related_name='orders', verbose_name="Смена")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")

    def __str__(self):
        return f"Заказ #{self.id} ({self.table}) - статус {self.status} ({self.price} руб)"

    def recalculate_price(self):
        total = sum(item.price * item.count for item in self.positions.all())
        self.price = total
        self.save()
        return total

    def to_dict(self):
        return {
            'id': self.id,
            'table': self.table,
            'status': self.status,
            'price': self.price,
            'shift_id': self.shift_id,
            'positions': [
                {
                    'id': pos.id,
                    'name': pos.name,
                    'price': pos.price,
                    'count': pos.count
                }
                for pos in self.positions.all()
            ]
        }


class OrderPosition(models.Model):
    """
    Позиция (блюдо/напиток) внутри заказа.
    """
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='positions', verbose_name="Заказ")
    name = models.CharField(max_length=150, verbose_name="Наименование позиции")
    price = models.IntegerField(default=0, verbose_name="Цена за единицу (руб)")
    count = models.IntegerField(default=1, verbose_name="Количество")

    def __str__(self):
        return f"{self.name} x{self.count} ({self.price * self.count} руб) в заказе #{self.order_id}"
