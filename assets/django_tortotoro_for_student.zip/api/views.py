import json
import uuid
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Role, User, WorkShift, Order, OrderPosition


def parse_json_body(request):
    """
    Вспомогательная функция для безопасного разбора JSON из тела запроса.
    """
    if not request.body:
        return {}
    try:
        return json.loads(request.body.decode('utf-8'))
    except Exception:
        return {}


def get_auth_user(request):
    """
    Извлекает токен из заголовка Authorization: Bearer <token>
    и находит активного пользователя.
    """
    auth_header = request.headers.get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        return None
    token = auth_header.split(' ', 1)[1].strip()
    if not token:
        return None
    try:
        return User.objects.get(token=token, status='active')
    except User.DoesNotExist:
        return None


# ==========================================
# 1. Авторизация и профиль
# ==========================================

@csrf_exempt
def login_view(request):
    """
    POST /api/login
    Авторизация пользователя по логину и паролю.
    """
    if request.method != 'POST':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    data = parse_json_body(request)
    login = data.get('login', '').strip()
    password = data.get('password', '').strip()

    if not login or not password:
        return JsonResponse({'message': 'Логин и пароль обязательны'}, status=400)

    try:
        user = User.objects.get(login=login, password=password)
    except User.DoesNotExist:
        return JsonResponse({'message': 'Неверный логин или пароль'}, status=401)

    if user.status == 'dismissed':
        return JsonResponse({'message': 'Учетная запись сотрудника заблокирована (уволен)'}, status=403)

    # Генерируем новый токен авторизации
    user.token = uuid.uuid4().hex
    user.save()

    return JsonResponse({
        'data': {
          'token': user.token,
          'user': user.to_dict()
        }
    }, status=200)


@csrf_exempt
def current_user_view(request):
    """
    GET /api/user
    Получение данных текущего авторизованного пользователя.
    """
    if request.method != 'GET':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    user = get_auth_user(request)
    if not user:
        return JsonResponse({'message': 'Не авторизован'}, status=401)

    return JsonResponse({
        'data': user.to_dict()
    }, status=200)


@csrf_exempt
def logout_view(request):
    """
    GET /api/logout
    Выход из системы (сброс токена).
    """
    if request.method != 'GET':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    user = get_auth_user(request)
    if user:
        user.token = None
        user.save()

    return JsonResponse({
        'data': {
            'message': 'Успешный выход из системы'
        }
    }, status=200)


# ==========================================
# 2. Сотрудники (Администратор)
# ==========================================

@csrf_exempt
def users_view(request):
    """
    GET /api/users -> Список всех сотрудников
    POST /api/users -> Создание нового сотрудника
    """
    if request.method == 'GET':
        users = User.objects.all().order_by('id')
        return JsonResponse({
            'data': [u.to_dict() for u in users]
        }, status=200)

    elif request.method == 'POST':
        data = parse_json_body(request)
        name = data.get('name', '').strip()
        login = data.get('login', '').strip()
        password = data.get('password', '').strip()
        role_id = data.get('role_id', 2)

        if not name or not login or not password:
            return JsonResponse({'message': 'Заполните все обязательные поля (ФИО, логин, пароль)'}, status=400)

        if User.objects.filter(login=login).exists():
            return JsonResponse({'message': 'Сотрудник с таким логином уже существует'}, status=400)

        try:
            role = Role.objects.get(id=role_id)
        except Role.DoesNotExist:
            role = Role.objects.first()

        new_user = User.objects.create(
            name=name,
            login=login,
            password=password,
            role=role,
            status='active'
        )

        return JsonResponse({
            'data': new_user.to_dict()
        }, status=201)

    return JsonResponse({'message': 'Метод не поддерживается'}, status=405)


@csrf_exempt
def dismiss_user_view(request, user_id):
    """
    DELETE /api/users/<user_id>
    Увольнение сотрудника (перевод в статус dismissed).
    """
    if request.method != 'DELETE':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return JsonResponse({'message': 'Сотрудник не найден'}, status=404)

    user.status = 'dismissed'
    user.token = None
    user.save()

    return JsonResponse({
        'data': {
            'message': 'Сотрудник успешно уволен',
            'user': user.to_dict()
        }
    }, status=200)


# ==========================================
# 3. Рабочие смены (Администратор)
# ==========================================

@csrf_exempt
def work_shifts_view(request):
    """
    GET /api/work-shifts -> Список смен
    POST /api/work-shifts -> Создать смену
    """
    if request.method == 'GET':
        shifts = WorkShift.objects.all().order_by('id')
        return JsonResponse({
            'data': [s.to_dict() for s in shifts]
        }, status=200)

    elif request.method == 'POST':
        data = parse_json_body(request)
        start = data.get('start', '08:00').strip()
        end = data.get('end', '20:00').strip()

        if not start or not end:
            return JsonResponse({'message': 'Укажите время начала и окончания смены'}, status=400)

        shift = WorkShift.objects.create(
            start=start,
            end=end,
            active=False,
            closed=False
        )

        return JsonResponse({
            'data': shift.to_dict()
        }, status=201)

    return JsonResponse({'message': 'Метод не поддерживается'}, status=405)


@csrf_exempt
def open_shift_view(request, shift_id):
    """
    GET /api/work-shifts/<shift_id>/open
    Открыть смену для работы.
    """
    if request.method != 'GET':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        shift = WorkShift.objects.get(id=shift_id)
    except WorkShift.DoesNotExist:
        return JsonResponse({'message': 'Смена не найдена'}, status=404)

    if shift.closed:
        return JsonResponse({'message': 'Нельзя открыть завершенную (закрытую) смену'}, status=400)

    # Делаем активной только эту смену
    WorkShift.objects.filter(active=True).update(active=False)
    shift.active = True
    shift.closed = False
    shift.save()

    return JsonResponse({
        'data': shift.to_dict()
    }, status=200)


@csrf_exempt
def close_shift_view(request, shift_id):
    """
    GET /api/work-shifts/<shift_id>/close
    Закрыть смену.
    """
    if request.method != 'GET':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        shift = WorkShift.objects.get(id=shift_id)
    except WorkShift.DoesNotExist:
        return JsonResponse({'message': 'Смена не найдена'}, status=404)

    shift.active = False
    shift.closed = True
    shift.save()

    return JsonResponse({
        'data': shift.to_dict()
    }, status=200)


@csrf_exempt
def add_user_to_shift_view(request, shift_id):
    """
    POST /api/work-shifts/<shift_id>/user
    Назначить сотрудника на смену.
    """
    if request.method != 'POST':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        shift = WorkShift.objects.get(id=shift_id)
    except WorkShift.DoesNotExist:
        return JsonResponse({'message': 'Смена не найдена'}, status=404)

    data = parse_json_body(request)
    user_id = data.get('user_id')
    if not user_id:
        return JsonResponse({'message': 'Параметр user_id обязателен'}, status=400)

    try:
        user = User.objects.get(id=user_id, status='active')
    except User.DoesNotExist:
        return JsonResponse({'message': 'Сотрудник не найден или уволен'}, status=404)

    shift.employees.add(user)

    return JsonResponse({
        'data': shift.to_dict()
    }, status=200)


@csrf_exempt
def remove_user_from_shift_view(request, shift_id, user_id):
    """
    DELETE /api/work-shifts/<shift_id>/user/<user_id>
    Снять сотрудника со смены.
    """
    if request.method != 'DELETE':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        shift = WorkShift.objects.get(id=shift_id)
        user = User.objects.get(id=user_id)
    except (WorkShift.DoesNotExist, User.DoesNotExist):
        return JsonResponse({'message': 'Смена или сотрудник не найдены'}, status=404)

    shift.employees.remove(user)

    return JsonResponse({
        'data': shift.to_dict()
    }, status=200)


# ==========================================
# 4. Заказы (Официант, Повар, Администратор)
# ==========================================

@csrf_exempt
def orders_view(request):
    """
    GET /api/orders -> Список всех заказов
    POST /api/orders -> Создать новый заказ
    """
    if request.method == 'GET':
        orders = Order.objects.all().order_by('-id')
        return JsonResponse({
            'data': [o.to_dict() for o in orders]
        }, status=200)

    elif request.method == 'POST':
        data = parse_json_body(request)
        table = data.get('table', '').strip()
        items = data.get('items', [])

        if not table:
            return JsonResponse({'message': 'Укажите столик'}, status=400)

        # Привязываем заказ к текущей активной смене (если есть)
        active_shift = WorkShift.objects.filter(active=True).first()

        order = Order.objects.create(
            table=table,
            status=1,  # 1 = Принят
            price=0,
            shift=active_shift
        )

        for item in items:
            name = item.get('name', '').strip()
            price = int(item.get('price', 0))
            count = int(item.get('count', 1))
            if name:
                OrderPosition.objects.create(
                    order=order,
                    name=name,
                    price=price,
                    count=count
                )

        order.recalculate_price()

        return JsonResponse({
            'data': order.to_dict()
        }, status=201)

    return JsonResponse({'message': 'Метод не поддерживается'}, status=405)


@csrf_exempt
def order_add_position_view(request, order_id):
    """
    POST /api/orders/<order_id>/position
    Добавить блюдо в существующий заказ.
    """
    if request.method != 'POST':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        order = Order.objects.get(id=order_id)
    except Order.DoesNotExist:
        return JsonResponse({'message': 'Заказ не найден'}, status=404)

    data = parse_json_body(request)
    name = data.get('name', '').strip()
    price = int(data.get('price', 0))
    count = int(data.get('count', 1))

    if not name:
        return JsonResponse({'message': 'Укажите название позиции'}, status=400)

    OrderPosition.objects.create(
        order=order,
        name=name,
        price=price,
        count=count
    )

    order.recalculate_price()

    return JsonResponse({
        'data': order.to_dict()
    }, status=201)


@csrf_exempt
def order_remove_position_view(request, order_id, pos_id):
    """
    DELETE /api/orders/<order_id>/position/<pos_id>
    Удалить блюдо из заказа.
    """
    if request.method != 'DELETE':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        order = Order.objects.get(id=order_id)
        pos = OrderPosition.objects.get(id=pos_id, order=order)
    except (Order.DoesNotExist, OrderPosition.DoesNotExist):
        return JsonResponse({'message': 'Заказ или позиция не найдены'}, status=404)

    pos.delete()
    order.recalculate_price()

    return JsonResponse({
        'data': order.to_dict()
    }, status=200)


@csrf_exempt
def order_change_status_view(request, order_id):
    """
    PATCH /api/orders/<order_id>/status
    Изменить статус заказа:
    1 - Принят
    2 - Готовится
    3 - Готов к выдаче
    4 - Оплачен
    5 - Отменен
    """
    if request.method != 'PATCH':
        return JsonResponse({'message': 'Метод не поддерживается'}, status=405)

    try:
        order = Order.objects.get(id=order_id)
    except Order.DoesNotExist:
        return JsonResponse({'message': 'Заказ не найден'}, status=404)

    data = parse_json_body(request)
    new_status = data.get('status')

    if new_status is None:
        return JsonResponse({'message': 'Параметр status обязателен'}, status=400)

    try:
        new_status = int(new_status)
    except ValueError:
        return JsonResponse({'message': 'Неверный формат статуса'}, status=400)

    order.status = new_status
    order.save()

    return JsonResponse({
        'data': order.to_dict()
    }, status=200)
