// ==========================================================================
// BESTGAMES - МИНИМАЛЬНЫЙ JS (МОДУЛЬ А)
// Простая логика без библиотек
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  // 1. Бургер-меню
  const burger = document.querySelector('.header__burger');
  const nav = document.querySelector('.header__nav');
  if (burger && nav) {
    burger.addEventListener('click', () => nav.classList.toggle('header__nav--open'));
  }

  // 2. Слайдер с новинками (минимум 3 слайда, автосмена, кнопки, точки)
  const track = document.querySelector('.slider__track');
  const slides = document.querySelectorAll('.slider__slide');
  const dots = document.querySelectorAll('.slider__dot');
  let currentSlide = 0;

  function showSlide(idx) {
    if (!track || slides.length === 0) return;
    currentSlide = (idx + slides.length) % slides.length;
    track.style.transform = `translateX(-${currentSlide * 100}%)`;
    dots.forEach((dot, i) => dot.classList.toggle('slider__dot--active', i === currentSlide));
  }

  const prevBtn = document.querySelector('.slider__nav-btn--prev');
  const nextBtn = document.querySelector('.slider__nav-btn--next');
  if (prevBtn) prevBtn.addEventListener('click', () => showSlide(currentSlide - 1));
  if (nextBtn) nextBtn.addEventListener('click', () => showSlide(currentSlide + 1));
  dots.forEach((dot, i) => dot.addEventListener('click', () => showSlide(i)));
  if (slides.length > 0) setInterval(() => showSlide(currentSlide + 1), 5000);

  // 3. Переключение темной/светлой темы
  const themeBtn = document.querySelector('.header__theme-toggle');
  const themeSelect = document.getElementById('theme-select');
  const savedTheme = localStorage.getItem('bestgames_theme');

  if (document.body.classList.contains('theme--light') || savedTheme === 'light') {
    document.body.classList.add('theme--light');
    if (themeBtn) themeBtn.textContent = '☀️ Светлая';
    if (themeSelect) themeSelect.value = 'light';
  }

  function toggleTheme(isLight) {
    document.body.classList.toggle('theme--light', isLight);
    localStorage.setItem('bestgames_theme', isLight ? 'light' : 'dark');
    if (themeBtn) themeBtn.textContent = isLight ? '☀️ Светлая' : '🌙 Темная';
    if (themeSelect) themeSelect.value = isLight ? 'light' : 'dark';
  }

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      toggleTheme(!document.body.classList.contains('theme--light'));
    });
  }
  if (themeSelect) {
    themeSelect.addEventListener('change', (e) => toggleTheme(e.target.value === 'light'));
  }

  // 4. Быстрый поиск по жанрам
  const searchInput = document.getElementById('genreSearchInput');
  const searchBtn = document.getElementById('genreSearchBtn');
  if (searchBtn && searchInput) {
    searchBtn.addEventListener('click', () => {
      if (searchInput.value.trim()) {
        window.location.href = `catalog.html?genre=${encodeURIComponent(searchInput.value.trim())}`;
      }
    });
  }

  // 5. Фильтрация в каталоге
  const filterBtn = document.querySelector('.filter-toggle-btn');
  const filterSidebar = document.querySelector('.filter-sidebar');
  if (filterBtn && filterSidebar) {
    filterBtn.addEventListener('click', () => filterSidebar.classList.toggle('filter-sidebar--open'));
  }

  const checkboxes = document.querySelectorAll('.genre-checkbox');
  const cards = document.querySelectorAll('.catalog-game-card');
  const urlGenre = new URLSearchParams(window.location.search).get('genre');

  if (urlGenre) {
    checkboxes.forEach((cb) => {
      if (cb.value.toLowerCase() === urlGenre.toLowerCase()) cb.checked = true;
    });
  }

  function applyFilter() {
    const selected = Array.from(checkboxes).filter(c => c.checked).map(c => c.value.toLowerCase());
    cards.forEach((card) => {
      const g = (card.getAttribute('data-genre') || '').toLowerCase();
      card.style.display = (selected.length === 0 || selected.includes(g)) ? 'flex' : 'none';
    });
  }

  checkboxes.forEach(cb => cb.addEventListener('change', applyFilter));
  if (urlGenre) applyFilter();

  // 6. Переход в каталог по клику на карточку
  document.querySelectorAll('.game-card[data-link]').forEach((card) => {
    card.addEventListener('click', (e) => {
      if (!e.target.closest('a')) window.location.href = card.getAttribute('data-link');
    });
  });
});
