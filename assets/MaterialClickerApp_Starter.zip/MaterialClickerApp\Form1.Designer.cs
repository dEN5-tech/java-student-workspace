using System.Drawing;
using System.Windows.Forms;
using Material3.WinForms;
using Material3.WinForms.Controls;

namespace MaterialClickerApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Менеджер темы Material 3
        private MaterialThemeManager materialThemeManager;

        // --- Верхняя навигация и статус БД ---
        private Panel panelTopNav;
        private Label lblAppTitle;
        private Label lblDbStatus;
        private MaterialButton btnNavLogin;
        private MaterialButton btnNavRegister;

        // --- Панель 1: Авторизация (Вход) ---
        private Panel panelLogin;
        private MaterialCard cardLogin;
        private Label lblLoginTitle;
        private Label lblLoginSubtitle;
        private MaterialTextField txtLogin;
        private MaterialTextField txtPassword;
        private MaterialButton btnLoginSubmit;
        private Button btnSwitchToRegister;

        // --- Панель 2: Регистрация ---
        private Panel panelRegister;
        private MaterialCard cardRegister;
        private Label lblRegisterTitle;
        private Label lblRegisterSubtitle;
        private MaterialTextField txtRegFullName;
        private MaterialTextField txtRegLogin;
        private MaterialTextField txtRegPassword;
        private MaterialTextField txtRegPhone;
        private MaterialButton btnRegisterSubmit;
        private Button btnSwitchToLogin;

        // --- Панель 3: Личный кабинет (Успешный вход) ---
        private Panel panelWelcome;
        private MaterialCard cardWelcome;
        private Label lblWelcomeUser;
        private Label lblWelcomeInfo;
        private MaterialButton btnLogout;
        private Label lblUsersTableTitle;
        private DataGridView dgvUsers;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            materialThemeManager = new MaterialThemeManager();
            panelTopNav = new Panel();
            lblAppTitle = new Label();
            lblDbStatus = new Label();
            btnNavLogin = new MaterialButton();
            btnNavRegister = new MaterialButton();
            panelLogin = new Panel();
            cardLogin = new MaterialCard();
            lblLoginTitle = new Label();
            lblLoginSubtitle = new Label();
            txtLogin = new MaterialTextField();
            txtPassword = new MaterialTextField();
            btnLoginSubmit = new MaterialButton();
            btnSwitchToRegister = new Button();
            panelRegister = new Panel();
            cardRegister = new MaterialCard();
            lblRegisterTitle = new Label();
            lblRegisterSubtitle = new Label();
            txtRegFullName = new MaterialTextField();
            txtRegLogin = new MaterialTextField();
            txtRegPassword = new MaterialTextField();
            txtRegPhone = new MaterialTextField();
            btnRegisterSubmit = new MaterialButton();
            btnSwitchToLogin = new Button();
            panelWelcome = new Panel();
            cardWelcome = new MaterialCard();
            lblWelcomeUser = new Label();
            lblWelcomeInfo = new Label();
            btnLogout = new MaterialButton();
            lblUsersTableTitle = new Label();
            dgvUsers = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)materialThemeManager).BeginInit();
            panelTopNav.SuspendLayout();
            panelLogin.SuspendLayout();
            cardLogin.SuspendLayout();
            panelRegister.SuspendLayout();
            cardRegister.SuspendLayout();
            panelWelcome.SuspendLayout();
            cardWelcome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).BeginInit();
            SuspendLayout();
            // 
            // panelTopNav
            // 
            panelTopNav.BackColor = Color.FromArgb(243, 237, 247);
            panelTopNav.Controls.Add(btnNavRegister);
            panelTopNav.Controls.Add(btnNavLogin);
            panelTopNav.Controls.Add(lblDbStatus);
            panelTopNav.Controls.Add(lblAppTitle);
            panelTopNav.Dock = DockStyle.Top;
            panelTopNav.Location = new Point(0, 0);
            panelTopNav.Name = "panelTopNav";
            panelTopNav.Padding = new Padding(16, 8, 16, 8);
            panelTopNav.Size = new Size(760, 68);
            panelTopNav.TabIndex = 0;
            // 
            // lblAppTitle
            // 
            lblAppTitle.AutoSize = true;
            lblAppTitle.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            lblAppTitle.ForeColor = Color.FromArgb(74, 68, 88);
            lblAppTitle.Location = new Point(14, 10);
            lblAppTitle.Name = "lblAppTitle";
            lblAppTitle.Size = new Size(330, 25);
            lblAppTitle.TabIndex = 0;
            lblAppTitle.Text = "🔐 Material3 + XSD DataSet Шаблон";
            // 
            // lblDbStatus
            // 
            lblDbStatus.AutoSize = true;
            lblDbStatus.Font = new Font("Segoe UI", 8.5F);
            lblDbStatus.ForeColor = Color.FromArgb(101, 85, 143);
            lblDbStatus.Location = new Point(16, 38);
            lblDbStatus.Name = "lblDbStatus";
            lblDbStatus.Size = new Size(260, 15);
            lblDbStatus.TabIndex = 1;
            lblDbStatus.Text = "Подключение к БД: .\\SQLEXPRESS (через XSD)";
            // 
            // btnNavLogin
            // 
            btnNavLogin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnNavLogin.Location = new Point(540, 14);
            btnNavLogin.Name = "btnNavLogin";
            btnNavLogin.Size = new Size(95, 38);
            btnNavLogin.TabIndex = 2;
            btnNavLogin.Text = "Войти";
            btnNavLogin.Click += btnNavLogin_Click;
            // 
            // btnNavRegister
            // 
            btnNavRegister.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnNavRegister.Location = new Point(642, 14);
            btnNavRegister.Name = "btnNavRegister";
            btnNavRegister.Size = new Size(105, 38);
            btnNavRegister.TabIndex = 3;
            btnNavRegister.Text = "Регистрация";
            btnNavRegister.Click += btnNavRegister_Click;
            // 
            // panelLogin
            // 
            panelLogin.BackColor = Color.FromArgb(254, 247, 255);
            panelLogin.Controls.Add(cardLogin);
            panelLogin.Dock = DockStyle.Fill;
            panelLogin.Location = new Point(0, 68);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(760, 472);
            panelLogin.TabIndex = 1;
            // 
            // cardLogin
            // 
            cardLogin.Anchor = AnchorStyles.None;
            cardLogin.BackColor = Color.FromArgb(255, 255, 255);
            cardLogin.Controls.Add(btnSwitchToRegister);
            cardLogin.Controls.Add(btnLoginSubmit);
            cardLogin.Controls.Add(txtPassword);
            cardLogin.Controls.Add(txtLogin);
            cardLogin.Controls.Add(lblLoginSubtitle);
            cardLogin.Controls.Add(lblLoginTitle);
            cardLogin.Location = new Point(190, 30);
            cardLogin.Name = "cardLogin";
            cardLogin.Padding = new Padding(24);
            cardLogin.Size = new Size(380, 400);
            cardLogin.TabIndex = 0;
            // 
            // lblLoginTitle
            // 
            lblLoginTitle.AutoSize = true;
            lblLoginTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblLoginTitle.ForeColor = Color.FromArgb(74, 68, 88);
            lblLoginTitle.Location = new Point(24, 20);
            lblLoginTitle.Name = "lblLoginTitle";
            lblLoginTitle.Size = new Size(153, 30);
            lblLoginTitle.TabIndex = 0;
            lblLoginTitle.Text = "Авторизация";
            // 
            // lblLoginSubtitle
            // 
            lblLoginSubtitle.AutoSize = true;
            lblLoginSubtitle.Font = new Font("Segoe UI", 9.5F);
            lblLoginSubtitle.ForeColor = Color.FromArgb(121, 116, 126);
            lblLoginSubtitle.Location = new Point(25, 54);
            lblLoginSubtitle.Name = "lblLoginSubtitle";
            lblLoginSubtitle.Size = new Size(251, 17);
            lblLoginSubtitle.TabIndex = 1;
            lblLoginSubtitle.Text = "Введите ваш логин и пароль для входа";
            // 
            // txtLogin
            // 
            txtLogin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtLogin.LabelText = "Логин / Имя пользователя";
            txtLogin.Location = new Point(25, 95);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(330, 48);
            txtLogin.TabIndex = 2;
            txtLogin.Text = "admin";
            // 
            // txtPassword
            // 
            txtPassword.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtPassword.LabelText = "Пароль";
            txtPassword.Location = new Point(25, 160);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(330, 48);
            txtPassword.TabIndex = 3;
            txtPassword.Text = "123";
            txtPassword.UseSystemPasswordChar = true;
            // 
            // btnLoginSubmit
            // 
            btnLoginSubmit.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnLoginSubmit.Location = new Point(25, 235);
            btnLoginSubmit.Name = "btnLoginSubmit";
            btnLoginSubmit.Size = new Size(330, 44);
            btnLoginSubmit.TabIndex = 4;
            btnLoginSubmit.Text = "ВОЙТИ В СИСТЕМУ";
            btnLoginSubmit.Click += btnLoginSubmit_Click;
            // 
            // btnSwitchToRegister
            // 
            btnSwitchToRegister.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnSwitchToRegister.BackColor = Color.Transparent;
            btnSwitchToRegister.Cursor = Cursors.Hand;
            btnSwitchToRegister.FlatAppearance.BorderSize = 0;
            btnSwitchToRegister.FlatStyle = FlatStyle.Flat;
            btnSwitchToRegister.Font = new Font("Segoe UI", 9F, FontStyle.Underline);
            btnSwitchToRegister.ForeColor = Color.FromArgb(103, 80, 164);
            btnSwitchToRegister.Location = new Point(25, 300);
            btnSwitchToRegister.Name = "btnSwitchToRegister";
            btnSwitchToRegister.Size = new Size(330, 30);
            btnSwitchToRegister.TabIndex = 5;
            btnSwitchToRegister.Text = "Нет аккаунта? Зарегистрироваться";
            btnSwitchToRegister.UseVisualStyleBackColor = false;
            btnSwitchToRegister.Click += btnSwitchToRegister_Click;
            // 
            // panelRegister
            // 
            panelRegister.BackColor = Color.FromArgb(254, 247, 255);
            panelRegister.Controls.Add(cardRegister);
            panelRegister.Dock = DockStyle.Fill;
            panelRegister.Location = new Point(0, 68);
            panelRegister.Name = "panelRegister";
            panelRegister.Size = new Size(760, 472);
            panelRegister.TabIndex = 2;
            panelRegister.Visible = false;
            // 
            // cardRegister
            // 
            cardRegister.Anchor = AnchorStyles.None;
            cardRegister.BackColor = Color.FromArgb(255, 255, 255);
            cardRegister.Controls.Add(btnSwitchToLogin);
            cardRegister.Controls.Add(btnRegisterSubmit);
            cardRegister.Controls.Add(txtRegPhone);
            cardRegister.Controls.Add(txtRegPassword);
            cardRegister.Controls.Add(txtRegLogin);
            cardRegister.Controls.Add(txtRegFullName);
            cardRegister.Controls.Add(lblRegisterSubtitle);
            cardRegister.Controls.Add(lblRegisterTitle);
            cardRegister.Location = new Point(180, 15);
            cardRegister.Name = "cardRegister";
            cardRegister.Padding = new Padding(24);
            cardRegister.Size = new Size(400, 440);
            cardRegister.TabIndex = 0;
            // 
            // lblRegisterTitle
            // 
            lblRegisterTitle.AutoSize = true;
            lblRegisterTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblRegisterTitle.ForeColor = Color.FromArgb(74, 68, 88);
            lblRegisterTitle.Location = new Point(24, 15);
            lblRegisterTitle.Name = "lblRegisterTitle";
            lblRegisterTitle.Size = new Size(149, 30);
            lblRegisterTitle.TabIndex = 0;
            lblRegisterTitle.Text = "Регистрация";
            // 
            // lblRegisterSubtitle
            // 
            lblRegisterSubtitle.AutoSize = true;
            lblRegisterSubtitle.Font = new Font("Segoe UI", 9.5F);
            lblRegisterSubtitle.ForeColor = Color.FromArgb(121, 116, 126);
            lblRegisterSubtitle.Location = new Point(25, 48);
            lblRegisterSubtitle.Name = "lblRegisterSubtitle";
            lblRegisterSubtitle.Size = new Size(270, 17);
            lblRegisterSubtitle.TabIndex = 1;
            lblRegisterSubtitle.Text = "Создайте новый профиль в базе SQLEXPRESS";
            // 
            // txtRegFullName
            // 
            txtRegFullName.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtRegFullName.LabelText = "ФИО (Полное имя)";
            txtRegFullName.Location = new Point(25, 78);
            txtRegFullName.Name = "txtRegFullName";
            txtRegFullName.Size = new Size(350, 48);
            txtRegFullName.TabIndex = 2;
            // 
            // txtRegLogin
            // 
            txtRegLogin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtRegLogin.LabelText = "Логин (для входа)";
            txtRegLogin.Location = new Point(25, 134);
            txtRegLogin.Name = "txtRegLogin";
            txtRegLogin.Size = new Size(350, 48);
            txtRegLogin.TabIndex = 3;
            // 
            // txtRegPassword
            // 
            txtRegPassword.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtRegPassword.LabelText = "Пароль";
            txtRegPassword.Location = new Point(25, 190);
            txtRegPassword.Name = "txtRegPassword";
            txtRegPassword.Size = new Size(350, 48);
            txtRegPassword.TabIndex = 4;
            txtRegPassword.UseSystemPasswordChar = true;
            // 
            // txtRegPhone
            // 
            txtRegPhone.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtRegPhone.LabelText = "Номер телефона";
            txtRegPhone.Location = new Point(25, 246);
            txtRegPhone.Name = "txtRegPhone";
            txtRegPhone.Size = new Size(350, 48);
            txtRegPhone.TabIndex = 5;
            // 
            // btnRegisterSubmit
            // 
            btnRegisterSubmit.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnRegisterSubmit.Location = new Point(25, 310);
            btnRegisterSubmit.Name = "btnRegisterSubmit";
            btnRegisterSubmit.Size = new Size(350, 44);
            btnRegisterSubmit.TabIndex = 6;
            btnRegisterSubmit.Text = "СОХРАНИТЬ В SQLEXPRESS (XSD)";
            btnRegisterSubmit.Click += btnRegisterSubmit_Click;
            // 
            // btnSwitchToLogin
            // 
            btnSwitchToLogin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnSwitchToLogin.BackColor = Color.Transparent;
            btnSwitchToLogin.Cursor = Cursors.Hand;
            btnSwitchToLogin.FlatAppearance.BorderSize = 0;
            btnSwitchToLogin.FlatStyle = FlatStyle.Flat;
            btnSwitchToLogin.Font = new Font("Segoe UI", 9F, FontStyle.Underline);
            btnSwitchToLogin.ForeColor = Color.FromArgb(103, 80, 164);
            btnSwitchToLogin.Location = new Point(25, 365);
            btnSwitchToLogin.Name = "btnSwitchToLogin";
            btnSwitchToLogin.Size = new Size(350, 30);
            btnSwitchToLogin.TabIndex = 7;
            btnSwitchToLogin.Text = "Уже есть аккаунт? Войти";
            btnSwitchToLogin.UseVisualStyleBackColor = false;
            btnSwitchToLogin.Click += btnSwitchToLogin_Click;
            // 
            // panelWelcome
            // 
            panelWelcome.BackColor = Color.FromArgb(254, 247, 255);
            panelWelcome.Controls.Add(cardWelcome);
            panelWelcome.Dock = DockStyle.Fill;
            panelWelcome.Location = new Point(0, 68);
            panelWelcome.Name = "panelWelcome";
            panelWelcome.Padding = new Padding(20);
            panelWelcome.Size = new Size(760, 472);
            panelWelcome.TabIndex = 3;
            panelWelcome.Visible = false;
            // 
            // cardWelcome
            // 
            cardWelcome.BackColor = Color.FromArgb(255, 255, 255);
            cardWelcome.Controls.Add(dgvUsers);
            cardWelcome.Controls.Add(lblUsersTableTitle);
            cardWelcome.Controls.Add(btnLogout);
            cardWelcome.Controls.Add(lblWelcomeInfo);
            cardWelcome.Controls.Add(lblWelcomeUser);
            cardWelcome.Dock = DockStyle.Fill;
            cardWelcome.Location = new Point(20, 20);
            cardWelcome.Name = "cardWelcome";
            cardWelcome.Padding = new Padding(20);
            cardWelcome.Size = new Size(720, 432);
            cardWelcome.TabIndex = 0;
            // 
            // lblWelcomeUser
            // 
            lblWelcomeUser.AutoSize = true;
            lblWelcomeUser.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblWelcomeUser.ForeColor = Color.FromArgb(74, 68, 88);
            lblWelcomeUser.Location = new Point(20, 15);
            lblWelcomeUser.Name = "lblWelcomeUser";
            lblWelcomeUser.Size = new Size(295, 30);
            lblWelcomeUser.TabIndex = 0;
            lblWelcomeUser.Text = "👋 Добро пожаловать, User!";
            // 
            // lblWelcomeInfo
            // 
            lblWelcomeInfo.AutoSize = true;
            lblWelcomeInfo.Font = new Font("Segoe UI", 9.5F);
            lblWelcomeInfo.ForeColor = Color.FromArgb(121, 116, 126);
            lblWelcomeInfo.Location = new Point(22, 48);
            lblWelcomeInfo.Name = "lblWelcomeInfo";
            lblWelcomeInfo.Size = new Size(392, 17);
            lblWelcomeInfo.TabIndex = 1;
            lblWelcomeInfo.Text = "Вы успешно авторизовались через XSD DataSet в MS SQL Server";
            // 
            // btnLogout
            // 
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.Location = new Point(595, 15);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(105, 38);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "ВЫЙТИ";
            btnLogout.Click += btnLogout_Click;
            // 
            // lblUsersTableTitle
            // 
            lblUsersTableTitle.AutoSize = true;
            lblUsersTableTitle.Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold);
            lblUsersTableTitle.ForeColor = Color.FromArgb(74, 68, 88);
            lblUsersTableTitle.Location = new Point(20, 85);
            lblUsersTableTitle.Name = "lblUsersTableTitle";
            lblUsersTableTitle.Size = new Size(310, 19);
            lblUsersTableTitle.TabIndex = 3;
            lblUsersTableTitle.Text = "📋 Список всех зарегистрированных в таблице Users:";
            // 
            // dgvUsers
            // 
            dgvUsers.AllowUserToAddRows = false;
            dgvUsers.AllowUserToDeleteRows = false;
            dgvUsers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUsers.BackgroundColor = Color.White;
            dgvUsers.BorderStyle = BorderStyle.None;
            dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsers.Location = new Point(20, 112);
            dgvUsers.MultiSelect = false;
            dgvUsers.Name = "dgvUsers";
            dgvUsers.ReadOnly = true;
            dgvUsers.RowHeadersVisible = false;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUsers.Size = new Size(680, 295);
            dgvUsers.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(760, 540);
            Controls.Add(panelWelcome);
            Controls.Add(panelRegister);
            Controls.Add(panelLogin);
            Controls.Add(panelTopNav);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(650, 500);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Информационная система — Авторизация и Регистрация (XSD + SQLEXPRESS)";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)materialThemeManager).EndInit();
            panelTopNav.ResumeLayout(false);
            panelTopNav.PerformLayout();
            panelLogin.ResumeLayout(false);
            cardLogin.ResumeLayout(false);
            cardLogin.PerformLayout();
            panelRegister.ResumeLayout(false);
            cardRegister.ResumeLayout(false);
            cardRegister.PerformLayout();
            panelWelcome.ResumeLayout(false);
            cardWelcome.ResumeLayout(false);
            cardWelcome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).EndInit();
            ResumeLayout(false);
        }

        #endregion
    }
}
