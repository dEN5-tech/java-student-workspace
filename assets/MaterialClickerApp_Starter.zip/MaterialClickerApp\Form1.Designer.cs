using System.Drawing;
using System.Windows.Forms;
using Material3.Core;
using Material3.WinForms;
using Material3.WinForms.Controls;

namespace MaterialClickerApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Менеджер темы Material 3
        private MaterialThemeManager materialThemeManager;

        // --- ЭКРАН 1: АВТОРИЗАЦИЯ ---
        private Panel panelLogin;
        private MaterialCard cardLogin;
        private Label lblLoginTitle;
        private Label lblLoginSubtitle;
        private MaterialTextField txtLogin;
        private MaterialTextField txtPassword;
        private MaterialButton btnLogin;
        private Label lblLoginHint;

        // --- ЭКРАН 2: ДАШБОРД ---
        private Panel panelDashboard;
        
        // Шапка дашборда
        private Panel panelTopHeader;
        private Label lblWelcome;
        private Label lblUserRole;
        private MaterialButton btnLogout;

        // Карточки метрик (KPI)
        private MaterialCard cardMetric1;
        private Label lblMetric1Title;
        private Label lblMetric1Value;

        private MaterialCard cardMetric2;
        private Label lblMetric2Title;
        private Label lblMetric2Value;

        private MaterialCard cardMetric3;
        private Label lblMetric3Title;
        private Label lblMetric3Value;

        // Таблица последних заказов
        private MaterialCard cardTableContainer;
        private Label lblTableTitle;
        private MaterialButton btnAddOrder;
        private MaterialButton btnRefresh;
        private DataGridView dgvOrders;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            materialThemeManager = new MaterialThemeManager();
            panelLogin = new Panel();
            cardLogin = new MaterialCard();
            lblLoginTitle = new Label();
            lblLoginSubtitle = new Label();
            txtLogin = new MaterialTextField();
            txtPassword = new MaterialTextField();
            btnLogin = new MaterialButton();
            lblLoginHint = new Label();
            panelDashboard = new Panel();
            panelTopHeader = new Panel();
            lblWelcome = new Label();
            lblUserRole = new Label();
            btnLogout = new MaterialButton();
            cardMetric1 = new MaterialCard();
            lblMetric1Title = new Label();
            lblMetric1Value = new Label();
            cardMetric2 = new MaterialCard();
            lblMetric2Title = new Label();
            lblMetric2Value = new Label();
            cardMetric3 = new MaterialCard();
            lblMetric3Title = new Label();
            lblMetric3Value = new Label();
            cardTableContainer = new MaterialCard();
            lblTableTitle = new Label();
            btnAddOrder = new MaterialButton();
            btnRefresh = new MaterialButton();
            dgvOrders = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)materialThemeManager).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvOrders).BeginInit();
            panelLogin.SuspendLayout();
            cardLogin.SuspendLayout();
            panelDashboard.SuspendLayout();
            panelTopHeader.SuspendLayout();
            cardMetric1.SuspendLayout();
            cardMetric2.SuspendLayout();
            cardMetric3.SuspendLayout();
            cardTableContainer.SuspendLayout();
            SuspendLayout();
            // 
            // materialThemeManager
            // 
            materialThemeManager.IsDark = false;
            materialThemeManager.Seed = Color.FromArgb(50, 100, 230);
            // 
            // panelLogin
            // 
            panelLogin.BackColor = Color.FromArgb(248, 249, 252);
            panelLogin.Controls.Add(cardLogin);
            panelLogin.Dock = DockStyle.Fill;
            panelLogin.Location = new Point(0, 0);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(920, 640);
            panelLogin.TabIndex = 0;
            // 
            // cardLogin
            // 
            cardLogin.Anchor = AnchorStyles.None;
            cardLogin.BackColor = Color.White;
            cardLogin.Controls.Add(lblLoginTitle);
            cardLogin.Controls.Add(lblLoginSubtitle);
            cardLogin.Controls.Add(txtLogin);
            cardLogin.Controls.Add(txtPassword);
            cardLogin.Controls.Add(btnLogin);
            cardLogin.Controls.Add(lblLoginHint);
            cardLogin.Location = new Point(260, 90);
            cardLogin.Name = "cardLogin";
            cardLogin.Padding = new Padding(16);
            cardLogin.Size = new Size(400, 450);
            cardLogin.TabIndex = 0;
            // 
            // lblLoginTitle
            // 
            lblLoginTitle.AutoSize = true;
            lblLoginTitle.BackColor = Color.Transparent;
            lblLoginTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblLoginTitle.ForeColor = Color.FromArgb(24, 43, 73);
            lblLoginTitle.Location = new Point(30, 30);
            lblLoginTitle.Name = "lblLoginTitle";
            lblLoginTitle.Size = new Size(171, 32);
            lblLoginTitle.TabIndex = 0;
            lblLoginTitle.Text = "Авторизация";
            // 
            // lblLoginSubtitle
            // 
            lblLoginSubtitle.AutoSize = true;
            lblLoginSubtitle.BackColor = Color.Transparent;
            lblLoginSubtitle.Font = new Font("Segoe UI", 9.5F);
            lblLoginSubtitle.ForeColor = Color.FromArgb(100, 116, 139);
            lblLoginSubtitle.Location = new Point(32, 68);
            lblLoginSubtitle.Name = "lblLoginSubtitle";
            lblLoginSubtitle.Size = new Size(248, 17);
            lblLoginSubtitle.TabIndex = 1;
            lblLoginSubtitle.Text = "Информационная система предприятия";
            // 
            // txtLogin
            // 
            txtLogin.BackColor = Color.White;
            txtLogin.LabelText = "Логин";
            txtLogin.Location = new Point(30, 110);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(340, 71);
            txtLogin.TabIndex = 1;
            txtLogin.Variant = MaterialTextFieldVariant.Outlined;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.White;
            txtPassword.LabelText = "Пароль";
            txtPassword.Location = new Point(30, 185);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(340, 71);
            txtPassword.TabIndex = 2;
            txtPassword.Variant = MaterialTextFieldVariant.Outlined;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.Transparent;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnLogin.ForeColor = Color.FromArgb(255, 255, 255);
            btnLogin.Location = new Point(30, 265);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(340, 55);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Войти в систему";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblLoginHint
            // 
            lblLoginHint.BackColor = Color.Transparent;
            lblLoginHint.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblLoginHint.ForeColor = Color.FromArgb(71, 85, 105);
            lblLoginHint.Location = new Point(30, 340);
            lblLoginHint.Name = "lblLoginHint";
            lblLoginHint.Size = new Size(340, 65);
            lblLoginHint.TabIndex = 4;
            lblLoginHint.Text = "💡 Подсказка для входа:\n• Логин: admin | Пароль: 123 (Администратор)\n• Логин: manager | Пароль: 123 (Менеджер)";
            // 
            // panelDashboard
            // 
            panelDashboard.BackColor = Color.FromArgb(248, 249, 252);
            panelDashboard.Controls.Add(panelTopHeader);
            panelDashboard.Controls.Add(cardMetric1);
            panelDashboard.Controls.Add(cardMetric2);
            panelDashboard.Controls.Add(cardMetric3);
            panelDashboard.Controls.Add(cardTableContainer);
            panelDashboard.Dock = DockStyle.Fill;
            panelDashboard.Location = new Point(0, 0);
            panelDashboard.Name = "panelDashboard";
            panelDashboard.Size = new Size(920, 640);
            panelDashboard.TabIndex = 1;
            panelDashboard.Visible = false;
            // 
            // panelTopHeader
            // 
            panelTopHeader.BackColor = Color.Transparent;
            panelTopHeader.Controls.Add(lblWelcome);
            panelTopHeader.Controls.Add(lblUserRole);
            panelTopHeader.Controls.Add(btnLogout);
            panelTopHeader.Dock = DockStyle.Top;
            panelTopHeader.Location = new Point(0, 0);
            panelTopHeader.Name = "panelTopHeader";
            panelTopHeader.Padding = new Padding(25, 10, 25, 10);
            panelTopHeader.Size = new Size(920, 70);
            panelTopHeader.TabIndex = 0;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.FromArgb(30, 58, 138);
            lblWelcome.Location = new Point(25, 12);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(351, 30);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Панель управления (Дашборд)";
            // 
            // lblUserRole
            // 
            lblUserRole.AutoSize = true;
            lblUserRole.Font = new Font("Segoe UI", 9.5F);
            lblUserRole.ForeColor = Color.FromArgb(100, 116, 139);
            lblUserRole.Location = new Point(27, 43);
            lblUserRole.Name = "lblUserRole";
            lblUserRole.Size = new Size(240, 17);
            lblUserRole.TabIndex = 1;
            lblUserRole.Text = "Пользователь: admin (Администратор)";
            // 
            // btnLogout
            // 
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.Transparent;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 9.5F);
            btnLogout.ForeColor = Color.FromArgb(25, 83, 214);
            btnLogout.Location = new Point(1505, 15);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(105, 40);
            btnLogout.TabIndex = 1;
            btnLogout.Text = "Выйти";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Variant = MaterialButtonVariant.Outlined;
            btnLogout.Click += btnLogout_Click;
            // 
            // cardMetric1
            // 
            cardMetric1.BackColor = Color.White;
            cardMetric1.Controls.Add(lblMetric1Title);
            cardMetric1.Controls.Add(lblMetric1Value);
            cardMetric1.Location = new Point(25, 85);
            cardMetric1.Name = "cardMetric1";
            cardMetric1.Padding = new Padding(16);
            cardMetric1.Size = new Size(270, 95);
            cardMetric1.TabIndex = 2;
            // 
            // lblMetric1Title
            // 
            lblMetric1Title.AutoSize = true;
            lblMetric1Title.BackColor = Color.Transparent;
            lblMetric1Title.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblMetric1Title.ForeColor = Color.FromArgb(100, 116, 139);
            lblMetric1Title.Location = new Point(15, 15);
            lblMetric1Title.Name = "lblMetric1Title";
            lblMetric1Title.Size = new Size(136, 17);
            lblMetric1Title.TabIndex = 0;
            lblMetric1Title.Text = "📦 ВСЕГО ТОВАРОВ";
            // 
            // lblMetric1Value
            // 
            lblMetric1Value.AutoSize = true;
            lblMetric1Value.BackColor = Color.Transparent;
            lblMetric1Value.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblMetric1Value.ForeColor = Color.FromArgb(37, 99, 235);
            lblMetric1Value.Location = new Point(15, 40);
            lblMetric1Value.Name = "lblMetric1Value";
            lblMetric1Value.Size = new Size(136, 37);
            lblMetric1Value.TabIndex = 1;
            lblMetric1Value.Text = "1,248 шт.";
            // 
            // cardMetric2
            // 
            cardMetric2.BackColor = Color.White;
            cardMetric2.Controls.Add(lblMetric2Title);
            cardMetric2.Controls.Add(lblMetric2Value);
            cardMetric2.Location = new Point(325, 85);
            cardMetric2.Name = "cardMetric2";
            cardMetric2.Padding = new Padding(16);
            cardMetric2.Size = new Size(270, 95);
            cardMetric2.TabIndex = 3;
            // 
            // lblMetric2Title
            // 
            lblMetric2Title.AutoSize = true;
            lblMetric2Title.BackColor = Color.Transparent;
            lblMetric2Title.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblMetric2Title.ForeColor = Color.FromArgb(100, 116, 139);
            lblMetric2Title.Location = new Point(15, 15);
            lblMetric2Title.Name = "lblMetric2Title";
            lblMetric2Title.Size = new Size(152, 17);
            lblMetric2Title.TabIndex = 0;
            lblMetric2Title.Text = "💰 ВЫРУЧКА ЗА ДЕНЬ";
            // 
            // lblMetric2Value
            // 
            lblMetric2Value.AutoSize = true;
            lblMetric2Value.BackColor = Color.Transparent;
            lblMetric2Value.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblMetric2Value.ForeColor = Color.FromArgb(16, 149, 90);
            lblMetric2Value.Location = new Point(15, 40);
            lblMetric2Value.Name = "lblMetric2Value";
            lblMetric2Value.Size = new Size(143, 37);
            lblMetric2Value.TabIndex = 1;
            lblMetric2Value.Text = "142,500 ₽";
            // 
            // cardMetric3
            // 
            cardMetric3.BackColor = Color.White;
            cardMetric3.Controls.Add(lblMetric3Title);
            cardMetric3.Controls.Add(lblMetric3Value);
            cardMetric3.Location = new Point(625, 85);
            cardMetric3.Name = "cardMetric3";
            cardMetric3.Padding = new Padding(16);
            cardMetric3.Size = new Size(265, 95);
            cardMetric3.TabIndex = 4;
            // 
            // lblMetric3Title
            // 
            lblMetric3Title.AutoSize = true;
            lblMetric3Title.BackColor = Color.Transparent;
            lblMetric3Title.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblMetric3Title.ForeColor = Color.FromArgb(100, 116, 139);
            lblMetric3Title.Location = new Point(15, 15);
            lblMetric3Title.Name = "lblMetric3Title";
            lblMetric3Title.Size = new Size(167, 17);
            lblMetric3Title.TabIndex = 0;
            lblMetric3Title.Text = "📋 АКТИВНЫХ ЗАКАЗОВ";
            // 
            // lblMetric3Value
            // 
            lblMetric3Value.AutoSize = true;
            lblMetric3Value.BackColor = Color.Transparent;
            lblMetric3Value.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblMetric3Value.ForeColor = Color.FromArgb(124, 58, 237);
            lblMetric3Value.Location = new Point(15, 40);
            lblMetric3Value.Name = "lblMetric3Value";
            lblMetric3Value.Size = new Size(160, 37);
            lblMetric3Value.TabIndex = 1;
            lblMetric3Value.Text = "28 заказов";
            // 
            // cardTableContainer
            // 
            cardTableContainer.BackColor = Color.White;
            cardTableContainer.Controls.Add(lblTableTitle);
            cardTableContainer.Controls.Add(btnAddOrder);
            cardTableContainer.Controls.Add(btnRefresh);
            cardTableContainer.Controls.Add(dgvOrders);
            cardTableContainer.Location = new Point(25, 200);
            cardTableContainer.Name = "cardTableContainer";
            cardTableContainer.Padding = new Padding(16);
            cardTableContainer.Size = new Size(865, 410);
            cardTableContainer.TabIndex = 5;
            // 
            // lblTableTitle
            // 
            lblTableTitle.AutoSize = true;
            lblTableTitle.BackColor = Color.Transparent;
            lblTableTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTableTitle.ForeColor = Color.FromArgb(30, 58, 138);
            lblTableTitle.Location = new Point(20, 18);
            lblTableTitle.Name = "lblTableTitle";
            lblTableTitle.Size = new Size(308, 21);
            lblTableTitle.TabIndex = 0;
            lblTableTitle.Text = "Журнал последних заказов клиентов";
            // 
            // btnAddOrder
            // 
            btnAddOrder.BackColor = Color.Transparent;
            btnAddOrder.FlatStyle = FlatStyle.Flat;
            btnAddOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnAddOrder.ForeColor = Color.FromArgb(255, 255, 255);
            btnAddOrder.Location = new Point(540, 12);
            btnAddOrder.Name = "btnAddOrder";
            btnAddOrder.Size = new Size(170, 36);
            btnAddOrder.TabIndex = 1;
            btnAddOrder.Text = "+ Новый заказ";
            btnAddOrder.UseVisualStyleBackColor = false;
            btnAddOrder.Click += btnAddOrder_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.Transparent;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.Font = new Font("Segoe UI", 9F);
            btnRefresh.ForeColor = Color.FromArgb(22, 27, 44);
            btnRefresh.Location = new Point(720, 12);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(125, 36);
            btnRefresh.TabIndex = 2;
            btnRefresh.Text = "Обновить";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Variant = MaterialButtonVariant.Tonal;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // dgvOrders
            // 
            dgvOrders.AllowUserToAddRows = false;
            dgvOrders.AllowUserToDeleteRows = false;
            dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrders.BackgroundColor = Color.White;
            dgvOrders.BorderStyle = BorderStyle.None;
            dgvOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrders.Location = new Point(20, 60);
            dgvOrders.Name = "dgvOrders";
            dgvOrders.ReadOnly = true;
            dgvOrders.RowHeadersVisible = false;
            dgvOrders.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrders.Size = new Size(825, 330);
            dgvOrders.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 249, 252);
            ClientSize = new Size(920, 640);
            Controls.Add(panelDashboard);
            Controls.Add(panelLogin);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Material 3 — Информационная система (Дашборд)";
            ((System.ComponentModel.ISupportInitialize)materialThemeManager).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvOrders).EndInit();
            panelLogin.ResumeLayout(false);
            cardLogin.ResumeLayout(false);
            cardLogin.PerformLayout();
            panelDashboard.ResumeLayout(false);
            panelTopHeader.ResumeLayout(false);
            panelTopHeader.PerformLayout();
            cardMetric1.ResumeLayout(false);
            cardMetric1.PerformLayout();
            cardMetric2.ResumeLayout(false);
            cardMetric2.PerformLayout();
            cardMetric3.ResumeLayout(false);
            cardMetric3.PerformLayout();
            cardTableContainer.ResumeLayout(false);
            cardTableContainer.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
    }
}
