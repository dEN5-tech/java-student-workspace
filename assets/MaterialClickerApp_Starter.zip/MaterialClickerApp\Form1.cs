using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MaterialClickerApp.DBTableAdapters;

namespace MaterialClickerApp
{
    public partial class Form1 : Form
    {
        // 1. Экземпляры автосгенерированного XSD типизированного DataSet и TableAdapter
        private DB dbDataSet;
        private UsersTableAdapter usersTableAdapter;
        private BindingSource usersBindingSource;

        // Флаг успешного подключения к реальной БД SQLEXPRESS
        private bool isDbConnected = false;

        public Form1()
        {
            InitializeComponent();

            // Создаем объекты типизированного DataSet
            dbDataSet = new DB();
            usersTableAdapter = new UsersTableAdapter();
            usersBindingSource = new BindingSource();
        }

        // --- СОБЫТИЕ ЗАГРУЗКИ ФОРМЫ (Form_Load) ---
        private void Form1_Load(object sender, EventArgs e)
        {
            // Подключаем BindingSource к таблице Users из типизированного DataSet
            usersBindingSource.DataSource = dbDataSet.Users;
            dgvUsers.DataSource = usersBindingSource;

            // Загружаем данные из MS SQL Server Express через TableAdapter
            LoadUsersFromDatabase();

            // По умолчанию открываем панель входа
            ShowLoginPanel();
        }

        // --- ЗАГРУЗКА ДАННЫХ ИЗ SQLEXPRESS ЧЕРЕЗ XSD TABLEADAPTER ---
        private void LoadUsersFromDatabase()
        {
            try
            {
                // Заполняем типизированную таблицу Users строками из базы данных
                usersTableAdapter.Fill(dbDataSet.Users);
                isDbConnected = true;
                lblDbStatus.Text = $"✓ Подключено к .\\SQLEXPRESS (XSD) | Пользователей в БД: {dbDataSet.Users.Count}";
                lblDbStatus.ForeColor = System.Drawing.Color.FromArgb(56, 142, 60); // Зеленый
            }
            catch (Exception ex)
            {
                isDbConnected = false;
                lblDbStatus.Text = $"⚠ Автономный режим (SQLEXPRESS не запущен): {ex.Message}";
                lblDbStatus.ForeColor = System.Drawing.Color.FromArgb(211, 47, 47); // Красный

                // Если SQL Server не запущен, добавляем демонстрационных пользователей
                if (dbDataSet.Users.Count == 0)
                {
                    var u1 = dbDataSet.Users.NewUsersRow();
                    u1.RoleId = 1;
                    u1.FullName = "Иванов Иван Иванович (Администратор)";
                    u1.Login = "admin";
                    u1.Password = "123";
                    u1.Phone = "+7 (999) 000-00-00";
                    u1.Email = "admin@college.ru";
                    dbDataSet.Users.AddUsersRow(u1);

                    var u2 = dbDataSet.Users.NewUsersRow();
                    u2.RoleId = 2;
                    u2.FullName = "Петров Петр Сергеевич (Студент)";
                    u2.Login = "student";
                    u2.Password = "123";
                    u2.Phone = "+7 (999) 111-22-33";
                    u2.Email = "student@college.ru";
                    dbDataSet.Users.AddUsersRow(u2);
                }
            }
        }

        // =========================================================================
        // ЛОГИКА АВТОРИЗАЦИИ (ВХОД)
        // =========================================================================
        private void btnLoginSubmit_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Валидация заполнения полей
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, введите логин и пароль!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Поиск пользователя в типизированной таблице Users
            var foundUser = dbDataSet.Users
                .FirstOrDefault(u => u.Login.Equals(login, StringComparison.OrdinalIgnoreCase) && u.Password == password);

            if (foundUser != null)
            {
                // Успешный вход -> открываем панель личного кабинета
                ShowWelcomePanel(foundUser.FullName, foundUser.Login);
            }
            else
            {
                MessageBox.Show(
                    "Неверный логин или пароль!\n\nТестовые данные:\n• Логин: admin / Пароль: 123\n• Логин: student / Пароль: 123\n\nИли нажмите кнопку 'Регистрация'.",
                    "Ошибка авторизации",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        // =========================================================================
        // ЛОГИКА РЕГИСТРАЦИИ НОВОГО ПОЛЬЗОВАТЕЛЯ (INSERT ЧЕРЕЗ XSD DATASET)
        // =========================================================================
        private void btnRegisterSubmit_Click(object sender, EventArgs e)
        {
            string fullName = txtRegFullName.Text.Trim();
            string login = txtRegLogin.Text.Trim();
            string password = txtRegPassword.Text.Trim();
            string phone = txtRegPhone.Text.Trim();

            // 1. Простая проверка обязательных полей
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните ФИО, логин и пароль для регистрации!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Проверка уникальности логина в базе данных
            bool loginExists = dbDataSet.Users
                .Any(u => u.Login.Equals(login, StringComparison.OrdinalIgnoreCase));

            if (loginExists)
            {
                MessageBox.Show("Пользователь с таким логином уже существует! Придумайте другой логин.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtRegLogin.Focus();
                return;
            }

            // 3. Создаем строго типизированную строку UsersRow
            var newRow = dbDataSet.Users.NewUsersRow();
            newRow.FullName = fullName;
            newRow.Login = login;
            newRow.Password = password;
            newRow.Phone = string.IsNullOrEmpty(phone) ? "+7 (000) 000-00-00" : phone;
            newRow.Email = login + "@mail.ru";
            newRow.RoleId = 1; // Роль по умолчанию

            // 4. Добавляем строку в локальную коллекцию таблицы
            dbDataSet.Users.AddUsersRow(newRow);

            // 5. Сохраняем изменения в MS SQL Server через TableAdapter.Update()
            try
            {
                if (isDbConnected)
                {
                    usersTableAdapter.Update(dbDataSet.Users);
                }

                MessageBox.Show(
                    $"Пользователь '{login}' успешно зарегистрирован в базе данных SQLEXPRESS!",
                    "Регистрация завершена",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                // Очищаем форму регистрации
                txtRegFullName.Text = "";
                txtRegLogin.Text = "";
                txtRegPassword.Text = "";
                txtRegPhone.Text = "";

                // Переключаем на экран входа и подставляем логин
                ShowLoginPanel();
                txtLogin.Text = login;
                txtPassword.Text = "";
                txtPassword.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении в базу данных SQLEXPRESS: {ex.Message}", "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // --- ВЫХОД ИЗ АККАУНТА ---
        private void btnLogout_Click(object sender, EventArgs e)
        {
            txtPassword.Text = "";
            ShowLoginPanel();
        }

        // =========================================================================
        // ПЕРЕКЛЮЧЕНИЕ ПАНЕЛЕЙ (UI NAVIGATION)
        // =========================================================================
        private void ShowLoginPanel()
        {
            panelLogin.Visible = true;
            panelRegister.Visible = false;
            panelWelcome.Visible = false;

            btnNavLogin.Enabled = false;
            btnNavRegister.Enabled = true;
        }

        private void ShowRegisterPanel()
        {
            panelLogin.Visible = false;
            panelRegister.Visible = true;
            panelWelcome.Visible = false;

            btnNavLogin.Enabled = true;
            btnNavRegister.Enabled = false;
        }

        private void ShowWelcomePanel(string fullName, string login)
        {
            panelLogin.Visible = false;
            panelRegister.Visible = false;
            panelWelcome.Visible = true;

            btnNavLogin.Enabled = true;
            btnNavRegister.Enabled = true;

            lblWelcomeUser.Text = $"👋 Добро пожаловать, {fullName}!";
            lblWelcomeInfo.Text = $"Вы успешно авторизовались под логином: {login} (Подключение: XSD DataSet к SQLEXPRESS)";

            // Обновляем отображение таблицы пользователей
            usersBindingSource.ResetBindings(false);
        }

        // Обработчики кнопок навигации
        private void btnNavLogin_Click(object sender, EventArgs e) => ShowLoginPanel();
        private void btnNavRegister_Click(object sender, EventArgs e) => ShowRegisterPanel();
        private void btnSwitchToRegister_Click(object sender, EventArgs e) => ShowRegisterPanel();
        private void btnSwitchToLogin_Click(object sender, EventArgs e) => ShowLoginPanel();
    }
}
