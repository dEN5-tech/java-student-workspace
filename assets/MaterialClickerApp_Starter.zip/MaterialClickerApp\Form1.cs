using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MaterialClickerApp
{
    public partial class Form1 : Form
    {
        // 1. Простая модель данных заказа (Student-Grade Model)
        public class OrderItem
        {
            public int Id { get; set; }
            public string Client { get; set; } = "";
            public string Product { get; set; } = "";
            public decimal Amount { get; set; }
            public string Status { get; set; } = "";
            public string Date { get; set; } = "";
        }

        // 2. Внутрипамятный список заказов (Mock Database)
        private List<OrderItem> ordersList = new List<OrderItem>();

        public Form1()
        {
            // Инициализация интерфейса из Form1.Designer.cs
            InitializeComponent();

            // Заполняем стартовыми тестовыми данными
            InitSampleData();
        }

        // Заполнение тестовыми данными при запуске
        private void InitSampleData()
        {
            ordersList.Add(new OrderItem { Id = 101, Client = "ООО Ромашка", Product = "Ноутбук ASUS", Amount = 65000, Status = "Выполнен", Date = "07.10.2026" });
            ordersList.Add(new OrderItem { Id = 102, Client = "ИП Иванов А.С.", Product = "Монитор 27\"", Amount = 24500, Status = "В обработке", Date = "07.10.2026" });
            ordersList.Add(new OrderItem { Id = 103, Client = "ООO Вектор", Product = "Серверный шкаф", Amount = 53000, Status = "Оплачен", Date = "06.10.2026" });
            
            // Привязываем список к таблице DataGridView
            RefreshTable();
        }

        // --- ЛОГИКА АВТОРИЗАЦИИ (ВХОД) ---
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Простая проверка логина и пароля
            if (login == "admin" && password == "123")
            {
                // Успешный вход под администратором
                lblWelcome.Text = "👋 Добро пожаловать, Администратор!";
                lblUserRole.Text = "Пользователь: admin | Роль: Главный администратор";
                
                // Переключаем видимость панелей
                panelLogin.Visible = false;
                panelDashboard.Visible = true;
            }
            else if (login == "manager" && password == "123")
            {
                // Успешный вход под менеджером
                lblWelcome.Text = "👋 Добро пожаловать, Менеджер!";
                lblUserRole.Text = "Пользователь: manager | Роль: Менеджер по продажам";

                // Переключаем видимость панелей
                panelLogin.Visible = false;
                panelDashboard.Visible = true;
            }
            else
            {
                // Ошибка входа
                MessageBox.Show(
                    "Неверный логин или пароль!\nИспользуйте: admin / 123 или manager / 123",
                    "Ошибка авторизации",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        // --- ЛОГИКА ВЫХОДА ИЗ СИСТЕМЫ ---
        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Возвращаемся на экран входа
            panelDashboard.Visible = false;
            panelLogin.Visible = true;

            // Очищаем поле пароля для безопасности
            txtPassword.Text = "";
            txtLogin.Focus();
        }

        // --- ДОБАВЛЕНИЕ НОВОГО ЗАКАЗА ---
        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            int nextId = 100 + ordersList.Count + 1;
            
            // Добавляем новый тестовый заказ
            ordersList.Add(new OrderItem
            {
                Id = nextId,
                Client = "Новый клиент " + nextId,
                Product = "Комплект оборудования",
                Amount = 35000,
                Status = "Новый",
                Date = DateTime.Now.ToString("dd.MM.yyyy")
            });

            // Обновляем таблицу и счетчики
            RefreshTable();

            MessageBox.Show($"Заказ №{nextId} успешно создан!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // --- ОБНОВЛЕНИЕ ДАННЫХ И ТАБЛИЦЫ ---
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshTable();
        }

        private void RefreshTable()
        {
            // Перепривязка источника данных DataGridView
            dgvOrders.DataSource = null;
            dgvOrders.DataSource = ordersList;

            // Настройка красивых заголовков колонок
            if (dgvOrders.Columns["Id"] != null) dgvOrders.Columns["Id"].HeaderText = "№ Заказа";
            if (dgvOrders.Columns["Client"] != null) dgvOrders.Columns["Client"].HeaderText = "Клиент / Организация";
            if (dgvOrders.Columns["Product"] != null) dgvOrders.Columns["Product"].HeaderText = "Наименование товара";
            if (dgvOrders.Columns["Amount"] != null)
            {
                dgvOrders.Columns["Amount"].HeaderText = "Сумма (руб.)";
                dgvOrders.Columns["Amount"].DefaultCellStyle.Format = "N0";
            }
            if (dgvOrders.Columns["Status"] != null) dgvOrders.Columns["Status"].HeaderText = "Статус";
            if (dgvOrders.Columns["Date"] != null) dgvOrders.Columns["Date"].HeaderText = "Дата";

            // Пересчет метрик дашборда
            decimal totalRevenue = 0;
            foreach (var item in ordersList)
            {
                totalRevenue += item.Amount;
            }

            lblMetric2Value.Text = $"{totalRevenue:N0} ₽";
            lblMetric3Value.Text = $"{ordersList.Count} заказов";
        }
    }
}
