using System;
using System.Drawing;
using System.Windows.Forms;
using Material3.Core;
using Material3.WinForms.Theming;
using M3Theme = Material3.WinForms.Theming.MaterialTheme;

namespace MaterialClickerApp
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // ☀️ Принудительно задаем глобальную светлую (белую) тему Material 3 на старте приложения
            var lightTheme = M3Theme.FromSeed(Color.FromArgb(50, 100, 230), SchemeVariant.TonalSpot);
            ThemeManager.Apply(lightTheme, isDark: false);

            Application.Run(new Form1());
        }
    }
}