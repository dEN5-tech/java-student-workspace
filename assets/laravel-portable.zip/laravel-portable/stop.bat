@echo off
setlocal
cd /d "%~dp0"
echo Stopping MariaDB...
"%~dp0mysql\bin\mysqladmin.exe" -u root shutdown >nul 2>&1
taskkill /f /im mysqld.exe >nul 2>&1
echo MariaDB stopped.
