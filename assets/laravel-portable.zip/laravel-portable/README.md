# Portable Laravel + MariaDB (MySQL) + PHP 8.3 + Composer

Полностью автономный переносимый стек веб-разработки для Windows без установки в систему.

## 🚀 Управление сборкой:

* **`start.bat`** — Запуск MariaDB + веб-сервера Laravel (`http://127.0.0.1:8000`) в 1 клик.
* **`stop.bat`** — Остановка сервера MariaDB.
* **`open_console.bat`** — Консоль разработчика, где сразу доступны команды: `artisan`, `composer`, `php`, `mysql`.
* **`mysql.bat`** — Быстрый вход в интерактивную консоль MySQL (к базе `laravel`).
* **`artisan.bat`** — Вызов команд Laravel Artisan (например `artisan route:list`).
* **`composer.bat`** — Вызов Composer (например `composer require <пакет>`).

---

## 🗄️ База данных (MariaDB / MySQL):
* **Хост:** `127.0.0.1`
* **Порт:** `3306`
* **Пользователь:** `root`
* **Пароль:** *(пустой)*
* **База данных:** `laravel`

> 💡 *К ней можно подключаться через DBeaver, HeidiSQL, TablePlus, Beekeeper Studio или расширения VS Code / PhpStorm.*

---

## 📁 Структура папок:
```text
C:\laravel-portable\
├── start.bat          # Запуск MariaDB + Laravel
├── stop.bat           # Остановка
├── open_console.bat   # Терминал со всеми утилитами
├── artisan.bat
├── composer.bat
├── mysql.bat
│
├── php\               # Портативный PHP 8.3
├── mysql\             # Портативная MariaDB 10.11 (MySQL) с базой в mysql/data/
├── composer.phar      # Пакетный менеджер Composer
│
└── app\               # Исходный код Laravel проекта (включая vendor/ и .env)
```
