@echo off
setlocal
cd /d "%~dp0"
title Laravel + MariaDB Portable

echo ========================================================
echo   Starting Portable MariaDB (MySQL)...
echo ========================================================
start "" /b "%~dp0mysql\bin\mysqld.exe" --datadir="%~dp0mysql\data" --port=3306

timeout /t 2 /nobreak >nul

echo ========================================================
echo   Starting Laravel Server...
echo   Local URL: http://127.0.0.1:8000
echo   MySQL:     127.0.0.1:3306 (user: root, no password)
echo ========================================================
echo.
"%~dp0php\php.exe" "%~dp0app\artisan" serve

echo.
echo Stopping MariaDB...
"%~dp0mysql\bin\mysqladmin.exe" -u root shutdown >nul 2>&1
