package ru.college.game;

import ru.college.engine.Game;

public class Main {
    public static void main(String[] args) {
        Game.launch(new MyGame());
    }
}
