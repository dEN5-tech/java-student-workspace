@echo off
chcp 65001 > nul
echo ==================================================================
echo  🎮 ЗАПУСК ИГРЫ (VS Code Starter - Без установки Maven)
echo ==================================================================

if not exist "bin" mkdir bin

echo [1/2] Компиляция Java классов (javac)...
javac --release 17 -encoding UTF-8 -cp "lib/*;lib" -d bin src/ru/college/game/*.java
if %ERRORLEVEL% NEQ 0 (
    echo [!] Ошибка компиляции Java. Проверьте код в папке src.
    pause
    exit /b %ERRORLEVEL%
)

echo [2/2] Запуск встроенного веб-сервера DevServer и открытие браузера...
java -Dfile.encoding=UTF-8 -cp "bin;lib/*;lib" ru.college.game.RunDev

pause
