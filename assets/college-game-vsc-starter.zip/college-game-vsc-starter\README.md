# 🎮 Шаблон игрового проекта для VS Code (Специальность 09.02.01 КСК)
### Полный аналог JavaFX Starter — без установки Maven!

Этот проект настроен точно так же, как ваши практические работы по JavaFX:
- **Никаких сложных инструментов:** Maven и сборщики не нужны.
- **Единая библиотека:** файл `lib/college-engine-1.0.0.jar` уже подключен в `.vscode/settings.json`.
- **Запуск в 1 клик:** по клавише **`F5`**, **`Ctrl + Shift + B`** или двойным кликом по **`run.bat`**.

---

## 📂 Структура проекта

```
college-game-vsc-starter/
├── .vscode/
│   ├── settings.json       # Подключение библиотеки из папки lib/*.jar
│   ├── launch.json         # Настройка запуска по F5
│   └── tasks.json          # Настройка сборки по Ctrl+Shift+B
├── lib/
│   └── college-engine-1.0.0.jar  # Наша главная библиотека (как JavaFX SDK)
├── src/
│   ├── ru/college/game/
│   │   ├── MyGame.java     # 👈 ВАШ КОД ИГРЫ (редактируйте его!)
│   │   ├── Main.java       # Точка входа для веб-компиляции
│   │   └── RunDev.java     # Быстрый запуск сервера из VS Code
│   └── webapp/
│       ├── index.html      # Лабораторный экран со спецификацией КСК
│       └── js/game.js      # Скомпилированный скрипт
├── run.bat                 # Запуск двойным кликом на Windows
└── README.md
```

---

## ⚡ Как запускать проект в VS Code:

### Способ 1: Горячая клавиша `F5`
1. Откройте эту папку в VS Code (*File $\to$ Open Folder*).
2. Нажмите клавишу **`F5`** на клавиатуре.
3. Встроенный сервер автоматически запустится и откроет игру в браузере!

### Способ 2: Горячая клавиша `Ctrl + Shift + B`
Нажмите **`Ctrl + Shift + B`** — запустится терминальная сборка через `javac` и сервер откроет игру на **http://localhost:8080**.

### Способ 3: Двойной клик по `run.bat`
Просто дважды кликните по файлу **`run.bat`** в Проводнике Windows.

---

## 📝 Как писать свой код:

Откройте файл [`src/ru/college/game/MyGame.java`](src/ru/college/game/MyGame.java) и создавайте свою игру:

```java
package ru.college.game;

import ru.college.engine.*;

public class MyGame extends Game {

    public MyGame() {
        super(800, 600);
    }

    @Override
    public void init() {
        // Установка фонового цвета игрового поля
        setBackgroundColor(new Color(24, 28, 36));

        // TODO: Добавьте инициализацию ваших игровых объектов и слушателей событий здесь
    }

    @Override
    public void update(double delta) {
        // TODO: Добавьте расчет игровой логики, физики и движения здесь
    }

    @Override
    public void render(Graphics g) {
        // Базовый стартовый экран
        g.drawText("Java Game Starter", 280, 270, 28, Color.WHITE);
        g.drawText("Начните разработку вашей игры в MyGame.java", 230, 315, 16, Color.CYAN);

        // TODO: Добавьте вашу отрисовку игровых элементов и интерфейса здесь
    }

    public static void main(String[] args) {
        launch(new MyGame());
    }
}
```
