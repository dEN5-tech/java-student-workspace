"use strict";
(function(module) {
    if (typeof define === 'function' && define.amd) {
        define(['exports'], function(exports)  {
            module(exports);
        });
    } else if (typeof exports === 'object' && exports !== null && typeof exports.nodeName !== 'string') {
        module(exports);
    } else {
        module(typeof self !== 'undefined' ? self : this);
}
}(function($rt_exports) {
let $rt_seed = 2463534242,
$rt_nextId = () => {
    let x = $rt_seed;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    $rt_seed = x;
    return x;
},
$rt_wrapFunction0 = f => function() {
    return f(this);
},
$rt_wrapFunction1 = f => function(p1) {
    return f(this, p1);
},
$rt_wrapFunction2 = f => function(p1, p2) {
    return f(this, p1, p2);
},
$rt_wrapFunction3 = f => function(p1, p2, p3) {
    return f(this, p1, p2, p3, p3);
},
$rt_wrapFunction4 = f => function(p1, p2, p3, p4) {
    return f(this, p1, p2, p3, p4);
},
$rt_mainStarter = f => (args, callback) => {
    if (!args) {
        args = [];
    }
    let javaArgs = $rt_createArray($rt_objcls(), args.length);
    for (let i = 0;i < args.length;++i) {
        javaArgs.data[i] = $rt_str(args[i]);
    }
    $rt_startThread(() => {
        f.call(null, javaArgs);
    }, callback);
},
$rt_eraseClinit = target => target.$clinit = () => {
},
$dbg_class = obj => {
    let cls = obj.constructor;
    let arrayDegree = 0;
    while (cls.$meta && cls.$meta.item) {
        ++arrayDegree;
        cls = cls.$meta.item;
    }
    let clsName = "";
    if (cls.$meta.primitive) {
        clsName = cls.$meta.name;
    } else {
        clsName = cls.$meta ? cls.$meta.name || "a/" + cls.name : "@" + cls.name;
    }
    while (arrayDegree-- > 0) {
        clsName += "[]";
    }
    return clsName;
},
$rt_classWithoutFields = superclass => {
    if (superclass === 0) {
        return function() {
        };
    }
    if (superclass === void 0) {
        superclass = $rt_objcls();
    }
    return function() {
        superclass.call(this);
    };
},
$rt_cls = cls => jl_Class_getClass(cls),
$rt_objcls = () => jl_Object,
$rt_getThread = () => {
    {
        return jl_Thread_currentThread();
    }
},
$rt_setThread = t => {
    {
        return jl_Thread_setCurrentThread(t);
    }
},
$rt_createcls = () => {
    return { $array : null, classObject : null, $meta : { supertypes : [], superclass : null } };
},
$rt_createPrimitiveCls = (name, binaryName) => {
    let cls = $rt_createcls();
    cls.$meta.primitive = true;
    cls.$meta.name = name;
    cls.$meta.binaryName = binaryName;
    cls.$meta.enum = false;
    cls.$meta.item = null;
    cls.$meta.simpleName = null;
    cls.$meta.declaringClass = null;
    cls.$meta.enclosingClass = null;
    return cls;
},
$rt_booleancls = $rt_createPrimitiveCls("boolean", "Z"),
$rt_charcls = $rt_createPrimitiveCls("char", "C"),
$rt_shortcls = $rt_createPrimitiveCls("short", "S"),
$rt_intcls = $rt_createPrimitiveCls("int", "I"),
$rt_longcls = $rt_createPrimitiveCls("long", "J"),
$rt_doublecls = $rt_createPrimitiveCls("double", "D"),
$rt_voidcls = $rt_createPrimitiveCls("void", "V"),
$rt_numberConversionBuffer = new ArrayBuffer(16),
$rt_numberConversionView = new DataView($rt_numberConversionBuffer),
$rt_numberConversionDoubleArray = new Float64Array($rt_numberConversionBuffer),
$rt_numberConversionIntArray = new Int32Array($rt_numberConversionBuffer),
$rt_doubleToRawLongBits,
$rt_longBitsToDouble;
if (typeof BigInt !== 'function') {
    $rt_doubleToRawLongBits = n => {
        $rt_numberConversionView.setFloat64(0, n, true);
        return new Long($rt_numberConversionView.getInt32(0, true), $rt_numberConversionView.getInt32(4, true));
    };
    $rt_longBitsToDouble = n => {
        $rt_numberConversionView.setInt32(0, n.lo, true);
        $rt_numberConversionView.setInt32(4, n.hi, true);
        return $rt_numberConversionView.getFloat64(0, true);
    };
} else if (typeof BigInt64Array !== 'function') {
    $rt_doubleToRawLongBits = n => {
        $rt_numberConversionView.setFloat64(0, n, true);
        let lo = $rt_numberConversionView.getInt32(0, true);
        let hi = $rt_numberConversionView.getInt32(4, true);
        return BigInt.asIntN(64, BigInt.asUintN(32, BigInt(lo)) | BigInt(hi) << BigInt(32));
    };
    $rt_longBitsToDouble = n => {
        $rt_numberConversionView.setFloat64(0, n, true);
        let lo = $rt_numberConversionView.getInt32(0, true);
        let hi = $rt_numberConversionView.getInt32(4, true);
        return BigInt.asIntN(64, BigInt.asUintN(32, BigInt(lo)) | BigInt(hi) << BigInt(32));
    };
} else {
    let $rt_numberConversionLongArray = new BigInt64Array($rt_numberConversionBuffer);
    $rt_doubleToRawLongBits = n => {
        $rt_numberConversionDoubleArray[0] = n;
        return $rt_numberConversionLongArray[0];
    };
    $rt_longBitsToDouble = n => {
        $rt_numberConversionLongArray[0] = n;
        return $rt_numberConversionDoubleArray[0];
    };
}
let $rt_equalDoubles = (a, b) => {
    if (a !== a) {
        return b !== b;
    }
    $rt_numberConversionDoubleArray[0] = a;
    $rt_numberConversionDoubleArray[1] = b;
    return $rt_numberConversionIntArray[0] === $rt_numberConversionIntArray[2] && $rt_numberConversionIntArray[1] === $rt_numberConversionIntArray[3];
},
$rt_compare = (a, b) => a > b ? 1 : a < b ?  -1 : a === b ? 0 : 1,
$rt_imul = Math.imul || function(a, b) {
    let ah = a >>> 16 & 0xFFFF;
    let al = a & 0xFFFF;
    let bh = b >>> 16 & 0xFFFF;
    let bl = b & 0xFFFF;
    return al * bl + (ah * bl + al * bh << 16 >>> 0) | 0;
},
$rt_udiv = (a, b) => (a >>> 0) / (b >>> 0) >>> 0,
$rt_umod = (a, b) => (a >>> 0) % (b >>> 0) >>> 0,
$rt_ucmp = (a, b) => {
    a >>>= 0;
    b >>>= 0;
    return a < b ?  -1 : a > b ? 1 : 0;
};
function Long(lo, hi) {
    this.lo = lo | 0;
    this.hi = hi | 0;
}
Long.prototype.__teavm_class__ = () => {
    return "long";
};
let Long_isPositive = a => (a.hi & 0x80000000) === 0,
Long_isNegative = a => (a.hi & 0x80000000) !== 0,
Long_MAX_NORMAL = 1 << 18,
Long_ZERO,
Long_create,
Long_fromInt,
Long_fromNumber,
Long_toNumber,
Long_hi,
Long_lo,
Long_divRem;
if (typeof BigInt !== "function") {
    Long.prototype.toString = function() {
        let result = [];
        let n = this;
        let positive = Long_isPositive(n);
        if (!positive) {
            n = Long_neg(n);
        }
        let radix = new Long(10, 0);
        do  {
            let divRem = Long_divRem(n, radix);
            result.push(String.fromCharCode(48 + divRem[1].lo));
            n = divRem[0];
        }while (n.lo !== 0 || n.hi !== 0);
        result = (result.reverse()).join('');
        return positive ? result : "-" + result;
    };
    Long.prototype.valueOf = function() {
        return Long_toNumber(this);
    };
    Long_ZERO = new Long(0, 0);
    Long_fromInt = val => new Long(val,  -(val < 0) | 0);
    Long_fromNumber = val => val >= 0 ? new Long(val | 0, val / 0x100000000 | 0) : Long_neg(new Long( -val | 0,  -val / 0x100000000 | 0));
    Long_create = (lo, hi) => new Long(lo, hi);
    Long_toNumber = val => 0x100000000 * val.hi + (val.lo >>> 0);
    Long_hi = val => val.hi;
    Long_lo = val => val.lo;
} else {
    Long_ZERO = BigInt(0);
    Long_create = (lo, hi) => BigInt.asIntN(64, BigInt.asUintN(64, BigInt(lo)) | BigInt.asUintN(64, BigInt(hi) << BigInt(32)));
    Long_fromInt = val => BigInt.asIntN(64, BigInt(val | 0));
    Long_fromNumber = val => BigInt.asIntN(64, BigInt(val >= 0 ? Math.floor(val) : Math.ceil(val)));
    Long_toNumber = val => Number(val);
    Long_hi = val => Number(BigInt.asIntN(64, val >> BigInt(32))) | 0;
    Long_lo = val => Number(BigInt.asIntN(32, val)) | 0;
}
let Long_eq,
Long_ne,
Long_gt,
Long_ge,
Long_lt,
Long_le,
Long_compare,
Long_ucompare,
Long_add,
Long_sub,
Long_inc,
Long_mul,
Long_div,
Long_rem,
Long_udiv,
Long_urem,
Long_neg,
Long_and,
Long_or,
Long_xor,
Long_shl,
Long_shr,
Long_shru;
if (typeof BigInt !== 'function') {
    Long_eq = (a, b) => a.hi === b.hi && a.lo === b.lo;
    Long_ne = (a, b) => a.hi !== b.hi || a.lo !== b.lo;
    Long_gt = (a, b) => {
        if (a.hi < b.hi) {
            return false;
        }
        if (a.hi > b.hi) {
            return true;
        }
        let x = a.lo >>> 1;
        let y = b.lo >>> 1;
        if (x !== y) {
            return x > y;
        }
        return (a.lo & 1) > (b.lo & 1);
    };
    Long_ge = (a, b) => {
        if (a.hi < b.hi) {
            return false;
        }
        if (a.hi > b.hi) {
            return true;
        }
        let x = a.lo >>> 1;
        let y = b.lo >>> 1;
        if (x !== y) {
            return x >= y;
        }
        return (a.lo & 1) >= (b.lo & 1);
    };
    Long_lt = (a, b) => {
        if (a.hi > b.hi) {
            return false;
        }
        if (a.hi < b.hi) {
            return true;
        }
        let x = a.lo >>> 1;
        let y = b.lo >>> 1;
        if (x !== y) {
            return x < y;
        }
        return (a.lo & 1) < (b.lo & 1);
    };
    Long_le = (a, b) => {
        if (a.hi > b.hi) {
            return false;
        }
        if (a.hi < b.hi) {
            return true;
        }
        let x = a.lo >>> 1;
        let y = b.lo >>> 1;
        if (x !== y) {
            return x <= y;
        }
        return (a.lo & 1) <= (b.lo & 1);
    };
    Long_add = (a, b) => {
        if (a.hi === a.lo >> 31 && b.hi === b.lo >> 31) {
            return Long_fromNumber(a.lo + b.lo);
        } else if (Math.abs(a.hi) < Long_MAX_NORMAL && Math.abs(b.hi) < Long_MAX_NORMAL) {
            return Long_fromNumber(Long_toNumber(a) + Long_toNumber(b));
        }
        let a_lolo = a.lo & 0xFFFF;
        let a_lohi = a.lo >>> 16;
        let a_hilo = a.hi & 0xFFFF;
        let a_hihi = a.hi >>> 16;
        let b_lolo = b.lo & 0xFFFF;
        let b_lohi = b.lo >>> 16;
        let b_hilo = b.hi & 0xFFFF;
        let b_hihi = b.hi >>> 16;
        let lolo = a_lolo + b_lolo | 0;
        let lohi = a_lohi + b_lohi + (lolo >> 16) | 0;
        let hilo = a_hilo + b_hilo + (lohi >> 16) | 0;
        let hihi = a_hihi + b_hihi + (hilo >> 16) | 0;
        return new Long(lolo & 0xFFFF | (lohi & 0xFFFF) << 16, hilo & 0xFFFF | (hihi & 0xFFFF) << 16);
    };
    Long_inc = a => {
        let lo = a.lo + 1 | 0;
        let hi = a.hi;
        if (lo === 0) {
            hi = hi + 1 | 0;
        }
        return new Long(lo, hi);
    };
    Long_neg = a => Long_inc(new Long(a.lo ^ 0xFFFFFFFF, a.hi ^ 0xFFFFFFFF));
    Long_sub = (a, b) => {
        if (a.hi === a.lo >> 31 && b.hi === b.lo >> 31) {
            return Long_fromNumber(a.lo - b.lo);
        }
        let a_lolo = a.lo & 0xFFFF;
        let a_lohi = a.lo >>> 16;
        let a_hilo = a.hi & 0xFFFF;
        let a_hihi = a.hi >>> 16;
        let b_lolo = b.lo & 0xFFFF;
        let b_lohi = b.lo >>> 16;
        let b_hilo = b.hi & 0xFFFF;
        let b_hihi = b.hi >>> 16;
        let lolo = a_lolo - b_lolo | 0;
        let lohi = a_lohi - b_lohi + (lolo >> 16) | 0;
        let hilo = a_hilo - b_hilo + (lohi >> 16) | 0;
        let hihi = a_hihi - b_hihi + (hilo >> 16) | 0;
        return new Long(lolo & 0xFFFF | (lohi & 0xFFFF) << 16, hilo & 0xFFFF | (hihi & 0xFFFF) << 16);
    };
    Long_compare = (a, b) => {
        let r = a.hi - b.hi;
        if (r !== 0) {
            return r;
        }
        r = (a.lo >>> 1) - (b.lo >>> 1);
        if (r !== 0) {
            return r;
        }
        return (a.lo & 1) - (b.lo & 1);
    };
    Long_ucompare = (a, b) => {
        let r = $rt_ucmp(a.hi, b.hi);
        if (r !== 0) {
            return r;
        }
        r = (a.lo >>> 1) - (b.lo >>> 1);
        if (r !== 0) {
            return r;
        }
        return (a.lo & 1) - (b.lo & 1);
    };
    Long_mul = (a, b) => {
        let positive = Long_isNegative(a) === Long_isNegative(b);
        if (Long_isNegative(a)) {
            a = Long_neg(a);
        }
        if (Long_isNegative(b)) {
            b = Long_neg(b);
        }
        let a_lolo = a.lo & 0xFFFF;
        let a_lohi = a.lo >>> 16;
        let a_hilo = a.hi & 0xFFFF;
        let a_hihi = a.hi >>> 16;
        let b_lolo = b.lo & 0xFFFF;
        let b_lohi = b.lo >>> 16;
        let b_hilo = b.hi & 0xFFFF;
        let b_hihi = b.hi >>> 16;
        let lolo = 0;
        let lohi = 0;
        let hilo = 0;
        let hihi = 0;
        lolo = a_lolo * b_lolo | 0;
        lohi = lolo >>> 16;
        lohi = (lohi & 0xFFFF) + a_lohi * b_lolo | 0;
        hilo = hilo + (lohi >>> 16) | 0;
        lohi = (lohi & 0xFFFF) + a_lolo * b_lohi | 0;
        hilo = hilo + (lohi >>> 16) | 0;
        hihi = hilo >>> 16;
        hilo = (hilo & 0xFFFF) + a_hilo * b_lolo | 0;
        hihi = hihi + (hilo >>> 16) | 0;
        hilo = (hilo & 0xFFFF) + a_lohi * b_lohi | 0;
        hihi = hihi + (hilo >>> 16) | 0;
        hilo = (hilo & 0xFFFF) + a_lolo * b_hilo | 0;
        hihi = hihi + (hilo >>> 16) | 0;
        hihi = hihi + a_hihi * b_lolo + a_hilo * b_lohi + a_lohi * b_hilo + a_lolo * b_hihi | 0;
        let result = new Long(lolo & 0xFFFF | lohi << 16, hilo & 0xFFFF | hihi << 16);
        return positive ? result : Long_neg(result);
    };
    Long_div = (a, b) => {
        if (Math.abs(a.hi) < Long_MAX_NORMAL && Math.abs(b.hi) < Long_MAX_NORMAL) {
            return Long_fromNumber(Long_toNumber(a) / Long_toNumber(b));
        }
        return (Long_divRem(a, b))[0];
    };
    Long_udiv = (a, b) => {
        if (a.hi >= 0 && a.hi < Long_MAX_NORMAL && b.hi >= 0 && b.hi < Long_MAX_NORMAL) {
            return Long_fromNumber(Long_toNumber(a) / Long_toNumber(b));
        }
        return (Long_udivRem(a, b))[0];
    };
    Long_rem = (a, b) => {
        if (Math.abs(a.hi) < Long_MAX_NORMAL && Math.abs(b.hi) < Long_MAX_NORMAL) {
            return Long_fromNumber(Long_toNumber(a) % Long_toNumber(b));
        }
        return (Long_divRem(a, b))[1];
    };
    Long_urem = (a, b) => {
        if (a.hi >= 0 && a.hi < Long_MAX_NORMAL && b.hi >= 0 && b.hi < Long_MAX_NORMAL) {
            return Long_fromNumber(Long_toNumber(a) / Long_toNumber(b));
        }
        return (Long_udivRem(a, b))[1];
    };
    Long_divRem = (a, b) => {
        if (b.lo === 0 && b.hi === 0) {
            throw new Error("Division by zero");
        }
        let positive = Long_isNegative(a) === Long_isNegative(b);
        if (Long_isNegative(a)) {
            a = Long_neg(a);
        }
        if (Long_isNegative(b)) {
            b = Long_neg(b);
        }
        a = new LongInt(a.lo, a.hi, 0);
        b = new LongInt(b.lo, b.hi, 0);
        let q = LongInt_div(a, b);
        a = new Long(a.lo, a.hi);
        q = new Long(q.lo, q.hi);
        return positive ? [q, a] : [Long_neg(q), Long_neg(a)];
    };
    let Long_udivRem = (a, b) => {
        if (b.lo === 0 && b.hi === 0) {
            throw new Error("Division by zero");
        }
        a = new LongInt(a.lo, a.hi, 0);
        b = new LongInt(b.lo, b.hi, 0);
        let q = LongInt_div(a, b);
        a = new Long(a.lo, a.hi);
        q = new Long(q.lo, q.hi);
        return [q, a];
    };
    Long_and = (a, b) => new Long(a.lo & b.lo, a.hi & b.hi);
    Long_or = (a, b) => new Long(a.lo | b.lo, a.hi | b.hi);
    Long_xor = (a, b) => new Long(a.lo ^ b.lo, a.hi ^ b.hi);
    Long_shl = (a, b) => {
        b &= 63;
        if (b === 0) {
            return a;
        } else if (b < 32) {
            return new Long(a.lo << b, a.lo >>> 32 - b | a.hi << b);
        } else if (b === 32) {
            return new Long(0, a.lo);
        } else {
            return new Long(0, a.lo << b - 32);
        }
    };
    Long_shr = (a, b) => {
        b &= 63;
        if (b === 0) {
            return a;
        } else if (b < 32) {
            return new Long(a.lo >>> b | a.hi << 32 - b, a.hi >> b);
        } else if (b === 32) {
            return new Long(a.hi, a.hi >> 31);
        } else {
            return new Long(a.hi >> b - 32, a.hi >> 31);
        }
    };
    Long_shru = (a, b) => {
        b &= 63;
        if (b === 0) {
            return a;
        } else if (b < 32) {
            return new Long(a.lo >>> b | a.hi << 32 - b, a.hi >>> b);
        } else if (b === 32) {
            return new Long(a.hi, 0);
        } else {
            return new Long(a.hi >>> b - 32, 0);
        }
    };
    function LongInt(lo, hi, sup) {
        this.lo = lo;
        this.hi = hi;
        this.sup = sup;
    }
    let LongInt_mul = (a, b) => {
        let a_lolo = (a.lo & 0xFFFF) * b | 0;
        let a_lohi = (a.lo >>> 16) * b | 0;
        let a_hilo = (a.hi & 0xFFFF) * b | 0;
        let a_hihi = (a.hi >>> 16) * b | 0;
        let sup = a.sup * b | 0;
        a_lohi = a_lohi + (a_lolo >>> 16) | 0;
        a_hilo = a_hilo + (a_lohi >>> 16) | 0;
        a_hihi = a_hihi + (a_hilo >>> 16) | 0;
        sup = sup + (a_hihi >>> 16) | 0;
        a.lo = a_lolo & 0xFFFF | a_lohi << 16;
        a.hi = a_hilo & 0xFFFF | a_hihi << 16;
        a.sup = sup & 0xFFFF;
    };
    let LongInt_sub = (a, b) => {
        let a_lolo = a.lo & 0xFFFF;
        let a_lohi = a.lo >>> 16;
        let a_hilo = a.hi & 0xFFFF;
        let a_hihi = a.hi >>> 16;
        let b_lolo = b.lo & 0xFFFF;
        let b_lohi = b.lo >>> 16;
        let b_hilo = b.hi & 0xFFFF;
        let b_hihi = b.hi >>> 16;
        a_lolo = a_lolo - b_lolo | 0;
        a_lohi = a_lohi - b_lohi + (a_lolo >> 16) | 0;
        a_hilo = a_hilo - b_hilo + (a_lohi >> 16) | 0;
        a_hihi = a_hihi - b_hihi + (a_hilo >> 16) | 0;
        let sup = a.sup - b.sup + (a_hihi >> 16) | 0;
        a.lo = a_lolo & 0xFFFF | a_lohi << 16;
        a.hi = a_hilo & 0xFFFF | a_hihi << 16;
        a.sup = sup;
    };
    let LongInt_add = (a, b) => {
        let a_lolo = a.lo & 0xFFFF;
        let a_lohi = a.lo >>> 16;
        let a_hilo = a.hi & 0xFFFF;
        let a_hihi = a.hi >>> 16;
        let b_lolo = b.lo & 0xFFFF;
        let b_lohi = b.lo >>> 16;
        let b_hilo = b.hi & 0xFFFF;
        let b_hihi = b.hi >>> 16;
        a_lolo = a_lolo + b_lolo | 0;
        a_lohi = a_lohi + b_lohi + (a_lolo >> 16) | 0;
        a_hilo = a_hilo + b_hilo + (a_lohi >> 16) | 0;
        a_hihi = a_hihi + b_hihi + (a_hilo >> 16) | 0;
        let sup = a.sup + b.sup + (a_hihi >> 16) | 0;
        a.lo = a_lolo & 0xFFFF | a_lohi << 16;
        a.hi = a_hilo & 0xFFFF | a_hihi << 16;
        a.sup = sup;
    };
    let LongInt_ucompare = (a, b) => {
        let r = a.sup - b.sup;
        if (r !== 0) {
            return r;
        }
        r = (a.hi >>> 1) - (b.hi >>> 1);
        if (r !== 0) {
            return r;
        }
        r = (a.hi & 1) - (b.hi & 1);
        if (r !== 0) {
            return r;
        }
        r = (a.lo >>> 1) - (b.lo >>> 1);
        if (r !== 0) {
            return r;
        }
        return (a.lo & 1) - (b.lo & 1);
    };
    let LongInt_numOfLeadingZeroBits = a => {
        let n = 0;
        let d = 16;
        while (d > 0) {
            if (a >>> d !== 0) {
                a >>>= d;
                n = n + d | 0;
            }
            d = d / 2 | 0;
        }
        return 31 - n;
    };
    let LongInt_shl = (a, b) => {
        if (b === 0) {
            return;
        }
        if (b < 32) {
            a.sup = (a.hi >>> 32 - b | a.sup << b) & 0xFFFF;
            a.hi = a.lo >>> 32 - b | a.hi << b;
            a.lo <<= b;
        } else if (b === 32) {
            a.sup = a.hi & 0xFFFF;
            a.hi = a.lo;
            a.lo = 0;
        } else if (b < 64) {
            a.sup = (a.lo >>> 64 - b | a.hi << b - 32) & 0xFFFF;
            a.hi = a.lo << b;
            a.lo = 0;
        } else if (b === 64) {
            a.sup = a.lo & 0xFFFF;
            a.hi = 0;
            a.lo = 0;
        } else {
            a.sup = a.lo << b - 64 & 0xFFFF;
            a.hi = 0;
            a.lo = 0;
        }
    };
    let LongInt_shr = (a, b) => {
        if (b === 0) {
            return;
        }
        if (b === 32) {
            a.lo = a.hi;
            a.hi = a.sup;
            a.sup = 0;
        } else if (b < 32) {
            a.lo = a.lo >>> b | a.hi << 32 - b;
            a.hi = a.hi >>> b | a.sup << 32 - b;
            a.sup >>>= b;
        } else if (b === 64) {
            a.lo = a.sup;
            a.hi = 0;
            a.sup = 0;
        } else if (b < 64) {
            a.lo = a.hi >>> b - 32 | a.sup << 64 - b;
            a.hi = a.sup >>> b - 32;
            a.sup = 0;
        } else {
            a.lo = a.sup >>> b - 64;
            a.hi = 0;
            a.sup = 0;
        }
    };
    let LongInt_copy = a => new LongInt(a.lo, a.hi, a.sup);
    let LongInt_div = (a, b) => {
        let bits = b.hi !== 0 ? LongInt_numOfLeadingZeroBits(b.hi) : LongInt_numOfLeadingZeroBits(b.lo) + 32;
        let sz = 1 + (bits / 16 | 0);
        let dividentBits = bits % 16;
        LongInt_shl(b, bits);
        LongInt_shl(a, dividentBits);
        let q = new LongInt(0, 0, 0);
        while (sz-- > 0) {
            LongInt_shl(q, 16);
            let digitA = (a.hi >>> 16) + 0x10000 * a.sup;
            let digitB = b.hi >>> 16;
            let digit = digitA / digitB | 0;
            let t = LongInt_copy(b);
            LongInt_mul(t, digit);
            if (LongInt_ucompare(t, a) >= 0) {
                while (LongInt_ucompare(t, a) > 0) {
                    LongInt_sub(t, b);
                     --digit;
                }
            } else {
                while (true) {
                    let nextT = LongInt_copy(t);
                    LongInt_add(nextT, b);
                    if (LongInt_ucompare(nextT, a) > 0) {
                        break;
                    }
                    t = nextT;
                    ++digit;
                }
            }
            LongInt_sub(a, t);
            q.lo |= digit;
            LongInt_shl(a, 16);
        }
        LongInt_shr(a, bits + 16);
        return q;
    };
} else {
    Long_eq = (a, b) => a === b;
    Long_ne = (a, b) => a !== b;
    Long_gt = (a, b) => a > b;
    Long_ge = (a, b) => a >= b;
    Long_lt = (a, b) => a < b;
    Long_le = (a, b) => a <= b;
    Long_add = (a, b) => BigInt.asIntN(64, a + b);
    Long_inc = a => BigInt.asIntN(64, a + 1);
    Long_neg = a => BigInt.asIntN(64,  -a);
    Long_sub = (a, b) => BigInt.asIntN(64, a - b);
    Long_compare = (a, b) => a < b ?  -1 : a > b ? 1 : 0;
    Long_ucompare = (a, b) => {
        a = BigInt.asUintN(64, a);
        b = BigInt.asUintN(64, b);
        return a < b ?  -1 : a > b ? 1 : 0;
    };
    Long_mul = (a, b) => BigInt.asIntN(64, a * b);
    Long_div = (a, b) => BigInt.asIntN(64, a / b);
    Long_udiv = (a, b) => BigInt.asIntN(64, BigInt.asUintN(64, a) / BigInt.asUintN(64, b));
    Long_rem = (a, b) => BigInt.asIntN(64, a % b);
    Long_urem = (a, b) => BigInt.asIntN(64, BigInt.asUintN(64, a) % BigInt.asUintN(64, b));
    Long_and = (a, b) => BigInt.asIntN(64, a & b);
    Long_or = (a, b) => BigInt.asIntN(64, a | b);
    Long_xor = (a, b) => BigInt.asIntN(64, a ^ b);
    Long_shl = (a, b) => BigInt.asIntN(64, a << BigInt(b & 63));
    Long_shr = (a, b) => BigInt.asIntN(64, a >> BigInt(b & 63));
    Long_shru = (a, b) => BigInt.asIntN(64, BigInt.asUintN(64, a) >> BigInt(b & 63));
}
let $rt_createArray = (cls, sz) => {
    let data = new Array(sz);
    data.fill(null);
    return new ($rt_arraycls(cls))(data);
},
$rt_wrapArray = (cls, data) => new ($rt_arraycls(cls))(data),
$rt_createLongArray,
$rt_createLongArrayFromData;
if (typeof BigInt64Array !== 'function') {
    $rt_createLongArray = sz => {
        let data = new Array(sz);
        let arr = new $rt_longArrayCls(data);
        data.fill(Long_ZERO);
        return arr;
    };
    $rt_createLongArrayFromData = init => new $rt_longArrayCls(init);
} else {
    $rt_createLongArray = sz => new $rt_longArrayCls(new BigInt64Array(sz));
    $rt_createLongArrayFromData = data => {
        let buffer = new BigInt64Array(data.length);
        buffer.set(data);
        return new $rt_longArrayCls(buffer);
    };
}
let $rt_createCharArray = sz => new $rt_charArrayCls(new Uint16Array(sz)),
$rt_createShortArray = sz => new $rt_shortArrayCls(new Int16Array(sz)),
$rt_createShortArrayFromData = data => {
    let buffer = new Int16Array(data.length);
    buffer.set(data);
    return new $rt_shortArrayCls(buffer);
},
$rt_createIntArray = sz => new $rt_intArrayCls(new Int32Array(sz)),
$rt_createIntArrayFromData = data => {
    let buffer = new Int32Array(data.length);
    buffer.set(data);
    return new $rt_intArrayCls(buffer);
},
$rt_createBooleanArray = sz => new $rt_booleanArrayCls(new Int8Array(sz)),
$rt_arraycls = cls => {
    let result = cls.$array;
    if (result === null) {
        function JavaArray(data) {
            ($rt_objcls()).call(this);
            this.data = data;
        }
        JavaArray.prototype = Object.create(($rt_objcls()).prototype);
        JavaArray.prototype.type = cls;
        JavaArray.prototype.constructor = JavaArray;
        JavaArray.prototype.toString = function() {
            let str = "[";
            for (let i = 0;i < this.data.length;++i) {
                if (i > 0) {
                    str += ", ";
                }
                str += this.data[i].toString();
            }
            str += "]";
            return str;
        };
        JavaArray.prototype.$clone0 = function() {
            let dataCopy;
            if ('slice' in this.data) {
                dataCopy = this.data.slice();
            } else {
                dataCopy = new this.data.constructor(this.data.length);
                for (let i = 0;i < dataCopy.length;++i) {
                    dataCopy[i] = this.data[i];
                }
            }
            return new ($rt_arraycls(this.type))(dataCopy);
        };
        let name = "[" + cls.$meta.binaryName;
        JavaArray.$meta = { item : cls, supertypes : [$rt_objcls()], primitive : false, superclass : $rt_objcls(), name : name, binaryName : name, enum : false, simpleName : null, declaringClass : null, enclosingClass : null };
        JavaArray.classObject = null;
        JavaArray.$array = null;
        result = JavaArray;
        cls.$array = JavaArray;
    }
    return result;
},
$rt_stringPool_instance,
$rt_stringPool = strings => {
    $rt_stringClassInit();
    $rt_stringPool_instance = new Array(strings.length);
    for (let i = 0;i < strings.length;++i) {
        $rt_stringPool_instance[i] = $rt_intern($rt_str(strings[i]));
    }
},
$rt_s = index => $rt_stringPool_instance[index],
$rt_charArrayToString = (array, offset, count) => {
    let result = "";
    let limit = offset + count;
    for (let i = offset;i < limit;i = i + 1024 | 0) {
        let next = Math.min(limit, i + 1024 | 0);
        result += String.fromCharCode.apply(null, array.subarray(i, next));
    }
    return result;
},
$rt_str = str => str === null ? null : jl_String__init_2(str),
$rt_ustr = str => str === null ? null : str.$nativeString,
$rt_stringClassInit = () => jl_String_$callClinit(),
$rt_intern;
{
    $rt_intern = str => str;
}
let $rt_isInstance = (obj, cls) => obj instanceof $rt_objcls() && !!obj.constructor.$meta && $rt_isAssignable(obj.constructor, cls),
$rt_isAssignable = (from, to) => {
    if (from === to) {
        return true;
    }
    let map = from.$meta.assignableCache;
    if (typeof map === 'undefined') {
        map = new Map();
        from.$meta.assignableCache = map;
    }
    let cachedResult = map.get(to);
    if (typeof cachedResult !== 'undefined') {
        return cachedResult;
    }
    if (to.$meta.item !== null) {
        let result = from.$meta.item !== null && $rt_isAssignable(from.$meta.item, to.$meta.item);
        map.set(to, result);
        return result;
    }
    let supertypes = from.$meta.supertypes;
    for (let i = 0;i < supertypes.length;i = i + 1 | 0) {
        if ($rt_isAssignable(supertypes[i], to)) {
            map.set(to, true);
            return true;
        }
    }
    map.set(to, false);
    return false;
},
$rt_throw = ex => {
    throw $rt_exception(ex);
},
$rt_javaExceptionProp = Symbol("javaException"),
$rt_exception = ex => {
    let err = ex.$jsException;
    if (!err) {
        let javaCause = $rt_throwableCause(ex);
        let jsCause = javaCause !== null ? javaCause.$jsException : void 0;
        let cause = typeof jsCause === "object" ? { cause : jsCause } : void 0;
        err = new JavaError("Java exception thrown", cause);
        if (typeof Error.captureStackTrace === "function") {
            Error.captureStackTrace(err);
        }
        err[$rt_javaExceptionProp] = ex;
        ex.$jsException = err;
        $rt_fillStack(err, ex);
    }
    return err;
},
$rt_fillStack = (err, ex) => {
    if (typeof $rt_decodeStack === "function" && err.stack) {
        let stack = $rt_decodeStack(err.stack);
        let javaStack = $rt_createArray($rt_stecls(), stack.length);
        let elem;
        let noStack = false;
        for (let i = 0;i < stack.length;++i) {
            let element = stack[i];
            elem = $rt_createStackElement($rt_str(element.className), $rt_str(element.methodName), $rt_str(element.fileName), element.lineNumber);
            if (elem == null) {
                noStack = true;
                break;
            }
            javaStack.data[i] = elem;
        }
        if (!noStack) {
            $rt_setStack(ex, javaStack);
        }
    }
},
JavaError;
if (typeof Reflect === 'object') {
    let defaultMessage = Symbol("defaultMessage");
    JavaError = function JavaError(message, cause) {
        let self = Reflect.construct(Error, [void 0, cause], JavaError);
        Object.setPrototypeOf(self, JavaError.prototype);
        self[defaultMessage] = message;
        return self;
    }
    ;
    JavaError.prototype = Object.create(Error.prototype, { constructor : { configurable : true, writable : true, value : JavaError }, message : { get() {
        try {
            let javaException = this[$rt_javaExceptionProp];
            if (typeof javaException === 'object') {
                let javaMessage = $rt_throwableMessage(javaException);
                if (typeof javaMessage === "object") {
                    return javaMessage !== null ? javaMessage.toString() : null;
                }
            }
            return this[defaultMessage];
        } catch (e){
            return "Exception occurred trying to extract Java exception message: " + e;
        }
    } } });
} else {
    JavaError = Error;
}
let $rt_javaException = e => e instanceof Error && typeof e[$rt_javaExceptionProp] === 'object' ? e[$rt_javaExceptionProp] : null,
$rt_wrapException = err => {
    let ex = err[$rt_javaExceptionProp];
    if (!ex) {
        ex = $rt_createException($rt_str("(JavaScript) " + err.toString()));
        err[$rt_javaExceptionProp] = ex;
        ex.$jsException = err;
        $rt_fillStack(err, ex);
    }
    return ex;
},
$rt_createException = message => jl_RuntimeException__init_1(message),
$rt_throwableMessage = t => jl_Throwable_getMessage(t),
$rt_throwableCause = t => jl_Throwable_getCause(t),
$rt_stecls = () => jl_StackTraceElement,
$rt_createStackElement = (className, methodName, fileName, lineNumber) => {
    {
        return null;
    }
},
$rt_setStack = (e, stack) => {
},
$rt_packageData = null,
$rt_packages = data => {
    let i = 0;
    let packages = new Array(data.length);
    for (let j = 0;j < data.length;++j) {
        let prefixIndex = data[i++];
        let prefix = prefixIndex >= 0 ? packages[prefixIndex] : "";
        packages[j] = prefix + data[i++] + ".";
    }
    $rt_packageData = packages;
},
$rt_metadata = data => {
    let packages = $rt_packageData;
    let i = 0;
    while (i < data.length) {
        let cls = data[i++];
        cls.$meta = {  };
        let m = cls.$meta;
        let className = data[i++];
        m.name = className !== 0 ? className : null;
        if (m.name !== null) {
            let packageIndex = data[i++];
            if (packageIndex >= 0) {
                m.name = packages[packageIndex] + m.name;
            }
        }
        m.binaryName = "L" + m.name + ";";
        let superclass = data[i++];
        m.superclass = superclass !== 0 ? superclass : null;
        m.supertypes = data[i++];
        if (m.superclass) {
            m.supertypes.push(m.superclass);
            cls.prototype = Object.create(m.superclass.prototype);
        } else {
            cls.prototype = {  };
        }
        let flags = data[i++];
        m.enum = (flags & 8) !== 0;
        m.flags = flags;
        m.primitive = false;
        m.item = null;
        cls.prototype.constructor = cls;
        cls.classObject = null;
        m.accessLevel = data[i++];
        let innerClassInfo = data[i++];
        if (innerClassInfo === 0) {
            m.simpleName = null;
            m.declaringClass = null;
            m.enclosingClass = null;
        } else {
            let enclosingClass = innerClassInfo[0];
            m.enclosingClass = enclosingClass !== 0 ? enclosingClass : null;
            let declaringClass = innerClassInfo[1];
            m.declaringClass = declaringClass !== 0 ? declaringClass : null;
            let simpleName = innerClassInfo[2];
            m.simpleName = simpleName !== 0 ? simpleName : null;
        }
        let clinit = data[i++];
        cls.$clinit = clinit !== 0 ? clinit : function() {
        };
        let virtualMethods = data[i++];
        if (virtualMethods !== 0) {
            for (let j = 0;j < virtualMethods.length;j += 2) {
                let name = virtualMethods[j];
                let func = virtualMethods[j + 1];
                if (typeof name === 'string') {
                    name = [name];
                }
                for (let k = 0;k < name.length;++k) {
                    cls.prototype[name[k]] = func;
                }
            }
        }
        cls.$array = null;
    }
};
function TeaVMThread(runner) {
    this.status = 3;
    this.stack = [];
    this.suspendCallback = null;
    this.runner = runner;
    this.attribute = null;
    this.completeCallback = null;
}
TeaVMThread.prototype.push = function() {
    for (let i = 0;i < arguments.length;++i) {
        this.stack.push(arguments[i]);
    }
    return this;
};
TeaVMThread.prototype.s = TeaVMThread.prototype.push;
TeaVMThread.prototype.pop = function() {
    return this.stack.pop();
};
TeaVMThread.prototype.l = TeaVMThread.prototype.pop;
TeaVMThread.prototype.isResuming = function() {
    return this.status === 2;
};
TeaVMThread.prototype.isSuspending = function() {
    return this.status === 1;
};
TeaVMThread.prototype.suspend = function(callback) {
    this.suspendCallback = callback;
    this.status = 1;
};
TeaVMThread.prototype.start = function(callback) {
    if (this.status !== 3) {
        throw new Error("Thread already started");
    }
    if ($rt_currentNativeThread !== null) {
        throw new Error("Another thread is running");
    }
    this.status = 0;
    this.completeCallback = callback ? callback : result => {
        if (result instanceof Error) {
            throw result;
        }
    };
    this.run();
};
TeaVMThread.prototype.resume = function() {
    if ($rt_currentNativeThread !== null) {
        throw new Error("Another thread is running");
    }
    this.status = 2;
    this.run();
};
TeaVMThread.prototype.run = function() {
    $rt_currentNativeThread = this;
    let result;
    try {
        result = this.runner();
    } catch (e){
        result = e;
    } finally {
        $rt_currentNativeThread = null;
    }
    if (this.suspendCallback !== null) {
        let self = this;
        let callback = this.suspendCallback;
        this.suspendCallback = null;
        callback(() => self.resume());
    } else if (this.status === 0) {
        this.completeCallback(result);
    }
};
let $rt_suspending = () => {
    let thread = $rt_nativeThread();
    return thread != null && thread.isSuspending();
},
$rt_resuming = () => {
    let thread = $rt_nativeThread();
    return thread != null && thread.isResuming();
},
$rt_startThread = (runner, callback) => (new TeaVMThread(runner)).start(callback),
$rt_currentNativeThread = null,
$rt_nativeThread = () => $rt_currentNativeThread,
$rt_invalidPointer = () => {
    throw new Error("Invalid recorded state");
};
function jl_Object() {
    this.$monitor = null;
    this.$id$ = 0;
}
let jl_Object_monitorEnterSync = $o => {
    let var$2;
    if ($o.$monitor === null)
        jl_Object_createMonitor($o);
    if ($o.$monitor.$owner === null)
        $o.$monitor.$owner = jl_Thread_currentThread();
    else if ($o.$monitor.$owner !== jl_Thread_currentThread())
        $rt_throw(jl_IllegalStateException__init_2($rt_s(0)));
    var$2 = $o.$monitor;
    var$2.$count = var$2.$count + 1 | 0;
},
jl_Object_monitorExitSync = $o => {
    let var$2, var$3;
    if (!jl_Object_isEmptyMonitor($o) && $o.$monitor.$owner === jl_Thread_currentThread()) {
        var$2 = $o.$monitor;
        var$3 = var$2.$count - 1 | 0;
        var$2.$count = var$3;
        if (!var$3)
            $o.$monitor.$owner = null;
        jl_Object_isEmptyMonitor($o);
        return;
    }
    $rt_throw(jl_IllegalMonitorStateException__init_0());
},
jl_Object_monitorEnter0 = $o => {
    jl_Object_monitorEnter($o, 1);
},
jl_Object_monitorEnter = ($o, $count) => {
    let var$3, $ptr, $tmp;
    $ptr = 0;
    if ($rt_resuming()) {
        let $thread = $rt_nativeThread();
        $ptr = $thread.pop();var$3 = $thread.pop();$count = $thread.pop();$o = $thread.pop();
    }
    main: while (true) { switch ($ptr) {
    case 0:
        if ($o.$monitor === null)
            jl_Object_createMonitor($o);
        if ($o.$monitor.$owner === null)
            $o.$monitor.$owner = jl_Thread_currentThread();
        if ($o.$monitor.$owner === jl_Thread_currentThread()) {
            var$3 = $o.$monitor;
            var$3.$count = var$3.$count + $count | 0;
            return;
        }
        $ptr = 1;
    case 1:
        jl_Object_monitorEnterWait($o, $count);
        if ($rt_suspending()) {
            break main;
        }
        return;
    default: $rt_invalidPointer();
    }}
    $rt_nativeThread().push($o, $count, var$3, $ptr);
},
jl_Object_createMonitor = $o => {
    $o.$monitor = jl_Object$Monitor__init_0();
},
jl_Object_monitorEnterWait = (var$1, var$2) => {
    let $ptr, $tmp;
    $ptr = 0;
    if ($rt_resuming()) {
        let $thread = $rt_nativeThread();
        $ptr = $thread.pop();var$2 = $thread.pop();var$1 = $thread.pop();
    }
    main: while (true) { switch ($ptr) {
    case 0:
        $ptr = 1;
    case 1:
        jl_Object_monitorEnterWait$_asyncCall_$(var$1, var$2);
        if ($rt_suspending()) {
            break main;
        }
        return;
    default: $rt_invalidPointer();
    }}
    $rt_nativeThread().push(var$1, var$2, $ptr);
},
jl_Object_monitorEnterWait0 = ($o, $count, $callback) => {
    let $thread_0, var$5, $monitor;
    $thread_0 = jl_Thread_currentThread();
    if ($o.$monitor === null) {
        jl_Object_createMonitor($o);
        jl_Thread_setCurrentThread($thread_0);
        var$5 = $o.$monitor;
        var$5.$count = var$5.$count + $count | 0;
        $callback.$complete(null);
        return;
    }
    if ($o.$monitor.$owner === null) {
        $o.$monitor.$owner = $thread_0;
        jl_Thread_setCurrentThread($thread_0);
        var$5 = $o.$monitor;
        var$5.$count = var$5.$count + $count | 0;
        $callback.$complete(null);
        return;
    }
    $monitor = $o.$monitor;
    if ($monitor.$enteringThreads === null)
        $monitor.$enteringThreads = otp_Platform_createQueue();
    otp_PlatformQueue_add$static($monitor.$enteringThreads, jl_Object$monitorEnterWait$lambda$_6_0__init_0($thread_0, $o, $count, $callback));
},
jl_Object_monitorExit0 = $o => {
    jl_Object_monitorExit($o, 1);
},
jl_Object_monitorExit = ($o, $count) => {
    let $monitor;
    if (!jl_Object_isEmptyMonitor($o) && $o.$monitor.$owner === jl_Thread_currentThread()) {
        $monitor = $o.$monitor;
        $monitor.$count = $monitor.$count - $count | 0;
        if ($monitor.$count > 0)
            return;
        $monitor.$owner = null;
        if ($monitor.$enteringThreads !== null && !otp_PlatformQueue_isEmpty$static($monitor.$enteringThreads))
            otp_Platform_postpone(jl_Object$monitorExit$lambda$_8_0__init_0($o));
        else
            jl_Object_isEmptyMonitor($o);
        return;
    }
    $rt_throw(jl_IllegalMonitorStateException__init_0());
},
jl_Object_waitForOtherThreads = $o => {
    let $monitor, $enteringThreads, $r;
    if (!jl_Object_isEmptyMonitor($o) && $o.$monitor.$owner === null) {
        $monitor = $o.$monitor;
        if ($monitor.$enteringThreads !== null && !otp_PlatformQueue_isEmpty$static($monitor.$enteringThreads)) {
            $enteringThreads = $monitor.$enteringThreads;
            $r = otp_PlatformQueue_remove$static($enteringThreads);
            $monitor.$enteringThreads = null;
            $r.$run();
        }
        return;
    }
},
jl_Object_isEmptyMonitor = $this => {
    let $monitor, var$2;
    $monitor = $this.$monitor;
    if ($monitor === null)
        return 1;
    a: {
        b: {
            if ($monitor.$owner === null) {
                if ($monitor.$enteringThreads !== null) {
                    var$2 = $monitor.$enteringThreads;
                    if (!otp_PlatformQueue_isEmpty$static(var$2))
                        break b;
                }
                if ($monitor.$notifyListeners === null)
                    break a;
                var$2 = $monitor.$notifyListeners;
                if (otp_PlatformQueue_isEmpty$static(var$2))
                    break a;
            }
        }
        return 0;
    }
    jl_Object_deleteMonitor($this);
    return 1;
},
jl_Object_deleteMonitor = $this => {
    $this.$monitor = null;
},
jl_Object__init_ = $this => {
    return;
},
jl_Object__init_0 = () => {
    let var_0 = new jl_Object();
    jl_Object__init_(var_0);
    return var_0;
},
jl_Object_getClass = $this => {
    return jl_Class_getClass($this.constructor);
},
jl_Object_hashCode = $this => {
    return jl_Object_identity($this);
},
jl_Object_equals = ($this, $other) => {
    return $this !== $other ? 0 : 1;
},
jl_Object_toString = $this => {
    let var$1, var$2, var$3;
    var$1 = (jl_Object_getClass($this)).$getName();
    var$2 = jl_Integer_toHexString(jl_Object_identity($this));
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append1(jl_StringBuilder_append(var$3, var$1), 64), var$2);
    return jl_StringBuilder_toString(var$3);
},
jl_Object_identity = $this => {
    let $platformThis;
    $platformThis = $this;
    if (!$platformThis.$id$)
        $platformThis.$id$ = $rt_nextId();
    return $this.$id$;
},
jl_Object_clone = $this => {
    let var$1, $result, var$3;
    if (!$rt_isInstance($this, jl_Cloneable)) {
        var$1 = $this;
        if (var$1.constructor.$meta.item === null)
            $rt_throw(jl_CloneNotSupportedException__init_0());
    }
    $result = otp_Platform_clone($this);
    var$1 = $result;
    var$3 = $rt_nextId();
    var$1.$id$ = var$3;
    return $result;
},
jl_Object_lambda$monitorExit$2 = $o => {
    jl_Object_waitForOtherThreads($o);
},
jl_Object_lambda$monitorEnterWait$0 = ($thread_0, $o, $count, $callback) => {
    let var$5;
    jl_Thread_setCurrentThread($thread_0);
    $o.$monitor.$owner = $thread_0;
    var$5 = $o.$monitor;
    var$5.$count = var$5.$count + $count | 0;
    $callback.$complete(null);
},
jl_Object_monitorEnterWait$_asyncCall_$ = (var$1, var$2) => {
    let thread = $rt_nativeThread();
    let javaThread = $rt_getThread();
    if (thread.isResuming()) {
        thread.status = 0;
        let result = thread.attribute;
        if (result instanceof Error) {
            throw result;
        }
        return result;
    }
    let callback = function() {
    };
    callback.$complete = val => {
        thread.attribute = val;
        $rt_setThread(javaThread);
        thread.resume();
    };
    callback.$error = e => {
        thread.attribute = $rt_exception(e);
        $rt_setThread(javaThread);
        thread.resume();
    };
    callback = otpp_AsyncCallbackWrapper_create(callback);
    thread.suspend(() => {
        try {
            jl_Object_monitorEnterWait0(var$1, var$2, callback);
            ;
        } catch ($e){
            callback.$error($e);
        }
    });
    return null;
};
function jl_Throwable() {
    let a = this; jl_Object.call(a);
    a.$message = null;
    a.$cause = null;
    a.$suppressionEnabled = 0;
    a.$writableStackTrace = 0;
}
let jl_Throwable__init_ = $this => {
    $this.$suppressionEnabled = 1;
    $this.$writableStackTrace = 1;
    $this.$fillInStackTrace();
},
jl_Throwable__init_4 = () => {
    let var_0 = new jl_Throwable();
    jl_Throwable__init_(var_0);
    return var_0;
},
jl_Throwable__init_0 = ($this, $message) => {
    $this.$suppressionEnabled = 1;
    $this.$writableStackTrace = 1;
    $this.$fillInStackTrace();
    $this.$message = $message;
},
jl_Throwable__init_2 = var_0 => {
    let var_1 = new jl_Throwable();
    jl_Throwable__init_0(var_1, var_0);
    return var_1;
},
jl_Throwable__init_1 = ($this, $message, $cause) => {
    $this.$suppressionEnabled = 1;
    $this.$writableStackTrace = 1;
    $this.$fillInStackTrace();
    $this.$message = $message;
    $this.$cause = $cause;
},
jl_Throwable__init_3 = (var_0, var_1) => {
    let var_2 = new jl_Throwable();
    jl_Throwable__init_1(var_2, var_0, var_1);
    return var_2;
},
jl_Throwable_fillInStackTrace = $this => {
    return $this;
},
jl_Throwable_getMessage = $this => {
    return $this.$message;
},
jl_Throwable_getLocalizedMessage = $this => {
    return $this.$getMessage();
},
jl_Throwable_getCause = $this => {
    return $this.$cause === $this ? null : $this.$cause;
},
jl_Throwable_toString = $this => {
    let $message, var$2, var$3, var$4;
    $message = $this.$getLocalizedMessage();
    var$2 = (jl_Object_getClass($this)).$getName();
    if ($message === null)
        var$3 = $rt_s(1);
    else {
        var$3 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(var$3, $rt_s(2)), $message);
        var$3 = jl_StringBuilder_toString(var$3);
    }
    var$4 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$4, var$2), var$3);
    return jl_StringBuilder_toString(var$4);
},
jl_Exception = $rt_classWithoutFields(jl_Throwable),
jl_Exception__init_ = $this => {
    jl_Throwable__init_($this);
},
jl_Exception__init_1 = () => {
    let var_0 = new jl_Exception();
    jl_Exception__init_(var_0);
    return var_0;
},
jl_Exception__init_0 = ($this, $message) => {
    jl_Throwable__init_0($this, $message);
},
jl_Exception__init_2 = var_0 => {
    let var_1 = new jl_Exception();
    jl_Exception__init_0(var_1, var_0);
    return var_1;
},
jl_RuntimeException = $rt_classWithoutFields(jl_Exception),
jl_RuntimeException__init_ = $this => {
    jl_Exception__init_($this);
},
jl_RuntimeException__init_2 = () => {
    let var_0 = new jl_RuntimeException();
    jl_RuntimeException__init_(var_0);
    return var_0;
},
jl_RuntimeException__init_0 = ($this, $message) => {
    jl_Exception__init_0($this, $message);
},
jl_RuntimeException__init_1 = var_0 => {
    let var_1 = new jl_RuntimeException();
    jl_RuntimeException__init_0(var_1, var_0);
    return var_1;
},
jl_IndexOutOfBoundsException = $rt_classWithoutFields(jl_RuntimeException),
jl_IndexOutOfBoundsException__init_0 = $this => {
    jl_RuntimeException__init_($this);
},
jl_IndexOutOfBoundsException__init_ = () => {
    let var_0 = new jl_IndexOutOfBoundsException();
    jl_IndexOutOfBoundsException__init_0(var_0);
    return var_0;
},
ji_Serializable = $rt_classWithoutFields(0),
jl_Cloneable = $rt_classWithoutFields(0),
jt_Format = $rt_classWithoutFields(),
jt_Format__init_ = $this => {
    jl_Object__init_($this);
},
jt_Format_format = ($this, $object) => {
    return ($this.$format($object, jl_StringBuffer__init_0(), jt_FieldPosition__init_0(0))).$toString();
},
jl_Number = $rt_classWithoutFields(),
jl_Number__init_ = $this => {
    jl_Object__init_($this);
},
jl_Comparable = $rt_classWithoutFields(0);
function jl_Integer() {
    jl_Number.call(this);
    this.$value0 = 0;
}
let jl_Integer_TYPE = null,
jl_Integer_integerCache = null,
jl_Integer_$callClinit = () => {
    jl_Integer_$callClinit = $rt_eraseClinit(jl_Integer);
    jl_Integer__clinit_();
},
jl_Integer__init_ = ($this, $value) => {
    jl_Integer_$callClinit();
    jl_Number__init_($this);
    $this.$value0 = $value;
},
jl_Integer__init_0 = var_0 => {
    let var_1 = new jl_Integer();
    jl_Integer__init_(var_1, var_0);
    return var_1;
},
jl_Integer_toString0 = ($i, $radix) => {
    jl_Integer_$callClinit();
    if (!($radix >= 2 && $radix <= 36))
        $radix = 10;
    return ((jl_AbstractStringBuilder__init_1(20)).$append1($i, $radix)).$toString();
},
jl_Integer_hashCode0 = $value => {
    jl_Integer_$callClinit();
    return $value;
},
jl_Integer_toHexString = $i => {
    jl_Integer_$callClinit();
    return otci_IntegerUtil_toUnsignedLogRadixString($i, 4);
},
jl_Integer_toString = $i => {
    jl_Integer_$callClinit();
    return jl_Integer_toString0($i, 10);
},
jl_Integer_valueOf = $i => {
    jl_Integer_$callClinit();
    if ($i >= (-128) && $i <= 127) {
        jl_Integer_ensureIntegerCache();
        return jl_Integer_integerCache.data[$i + 128 | 0];
    }
    return jl_Integer__init_0($i);
},
jl_Integer_ensureIntegerCache = () => {
    let $j;
    jl_Integer_$callClinit();
    a: {
        if (jl_Integer_integerCache === null) {
            jl_Integer_integerCache = $rt_createArray(jl_Integer, 256);
            $j = 0;
            while (true) {
                if ($j >= jl_Integer_integerCache.data.length)
                    break a;
                jl_Integer_integerCache.data[$j] = jl_Integer__init_0($j - 128 | 0);
                $j = $j + 1 | 0;
            }
        }
    }
},
jl_Integer_intValue = $this => {
    return $this.$value0;
},
jl_Integer_longValue = $this => {
    return Long_fromInt($this.$value0);
},
jl_Integer_doubleValue = $this => {
    return $this.$value0;
},
jl_Integer_toString1 = $this => {
    return jl_Integer_toString($this.$value0);
},
jl_Integer_hashCode = $this => {
    return jl_Integer_hashCode0($this.$value0);
},
jl_Integer_equals = ($this, $other) => {
    if ($this === $other)
        return 1;
    return $other instanceof jl_Integer && $other.$value0 == $this.$value0 ? 1 : 0;
},
jl_Integer_compareTo = ($this, $other) => {
    return jl_Integer_compare($this.$value0, $other.$value0);
},
jl_Integer_compare = (var$1, var$2) => {
    jl_Integer_$callClinit();
    return $rt_compare(var$1, var$2);
},
jl_Integer_numberOfLeadingZeros = $i => {
    let $n, var$3, var$4;
    jl_Integer_$callClinit();
    if (!$i)
        return 32;
    $n = 0;
    var$3 = $i >>> 16 | 0;
    if (var$3)
        $n = 16;
    else
        var$3 = $i;
    var$4 = var$3 >>> 8 | 0;
    if (!var$4)
        var$4 = var$3;
    else
        $n = $n | 8;
    var$3 = var$4 >>> 4 | 0;
    if (!var$3)
        var$3 = var$4;
    else
        $n = $n | 4;
    var$4 = var$3 >>> 2 | 0;
    if (!var$4)
        var$4 = var$3;
    else
        $n = $n | 2;
    if (var$4 >>> 1 | 0)
        $n = $n | 1;
    return (32 - $n | 0) - 1 | 0;
},
jl_Integer_numberOfTrailingZeros = $i => {
    let $n, var$3, var$4;
    jl_Integer_$callClinit();
    if (!$i)
        return 32;
    $n = 0;
    var$3 = $i << 16;
    if (var$3)
        $n = 16;
    else
        var$3 = $i;
    var$4 = var$3 << 8;
    if (!var$4)
        var$4 = var$3;
    else
        $n = $n | 8;
    var$3 = var$4 << 4;
    if (!var$3)
        var$3 = var$4;
    else
        $n = $n | 4;
    var$4 = var$3 << 2;
    if (!var$4)
        var$4 = var$3;
    else
        $n = $n | 2;
    if (var$4 << 1)
        $n = $n | 1;
    return (32 - $n | 0) - 1 | 0;
},
jl_Integer_compareTo0 = ($this, var$1) => {
    return $this.$compareTo(var$1);
},
jl_Integer__clinit_ = () => {
    jl_Integer_TYPE = $rt_cls($rt_intcls);
},
jl_CloneNotSupportedException = $rt_classWithoutFields(jl_Exception),
jl_CloneNotSupportedException__init_ = $this => {
    jl_Exception__init_($this);
},
jl_CloneNotSupportedException__init_0 = () => {
    let var_0 = new jl_CloneNotSupportedException();
    jl_CloneNotSupportedException__init_(var_0);
    return var_0;
},
jl_AbstractStringBuilder$Constants = $rt_classWithoutFields(),
jl_AbstractStringBuilder$Constants_longLogPowersOfTen = null,
jl_AbstractStringBuilder$Constants_doubleAnalysisResult = null,
jl_AbstractStringBuilder$Constants_floatAnalysisResult = null,
jl_AbstractStringBuilder$Constants_$callClinit = () => {
    jl_AbstractStringBuilder$Constants_$callClinit = $rt_eraseClinit(jl_AbstractStringBuilder$Constants);
    jl_AbstractStringBuilder$Constants__clinit_();
},
jl_AbstractStringBuilder$Constants__clinit_ = () => {
    jl_AbstractStringBuilder$Constants_longLogPowersOfTen = $rt_createLongArrayFromData([Long_fromInt(1), Long_fromInt(10), Long_fromInt(100), Long_fromInt(10000), Long_fromInt(100000000), Long_create(1874919424, 2328306)]);
    jl_AbstractStringBuilder$Constants_doubleAnalysisResult = otcit_DoubleAnalyzer$Result__init_();
    jl_AbstractStringBuilder$Constants_floatAnalysisResult = otcit_FloatAnalyzer$Result__init_0();
},
jl_Long = $rt_classWithoutFields(jl_Number),
jl_Long_TYPE = null,
jl_Long_$callClinit = () => {
    jl_Long_$callClinit = $rt_eraseClinit(jl_Long);
    jl_Long__clinit_();
},
jl_Long_toString = $value => {
    jl_Long_$callClinit();
    return ((jl_StringBuilder__init_()).$append2($value)).$toString();
},
jl_Long_numberOfLeadingZeros = $i => {
    let $n, var$3, var$4;
    jl_Long_$callClinit();
    if (Long_eq($i, Long_ZERO))
        return 64;
    $n = 0;
    var$3 = Long_shru($i, 32);
    if (Long_ne(var$3, Long_ZERO))
        $n = 32;
    else
        var$3 = $i;
    var$4 = Long_shru(var$3, 16);
    if (Long_eq(var$4, Long_ZERO))
        var$4 = var$3;
    else
        $n = $n | 16;
    var$3 = Long_shru(var$4, 8);
    if (Long_eq(var$3, Long_ZERO))
        var$3 = var$4;
    else
        $n = $n | 8;
    var$4 = Long_shru(var$3, 4);
    if (Long_eq(var$4, Long_ZERO))
        var$4 = var$3;
    else
        $n = $n | 4;
    var$3 = Long_shru(var$4, 2);
    if (Long_eq(var$3, Long_ZERO))
        var$3 = var$4;
    else
        $n = $n | 2;
    if (Long_ne(Long_shru(var$3, 1), Long_ZERO))
        $n = $n | 1;
    return (64 - $n | 0) - 1 | 0;
},
jl_Long_signum = $i => {
    jl_Long_$callClinit();
    return Long_lo(Long_or(Long_shr($i, 63), Long_shru(Long_neg($i), 63)));
},
jl_Long_divideUnsigned = (var$1, var$2) => {
    return Long_udiv(var$1, var$2);
},
jl_Long_remainderUnsigned = (var$1, var$2) => {
    return Long_urem(var$1, var$2);
},
jl_Long_compareUnsigned = (var$1, var$2) => {
    return Long_ucompare(var$1, var$2);
},
jl_Long__clinit_ = () => {
    jl_Long_TYPE = $rt_cls($rt_longcls);
},
rce_Sound = $rt_classWithoutFields(),
rce_Sound_playCoin = () => {
    rce_Audio_playCoin();
},
rce_Sound_playDamage = () => {
    rce_Audio_playDamage();
},
rce_Sound_playGameOver = () => {
    rce_Audio_playGameOver();
},
ju_Map = $rt_classWithoutFields(0),
jl_Runnable = $rt_classWithoutFields(0);
function jl_Thread() {
    let a = this; jl_Object.call(a);
    a.$id = Long_ZERO;
    a.$timeSliceStart = Long_ZERO;
    a.$finishedLock = null;
    a.$name5 = null;
    a.$alive = 0;
    a.$target = null;
}
let jl_Thread_mainThread = null,
jl_Thread_currentThread0 = null,
jl_Thread_nextId = 0,
jl_Thread_activeCount = 0,
jl_Thread_defaultUncaughtExceptionHandler = null,
jl_Thread_$callClinit = () => {
    jl_Thread_$callClinit = $rt_eraseClinit(jl_Thread);
    jl_Thread__clinit_();
},
jl_Thread__init_0 = ($this, $name) => {
    jl_Thread_$callClinit();
    jl_Thread__init_($this, null, $name);
},
jl_Thread__init_1 = var_0 => {
    let var_1 = new jl_Thread();
    jl_Thread__init_0(var_1, var_0);
    return var_1;
},
jl_Thread__init_ = ($this, $target, $name) => {
    let var$3;
    jl_Thread_$callClinit();
    jl_Object__init_($this);
    $this.$finishedLock = jl_Object__init_0();
    $this.$alive = 1;
    $this.$name5 = $name;
    $this.$target = $target;
    var$3 = jl_Thread_nextId;
    jl_Thread_nextId = var$3 + 1 | 0;
    $this.$id = Long_fromInt(var$3);
},
jl_Thread__init_2 = (var_0, var_1) => {
    let var_2 = new jl_Thread();
    jl_Thread__init_(var_2, var_0, var_1);
    return var_2;
},
jl_Thread_setCurrentThread = $thread_0 => {
    jl_Thread_$callClinit();
    if (jl_Thread_currentThread0 !== $thread_0)
        jl_Thread_currentThread0 = $thread_0;
    jl_Thread_currentThread0.$timeSliceStart = jl_System_currentTimeMillis();
},
jl_Thread_run = $this => {
    if ($this.$target !== null)
        $this.$target.$run();
},
jl_Thread_currentThread = () => {
    jl_Thread_$callClinit();
    return jl_Thread_currentThread0;
},
jl_Thread__clinit_ = () => {
    jl_Thread_mainThread = jl_Thread__init_1($rt_s(3));
    jl_Thread_currentThread0 = jl_Thread_mainThread;
    jl_Thread_nextId = 1;
    jl_Thread_activeCount = 1;
    jl_Thread_defaultUncaughtExceptionHandler = jl_DefaultUncaughtExceptionHandler__init_0();
};
function rceh_GpioPort() {
    let a = this; jl_Object.call(a);
    a.$name4 = null;
    a.$pins = null;
    a.$ddr = 0;
}
let rceh_GpioPort__init_ = ($this, $name) => {
    let $i, var$3, var$4, var$5;
    jl_Object__init_($this);
    $this.$pins = $rt_createArray(rceh_VirtualPin, 8);
    $this.$ddr = 0;
    $this.$name4 = $name;
    $i = 0;
    while ($i < 8) {
        var$3 = $this.$pins.data;
        var$4 = new rceh_VirtualPin;
        var$5 = jl_StringBuilder__init_();
        jl_StringBuilder_append0(jl_StringBuilder_append(var$5, $name), $i);
        rceh_VirtualPin__init_(var$4, $i, jl_StringBuilder_toString(var$5));
        var$3[$i] = var$4;
        $i = $i + 1 | 0;
    }
},
rceh_GpioPort__init_0 = var_0 => {
    let var_1 = new rceh_GpioPort();
    rceh_GpioPort__init_(var_1, var_0);
    return var_1;
};
function jm_BigInteger() {
    let a = this; jl_Number.call(a);
    a.$digits = null;
    a.$numberLength = 0;
    a.$sign = 0;
    a.$firstNonzeroDigit = 0;
    a.$hashCode6 = 0;
}
let jm_BigInteger_ZERO = null,
jm_BigInteger_ONE = null,
jm_BigInteger_TWO = null,
jm_BigInteger_TEN = null,
jm_BigInteger_MINUS_ONE = null,
jm_BigInteger_SMALL_VALUES = null,
jm_BigInteger_TWO_POWS = null,
jm_BigInteger_$callClinit = () => {
    jm_BigInteger_$callClinit = $rt_eraseClinit(jm_BigInteger);
    jm_BigInteger__clinit_();
},
jm_BigInteger__init_2 = ($this, $sign, $value) => {
    let var$3;
    jm_BigInteger_$callClinit();
    jl_Number__init_($this);
    $this.$firstNonzeroDigit = (-2);
    $this.$sign = $sign;
    $this.$numberLength = 1;
    var$3 = $rt_createIntArray(1);
    var$3.data[0] = $value;
    $this.$digits = var$3;
},
jm_BigInteger__init_0 = (var_0, var_1) => {
    let var_2 = new jm_BigInteger();
    jm_BigInteger__init_2(var_2, var_0, var_1);
    return var_2;
},
jm_BigInteger__init_3 = ($this, $sign, $numberLength, $digits) => {
    jm_BigInteger_$callClinit();
    jl_Number__init_($this);
    $this.$firstNonzeroDigit = (-2);
    $this.$sign = $sign;
    $this.$numberLength = $numberLength;
    $this.$digits = $digits;
},
jm_BigInteger__init_ = (var_0, var_1, var_2) => {
    let var_3 = new jm_BigInteger();
    jm_BigInteger__init_3(var_3, var_0, var_1, var_2);
    return var_3;
},
jm_BigInteger__init_1 = ($this, $sign, $val) => {
    let var$3;
    jm_BigInteger_$callClinit();
    jl_Number__init_($this);
    $this.$firstNonzeroDigit = (-2);
    $this.$sign = $sign;
    if (Long_eq(Long_and($val, Long_create(0, 4294967295)), Long_ZERO)) {
        $this.$numberLength = 1;
        var$3 = $rt_createIntArray(1);
        var$3.data[0] = Long_lo($val);
        $this.$digits = var$3;
    } else {
        $this.$numberLength = 2;
        $this.$digits = $rt_createIntArrayFromData([Long_lo($val), Long_hi($val)]);
    }
},
jm_BigInteger__init_4 = (var_0, var_1) => {
    let var_2 = new jm_BigInteger();
    jm_BigInteger__init_1(var_2, var_0, var_1);
    return var_2;
},
jm_BigInteger__init_5 = ($this, $signum, $digits) => {
    let var$3, var$4;
    jm_BigInteger_$callClinit();
    var$3 = $digits.data;
    jl_Number__init_($this);
    $this.$firstNonzeroDigit = (-2);
    var$4 = var$3.length;
    if (var$4) {
        $this.$sign = $signum;
        $this.$numberLength = var$4;
        $this.$digits = $digits;
        jm_BigInteger_cutOffLeadingZeroes($this);
    } else {
        $this.$sign = 0;
        $this.$numberLength = 1;
        var$3 = $rt_createIntArray(1);
        var$3.data[0] = 0;
        $this.$digits = var$3;
    }
},
jm_BigInteger__init_6 = (var_0, var_1) => {
    let var_2 = new jm_BigInteger();
    jm_BigInteger__init_5(var_2, var_0, var_1);
    return var_2;
},
jm_BigInteger_valueOf = $val => {
    jm_BigInteger_$callClinit();
    if (Long_lt($val, Long_ZERO)) {
        if (Long_eq($val, Long_fromInt(-1)))
            return jm_BigInteger_MINUS_ONE;
        return jm_BigInteger__init_4((-1), Long_neg($val));
    }
    if (Long_gt($val, Long_fromInt(10)))
        return jm_BigInteger__init_4(1, $val);
    return jm_BigInteger_SMALL_VALUES.data[Long_lo($val)];
},
jm_BigInteger_abs = $this => {
    if ($this.$sign < 0)
        $this = jm_BigInteger__init_(1, $this.$numberLength, $this.$digits);
    return $this;
},
jm_BigInteger_negate = $this => {
    return !$this.$sign ? $this : jm_BigInteger__init_( -$this.$sign | 0, $this.$numberLength, $this.$digits);
},
jm_BigInteger_add = ($this, $val) => {
    return jm_Elementary_add1($this, $val);
},
jm_BigInteger_subtract = ($this, $val) => {
    return jm_Elementary_subtract0($this, $val);
},
jm_BigInteger_signum = $this => {
    return $this.$sign;
},
jm_BigInteger_shiftRight = ($this, $n) => {
    if ($n && $this.$sign)
        return $n > 0 ? jm_BitLevel_shiftRight($this, $n) : jm_BitLevel_shiftLeft0($this,  -$n | 0);
    return $this;
},
jm_BigInteger_shiftLeft = ($this, $n) => {
    if ($n && $this.$sign)
        return $n > 0 ? jm_BitLevel_shiftLeft0($this, $n) : jm_BitLevel_shiftRight($this,  -$n | 0);
    return $this;
},
jm_BigInteger_shiftLeftOneBit = $this => {
    if ($this.$sign)
        $this = jm_BitLevel_shiftLeftOneBit0($this);
    return $this;
},
jm_BigInteger_bitLength = $this => {
    return jm_BitLevel_bitLength($this);
},
jm_BigInteger_testBit = ($this, $n) => {
    let $intCount, $digit, var$4, $firstNonZeroDigit;
    if (!$n)
        return !($this.$digits.data[0] & 1) ? 0 : 1;
    if ($n < 0)
        $rt_throw(jl_ArithmeticException__init_($rt_s(4)));
    $intCount = $n >> 5;
    if ($intCount >= $this.$numberLength)
        return $this.$sign >= 0 ? 0 : 1;
    $digit = $this.$digits.data[$intCount];
    var$4 = 1 << ($n & 31);
    if ($this.$sign < 0) {
        $firstNonZeroDigit = $this.$getFirstNonzeroDigit();
        if ($intCount < $firstNonZeroDigit)
            return 0;
        $digit = $firstNonZeroDigit == $intCount ?  -$digit | 0 : $digit ^ (-1);
    }
    return !($digit & var$4) ? 0 : 1;
},
jm_BigInteger_getLowestSetBit = $this => {
    let $i;
    if (!$this.$sign)
        return (-1);
    $i = $this.$getFirstNonzeroDigit();
    return ($i << 5) + jl_Integer_numberOfTrailingZeros($this.$digits.data[$i]) | 0;
},
jm_BigInteger_intValue = $this => {
    return $rt_imul($this.$sign, $this.$digits.data[0]);
},
jm_BigInteger_longValue = $this => {
    let $value;
    $value = $this.$numberLength <= 1 ? Long_and(Long_fromInt($this.$digits.data[0]), Long_create(4294967295, 0)) : Long_or(Long_shl(Long_fromInt($this.$digits.data[1]), 32), Long_and(Long_fromInt($this.$digits.data[0]), Long_create(4294967295, 0)));
    return Long_mul(Long_fromInt($this.$sign), $value);
},
jm_BigInteger_doubleValue = $this => {
    return jm_Conversion_bigInteger2Double($this);
},
jm_BigInteger_compareTo = ($this, $val) => {
    if ($this.$sign > $val.$sign)
        return 1;
    if ($this.$sign < $val.$sign)
        return (-1);
    if ($this.$numberLength > $val.$numberLength)
        return $this.$sign;
    if ($this.$numberLength < $val.$numberLength)
        return  -$val.$sign | 0;
    return $rt_imul($this.$sign, jm_Elementary_compareArrays($this.$digits, $val.$digits, $this.$numberLength));
},
jm_BigInteger_hashCode = $this => {
    let $i;
    if ($this.$hashCode6)
        return $this.$hashCode6;
    $i = 0;
    while ($i < $this.$digits.data.length) {
        $this.$hashCode6 = ($this.$hashCode6 * 33 | 0) + $this.$digits.data[$i] | 0;
        $i = $i + 1 | 0;
    }
    $this.$hashCode6 = $rt_imul($this.$hashCode6, $this.$sign);
    return $this.$hashCode6;
},
jm_BigInteger_equals = ($this, $x) => {
    let $x1;
    if ($this === $x)
        return 1;
    if (!($x instanceof jm_BigInteger))
        return 0;
    $x1 = $x;
    return $this.$sign == $x1.$sign && $this.$numberLength == $x1.$numberLength && $this.$equalsArrays($x1.$digits) ? 1 : 0;
},
jm_BigInteger_equalsArrays = ($this, $b) => {
    let $i, var$3;
    $i = $this.$numberLength - 1 | 0;
    while ($i >= 0) {
        var$3 = $b.data;
        if ($this.$digits.data[$i] != var$3[$i])
            break;
        $i = $i + (-1) | 0;
    }
    return $i >= 0 ? 0 : 1;
},
jm_BigInteger_toString = $this => {
    return jm_Conversion_toDecimalScaledString($this, 0);
},
jm_BigInteger_multiply = ($this, $val) => {
    if (!$val.$sign) {
        jm_BigInteger_$callClinit();
        return jm_BigInteger_ZERO;
    }
    if ($this.$sign)
        return jm_Multiplication_multiply($this, $val);
    jm_BigInteger_$callClinit();
    return jm_BigInteger_ZERO;
},
jm_BigInteger_pow = ($this, $exp) => {
    let $x;
    if ($exp < 0)
        $rt_throw(jl_ArithmeticException__init_($rt_s(5)));
    if (!$exp) {
        jm_BigInteger_$callClinit();
        return jm_BigInteger_ONE;
    }
    if ($exp != 1) {
        jm_BigInteger_$callClinit();
        if (!$this.$equals(jm_BigInteger_ONE) && !$this.$equals(jm_BigInteger_ZERO)) {
            if ($this.$testBit(0))
                return jm_Multiplication_pow($this, $exp);
            $x = 1;
            while (!$this.$testBit($x)) {
                $x = $x + 1 | 0;
            }
            return (jm_BigInteger_getPowerOfTwo($rt_imul($x, $exp))).$multiply0(($this.$shiftRight0($x)).$pow0($exp));
        }
    }
    return $this;
},
jm_BigInteger_divideAndRemainder = ($this, $divisor) => {
    let $divisorSign, $divisorLen, $divisorDigits, $thisDigits, $thisLen, var$7, $cmp, var$9, var$10, $thisSign, $quotientLength, $quotientSign, $quotientDigits, $remainderDigits, $result0, $result1;
    $divisorSign = $divisor.$sign;
    if (!$divisorSign)
        $rt_throw(jl_ArithmeticException__init_($rt_s(6)));
    $divisorLen = $divisor.$numberLength;
    $divisorDigits = $divisor.$digits;
    if ($divisorLen == 1)
        return jm_Division_divideAndRemainderByInteger($this, $divisorDigits.data[0], $divisorSign);
    $thisDigits = $this.$digits;
    $thisLen = $this.$numberLength;
    var$7 = $rt_compare($thisLen, $divisorLen);
    $cmp = !var$7 ? jm_Elementary_compareArrays($thisDigits, $divisorDigits, $thisLen) : var$7 <= 0 ? (-1) : 1;
    if ($cmp < 0) {
        var$9 = $rt_createArray(jm_BigInteger, 2);
        var$10 = var$9.data;
        jm_BigInteger_$callClinit();
        var$10[0] = jm_BigInteger_ZERO;
        var$10[1] = $this;
        return var$9;
    }
    $thisSign = $this.$sign;
    $quotientLength = ($thisLen - $divisorLen | 0) + 1 | 0;
    $quotientSign = $thisSign != $divisorSign ? (-1) : 1;
    $quotientDigits = $rt_createIntArray($quotientLength);
    $remainderDigits = jm_Division_divide($quotientDigits, $quotientLength, $thisDigits, $thisLen, $divisorDigits, $divisorLen);
    $result0 = jm_BigInteger__init_($quotientSign, $quotientLength, $quotientDigits);
    $result1 = jm_BigInteger__init_($thisSign, $divisorLen, $remainderDigits);
    jm_BigInteger_cutOffLeadingZeroes($result0);
    jm_BigInteger_cutOffLeadingZeroes($result1);
    return $rt_wrapArray(jm_BigInteger, [$result0, $result1]);
},
jm_BigInteger_divide = ($this, $divisor) => {
    let $divisorSign, $thisSign, $thisLen, $divisorLen, $val, var$7, $cmp, $resLength, $resDigits, $resSign, $result;
    if (!$divisor.$sign)
        $rt_throw(jl_ArithmeticException__init_($rt_s(6)));
    $divisorSign = $divisor.$sign;
    if ($divisor.$isOne()) {
        if ($divisor.$sign <= 0)
            $this = $this.$negate();
        return $this;
    }
    $thisSign = $this.$sign;
    $thisLen = $this.$numberLength;
    $divisorLen = $divisor.$numberLength;
    if (($thisLen + $divisorLen | 0) == 2) {
        $val = Long_div(Long_and(Long_fromInt($this.$digits.data[0]), Long_create(4294967295, 0)), Long_and(Long_fromInt($divisor.$digits.data[0]), Long_create(4294967295, 0)));
        if ($thisSign != $divisorSign)
            $val = Long_neg($val);
        return jm_BigInteger_valueOf($val);
    }
    var$7 = $rt_compare($thisLen, $divisorLen);
    $cmp = !var$7 ? jm_Elementary_compareArrays($this.$digits, $divisor.$digits, $thisLen) : var$7 <= 0 ? (-1) : 1;
    if (!$cmp)
        return $thisSign != $divisorSign ? jm_BigInteger_MINUS_ONE : jm_BigInteger_ONE;
    if ($cmp == (-1))
        return jm_BigInteger_ZERO;
    $resLength = ($thisLen - $divisorLen | 0) + 1 | 0;
    $resDigits = $rt_createIntArray($resLength);
    $resSign = $thisSign != $divisorSign ? (-1) : 1;
    if ($divisorLen != 1)
        jm_Division_divide($resDigits, $resLength, $this.$digits, $thisLen, $divisor.$digits, $divisorLen);
    else
        jm_Division_divideArrayByInt($resDigits, $this.$digits, $thisLen, $divisor.$digits.data[0]);
    $result = jm_BigInteger__init_($resSign, $resLength, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($result);
    return $result;
},
jm_BigInteger_remainder = ($this, $divisor) => {
    let $thisLen, $divisorLen, var$4, $resDigits, $qLen, $result;
    if (!$divisor.$sign)
        $rt_throw(jl_ArithmeticException__init_($rt_s(6)));
    $thisLen = $this.$numberLength;
    $divisorLen = $divisor.$numberLength;
    var$4 = $rt_compare($thisLen, $divisorLen);
    if ((!var$4 ? jm_Elementary_compareArrays($this.$digits, $divisor.$digits, $thisLen) : var$4 <= 0 ? (-1) : 1) == (-1))
        return $this;
    $resDigits = $rt_createIntArray($divisorLen);
    if ($divisorLen != 1) {
        $qLen = ($thisLen - $divisorLen | 0) + 1 | 0;
        $resDigits = jm_Division_divide(null, $qLen, $this.$digits, $thisLen, $divisor.$digits, $divisorLen);
    } else
        $resDigits.data[0] = jm_Division_remainderArrayByInt($this.$digits, $thisLen, $divisor.$digits.data[0]);
    $result = jm_BigInteger__init_($this.$sign, $divisorLen, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($result);
    return $result;
},
jm_BigInteger_cutOffLeadingZeroes = $this => {
    let var$1, var$2, var$3;
    while ($this.$numberLength > 0) {
        var$1 = $this.$digits.data;
        var$2 = $this.$numberLength - 1 | 0;
        $this.$numberLength = var$2;
        if (var$1[var$2])
            break;
    }
    var$1 = $this.$digits.data;
    var$3 = $this.$numberLength;
    $this.$numberLength = var$3 + 1 | 0;
    if (!var$1[var$3])
        $this.$sign = 0;
},
jm_BigInteger_isOne = $this => {
    return $this.$numberLength == 1 && $this.$digits.data[0] == 1 ? 1 : 0;
},
jm_BigInteger_getFirstNonzeroDigit = $this => {
    let $i;
    if ($this.$firstNonzeroDigit == (-2)) {
        if (!$this.$sign)
            $i = (-1);
        else {
            $i = 0;
            while (!$this.$digits.data[$i]) {
                $i = $i + 1 | 0;
            }
        }
        $this.$firstNonzeroDigit = $i;
    }
    return $this.$firstNonzeroDigit;
},
jm_BigInteger_getPowerOfTwo = $exp => {
    let $intCount, $bitN, var$4, $resDigits, var$6;
    jm_BigInteger_$callClinit();
    if ($exp < jm_BigInteger_TWO_POWS.data.length)
        return jm_BigInteger_TWO_POWS.data[$exp];
    $intCount = $exp >> 5;
    $bitN = $exp & 31;
    var$4 = $intCount + 1 | 0;
    $resDigits = $rt_createIntArray(var$4);
    var$6 = $resDigits.data;
    var$6[$intCount] = 1 << $bitN;
    return jm_BigInteger__init_(1, var$4, $resDigits);
},
jm_BigInteger_compareTo0 = ($this, var$1) => {
    return $this.$compareTo0(var$1);
},
jm_BigInteger__clinit_ = () => {
    let var$1, var$2, $i;
    jm_BigInteger_ZERO = jm_BigInteger__init_0(0, 0);
    jm_BigInteger_ONE = jm_BigInteger__init_0(1, 1);
    jm_BigInteger_TWO = jm_BigInteger__init_0(1, 2);
    jm_BigInteger_TEN = jm_BigInteger__init_0(1, 10);
    jm_BigInteger_MINUS_ONE = jm_BigInteger__init_0((-1), 1);
    var$1 = $rt_createArray(jm_BigInteger, 11);
    var$2 = var$1.data;
    var$2[0] = jm_BigInteger_ZERO;
    var$2[1] = jm_BigInteger_ONE;
    var$2[2] = jm_BigInteger_TWO;
    var$2[3] = jm_BigInteger__init_0(1, 3);
    var$2[4] = jm_BigInteger__init_0(1, 4);
    var$2[5] = jm_BigInteger__init_0(1, 5);
    var$2[6] = jm_BigInteger__init_0(1, 6);
    var$2[7] = jm_BigInteger__init_0(1, 7);
    var$2[8] = jm_BigInteger__init_0(1, 8);
    var$2[9] = jm_BigInteger__init_0(1, 9);
    var$2[10] = jm_BigInteger_TEN;
    jm_BigInteger_SMALL_VALUES = var$1;
    jm_BigInteger_TWO_POWS = $rt_createArray(jm_BigInteger, 32);
    $i = 0;
    while ($i < jm_BigInteger_TWO_POWS.data.length) {
        jm_BigInteger_TWO_POWS.data[$i] = jm_BigInteger_valueOf(Long_shl(Long_fromInt(1), $i));
        $i = $i + 1 | 0;
    }
},
jl_ArithmeticException = $rt_classWithoutFields(jl_RuntimeException),
jl_ArithmeticException__init_0 = ($this, $message) => {
    jl_RuntimeException__init_0($this, $message);
},
jl_ArithmeticException__init_ = var_0 => {
    let var_1 = new jl_ArithmeticException();
    jl_ArithmeticException__init_0(var_1, var_0);
    return var_1;
};
let otj_JSObject = $rt_classWithoutFields(0),
otp_PlatformQueue = $rt_classWithoutFields(),
otp_PlatformQueue_wrap = $obj => {
    return $obj;
},
otp_PlatformQueue_isEmpty$static = $this => {
    return $this.length ? 0 : 1;
},
otp_PlatformQueue_add$static = ($this, $e) => {
    let var$3;
    var$3 = otp_PlatformQueue_wrap($e);
    $this.push(var$3);
},
otp_PlatformQueue_remove$static = $this => {
    return otji_JSWrapper_maybeWrap($this.shift());
},
otciu_CLDRHelper = $rt_classWithoutFields(),
otciu_CLDRHelper_$$metadata$$0 = null,
otciu_CLDRHelper_$$metadata$$10 = null,
otciu_CLDRHelper_$$metadata$$17 = null,
otciu_CLDRHelper_$$metadata$$20 = null,
otciu_CLDRHelper_$$metadata$$21 = null,
otciu_CLDRHelper_getCode = ($language, $country) => {
    let var$3;
    if (!$country.$isEmpty()) {
        var$3 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append1(jl_StringBuilder_append(var$3, $language), 45), $country);
        $language = jl_StringBuilder_toString(var$3);
    }
    return $language;
},
otciu_CLDRHelper_getLikelySubtags = $localeCode => {
    let $map;
    $map = otciu_CLDRHelper_getLikelySubtagsMap();
    if ($map.hasOwnProperty($rt_ustr($localeCode)))
        $localeCode = ($map[$rt_ustr($localeCode)].value !== null ? $rt_str($map[$rt_ustr($localeCode)].value) : null);
    return $localeCode;
},
otciu_CLDRHelper_resolveCountry = ($language, $country) => {
    let $subtags, $index;
    if ($country.$isEmpty()) {
        $subtags = otciu_CLDRHelper_getLikelySubtags($language);
        $index = $subtags.$lastIndexOf(95);
        $country = $index <= 0 ? $rt_s(1) : $subtags.$substring($index + 1 | 0);
    }
    return $country;
},
otciu_CLDRHelper_getLikelySubtagsMap = () => {
    if (otciu_CLDRHelper_$$metadata$$0 === null)
        otciu_CLDRHelper_$$metadata$$0 = otciu_CLDRHelper_getLikelySubtagsMap$$create();
    return otciu_CLDRHelper_$$metadata$$0;
},
otciu_CLDRHelper_getDefaultLocale = () => {
    if (otciu_CLDRHelper_$$metadata$$10 === null)
        otciu_CLDRHelper_$$metadata$$10 = otciu_CLDRHelper_getDefaultLocale$$create();
    return otciu_CLDRHelper_$$metadata$$10;
},
otciu_CLDRHelper_resolveNumberFormat = ($language, $country) => {
    return otciu_CLDRHelper_resolveFormatSymbols(otciu_CLDRHelper_getNumberFormatMap(), $language, $country);
},
otciu_CLDRHelper_getNumberFormatMap = () => {
    if (otciu_CLDRHelper_$$metadata$$17 === null)
        otciu_CLDRHelper_$$metadata$$17 = otciu_CLDRHelper_getNumberFormatMap$$create();
    return otciu_CLDRHelper_$$metadata$$17;
},
otciu_CLDRHelper_resolveFormatSymbols = ($map, $language, $country) => {
    let $localeCode, $res;
    $localeCode = otciu_CLDRHelper_getCode($language, $country);
    $res = $map.hasOwnProperty($rt_ustr($localeCode)) ? $map[$rt_ustr($localeCode)] : $map.hasOwnProperty($rt_ustr($language)) ? $map[$rt_ustr($language)] : $map.root;
    return ($res.value !== null ? $rt_str($res.value) : null);
},
otciu_CLDRHelper_resolveDecimalData = ($language, $country) => {
    let $map, $localeCode;
    $map = otciu_CLDRHelper_getDecimalDataMap();
    $localeCode = otciu_CLDRHelper_getCode($language, $country);
    return $map.hasOwnProperty($rt_ustr($localeCode)) ? $map[$rt_ustr($localeCode)] : $map.hasOwnProperty($rt_ustr($language)) ? $map[$rt_ustr($language)] : $map.root;
},
otciu_CLDRHelper_getDecimalDataMap = () => {
    if (otciu_CLDRHelper_$$metadata$$20 === null)
        otciu_CLDRHelper_$$metadata$$20 = otciu_CLDRHelper_getDecimalDataMap$$create();
    return otciu_CLDRHelper_$$metadata$$20;
},
otciu_CLDRHelper_resolveCurrency = ($language, $country, $currency) => {
    let $localeCode, $map, $currencies, var$7;
    $localeCode = otciu_CLDRHelper_getCode($language, $country);
    $map = otciu_CLDRHelper_getCurrencyMap();
    if ($map.hasOwnProperty($rt_ustr($localeCode))) {
        $currencies = $map[$rt_ustr($localeCode)];
        if ($currencies.hasOwnProperty($rt_ustr($currency))) {
            var$7 = $currencies[$rt_ustr($currency)];
            return var$7;
        }
    }
    if ($map.hasOwnProperty($rt_ustr($language))) {
        $currencies = $map[$rt_ustr($language)];
        if ($currencies.hasOwnProperty($rt_ustr($currency))) {
            var$7 = $currencies[$rt_ustr($currency)];
            return var$7;
        }
    }
    return null;
},
otciu_CLDRHelper_getCurrencyMap = () => {
    if (otciu_CLDRHelper_$$metadata$$21 === null)
        otciu_CLDRHelper_$$metadata$$21 = otciu_CLDRHelper_getCurrencyMap$$create();
    return otciu_CLDRHelper_$$metadata$$21;
},
otciu_CLDRHelper_getLikelySubtagsMap$$create = () => {
    return {"ksh": {"value" : "ksh-Latn-DE"}, "ksj": {"value" : "ksj-Latn-ZZ"}, "tdu": {"value" : "tdu-Latn-MY"}, "cch": {"value" : "cch-Latn-NG"}, "und-Khar": {"value" : "pra-Khar-PK"}, "gkn": {"value" : "gkn-Latn-ZZ"}, "ksr": {"value" : "ksr-Latn-ZZ"}, "und-Mani": {"value" : "xmn-Mani-CN"}, "gkp": {"value" : "gkp-Latn-ZZ"}, "xmf": {"value" : "xmf-Geor-GE"}, "ccp": {"value" : "ccp-Cakm-BD"}, "ted": {"value" : "ted-Latn-ZZ"}, "und-Mand": {"value" : "myz-Mand-IR"}, "ktb": {"value" : "ktb-Ethi-ZZ"}, "xmn": {"value"
    : "xmn-Mani-CN"}, "sd-Sind": {"value" : "sd-Sind-IN"}, "xmr": {"value" : "xmr-Merc-SD"}, "tem": {"value" : "tem-Latn-SL"}, "und-Mroo": {"value" : "mro-Mroo-BD"}, "teo": {"value" : "teo-Latn-UG"}, "tet": {"value" : "tet-Latn-TL"}, "ktm": {"value" : "ktm-Latn-ZZ"}, "glk": {"value" : "glk-Arab-IR"}, "kto": {"value" : "kto-Latn-ZZ"}, "ktr": {"value" : "ktr-Latn-MY"}, "und-Soyo": {"value" : "cmg-Soyo-MN"}, "xna": {"value" : "xna-Narb-SA"}, "tfi": {"value" : "tfi-Latn-ZZ"}, "kub": {"value" : "kub-Latn-ZZ"}, "kue":
    {"value" : "kue-Latn-ZZ"}, "kud": {"value" : "kud-Latn-ZZ"}, "xnr": {"value" : "xnr-Deva-IN"}, "ceb": {"value" : "ceb-Latn-PH"}, "kuj": {"value" : "kuj-Latn-ZZ"}, "kum": {"value" : "kum-Cyrl-RU"}, "kun": {"value" : "kun-Latn-ZZ"}, "gmm": {"value" : "gmm-Latn-ZZ"}, "kup": {"value" : "kup-Latn-ZZ"}, "kus": {"value" : "kus-Latn-ZZ"}, "gmv": {"value" : "gmv-Ethi-ZZ"}, "tgc": {"value" : "tgc-Latn-ZZ"}, "xog": {"value" : "xog-Latn-UG"}, "und-Arab-YT": {"value" : "swb-Arab-YT"}, "und-Latn-ET": {"value" : "en-Latn-ET"}
    , "xon": {"value" : "xon-Latn-ZZ"}, "ha-CM": {"value" : "ha-Arab-CM"}, "gnd": {"value" : "gnd-Latn-ZZ"}, "kvg": {"value" : "kvg-Latn-ZZ"}, "tgo": {"value" : "tgo-Latn-ZZ"}, "cfa": {"value" : "cfa-Latn-ZZ"}, "gng": {"value" : "gng-Latn-ZZ"}, "tgu": {"value" : "tgu-Latn-ZZ"}, "und-Latn-GE": {"value" : "ku-Latn-GE"}, "kvr": {"value" : "kvr-Latn-ID"}, "kvx": {"value" : "kvx-Arab-PK"}, "und-Gujr": {"value" : "gu-Gujr-IN"}, "thl": {"value" : "thl-Deva-NP"}, "xpr": {"value" : "xpr-Prti-IR"}, "thq": {"value" : "thq-Deva-NP"}
    , "god": {"value" : "god-Latn-ZZ"}, "gof": {"value" : "gof-Ethi-ZZ"}, "kwj": {"value" : "kwj-Latn-ZZ"}, "ky-Arab": {"value" : "ky-Arab-CN"}, "thr": {"value" : "thr-Deva-NP"}, "goi": {"value" : "goi-Latn-ZZ"}, "cgg": {"value" : "cgg-Latn-UG"}, "kwo": {"value" : "kwo-Latn-ZZ"}, "gom": {"value" : "gom-Deva-IN"}, "kwq": {"value" : "kwq-Latn-ZZ"}, "gon": {"value" : "gon-Telu-IN"}, "gos": {"value" : "gos-Latn-NL"}, "gor": {"value" : "gor-Latn-ID"}, "und-Latn-CY": {"value" : "tr-Latn-CY"}, "got": {"value" : "got-Goth-UA"}
    , "tif": {"value" : "tif-Latn-ZZ"}, "tig": {"value" : "tig-Ethi-ER"}, "kxa": {"value" : "kxa-Latn-ZZ"}, "kxc": {"value" : "kxc-Ethi-ZZ"}, "pag": {"value" : "pag-Latn-PH"}, "tik": {"value" : "tik-Latn-ZZ"}, "kxe": {"value" : "kxe-Latn-ZZ"}, "tim": {"value" : "tim-Latn-ZZ"}, "pal": {"value" : "pal-Phli-IR"}, "tio": {"value" : "tio-Latn-ZZ"}, "pam": {"value" : "pam-Latn-PH"}, "und-Marc": {"value" : "bo-Marc-CN"}, "pap": {"value" : "pap-Latn-AW"}, "und-Latn-CN": {"value" : "za-Latn-CN"}, "tiv": {"value" : "tiv-Latn-NG"}
    , "kxm": {"value" : "kxm-Thai-TH"}, "kxp": {"value" : "kxp-Arab-PK"}, "pau": {"value" : "pau-Latn-PW"}, "chk": {"value" : "chk-Latn-FM"}, "chm": {"value" : "chm-Cyrl-RU"}, "xrb": {"value" : "xrb-Latn-ZZ"}, "chp": {"value" : "chp-Latn-CA"}, "cho": {"value" : "cho-Latn-US"}, "kxw": {"value" : "kxw-Latn-ZZ"}, "und-Latn-DZ": {"value" : "fr-Latn-DZ"}, "chr": {"value" : "chr-Cher-US"}, "kxz": {"value" : "kxz-Latn-ZZ"}, "und-Batk": {"value" : "bbc-Batk-ID"}, "und-Bass": {"value" : "bsq-Bass-LR"}, "kye": {"value"
    : "kye-Latn-ZZ"}, "pbi": {"value" : "pbi-Latn-ZZ"}, "und-Deva-MU": {"value" : "bho-Deva-MU"}, "cic": {"value" : "cic-Latn-US"}, "und-Sgnw": {"value" : "ase-Sgnw-US"}, "xsa": {"value" : "xsa-Sarb-YE"}, "kyx": {"value" : "kyx-Latn-ZZ"}, "xsi": {"value" : "xsi-Latn-ZZ"}, "pcd": {"value" : "pcd-Latn-FR"}, "und-Latn-AM": {"value" : "ku-Latn-AM"}, "xsm": {"value" : "xsm-Latn-ZZ"}, "tkl": {"value" : "tkl-Latn-TK"}, "und-Thai-CN": {"value" : "lcp-Thai-CN"}, "grb": {"value" : "grb-Latn-ZZ"}, "xsr": {"value" : "xsr-Deva-NP"}
    , "und-Latn-AF": {"value" : "tk-Latn-AF"}, "grc": {"value" : "grc-Cprt-CY"}, "kzj": {"value" : "kzj-Latn-MY"}, "tkr": {"value" : "tkr-Latn-AZ"}, "cja": {"value" : "cja-Arab-KH"}, "pcm": {"value" : "pcm-Latn-NG"}, "tkt": {"value" : "tkt-Deva-NP"}, "und-Olck": {"value" : "sat-Olck-IN"}, "kzr": {"value" : "kzr-Latn-ZZ"}, "kzt": {"value" : "kzt-Latn-MY"}, "cjm": {"value" : "cjm-Cham-VN"}, "grt": {"value" : "grt-Beng-IN"}, "und-Arab-TJ": {"value" : "fa-Arab-TJ"}, "und-Arab-TG": {"value" : "apd-Arab-TG"}, "und-Arab-TH":
    {"value" : "mfa-Arab-TH"}, "und-Deva-PK": {"value" : "btv-Deva-PK"}, "grw": {"value" : "grw-Latn-ZZ"}, "cjv": {"value" : "cjv-Latn-ZZ"}, "pdc": {"value" : "pdc-Latn-US"}, "tlf": {"value" : "tlf-Latn-ZZ"}, "und-Arab-TR": {"value" : "az-Arab-TR"}, "ckb": {"value" : "ckb-Arab-IQ"}, "tly": {"value" : "tly-Latn-AZ"}, "pdt": {"value" : "pdt-Latn-CA"}, "tlx": {"value" : "tlx-Latn-ZZ"}, "ckl": {"value" : "ckl-Latn-ZZ"}, "cko": {"value" : "cko-Latn-ZZ"}, "gsw": {"value" : "gsw-Latn-CH"}, "ped": {"value" : "ped-Latn-ZZ"}
    , "tmh": {"value" : "tmh-Latn-NE"}, "cky": {"value" : "cky-Latn-ZZ"}, "kk-Arab": {"value" : "kk-Arab-CN"}, "und-Runr": {"value" : "non-Runr-SE"}, "cla": {"value" : "cla-Latn-ZZ"}, "peo": {"value" : "peo-Xpeo-IR"}, "tmy": {"value" : "tmy-Latn-ZZ"}, "pex": {"value" : "pex-Latn-ZZ"}, "ky-TR": {"value" : "ky-Latn-TR"}, "tnh": {"value" : "tnh-Latn-ZZ"}, "guc": {"value" : "guc-Latn-CO"}, "gub": {"value" : "gub-Latn-BR"}, "gud": {"value" : "gud-Latn-ZZ"}, "pfl": {"value" : "pfl-Latn-DE"}, "cme": {"value" : "cme-Latn-ZZ"}
    , "cmg": {"value" : "cmg-Soyo-MN"}, "gur": {"value" : "gur-Latn-GH"}, "xwe": {"value" : "xwe-Latn-ZZ"}, "guw": {"value" : "guw-Latn-ZZ"}, "tof": {"value" : "tof-Latn-ZZ"}, "gux": {"value" : "gux-Latn-ZZ"}, "guz": {"value" : "guz-Latn-KE"}, "tog": {"value" : "tog-Latn-MW"}, "gvf": {"value" : "gvf-Latn-ZZ"}, "toq": {"value" : "toq-Latn-ZZ"}, "gvr": {"value" : "gvr-Deva-NP"}, "und-Guru": {"value" : "pa-Guru-IN"}, "gvs": {"value" : "gvs-Latn-ZZ"}, "tpi": {"value" : "tpi-Latn-PG"}, "tpm": {"value" : "tpm-Latn-ZZ"}
    , "und-Tfng": {"value" : "zgh-Tfng-MA"}, "gwc": {"value" : "gwc-Arab-ZZ"}, "und-Arab-PK": {"value" : "ur-Arab-PK"}, "phl": {"value" : "phl-Arab-ZZ"}, "und-Aghb": {"value" : "lez-Aghb-RU"}, "phn": {"value" : "phn-Phnx-LB"}, "gwi": {"value" : "gwi-Latn-CA"}, "tpz": {"value" : "tpz-Latn-ZZ"}, "cop": {"value" : "cop-Copt-EG"}, "gwt": {"value" : "gwt-Arab-ZZ"}, "lab": {"value" : "lab-Lina-GR"}, "lad": {"value" : "lad-Hebr-IL"}, "lah": {"value" : "lah-Arab-PK"}, "pil": {"value" : "pil-Latn-ZZ"}, "lag": {"value"
    : "lag-Latn-TZ"}, "tqo": {"value" : "tqo-Latn-ZZ"}, "laj": {"value" : "laj-Latn-UG"}, "pip": {"value" : "pip-Latn-ZZ"}, "und-Khmr": {"value" : "km-Khmr-KH"}, "las": {"value" : "las-Latn-ZZ"}, "sd-Deva": {"value" : "sd-Deva-IN"}, "und-Khoj": {"value" : "sd-Khoj-IN"}, "cps": {"value" : "cps-Latn-PH"}, "kk-AF": {"value" : "kk-Arab-AF"}, "und-Arab-MU": {"value" : "ur-Arab-MU"}, "lbe": {"value" : "lbe-Cyrl-RU"}, "und-Arab-NG": {"value" : "ha-Arab-NG"}, "gyi": {"value" : "gyi-Latn-ZZ"}, "tru": {"value" : "tru-Latn-TR"}
    , "trw": {"value" : "trw-Arab-ZZ"}, "trv": {"value" : "trv-Latn-TW"}, "lbu": {"value" : "lbu-Latn-ZZ"}, "lbw": {"value" : "lbw-Latn-ID"}, "tsd": {"value" : "tsd-Grek-GR"}, "tsf": {"value" : "tsf-Deva-NP"}, "pka": {"value" : "pka-Brah-IN"}, "tsg": {"value" : "tsg-Latn-PH"}, "tsj": {"value" : "tsj-Tibt-BT"}, "und-Deva-FJ": {"value" : "hif-Deva-FJ"}, "pko": {"value" : "pko-Latn-KE"}, "lcm": {"value" : "lcm-Latn-ZZ"}, "crh": {"value" : "crh-Cyrl-UA"}, "lcp": {"value" : "lcp-Thai-CN"}, "tsw": {"value" : "tsw-Latn-ZZ"}
    , "crj": {"value" : "crj-Cans-CA"}, "crl": {"value" : "crl-Cans-CA"}, "und-Arab-MN": {"value" : "kk-Arab-MN"}, "crk": {"value" : "crk-Cans-CA"}, "crm": {"value" : "crm-Cans-CA"}, "und-Arab-MM": {"value" : "rhg-Arab-MM"}, "pla": {"value" : "pla-Latn-ZZ"}, "tte": {"value" : "tte-Latn-ZZ"}, "crs": {"value" : "crs-Latn-SC"}, "ttd": {"value" : "ttd-Latn-ZZ"}, "ldb": {"value" : "ldb-Latn-ZZ"}, "ttj": {"value" : "ttj-Latn-UG"}, "kk-CN": {"value" : "kk-Arab-CN"}, "und-Yiii": {"value" : "ii-Yiii-CN"}, "tts": {"value"
    : "tts-Thai-TH"}, "csb": {"value" : "csb-Latn-PL"}, "ttr": {"value" : "ttr-Latn-ZZ"}, "ttt": {"value" : "ttt-Latn-AZ"}, "csw": {"value" : "csw-Cans-CA"}, "tuh": {"value" : "tuh-Latn-ZZ"}, "led": {"value" : "led-Latn-ZZ"}, "tul": {"value" : "tul-Latn-ZZ"}, "lee": {"value" : "lee-Latn-ZZ"}, "tum": {"value" : "tum-Latn-MW"}, "und-Arab-KH": {"value" : "cja-Arab-KH"}, "tuq": {"value" : "tuq-Latn-ZZ"}, "ctd": {"value" : "ctd-Pauc-MM"}, "lem": {"value" : "lem-Latn-ZZ"}, "lep": {"value" : "lep-Lepc-IN"}, "pms":
    {"value" : "pms-Latn-IT"}, "leq": {"value" : "leq-Latn-ZZ"}, "und-Pauc": {"value" : "ctd-Pauc-MM"}, "und-Sogo": {"value" : "sog-Sogo-UZ"}, "leu": {"value" : "leu-Latn-ZZ"}, "lez": {"value" : "lez-Cyrl-RU"}, "tvd": {"value" : "tvd-Latn-ZZ"}, "mn-CN": {"value" : "mn-Mong-CN"}, "sr-TR": {"value" : "sr-Latn-TR"}, "png": {"value" : "png-Latn-ZZ"}, "tvl": {"value" : "tvl-Latn-TV"}, "und-Brah": {"value" : "pka-Brah-IN"}, "und-Brai": {"value" : "fr-Brai-FR"}, "pnn": {"value" : "pnn-Latn-ZZ"}, "tvu": {"value" : "tvu-Latn-ZZ"}
    , "pnt": {"value" : "pnt-Grek-GR"}, "uz-CN": {"value" : "uz-Cyrl-CN"}, "ha-SD": {"value" : "ha-Arab-SD"}, "twh": {"value" : "twh-Latn-ZZ"}, "und-Takr": {"value" : "doi-Takr-IN"}, "lgg": {"value" : "lgg-Latn-ZZ"}, "pon": {"value" : "pon-Latn-FM"}, "twq": {"value" : "twq-Latn-NE"}, "und-Arab-ID": {"value" : "ms-Arab-ID"}, "und-Arab-IN": {"value" : "ur-Arab-IN"}, "ppa": {"value" : "ppa-Deva-IN"}, "txg": {"value" : "txg-Tang-CN"}, "yam": {"value" : "yam-Latn-ZZ"}, "und-Talu": {"value" : "khb-Talu-CN"}, "yao":
    {"value" : "yao-Latn-MZ"}, "yap": {"value" : "yap-Latn-FM"}, "yas": {"value" : "yas-Latn-ZZ"}, "yat": {"value" : "yat-Latn-ZZ"}, "ppo": {"value" : "ppo-Latn-ZZ"}, "yav": {"value" : "yav-Latn-CM"}, "yay": {"value" : "yay-Latn-ZZ"}, "yaz": {"value" : "yaz-Latn-ZZ"}, "und-Tale": {"value" : "tdd-Tale-CN"}, "ybb": {"value" : "ybb-Latn-CM"}, "yba": {"value" : "yba-Latn-ZZ"}, "tya": {"value" : "tya-Latn-ZZ"}, "lia": {"value" : "lia-Latn-ZZ"}, "lid": {"value" : "lid-Latn-ZZ"}, "und-Latn-TW": {"value" : "trv-Latn-TW"}
    , "lif": {"value" : "lif-Deva-NP"}, "lih": {"value" : "lih-Latn-ZZ"}, "lig": {"value" : "lig-Latn-ZZ"}, "lij": {"value" : "lij-Latn-IT"}, "hag": {"value" : "hag-Latn-ZZ"}, "und-Latn-TN": {"value" : "fr-Latn-TN"}, "tyv": {"value" : "tyv-Cyrl-RU"}, "yby": {"value" : "yby-Latn-ZZ"}, "und-Arab-GB": {"value" : "ks-Arab-GB"}, "hak": {"value" : "hak-Hans-CN"}, "und-Taml": {"value" : "ta-Taml-IN"}, "ham": {"value" : "ham-Latn-ZZ"}, "lis": {"value" : "lis-Lisu-CN"}, "und-Latn-SY": {"value" : "fr-Latn-SY"}, "ky-Latn":
    {"value" : "ky-Latn-TR"}, "pra": {"value" : "pra-Khar-PK"}, "haw": {"value" : "haw-Latn-US"}, "haz": {"value" : "haz-Arab-AF"}, "ku-LB": {"value" : "ku-Arab-LB"}, "prd": {"value" : "prd-Arab-IR"}, "prg": {"value" : "prg-Latn-001"}, "tzm": {"value" : "tzm-Latn-MA"}, "hbb": {"value" : "hbb-Latn-ZZ"}, "und-Latn-UA": {"value" : "pl-Latn-UA"}, "ljp": {"value" : "ljp-Latn-ID"}, "und-Tang": {"value" : "txg-Tang-CN"}, "yue-Hans": {"value" : "yue-Hans-CN"}, "und-Latn-RU": {"value" : "krl-Latn-RU"}, "lki": {"value"
    : "lki-Arab-IR"}, "pss": {"value" : "pss-Latn-ZZ"}, "lkt": {"value" : "lkt-Latn-US"}, "sr-RO": {"value" : "sr-Latn-RO"}, "und-Arab-CN": {"value" : "ug-Arab-CN"}, "lle": {"value" : "lle-Latn-ZZ"}, "und-Cyrl": {"value" : "ru-Cyrl-RU"}, "uz-AF": {"value" : "uz-Arab-AF"}, "yer": {"value" : "yer-Latn-ZZ"}, "und-Beng": {"value" : "bn-Beng-BD"}, "ptp": {"value" : "ptp-Latn-ZZ"}, "lln": {"value" : "lln-Latn-ZZ"}, "sr-RU": {"value" : "sr-Latn-RU"}, "hdy": {"value" : "hdy-Ethi-ZZ"}, "unr-NP": {"value" : "unr-Deva-NP"}
    , "und-Mend": {"value" : "men-Mend-SL"}, "lmn": {"value" : "lmn-Telu-IN"}, "lmp": {"value" : "lmp-Latn-ZZ"}, "lmo": {"value" : "lmo-Latn-IT"}, "puu": {"value" : "puu-Latn-GA"}, "und-Arab-CC": {"value" : "ms-Arab-CC"}, "pal-Phlp": {"value" : "pal-Phlp-CN"}, "ygr": {"value" : "ygr-Latn-ZZ"}, "ygw": {"value" : "ygw-Latn-ZZ"}, "lns": {"value" : "lns-Latn-ZZ"}, "ky-CN": {"value" : "ky-Arab-CN"}, "lnu": {"value" : "lnu-Latn-ZZ"}, "pwa": {"value" : "pwa-Latn-ZZ"}, "und-Chrs": {"value" : "xco-Chrs-UZ"}, "und-Mahj":
    {"value" : "hi-Mahj-IN"}, "rif-NL": {"value" : "rif-Latn-NL"}, "loj": {"value" : "loj-Latn-ZZ"}, "lol": {"value" : "lol-Latn-CD"}, "lok": {"value" : "lok-Latn-ZZ"}, "lor": {"value" : "lor-Latn-ZZ"}, "und-Sora": {"value" : "srb-Sora-IN"}, "los": {"value" : "los-Latn-ZZ"}, "loz": {"value" : "loz-Latn-ZM"}, "und-202": {"value" : "en-Latn-NG"}, "und-Latn-MR": {"value" : "fr-Latn-MR"}, "ku-Yezi": {"value" : "ku-Yezi-GE"}, "hhy": {"value" : "hhy-Latn-ZZ"}, "hia": {"value" : "hia-Latn-ZZ"}, "hif": {"value" : "hif-Latn-FJ"}
    , "dad": {"value" : "dad-Latn-ZZ"}, "hih": {"value" : "hih-Latn-ZZ"}, "hig": {"value" : "hig-Latn-ZZ"}, "daf": {"value" : "daf-Latn-ZZ"}, "ubu": {"value" : "ubu-Latn-ZZ"}, "dah": {"value" : "dah-Latn-ZZ"}, "hil": {"value" : "hil-Latn-PH"}, "dag": {"value" : "dag-Latn-ZZ"}, "und-Mero": {"value" : "xmr-Mero-SD"}, "dak": {"value" : "dak-Latn-US"}, "und-Merc": {"value" : "xmr-Merc-SD"}, "dar": {"value" : "dar-Cyrl-RU"}, "dav": {"value" : "dav-Latn-KE"}, "lrc": {"value" : "lrc-Arab-IR"}, "yko": {"value" : "yko-Latn-ZZ"}
    , "und-Latn-MK": {"value" : "sq-Latn-MK"}, "und-Latn-MM": {"value" : "kac-Latn-MM"}, "dbd": {"value" : "dbd-Latn-ZZ"}, "und-Latn-MO": {"value" : "pt-Latn-MO"}, "und-Latn-MA": {"value" : "fr-Latn-MA"}, "und-Bali": {"value" : "ban-Bali-ID"}, "und-Tavt": {"value" : "blt-Tavt-VN"}, "dbq": {"value" : "dbq-Latn-ZZ"}, "yle": {"value" : "yle-Latn-ZZ"}, "ylg": {"value" : "ylg-Latn-ZZ"}, "und-Maka": {"value" : "mak-Maka-ID"}, "yll": {"value" : "yll-Latn-ZZ"}, "udm": {"value" : "udm-Cyrl-RU"}, "dcc": {"value" : "dcc-Arab-IN"}
    , "yml": {"value" : "yml-Latn-ZZ"}, "hla": {"value" : "hla-Latn-ZZ"}, "und-Latn-IR": {"value" : "tk-Latn-IR"}, "ltg": {"value" : "ltg-Latn-LV"}, "und-Latn-KM": {"value" : "fr-Latn-KM"}, "ddn": {"value" : "ddn-Latn-ZZ"}, "hlu": {"value" : "hlu-Hluw-TR"}, "lua": {"value" : "lua-Latn-CD"}, "und-Bamu": {"value" : "bax-Bamu-CM"}, "hmd": {"value" : "hmd-Plrd-CN"}, "ded": {"value" : "ded-Latn-ZZ"}, "luo": {"value" : "luo-Latn-KE"}, "und-142": {"value" : "zh-Hans-CN"}, "und-143": {"value" : "uz-Latn-UZ"}, "den":
    {"value" : "den-Latn-CA"}, "und-Gran": {"value" : "sa-Gran-IN"}, "hmt": {"value" : "hmt-Latn-ZZ"}, "uga": {"value" : "uga-Ugar-SY"}, "luz": {"value" : "luz-Arab-IR"}, "luy": {"value" : "luy-Latn-KE"}, "und-145": {"value" : "ar-Arab-SA"}, "und-Cakm": {"value" : "ccp-Cakm-BD"}, "und-Dupl": {"value" : "fr-Dupl-FR"}, "yon": {"value" : "yon-Latn-ZZ"}, "ug-MN": {"value" : "ug-Cyrl-MN"}, "hne": {"value" : "hne-Deva-IN"}, "hnd": {"value" : "hnd-Arab-PK"}, "hnj": {"value" : "hnj-Hmng-LA"}, "hno": {"value" : "hno-Arab-PK"}
    , "hnn": {"value" : "hnn-Latn-PH"}, "ug-KZ": {"value" : "ug-Cyrl-KZ"}, "und-154": {"value" : "en-Latn-GB"}, "und-155": {"value" : "de-Latn-DE"}, "und-150": {"value" : "ru-Cyrl-RU"}, "und-151": {"value" : "ru-Cyrl-RU"}, "und-Sylo": {"value" : "syl-Sylo-BD"}, "hoc": {"value" : "hoc-Deva-IN"}, "dga": {"value" : "dga-Latn-ZZ"}, "lwl": {"value" : "lwl-Thai-TH"}, "und-Ital": {"value" : "ett-Ital-IT"}, "hoj": {"value" : "hoj-Deva-IN"}, "dgh": {"value" : "dgh-Latn-ZZ"}, "dgi": {"value" : "dgi-Latn-ZZ"}, "dgl": {"value"
    : "dgl-Arab-ZZ"}, "hot": {"value" : "hot-Latn-ZZ"}, "dgr": {"value" : "dgr-Latn-CA"}, "dgz": {"value" : "dgz-Latn-ZZ"}, "yrb": {"value" : "yrb-Latn-ZZ"}, "yre": {"value" : "yre-Latn-ZZ"}, "und-Lyci": {"value" : "xlc-Lyci-TR"}, "und-Cans": {"value" : "cr-Cans-CA"}, "und-Hluw": {"value" : "hlu-Hluw-TR"}, "und-Nand": {"value" : "sa-Nand-IN"}, "yrl": {"value" : "yrl-Latn-BR"}, "dia": {"value" : "dia-Latn-ZZ"}, "und-Grek": {"value" : "el-Grek-GR"}, "und-Mong": {"value" : "mn-Mong-CN"}, "und-Lydi": {"value" :
    "xld-Lydi-TR"}, "yss": {"value" : "yss-Latn-ZZ"}, "und-Newa": {"value" : "new-Newa-NP"}, "lzh": {"value" : "lzh-Hans-CN"}, "dje": {"value" : "dje-Latn-NE"}, "lzz": {"value" : "lzz-Latn-TR"}, "uli": {"value" : "uli-Latn-FM"}, "hsb": {"value" : "hsb-Latn-DE"}, "und-Xsux": {"value" : "akk-Xsux-IQ"}, "hsn": {"value" : "hsn-Hans-CN"}, "und-Cari": {"value" : "xcr-Cari-TR"}, "und-Syrc": {"value" : "syr-Syrc-IQ"}, "yua": {"value" : "yua-Latn-MX"}, "yue": {"value" : "yue-Hant-HK"}, "umb": {"value" : "umb-Latn-AO"}
    , "yuj": {"value" : "yuj-Latn-ZZ"}, "yut": {"value" : "yut-Latn-ZZ"}, "yuw": {"value" : "yuw-Latn-ZZ"}, "und-Bopo": {"value" : "zh-Bopo-TW"}, "und-Yezi": {"value" : "ku-Yezi-GE"}, "und": {"value" : "en-Latn-US"}, "und-Egyp": {"value" : "egy-Egyp-EG"}, "und-Tglg": {"value" : "fil-Tglg-PH"}, "unr": {"value" : "unr-Beng-IN"}, "hui": {"value" : "hui-Latn-ZZ"}, "und-Elba": {"value" : "sq-Elba-AL"}, "unx": {"value" : "unx-Beng-IN"}, "und-Narb": {"value" : "xna-Narb-SA"}, "pa-PK": {"value" : "pa-Arab-PK"}, "und-Hebr-CA":
    {"value" : "yi-Hebr-CA"}, "uok": {"value" : "uok-Latn-ZZ"}, "und-Geor": {"value" : "ka-Geor-GE"}, "und-Shrd": {"value" : "sa-Shrd-IN"}, "dnj": {"value" : "dnj-Latn-CI"}, "und-Diak": {"value" : "dv-Diak-MV"}, "dob": {"value" : "dob-Latn-ZZ"}, "und-Mymr-TH": {"value" : "mnw-Mymr-TH"}, "doi": {"value" : "doi-Arab-IN"}, "dop": {"value" : "dop-Latn-ZZ"}, "und-Sund": {"value" : "su-Sund-ID"}, "dow": {"value" : "dow-Latn-ZZ"}, "sr-ME": {"value" : "sr-Latn-ME"}, "und-Hung": {"value" : "hu-Hung-HU"}, "mad": {"value"
    : "mad-Latn-ID"}, "mag": {"value" : "mag-Deva-IN"}, "maf": {"value" : "maf-Latn-CM"}, "mai": {"value" : "mai-Deva-IN"}, "mak": {"value" : "mak-Latn-ID"}, "man": {"value" : "man-Latn-GM"}, "mas": {"value" : "mas-Latn-KE"}, "maw": {"value" : "maw-Latn-ZZ"}, "maz": {"value" : "maz-Latn-MX"}, "uri": {"value" : "uri-Latn-ZZ"}, "mbh": {"value" : "mbh-Latn-ZZ"}, "urt": {"value" : "urt-Latn-ZZ"}, "mbo": {"value" : "mbo-Latn-ZZ"}, "urw": {"value" : "urw-Latn-ZZ"}, "mbq": {"value" : "mbq-Latn-ZZ"}, "mbu": {"value"
    : "mbu-Latn-ZZ"}, "und-Hebr-GB": {"value" : "yi-Hebr-GB"}, "usa": {"value" : "usa-Latn-ZZ"}, "mbw": {"value" : "mbw-Latn-ZZ"}, "mci": {"value" : "mci-Latn-ZZ"}, "dri": {"value" : "dri-Latn-ZZ"}, "mcq": {"value" : "mcq-Latn-ZZ"}, "drh": {"value" : "drh-Mong-CN"}, "mcp": {"value" : "mcp-Latn-ZZ"}, "mcr": {"value" : "mcr-Latn-ZZ"}, "mcu": {"value" : "mcu-Latn-ZZ"}, "drs": {"value" : "drs-Ethi-ZZ"}, "mda": {"value" : "mda-Latn-ZZ"}, "mdf": {"value" : "mdf-Cyrl-RU"}, "mde": {"value" : "mde-Arab-ZZ"}, "mdh": {"value"
    : "mdh-Latn-PH"}, "dsb": {"value" : "dsb-Latn-DE"}, "mdj": {"value" : "mdj-Latn-ZZ"}, "utr": {"value" : "utr-Latn-ZZ"}, "mdr": {"value" : "mdr-Latn-ID"}, "mdx": {"value" : "mdx-Ethi-ZZ"}, "mee": {"value" : "mee-Latn-ZZ"}, "med": {"value" : "med-Latn-ZZ"}, "mek": {"value" : "mek-Latn-ZZ"}, "men": {"value" : "men-Latn-SL"}, "az-RU": {"value" : "az-Cyrl-RU"}, "mis-Medf": {"value" : "mis-Medf-NG"}, "mer": {"value" : "mer-Latn-KE"}, "dtm": {"value" : "dtm-Latn-ML"}, "meu": {"value" : "meu-Latn-ZZ"}, "met": {"value"
    : "met-Latn-ZZ"}, "dtp": {"value" : "dtp-Latn-MY"}, "dts": {"value" : "dts-Latn-ZZ"}, "uvh": {"value" : "uvh-Latn-ZZ"}, "dty": {"value" : "dty-Deva-NP"}, "mfa": {"value" : "mfa-Arab-TH"}, "uvl": {"value" : "uvl-Latn-ZZ"}, "mfe": {"value" : "mfe-Latn-MU"}, "dua": {"value" : "dua-Latn-CM"}, "dud": {"value" : "dud-Latn-ZZ"}, "duc": {"value" : "duc-Latn-ZZ"}, "mfn": {"value" : "mfn-Latn-ZZ"}, "dug": {"value" : "dug-Latn-ZZ"}, "mfo": {"value" : "mfo-Latn-ZZ"}, "mfq": {"value" : "mfq-Latn-ZZ"}, "und-Phag": {"value"
    : "lzh-Phag-CN"}, "dva": {"value" : "dva-Latn-ZZ"}, "mgh": {"value" : "mgh-Latn-MZ"}, "mgl": {"value" : "mgl-Latn-ZZ"}, "mgo": {"value" : "mgo-Latn-CM"}, "mgp": {"value" : "mgp-Deva-NP"}, "mgy": {"value" : "mgy-Latn-TZ"}, "zag": {"value" : "zag-Latn-SD"}, "mhi": {"value" : "mhi-Latn-ZZ"}, "mhl": {"value" : "mhl-Latn-ZZ"}, "dww": {"value" : "dww-Latn-ZZ"}, "mif": {"value" : "mif-Latn-ZZ"}, "und-Mymr-IN": {"value" : "kht-Mymr-IN"}, "min": {"value" : "min-Latn-ID"}, "mis": {"value" : "mis-Hatr-IQ"}, "ian":
    {"value" : "ian-Latn-ZZ"}, "miw": {"value" : "miw-Latn-ZZ"}, "iar": {"value" : "iar-Latn-ZZ"}, "uz-Arab": {"value" : "uz-Arab-AF"}, "ibb": {"value" : "ibb-Latn-NG"}, "iba": {"value" : "iba-Latn-MY"}, "dyo": {"value" : "dyo-Latn-SN"}, "dyu": {"value" : "dyu-Latn-BF"}, "iby": {"value" : "iby-Latn-ZZ"}, "zdj": {"value" : "zdj-Arab-KM"}, "ica": {"value" : "ica-Latn-ZZ"}, "mki": {"value" : "mki-Arab-ZZ"}, "und-Wcho": {"value" : "nnp-Wcho-IN"}, "ich": {"value" : "ich-Latn-ZZ"}, "mkl": {"value" : "mkl-Latn-ZZ"}
    , "dzg": {"value" : "dzg-Latn-ZZ"}, "mkp": {"value" : "mkp-Latn-ZZ"}, "zea": {"value" : "zea-Latn-NL"}, "mkw": {"value" : "mkw-Latn-ZZ"}, "mle": {"value" : "mle-Latn-ZZ"}, "idd": {"value" : "idd-Latn-ZZ"}, "idi": {"value" : "idi-Latn-ZZ"}, "lif-Limb": {"value" : "lif-Limb-IN"}, "mlp": {"value" : "mlp-Latn-ZZ"}, "mls": {"value" : "mls-Latn-SD"}, "idu": {"value" : "idu-Latn-ZZ"}, "quc": {"value" : "quc-Latn-GT"}, "qug": {"value" : "qug-Latn-EC"}, "und-Jamo": {"value" : "ko-Jamo-KR"}, "mmo": {"value" : "mmo-Latn-ZZ"}
    , "mmu": {"value" : "mmu-Latn-ZZ"}, "mmx": {"value" : "mmx-Latn-ZZ"}, "zgh": {"value" : "zgh-Tfng-MA"}, "mna": {"value" : "mna-Latn-ZZ"}, "mnf": {"value" : "mnf-Latn-ZZ"}, "ife": {"value" : "ife-Latn-TG"}, "mni": {"value" : "mni-Beng-IN"}, "mnw": {"value" : "mnw-Mymr-MM"}, "moa": {"value" : "moa-Latn-ZZ"}, "moe": {"value" : "moe-Latn-CA"}, "igb": {"value" : "igb-Latn-ZZ"}, "ige": {"value" : "ige-Latn-ZZ"}, "moh": {"value" : "moh-Latn-CA"}, "und-Hebr-SE": {"value" : "yi-Hebr-SE"}, "zhx": {"value" : "zhx-Nshu-CN"}
    , "mos": {"value" : "mos-Latn-BF"}, "und-Shaw": {"value" : "en-Shaw-GB"}, "zia": {"value" : "zia-Latn-ZZ"}, "mox": {"value" : "mox-Latn-ZZ"}, "vag": {"value" : "vag-Latn-ZZ"}, "vai": {"value" : "vai-Vaii-LR"}, "van": {"value" : "van-Latn-ZZ"}, "mpp": {"value" : "mpp-Latn-ZZ"}, "mpt": {"value" : "mpt-Latn-ZZ"}, "mps": {"value" : "mps-Latn-ZZ"}, "mpx": {"value" : "mpx-Latn-ZZ"}, "und-Hebr-US": {"value" : "yi-Hebr-US"}, "hi-Latn": {"value" : "hi-Latn-IN"}, "mql": {"value" : "mql-Latn-ZZ"}, "und-Hebr-UA": {"value"
    : "yi-Hebr-UA"}, "mrd": {"value" : "mrd-Deva-NP"}, "zkt": {"value" : "zkt-Kits-CN"}, "mrj": {"value" : "mrj-Cyrl-RU"}, "ijj": {"value" : "ijj-Latn-ZZ"}, "mro": {"value" : "mro-Mroo-BD"}, "und-Modi": {"value" : "mr-Modi-IN"}, "ebu": {"value" : "ebu-Latn-KE"}, "zlm": {"value" : "zlm-Latn-TG"}, "arc-Palm": {"value" : "arc-Palm-SY"}, "ikk": {"value" : "ikk-Latn-ZZ"}, "ikt": {"value" : "ikt-Latn-CA"}, "ikw": {"value" : "ikw-Latn-ZZ"}, "vec": {"value" : "vec-Latn-IT"}, "ikx": {"value" : "ikx-Latn-ZZ"}, "zmi":
    {"value" : "zmi-Latn-MY"}, "mtc": {"value" : "mtc-Latn-ZZ"}, "mtf": {"value" : "mtf-Latn-ZZ"}, "vep": {"value" : "vep-Latn-RU"}, "zh-Bopo": {"value" : "zh-Bopo-TW"}, "mti": {"value" : "mti-Latn-ZZ"}, "und-Ethi": {"value" : "am-Ethi-ET"}, "mtr": {"value" : "mtr-Deva-IN"}, "und-Thai-LA": {"value" : "kdt-Thai-LA"}, "ilo": {"value" : "ilo-Latn-PH"}, "zne": {"value" : "zne-Latn-ZZ"}, "mua": {"value" : "mua-Latn-CM"}, "und-Thai-KH": {"value" : "kdt-Thai-KH"}, "imo": {"value" : "imo-Latn-ZZ"}, "mus": {"value" :
    "mus-Latn-US"}, "mur": {"value" : "mur-Latn-ZZ"}, "mva": {"value" : "mva-Latn-ZZ"}, "inh": {"value" : "inh-Cyrl-RU"}, "mvn": {"value" : "mvn-Latn-ZZ"}, "efi": {"value" : "efi-Latn-NG"}, "mvy": {"value" : "mvy-Arab-PK"}, "und-Java": {"value" : "jv-Java-ID"}, "mwk": {"value" : "mwk-Latn-ML"}, "mwr": {"value" : "mwr-Deva-IN"}, "und-021": {"value" : "en-Latn-US"}, "egl": {"value" : "egl-Latn-IT"}, "mww": {"value" : "mww-Hmnp-US"}, "mwv": {"value" : "mwv-Latn-ID"}, "iou": {"value" : "iou-Latn-ZZ"}, "und-029":
    {"value" : "es-Latn-CU"}, "vic": {"value" : "vic-Latn-SX"}, "egy": {"value" : "egy-Egyp-EG"}, "und-Ugar": {"value" : "uga-Ugar-SY"}, "mxc": {"value" : "mxc-Latn-ZW"}, "raj": {"value" : "raj-Deva-IN"}, "rai": {"value" : "rai-Latn-ZZ"}, "rao": {"value" : "rao-Latn-ZZ"}, "viv": {"value" : "viv-Latn-ZZ"}, "mxm": {"value" : "mxm-Latn-ZZ"}, "und-034": {"value" : "hi-Deva-IN"}, "und-030": {"value" : "zh-Hans-CN"}, "und-039": {"value" : "it-Latn-IT"}, "und-035": {"value" : "id-Latn-ID"}, "ug-Cyrl": {"value" : "ug-Cyrl-KZ"}
    , "myk": {"value" : "myk-Latn-ZZ"}, "mym": {"value" : "mym-Ethi-ZZ"}, "aai": {"value" : "aai-Latn-ZZ"}, "aak": {"value" : "aak-Latn-ZZ"}, "myw": {"value" : "myw-Latn-ZZ"}, "myv": {"value" : "myv-Cyrl-RU"}, "myx": {"value" : "myx-Latn-UG"}, "myz": {"value" : "myz-Mand-IR"}, "und-Sinh": {"value" : "si-Sinh-LK"}, "und-Sind": {"value" : "sd-Sind-IN"}, "aau": {"value" : "aau-Latn-ZZ"}, "rcf": {"value" : "rcf-Latn-RE"}, "und-Orkh": {"value" : "otk-Orkh-MN"}, "mzk": {"value" : "mzk-Latn-ZZ"}, "mzn": {"value" :
    "mzn-Arab-IR"}, "iri": {"value" : "iri-Latn-ZZ"}, "mzm": {"value" : "mzm-Latn-ZZ"}, "mzp": {"value" : "mzp-Latn-ZZ"}, "und-053": {"value" : "en-Latn-AU"}, "abi": {"value" : "abi-Latn-ZZ"}, "und-054": {"value" : "en-Latn-PG"}, "mzw": {"value" : "mzw-Latn-ZZ"}, "mzz": {"value" : "mzz-Latn-ZZ"}, "abr": {"value" : "abr-Latn-GH"}, "abq": {"value" : "abq-Cyrl-ZZ"}, "abt": {"value" : "abt-Latn-ZZ"}, "und-057": {"value" : "en-Latn-GU"}, "aby": {"value" : "aby-Latn-ZZ"}, "eka": {"value" : "eka-Latn-ZZ"}, "vls": {"value"
    : "vls-Latn-BE"}, "ace": {"value" : "ace-Latn-ID"}, "acd": {"value" : "acd-Latn-ZZ"}, "ach": {"value" : "ach-Latn-UG"}, "vmf": {"value" : "vmf-Latn-DE"}, "eky": {"value" : "eky-Kali-MM"}, "rej": {"value" : "rej-Latn-ID"}, "rel": {"value" : "rel-Latn-ZZ"}, "ada": {"value" : "ada-Latn-GH"}, "res": {"value" : "res-Latn-ZZ"}, "vmw": {"value" : "vmw-Latn-MZ"}, "ade": {"value" : "ade-Latn-ZZ"}, "adj": {"value" : "adj-Latn-ZZ"}, "und-Hira": {"value" : "ja-Hira-JP"}, "adp": {"value" : "adp-Tibt-BT"}, "adz": {"value"
    : "adz-Latn-ZZ"}, "ady": {"value" : "ady-Cyrl-RU"}, "ema": {"value" : "ema-Latn-ZZ"}, "und-Deva": {"value" : "hi-Deva-IN"}, "aeb": {"value" : "aeb-Arab-TN"}, "emi": {"value" : "emi-Latn-ZZ"}, "und-009": {"value" : "en-Latn-AU"}, "aey": {"value" : "aey-Latn-ZZ"}, "und-002": {"value" : "en-Latn-NG"}, "und-003": {"value" : "en-Latn-US"}, "und-005": {"value" : "pt-Latn-BR"}, "rgn": {"value" : "rgn-Latn-IT"}, "vot": {"value" : "vot-Latn-RU"}, "enn": {"value" : "enn-Latn-ZZ"}, "enq": {"value" : "enq-Latn-ZZ"}
    , "und-011": {"value" : "en-Latn-NG"}, "rhg": {"value" : "rhg-Arab-MM"}, "und-017": {"value" : "sw-Latn-CD"}, "und-018": {"value" : "en-Latn-ZA"}, "und-019": {"value" : "en-Latn-US"}, "und-013": {"value" : "es-Latn-MX"}, "und-014": {"value" : "sw-Latn-TZ"}, "und-015": {"value" : "ar-Arab-EG"}, "agc": {"value" : "agc-Latn-ZZ"}, "und-Zanb": {"value" : "cmg-Zanb-MN"}, "iwm": {"value" : "iwm-Latn-ZZ"}, "agd": {"value" : "agd-Latn-ZZ"}, "agg": {"value" : "agg-Latn-ZZ"}, "iws": {"value" : "iws-Latn-ZZ"}, "agm":
    {"value" : "agm-Latn-ZZ"}, "ago": {"value" : "ago-Latn-ZZ"}, "agq": {"value" : "agq-Latn-CM"}, "ria": {"value" : "ria-Latn-IN"}, "rif": {"value" : "rif-Tfng-MA"}, "nac": {"value" : "nac-Latn-ZZ"}, "naf": {"value" : "naf-Latn-ZZ"}, "nak": {"value" : "nak-Latn-ZZ"}, "nan": {"value" : "nan-Hans-CN"}, "aha": {"value" : "aha-Latn-ZZ"}, "nap": {"value" : "nap-Latn-IT"}, "naq": {"value" : "naq-Latn-NA"}, "zza": {"value" : "zza-Latn-TR"}, "nas": {"value" : "nas-Latn-ZZ"}, "ahl": {"value" : "ahl-Latn-ZZ"}, "en-Shaw":
    {"value" : "en-Shaw-GB"}, "und-Copt": {"value" : "cop-Copt-EG"}, "aho": {"value" : "aho-Ahom-IN"}, "vro": {"value" : "vro-Latn-EE"}, "rjs": {"value" : "rjs-Deva-NP"}, "nca": {"value" : "nca-Latn-ZZ"}, "ncf": {"value" : "ncf-Latn-ZZ"}, "nce": {"value" : "nce-Latn-ZZ"}, "nch": {"value" : "nch-Latn-MX"}, "izh": {"value" : "izh-Latn-RU"}, "izi": {"value" : "izi-Latn-ZZ"}, "rkt": {"value" : "rkt-Beng-BD"}, "nco": {"value" : "nco-Latn-ZZ"}, "eri": {"value" : "eri-Latn-ZZ"}, "ajg": {"value" : "ajg-Latn-ZZ"}, "ncu":
    {"value" : "ncu-Latn-ZZ"}, "ndc": {"value" : "ndc-Latn-MZ"}, "esg": {"value" : "esg-Gonm-IN"}, "nds": {"value" : "nds-Latn-DE"}, "akk": {"value" : "akk-Xsux-IQ"}, "esu": {"value" : "esu-Latn-US"}, "neb": {"value" : "neb-Latn-ZZ"}, "rmf": {"value" : "rmf-Latn-FI"}, "und-061": {"value" : "sm-Latn-WS"}, "und-Limb": {"value" : "lif-Limb-IN"}, "vun": {"value" : "vun-Latn-TZ"}, "ff-Adlm": {"value" : "ff-Adlm-GN"}, "vut": {"value" : "vut-Latn-ZZ"}, "rmo": {"value" : "rmo-Latn-CH"}, "ala": {"value" : "ala-Latn-ZZ"}
    , "rmt": {"value" : "rmt-Arab-IR"}, "rmu": {"value" : "rmu-Latn-SE"}, "ali": {"value" : "ali-Latn-ZZ"}, "nex": {"value" : "nex-Latn-ZZ"}, "new": {"value" : "new-Deva-NP"}, "aln": {"value" : "aln-Latn-XK"}, "etr": {"value" : "etr-Latn-ZZ"}, "und-Rohg": {"value" : "rhg-Rohg-MM"}, "ett": {"value" : "ett-Ital-IT"}, "rna": {"value" : "rna-Latn-ZZ"}, "etu": {"value" : "etu-Latn-ZZ"}, "alt": {"value" : "alt-Cyrl-RU"}, "etx": {"value" : "etx-Latn-ZZ"}, "rng": {"value" : "rng-Latn-MZ"}, "und-Linb": {"value" : "grc-Linb-GR"}
    , "und-Lina": {"value" : "lab-Lina-GR"}, "und-Jpan": {"value" : "ja-Jpan-JP"}, "man-GN": {"value" : "man-Nkoo-GN"}, "nfr": {"value" : "nfr-Latn-ZZ"}, "amm": {"value" : "amm-Latn-ZZ"}, "und-Arab": {"value" : "ar-Arab-EG"}, "amo": {"value" : "amo-Latn-NG"}, "amn": {"value" : "amn-Latn-ZZ"}, "rob": {"value" : "rob-Latn-ID"}, "amp": {"value" : "amp-Latn-ZZ"}, "ngb": {"value" : "ngb-Latn-ZZ"}, "rof": {"value" : "rof-Latn-TZ"}, "nga": {"value" : "nga-Latn-ZZ"}, "ngl": {"value" : "ngl-Latn-MZ"}, "roo": {"value"
    : "roo-Latn-ZZ"}, "anc": {"value" : "anc-Latn-ZZ"}, "ank": {"value" : "ank-Latn-ZZ"}, "ann": {"value" : "ann-Latn-ZZ"}, "und-Bhks": {"value" : "sa-Bhks-IN"}, "nhb": {"value" : "nhb-Latn-ZZ"}, "nhe": {"value" : "nhe-Latn-MX"}, "any": {"value" : "any-Latn-ZZ"}, "und-Orya": {"value" : "or-Orya-IN"}, "ewo": {"value" : "ewo-Latn-CM"}, "nhw": {"value" : "nhw-Latn-MX"}, "aoj": {"value" : "aoj-Latn-ZZ"}, "aom": {"value" : "aom-Latn-ZZ"}, "zh-Hanb": {"value" : "zh-Hanb-TW"}, "und-Kits": {"value" : "zkt-Kits-CN"}
    , "jab": {"value" : "jab-Latn-ZZ"}, "nif": {"value" : "nif-Latn-ZZ"}, "aoz": {"value" : "aoz-Latn-ID"}, "nij": {"value" : "nij-Latn-ID"}, "nii": {"value" : "nii-Latn-ZZ"}, "zh-PH": {"value" : "zh-Hant-PH"}, "nin": {"value" : "nin-Latn-ZZ"}, "zh-Hant": {"value" : "zh-Hant-TW"}, "zh-PF": {"value" : "zh-Hant-PF"}, "und-Ahom": {"value" : "aho-Ahom-IN"}, "apd": {"value" : "apd-Arab-TG"}, "apc": {"value" : "apc-Arab-ZZ"}, "ape": {"value" : "ape-Latn-ZZ"}, "jam": {"value" : "jam-Latn-JM"}, "zh-PA": {"value" : "zh-Hant-PA"}
    , "niu": {"value" : "niu-Latn-NU"}, "niz": {"value" : "niz-Latn-ZZ"}, "niy": {"value" : "niy-Latn-ZZ"}, "ext": {"value" : "ext-Latn-ES"}, "apr": {"value" : "apr-Latn-ZZ"}, "aps": {"value" : "aps-Latn-ZZ"}, "apz": {"value" : "apz-Latn-ZZ"}, "rro": {"value" : "rro-Latn-ZZ"}, "njo": {"value" : "njo-Latn-IN"}, "jbo": {"value" : "jbo-Latn-001"}, "jbu": {"value" : "jbu-Latn-ZZ"}, "zh-MO": {"value" : "zh-Hant-MO"}, "nkg": {"value" : "nkg-Latn-ZZ"}, "zh-MY": {"value" : "zh-Hant-MY"}, "arc": {"value" : "arc-Armi-IR"}
    , "nko": {"value" : "nko-Latn-ZZ"}, "arh": {"value" : "arh-Latn-ZZ"}, "pa-Arab": {"value" : "pa-Arab-PK"}, "und-Mtei": {"value" : "mni-Mtei-IN"}, "arn": {"value" : "arn-Latn-CL"}, "aro": {"value" : "aro-Latn-BO"}, "und-Cyrl-RO": {"value" : "bg-Cyrl-RO"}, "arq": {"value" : "arq-Arab-DZ"}, "ars": {"value" : "ars-Arab-SA"}, "arz": {"value" : "arz-Arab-EG"}, "ary": {"value" : "ary-Arab-MA"}, "rtm": {"value" : "rtm-Latn-FJ"}, "asa": {"value" : "asa-Latn-TZ"}, "und-Grek-TR": {"value" : "bgx-Grek-TR"}, "ase": {"value"
    : "ase-Sgnw-US"}, "asg": {"value" : "asg-Latn-ZZ"}, "aso": {"value" : "aso-Latn-ZZ"}, "ast": {"value" : "ast-Latn-ES"}, "rue": {"value" : "rue-Cyrl-UA"}, "rug": {"value" : "rug-Latn-SB"}, "nmg": {"value" : "nmg-Latn-CM"}, "ata": {"value" : "ata-Latn-ZZ"}, "jen": {"value" : "jen-Latn-ZZ"}, "atg": {"value" : "atg-Latn-ZZ"}, "atj": {"value" : "atj-Latn-CA"}, "nmz": {"value" : "nmz-Latn-ZZ"}, "unr-Deva": {"value" : "unr-Deva-NP"}, "nnf": {"value" : "nnf-Latn-ZZ"}, "nnh": {"value" : "nnh-Latn-CM"}, "nnk": {"value"
    : "nnk-Latn-ZZ"}, "nnm": {"value" : "nnm-Latn-ZZ"}, "nnp": {"value" : "nnp-Wcho-IN"}, "az-IR": {"value" : "az-Arab-IR"}, "und-Adlm": {"value" : "ff-Adlm-GN"}, "az-IQ": {"value" : "az-Arab-IQ"}, "und-Nbat": {"value" : "arc-Nbat-JO"}, "sd-Khoj": {"value" : "sd-Khoj-IN"}, "nod": {"value" : "nod-Lana-TH"}, "auy": {"value" : "auy-Latn-ZZ"}, "noe": {"value" : "noe-Deva-IN"}, "rwk": {"value" : "rwk-Latn-TZ"}, "und-Cyrl-MD": {"value" : "uk-Cyrl-MD"}, "rwo": {"value" : "rwo-Latn-ZZ"}, "non": {"value" : "non-Runr-SE"}
    , "nop": {"value" : "nop-Latn-ZZ"}, "jgk": {"value" : "jgk-Latn-ZZ"}, "jgo": {"value" : "jgo-Latn-CM"}, "und-Vaii": {"value" : "vai-Vaii-LR"}, "nou": {"value" : "nou-Latn-ZZ"}, "avl": {"value" : "avl-Arab-ZZ"}, "avn": {"value" : "avn-Latn-ZZ"}, "wae": {"value" : "wae-Latn-CH"}, "avt": {"value" : "avt-Latn-ZZ"}, "avu": {"value" : "avu-Latn-ZZ"}, "waj": {"value" : "waj-Latn-ZZ"}, "wal": {"value" : "wal-Ethi-ET"}, "wan": {"value" : "wan-Latn-ZZ"}, "zh-HK": {"value" : "zh-Hant-HK"}, "war": {"value" : "war-Latn-PH"}
    , "awa": {"value" : "awa-Deva-IN"}, "und-Plrd": {"value" : "hmd-Plrd-CN"}, "awb": {"value" : "awb-Latn-ZZ"}, "awo": {"value" : "awo-Latn-ZZ"}, "und-Knda": {"value" : "kn-Knda-IN"}, "zh-ID": {"value" : "zh-Hant-ID"}, "jib": {"value" : "jib-Latn-ZZ"}, "awx": {"value" : "awx-Latn-ZZ"}, "wbp": {"value" : "wbp-Latn-AU"}, "und-Sidd": {"value" : "sa-Sidd-IN"}, "fab": {"value" : "fab-Latn-ZZ"}, "wbr": {"value" : "wbr-Deva-IN"}, "faa": {"value" : "faa-Latn-ZZ"}, "wbq": {"value" : "wbq-Telu-IN"}, "und-Kali": {"value"
    : "eky-Kali-MM"}, "fag": {"value" : "fag-Latn-ZZ"}, "nqo": {"value" : "nqo-Nkoo-GN"}, "fai": {"value" : "fai-Latn-ZZ"}, "ryu": {"value" : "ryu-Kana-JP"}, "fan": {"value" : "fan-Latn-GQ"}, "wci": {"value" : "wci-Latn-ZZ"}, "nrb": {"value" : "nrb-Latn-ZZ"}, "und-Phlp": {"value" : "pal-Phlp-CN"}, "ayb": {"value" : "ayb-Latn-ZZ"}, "und-Phli": {"value" : "pal-Phli-IR"}, "cu-Glag": {"value" : "cu-Glag-BG"}, "und-Cyrl-XK": {"value" : "sr-Cyrl-XK"}, "az-Arab": {"value" : "az-Arab-IR"}, "ks-Deva": {"value" : "ks-Deva-IN"}
    , "und-Thai": {"value" : "th-Thai-TH"}, "nsk": {"value" : "nsk-Cans-CA"}, "nsn": {"value" : "nsn-Latn-ZZ"}, "nso": {"value" : "nso-Latn-ZA"}, "und-Thaa": {"value" : "dv-Thaa-MV"}, "und-Nshu": {"value" : "zhx-Nshu-CN"}, "nss": {"value" : "nss-Latn-ZZ"}, "zh-VN": {"value" : "zh-Hant-VN"}, "und-Hmnp": {"value" : "mww-Hmnp-US"}, "und-Kana": {"value" : "ja-Kana-JP"}, "und-Hmng": {"value" : "hnj-Hmng-LA"}, "wer": {"value" : "wer-Latn-ZZ"}, "zh-TW": {"value" : "zh-Hant-TW"}, "ntm": {"value" : "ntm-Latn-ZZ"}, "ntr":
    {"value" : "ntr-Latn-ZZ"}, "zh-US": {"value" : "zh-Hant-US"}, "und-Xpeo": {"value" : "peo-Xpeo-IR"}, "jmc": {"value" : "jmc-Latn-TZ"}, "nui": {"value" : "nui-Latn-ZZ"}, "jml": {"value" : "jml-Deva-NP"}, "nup": {"value" : "nup-Latn-ZZ"}, "und-Cyrl-SK": {"value" : "uk-Cyrl-SK"}, "nus": {"value" : "nus-Latn-SS"}, "nuv": {"value" : "nuv-Latn-ZZ"}, "nux": {"value" : "nux-Latn-ZZ"}, "zh-TH": {"value" : "zh-Hant-TH"}, "wgi": {"value" : "wgi-Latn-ZZ"}, "und-Phnx": {"value" : "phn-Phnx-LB"}, "und-Cyrl-TR": {"value"
    : "kbd-Cyrl-TR"}, "ffi": {"value" : "ffi-Latn-ZZ"}, "und-Elym": {"value" : "arc-Elym-IR"}, "ffm": {"value" : "ffm-Latn-ML"}, "und-Rjng": {"value" : "rej-Rjng-ID"}, "whg": {"value" : "whg-Latn-ZZ"}, "nwb": {"value" : "nwb-Latn-ZZ"}, "zh-SR": {"value" : "zh-Hant-SR"}, "wib": {"value" : "wib-Latn-ZZ"}, "und-Hebr": {"value" : "he-Hebr-IL"}, "saf": {"value" : "saf-Latn-GH"}, "sah": {"value" : "sah-Cyrl-RU"}, "saq": {"value" : "saq-Latn-KE"}, "wiu": {"value" : "wiu-Latn-ZZ"}, "sas": {"value" : "sas-Latn-ID"},
    "wiv": {"value" : "wiv-Latn-ZZ"}, "nxq": {"value" : "nxq-Latn-CN"}, "sat": {"value" : "sat-Olck-IN"}, "nxr": {"value" : "nxr-Latn-ZZ"}, "sav": {"value" : "sav-Latn-SN"}, "saz": {"value" : "saz-Saur-IN"}, "wja": {"value" : "wja-Latn-ZZ"}, "sba": {"value" : "sba-Latn-ZZ"}, "sbe": {"value" : "sbe-Latn-ZZ"}, "wji": {"value" : "wji-Latn-ZZ"}, "mn-Mong": {"value" : "mn-Mong-CN"}, "und-419": {"value" : "es-Latn-419"}, "fia": {"value" : "fia-Arab-SD"}, "sbp": {"value" : "sbp-Latn-TZ"}, "und-NO": {"value" : "nb-Latn-NO"}
    , "nyn": {"value" : "nyn-Latn-UG"}, "nym": {"value" : "nym-Latn-TZ"}, "und-NL": {"value" : "nl-Latn-NL"}, "und-NP": {"value" : "ne-Deva-NP"}, "fil": {"value" : "fil-Latn-PH"}, "bal": {"value" : "bal-Arab-PK"}, "ban": {"value" : "ban-Latn-ID"}, "bap": {"value" : "bap-Deva-NP"}, "fit": {"value" : "fit-Latn-SE"}, "bar": {"value" : "bar-Latn-AT"}, "bas": {"value" : "bas-Latn-CM"}, "bav": {"value" : "bav-Latn-ZZ"}, "bax": {"value" : "bax-Bamu-CM"}, "jra": {"value" : "jra-Latn-ZZ"}, "sck": {"value" : "sck-Deva-IN"}
    , "nzi": {"value" : "nzi-Latn-GH"}, "scl": {"value" : "scl-Arab-ZZ"}, "sco": {"value" : "sco-Latn-GB"}, "scn": {"value" : "scn-Latn-IT"}, "aa": {"value" : "aa-Latn-ET"}, "bba": {"value" : "bba-Latn-ZZ"}, "und-MN": {"value" : "mn-Cyrl-MN"}, "ab": {"value" : "ab-Cyrl-GE"}, "und-MM": {"value" : "my-Mymr-MM"}, "und-Osma": {"value" : "so-Osma-SO"}, "bbc": {"value" : "bbc-Latn-ID"}, "scs": {"value" : "scs-Latn-CA"}, "und-ML": {"value" : "bm-Latn-ML"}, "bbb": {"value" : "bbb-Latn-ZZ"}, "und-MK": {"value" : "mk-Cyrl-MK"}
    , "ae": {"value" : "ae-Avst-IR"}, "und-MR": {"value" : "ar-Arab-MR"}, "af": {"value" : "af-Latn-ZA"}, "bbd": {"value" : "bbd-Latn-ZZ"}, "und-MQ": {"value" : "fr-Latn-MQ"}, "und-Wara": {"value" : "hoc-Wara-IN"}, "und-MO": {"value" : "zh-Hant-MO"}, "und-MV": {"value" : "dv-Thaa-MV"}, "und-MU": {"value" : "mfe-Latn-MU"}, "ak": {"value" : "ak-Latn-GH"}, "und-MT": {"value" : "mt-Latn-MT"}, "bbj": {"value" : "bbj-Latn-CM"}, "am": {"value" : "am-Ethi-ET"}, "und-MZ": {"value" : "pt-Latn-MZ"}, "an": {"value" : "an-Latn-ES"}
    , "und-MY": {"value" : "ms-Latn-MY"}, "und-MX": {"value" : "es-Latn-MX"}, "ar": {"value" : "ar-Arab-EG"}, "bbp": {"value" : "bbp-Latn-ZZ"}, "as": {"value" : "as-Beng-IN"}, "bbr": {"value" : "bbr-Latn-ZZ"}, "sdc": {"value" : "sdc-Latn-IT"}, "und-NC": {"value" : "fr-Latn-NC"}, "av": {"value" : "av-Cyrl-RU"}, "sdh": {"value" : "sdh-Arab-IR"}, "und-NA": {"value" : "af-Latn-NA"}, "ay": {"value" : "ay-Latn-BO"}, "az": {"value" : "az-Latn-AZ"}, "und-NE": {"value" : "ha-Latn-NE"}, "und-NI": {"value" : "es-Latn-NI"}
    , "ba": {"value" : "ba-Cyrl-RU"}, "wls": {"value" : "wls-Latn-WF"}, "und-Kore": {"value" : "ko-Kore-KR"}, "und-LK": {"value" : "si-Sinh-LK"}, "be": {"value" : "be-Cyrl-BY"}, "bcf": {"value" : "bcf-Latn-ZZ"}, "bg": {"value" : "bg-Cyrl-BG"}, "bch": {"value" : "bch-Latn-ZZ"}, "bi": {"value" : "bi-Latn-VU"}, "und-LU": {"value" : "fr-Latn-LU"}, "bci": {"value" : "bci-Latn-CI"}, "und-LT": {"value" : "lt-Latn-LT"}, "und-LS": {"value" : "st-Latn-LS"}, "bm": {"value" : "bm-Latn-ML"}, "bcn": {"value" : "bcn-Latn-ZZ"}
    , "bn": {"value" : "bn-Beng-BD"}, "und-LY": {"value" : "ar-Arab-LY"}, "bcm": {"value" : "bcm-Latn-ZZ"}, "bo": {"value" : "bo-Tibt-CN"}, "bco": {"value" : "bco-Latn-ZZ"}, "und-LV": {"value" : "lv-Latn-LV"}, "br": {"value" : "br-Latn-FR"}, "bcq": {"value" : "bcq-Ethi-ZZ"}, "bs": {"value" : "bs-Latn-BA"}, "bcu": {"value" : "bcu-Latn-ZZ"}, "sef": {"value" : "sef-Latn-CI"}, "und-MA": {"value" : "ar-Arab-MA"}, "sei": {"value" : "sei-Latn-MX"}, "seh": {"value" : "seh-Latn-MZ"}, "und-MF": {"value" : "fr-Latn-MF"}
    , "wmo": {"value" : "wmo-Latn-ZZ"}, "und-ME": {"value" : "sr-Latn-ME"}, "und-MD": {"value" : "ro-Latn-MD"}, "und-MC": {"value" : "fr-Latn-MC"}, "ca": {"value" : "ca-Latn-ES"}, "und-MG": {"value" : "mg-Latn-MG"}, "ses": {"value" : "ses-Latn-ML"}, "ce": {"value" : "ce-Cyrl-RU"}, "und-Cyrl-BA": {"value" : "sr-Cyrl-BA"}, "bdd": {"value" : "bdd-Latn-ZZ"}, "und-KP": {"value" : "ko-Kore-KP"}, "ch": {"value" : "ch-Latn-GU"}, "und-KM": {"value" : "ar-Arab-KM"}, "und-KR": {"value" : "ko-Kore-KR"}, "co": {"value" :
    "co-Latn-FR"}, "flr": {"value" : "flr-Latn-ZZ"}, "und-KW": {"value" : "ar-Arab-KW"}, "wnc": {"value" : "wnc-Latn-ZZ"}, "und-Dogr": {"value" : "doi-Dogr-IN"}, "cr": {"value" : "cr-Cans-CA"}, "cs": {"value" : "cs-Latn-CZ"}, "cu": {"value" : "cu-Cyrl-RU"}, "und-KZ": {"value" : "ru-Cyrl-KZ"}, "cv": {"value" : "cv-Cyrl-RU"}, "wni": {"value" : "wni-Arab-KM"}, "und-LA": {"value" : "lo-Laoo-LA"}, "cy": {"value" : "cy-Latn-GB"}, "und-LB": {"value" : "ar-Arab-LB"}, "und-LI": {"value" : "de-Latn-LI"}, "da": {"value"
    : "da-Latn-DK"}, "und-Cyrl-AL": {"value" : "mk-Cyrl-AL"}, "wnu": {"value" : "wnu-Latn-ZZ"}, "de": {"value" : "de-Latn-DE"}, "bef": {"value" : "bef-Latn-ZZ"}, "beh": {"value" : "beh-Latn-ZZ"}, "und-JO": {"value" : "ar-Arab-JO"}, "bej": {"value" : "bej-Arab-SD"}, "fmp": {"value" : "fmp-Latn-ZZ"}, "jut": {"value" : "jut-Latn-DK"}, "bem": {"value" : "bem-Latn-ZM"}, "und-JP": {"value" : "ja-Jpan-JP"}, "wob": {"value" : "wob-Latn-ZZ"}, "sga": {"value" : "sga-Ogam-IE"}, "bet": {"value" : "bet-Latn-ZZ"}, "dv": {"value"
    : "dv-Thaa-MV"}, "bex": {"value" : "bex-Latn-ZZ"}, "bew": {"value" : "bew-Latn-ID"}, "bez": {"value" : "bez-Latn-TZ"}, "dz": {"value" : "dz-Tibt-BT"}, "ms-ID": {"value" : "ms-Latn-ID"}, "wos": {"value" : "wos-Latn-ZZ"}, "und-KH": {"value" : "km-Khmr-KH"}, "und-KG": {"value" : "ky-Cyrl-KG"}, "sgs": {"value" : "sgs-Latn-LT"}, "und-KE": {"value" : "sw-Latn-KE"}, "ee": {"value" : "ee-Latn-GH"}, "bfd": {"value" : "bfd-Latn-CM"}, "sgw": {"value" : "sgw-Ethi-ZZ"}, "und-IN": {"value" : "hi-Deva-IN"}, "und-IL": {"value"
    : "he-Hebr-IL"}, "el": {"value" : "el-Grek-GR"}, "sgz": {"value" : "sgz-Latn-ZZ"}, "und-IR": {"value" : "fa-Arab-IR"}, "en": {"value" : "en-Latn-US"}, "und-IQ": {"value" : "ar-Arab-IQ"}, "und-Perm": {"value" : "kv-Perm-RU"}, "eo": {"value" : "eo-Latn-001"}, "bfq": {"value" : "bfq-Taml-IN"}, "es": {"value" : "es-Latn-ES"}, "und-IT": {"value" : "it-Latn-IT"}, "et": {"value" : "et-Latn-EE"}, "und-IS": {"value" : "is-Latn-IS"}, "eu": {"value" : "eu-Latn-ES"}, "bft": {"value" : "bft-Arab-PK"}, "bfy": {"value"
    : "bfy-Deva-IN"}, "shi": {"value" : "shi-Tfng-MA"}, "shk": {"value" : "shk-Latn-ZZ"}, "shn": {"value" : "shn-Mymr-MM"}, "fod": {"value" : "fod-Latn-ZZ"}, "fa": {"value" : "fa-Arab-IR"}, "bgc": {"value" : "bgc-Deva-IN"}, "ff": {"value" : "ff-Latn-SN"}, "shu": {"value" : "shu-Arab-ZZ"}, "fi": {"value" : "fi-Latn-FI"}, "fj": {"value" : "fj-Latn-FJ"}, "fon": {"value" : "fon-Latn-BJ"}, "und-HM": {"value" : "und-Latn-HM"}, "und-HK": {"value" : "zh-Hant-HK"}, "bgn": {"value" : "bgn-Arab-PK"}, "for": {"value" :
    "for-Latn-ZZ"}, "fo": {"value" : "fo-Latn-FO"}, "und-HN": {"value" : "es-Latn-HN"}, "fr": {"value" : "fr-Latn-FR"}, "und-HU": {"value" : "hu-Latn-HU"}, "und-HT": {"value" : "ht-Latn-HT"}, "ku-Arab": {"value" : "ku-Arab-IQ"}, "sid": {"value" : "sid-Latn-ET"}, "und-HR": {"value" : "hr-Latn-HR"}, "sig": {"value" : "sig-Latn-ZZ"}, "bgx": {"value" : "bgx-Grek-TR"}, "fy": {"value" : "fy-Latn-NL"}, "sim": {"value" : "sim-Latn-ZZ"}, "sil": {"value" : "sil-Latn-ZZ"}, "fpe": {"value" : "fpe-Latn-ZZ"}, "ga": {"value"
    : "ga-Latn-IE"}, "bhb": {"value" : "bhb-Deva-IN"}, "gd": {"value" : "gd-Latn-GB"}, "und-ID": {"value" : "id-Latn-ID"}, "und-IC": {"value" : "es-Latn-IC"}, "bhg": {"value" : "bhg-Latn-ZZ"}, "und-GH": {"value" : "ak-Latn-GH"}, "bhi": {"value" : "bhi-Deva-IN"}, "und-GF": {"value" : "fr-Latn-GF"}, "und-GE": {"value" : "ka-Geor-GE"}, "und-GL": {"value" : "kl-Latn-GL"}, "gl": {"value" : "gl-Latn-ES"}, "bhl": {"value" : "bhl-Latn-ZZ"}, "gn": {"value" : "gn-Latn-PY"}, "bho": {"value" : "bho-Deva-IN"}, "und-GP":
    {"value" : "fr-Latn-GP"}, "und-GN": {"value" : "fr-Latn-GN"}, "und-GT": {"value" : "es-Latn-GT"}, "und-GS": {"value" : "und-Latn-GS"}, "gu": {"value" : "gu-Gujr-IN"}, "und-GR": {"value" : "el-Grek-GR"}, "gv": {"value" : "gv-Latn-IM"}, "und-GQ": {"value" : "es-Latn-GQ"}, "und-Palm": {"value" : "arc-Palm-SY"}, "und-GW": {"value" : "pt-Latn-GW"}, "bhy": {"value" : "bhy-Latn-ZZ"}, "ha": {"value" : "ha-Latn-NG"}, "wrs": {"value" : "wrs-Latn-ZZ"}, "bib": {"value" : "bib-Latn-ZZ"}, "sjr": {"value" : "sjr-Latn-ZZ"}
    , "he": {"value" : "he-Hebr-IL"}, "big": {"value" : "big-Latn-ZZ"}, "hi": {"value" : "hi-Deva-IN"}, "und-Cyrl-GE": {"value" : "ab-Cyrl-GE"}, "bik": {"value" : "bik-Latn-PH"}, "bin": {"value" : "bin-Latn-NG"}, "und-Cham": {"value" : "cjm-Cham-VN"}, "und-FI": {"value" : "fi-Latn-FI"}, "bim": {"value" : "bim-Latn-ZZ"}, "ho": {"value" : "ho-Latn-PG"}, "tg-PK": {"value" : "tg-Arab-PK"}, "und-FO": {"value" : "fo-Latn-FO"}, "bio": {"value" : "bio-Latn-ZZ"}, "fqs": {"value" : "fqs-Latn-ZZ"}, "hr": {"value" : "hr-Latn-HR"}
    , "skc": {"value" : "skc-Latn-ZZ"}, "wsg": {"value" : "wsg-Gong-IN"}, "biq": {"value" : "biq-Latn-ZZ"}, "ht": {"value" : "ht-Latn-HT"}, "hu": {"value" : "hu-Latn-HU"}, "und-FR": {"value" : "fr-Latn-FR"}, "wsk": {"value" : "wsk-Latn-ZZ"}, "hy": {"value" : "hy-Armn-AM"}, "hz": {"value" : "hz-Latn-NA"}, "frc": {"value" : "frc-Latn-US"}, "ia": {"value" : "ia-Latn-001"}, "sks": {"value" : "sks-Latn-ZZ"}, "id": {"value" : "id-Latn-ID"}, "skr": {"value" : "skr-Arab-PK"}, "ig": {"value" : "ig-Latn-NG"}, "und-GA":
    {"value" : "fr-Latn-GA"}, "bji": {"value" : "bji-Ethi-ZZ"}, "ii": {"value" : "ii-Yiii-CN"}, "bjh": {"value" : "bjh-Latn-ZZ"}, "und-EE": {"value" : "et-Latn-EE"}, "ik": {"value" : "ik-Latn-US"}, "bjj": {"value" : "bjj-Deva-IN"}, "und-EC": {"value" : "es-Latn-EC"}, "und-Cprt": {"value" : "grc-Cprt-CY"}, "frp": {"value" : "frp-Latn-FR"}, "in": {"value" : "in-Latn-ID"}, "bjo": {"value" : "bjo-Latn-ZZ"}, "frs": {"value" : "frs-Latn-DE"}, "io": {"value" : "io-Latn-001"}, "und-EH": {"value" : "ar-Arab-EH"}, "bjn":
    {"value" : "bjn-Latn-ID"}, "frr": {"value" : "frr-Latn-DE"}, "und-EG": {"value" : "ar-Arab-EG"}, "is": {"value" : "is-Latn-IS"}, "sld": {"value" : "sld-Latn-ZZ"}, "bjr": {"value" : "bjr-Latn-ZZ"}, "it": {"value" : "it-Latn-IT"}, "iu": {"value" : "iu-Cans-CA"}, "und-ER": {"value" : "ti-Ethi-ER"}, "bjt": {"value" : "bjt-Latn-SN"}, "iw": {"value" : "iw-Hebr-IL"}, "und-Tirh": {"value" : "mai-Tirh-IN"}, "sli": {"value" : "sli-Latn-PL"}, "und-EU": {"value" : "en-Latn-GB"}, "wtm": {"value" : "wtm-Deva-IN"}, "sll":
    {"value" : "sll-Latn-ZZ"}, "und-ET": {"value" : "am-Ethi-ET"}, "bjz": {"value" : "bjz-Latn-ZZ"}, "und-ES": {"value" : "es-Latn-ES"}, "und-EZ": {"value" : "de-Latn-EZ"}, "ja": {"value" : "ja-Jpan-JP"}, "zh-GF": {"value" : "zh-Hant-GF"}, "bkc": {"value" : "bkc-Latn-ZZ"}, "zh-GB": {"value" : "zh-Hant-GB"}, "und-Cyrl-GR": {"value" : "mk-Cyrl-GR"}, "ji": {"value" : "ji-Hebr-UA"}, "und-DE": {"value" : "de-Latn-DE"}, "sly": {"value" : "sly-Latn-ID"}, "bkm": {"value" : "bkm-Latn-CM"}, "sma": {"value" : "sma-Latn-SE"}
    , "bkq": {"value" : "bkq-Latn-ZZ"}, "und-DK": {"value" : "da-Latn-DK"}, "und-DJ": {"value" : "aa-Latn-DJ"}, "bkv": {"value" : "bkv-Latn-ZZ"}, "jv": {"value" : "jv-Latn-ID"}, "bku": {"value" : "bku-Latn-PH"}, "jw": {"value" : "jw-Latn-ID"}, "und-DO": {"value" : "es-Latn-DO"}, "smj": {"value" : "smj-Latn-SE"}, "smn": {"value" : "smn-Latn-FI"}, "ka": {"value" : "ka-Geor-GE"}, "smq": {"value" : "smq-Latn-ZZ"}, "wuu": {"value" : "wuu-Hans-CN"}, "smp": {"value" : "smp-Samr-IL"}, "sms": {"value" : "sms-Latn-FI"}
    , "wuv": {"value" : "wuv-Latn-ZZ"}, "und-DZ": {"value" : "ar-Arab-DZ"}, "kg": {"value" : "kg-Latn-CD"}, "und-EA": {"value" : "es-Latn-EA"}, "ki": {"value" : "ki-Latn-KE"}, "kj": {"value" : "kj-Latn-NA"}, "kk": {"value" : "kk-Cyrl-KZ"}, "man-Nkoo": {"value" : "man-Nkoo-GN"}, "und-CD": {"value" : "sw-Latn-CD"}, "kl": {"value" : "kl-Latn-GL"}, "und-Telu": {"value" : "te-Telu-IN"}, "km": {"value" : "km-Khmr-KH"}, "kn": {"value" : "kn-Knda-IN"}, "ko": {"value" : "ko-Kore-KR"}, "und-CH": {"value" : "de-Latn-CH"}
    , "und-CG": {"value" : "fr-Latn-CG"}, "und-CF": {"value" : "fr-Latn-CF"}, "kr": {"value" : "kr-Latn-ZZ"}, "ks": {"value" : "ks-Arab-IN"}, "und-CL": {"value" : "es-Latn-CL"}, "snc": {"value" : "snc-Latn-ZZ"}, "ku": {"value" : "ku-Latn-TR"}, "blt": {"value" : "blt-Tavt-VN"}, "kv": {"value" : "kv-Cyrl-RU"}, "und-CI": {"value" : "fr-Latn-CI"}, "kw": {"value" : "kw-Latn-GB"}, "und-CP": {"value" : "und-Latn-CP"}, "und-CO": {"value" : "es-Latn-CO"}, "ky": {"value" : "ky-Cyrl-KG"}, "und-CN": {"value" : "zh-Hans-CN"}
    , "und-CM": {"value" : "fr-Latn-CM"}, "snk": {"value" : "snk-Latn-ML"}, "fub": {"value" : "fub-Arab-CM"}, "und-CR": {"value" : "es-Latn-CR"}, "fud": {"value" : "fud-Latn-WF"}, "snp": {"value" : "snp-Latn-ZZ"}, "la": {"value" : "la-Latn-VA"}, "und-CW": {"value" : "pap-Latn-CW"}, "fuf": {"value" : "fuf-Latn-GN"}, "lb": {"value" : "lb-Latn-LU"}, "und-CV": {"value" : "pt-Latn-CV"}, "fue": {"value" : "fue-Latn-ZZ"}, "und-CU": {"value" : "es-Latn-CU"}, "fuh": {"value" : "fuh-Latn-ZZ"}, "und-CZ": {"value" : "cs-Latn-CZ"}
    , "lg": {"value" : "lg-Latn-UG"}, "und-CY": {"value" : "el-Grek-CY"}, "bmh": {"value" : "bmh-Latn-ZZ"}, "snx": {"value" : "snx-Latn-ZZ"}, "li": {"value" : "li-Latn-NL"}, "sny": {"value" : "sny-Latn-ZZ"}, "wwa": {"value" : "wwa-Latn-ZZ"}, "bmk": {"value" : "bmk-Latn-ZZ"}, "und-Cher": {"value" : "chr-Cher-US"}, "fur": {"value" : "fur-Latn-IT"}, "ln": {"value" : "ln-Latn-CD"}, "und-BA": {"value" : "bs-Latn-BA"}, "fuq": {"value" : "fuq-Latn-NE"}, "lo": {"value" : "lo-Laoo-LA"}, "und-BG": {"value" : "bg-Cyrl-BG"}
    , "und-BF": {"value" : "fr-Latn-BF"}, "fuv": {"value" : "fuv-Latn-NG"}, "und-BE": {"value" : "nl-Latn-BE"}, "bmq": {"value" : "bmq-Latn-ML"}, "und-BD": {"value" : "bn-Beng-BD"}, "lt": {"value" : "lt-Latn-LT"}, "lu": {"value" : "lu-Latn-CD"}, "und-BJ": {"value" : "fr-Latn-BJ"}, "lv": {"value" : "lv-Latn-LV"}, "ogc": {"value" : "ogc-Latn-ZZ"}, "sog": {"value" : "sog-Sogd-UZ"}, "und-BI": {"value" : "rn-Latn-BI"}, "bmu": {"value" : "bmu-Latn-ZZ"}, "fuy": {"value" : "fuy-Latn-ZZ"}, "und-BH": {"value" : "ar-Arab-BH"}
    , "und-BO": {"value" : "es-Latn-BO"}, "und-BN": {"value" : "ms-Latn-BN"}, "sok": {"value" : "sok-Latn-ZZ"}, "und-BL": {"value" : "fr-Latn-BL"}, "und-BR": {"value" : "pt-Latn-BR"}, "und-BQ": {"value" : "pap-Latn-BQ"}, "soq": {"value" : "soq-Latn-ZZ"}, "und-BV": {"value" : "und-Latn-BV"}, "und-BT": {"value" : "dz-Tibt-BT"}, "sou": {"value" : "sou-Thai-TH"}, "bng": {"value" : "bng-Latn-ZZ"}, "mg": {"value" : "mg-Latn-MG"}, "und-BY": {"value" : "be-Cyrl-BY"}, "und-Glag": {"value" : "cu-Glag-BG"}, "mh": {"value"
    : "mh-Latn-MH"}, "mi": {"value" : "mi-Latn-NZ"}, "soy": {"value" : "soy-Latn-ZZ"}, "mk": {"value" : "mk-Cyrl-MK"}, "ml": {"value" : "ml-Mlym-IN"}, "bnm": {"value" : "bnm-Latn-ZZ"}, "mn": {"value" : "mn-Cyrl-MN"}, "mo": {"value" : "mo-Latn-RO"}, "und-Prti": {"value" : "xpr-Prti-IR"}, "fvr": {"value" : "fvr-Latn-SD"}, "und-AF": {"value" : "fa-Arab-AF"}, "bnp": {"value" : "bnp-Latn-ZZ"}, "mr": {"value" : "mr-Deva-IN"}, "und-AE": {"value" : "ar-Arab-AE"}, "ms": {"value" : "ms-Latn-MY"}, "spd": {"value" : "spd-Latn-ZZ"}
    , "und-AD": {"value" : "ca-Latn-AD"}, "mt": {"value" : "mt-Latn-MT"}, "my": {"value" : "my-Mymr-MM"}, "zh-BN": {"value" : "zh-Hant-BN"}, "und-AM": {"value" : "hy-Armn-AM"}, "spl": {"value" : "spl-Latn-ZZ"}, "und-AL": {"value" : "sq-Latn-AL"}, "und-AR": {"value" : "es-Latn-AR"}, "und-AQ": {"value" : "und-Latn-AQ"}, "na": {"value" : "na-Latn-NR"}, "und-AO": {"value" : "pt-Latn-AO"}, "nb": {"value" : "nb-Latn-NO"}, "nd": {"value" : "nd-Latn-ZW"}, "und-AT": {"value" : "de-Latn-AT"}, "ne": {"value" : "ne-Deva-NP"}
    , "sps": {"value" : "sps-Latn-ZZ"}, "und-AS": {"value" : "sm-Latn-AS"}, "und-AZ": {"value" : "az-Latn-AZ"}, "ng": {"value" : "ng-Latn-NA"}, "und-AX": {"value" : "sv-Latn-AX"}, "und-AW": {"value" : "nl-Latn-AW"}, "boj": {"value" : "boj-Latn-ZZ"}, "nl": {"value" : "nl-Latn-NL"}, "bon": {"value" : "bon-Latn-ZZ"}, "nn": {"value" : "nn-Latn-NO"}, "bom": {"value" : "bom-Latn-ZZ"}, "no": {"value" : "no-Latn-NO"}, "nr": {"value" : "nr-Latn-ZA"}, "arc-Nbat": {"value" : "arc-Nbat-JO"}, "und-Medf": {"value" : "mis-Medf-NG"}
    , "nv": {"value" : "nv-Latn-US"}, "kaa": {"value" : "kaa-Cyrl-UZ"}, "ny": {"value" : "ny-Latn-MW"}, "kac": {"value" : "kac-Latn-MM"}, "kab": {"value" : "kab-Latn-DZ"}, "kad": {"value" : "kad-Latn-ZZ"}, "kai": {"value" : "kai-Latn-ZZ"}, "oc": {"value" : "oc-Latn-FR"}, "zh-AU": {"value" : "zh-Hant-AU"}, "kaj": {"value" : "kaj-Latn-NG"}, "kam": {"value" : "kam-Latn-KE"}, "und-Tagb": {"value" : "tbw-Tagb-PH"}, "kao": {"value" : "kao-Latn-ML"}, "und-Ogam": {"value" : "sga-Ogam-IE"}, "om": {"value" : "om-Latn-ET"}
    , "srb": {"value" : "srb-Sora-IN"}, "or": {"value" : "or-Orya-IN"}, "tg-Arab": {"value" : "tg-Arab-PK"}, "os": {"value" : "os-Cyrl-GE"}, "und-Sogd": {"value" : "sog-Sogd-UZ"}, "bpy": {"value" : "bpy-Beng-IN"}, "kbd": {"value" : "kbd-Cyrl-RU"}, "srn": {"value" : "srn-Latn-SR"}, "pa": {"value" : "pa-Guru-IN"}, "srr": {"value" : "srr-Latn-SN"}, "bqc": {"value" : "bqc-Latn-ZZ"}, "und-Kthi": {"value" : "bho-Kthi-IN"}, "kbm": {"value" : "kbm-Latn-ZZ"}, "kbp": {"value" : "kbp-Latn-ZZ"}, "srx": {"value" : "srx-Deva-IN"}
    , "bqi": {"value" : "bqi-Arab-IR"}, "kbq": {"value" : "kbq-Latn-ZZ"}, "pl": {"value" : "pl-Latn-PL"}, "bqp": {"value" : "bqp-Latn-ZZ"}, "kbx": {"value" : "kbx-Latn-ZZ"}, "kby": {"value" : "kby-Arab-NE"}, "ps": {"value" : "ps-Arab-AF"}, "pt": {"value" : "pt-Latn-BR"}, "ssd": {"value" : "ssd-Latn-ZZ"}, "und-Nkoo": {"value" : "man-Nkoo-GN"}, "bqv": {"value" : "bqv-Latn-CI"}, "ssg": {"value" : "ssg-Latn-ZZ"}, "und-Mymr": {"value" : "my-Mymr-MM"}, "kcg": {"value" : "kcg-Latn-NG"}, "bra": {"value" : "bra-Deva-IN"}
    , "kck": {"value" : "kck-Latn-ZW"}, "kcl": {"value" : "kcl-Latn-ZZ"}, "okr": {"value" : "okr-Latn-ZZ"}, "ssy": {"value" : "ssy-Latn-ER"}, "brh": {"value" : "brh-Arab-PK"}, "okv": {"value" : "okv-Latn-ZZ"}, "kct": {"value" : "kct-Latn-ZZ"}, "und-Hani": {"value" : "zh-Hani-CN"}, "und-Bugi": {"value" : "bug-Bugi-ID"}, "und-Hang": {"value" : "ko-Hang-KR"}, "qu": {"value" : "qu-Latn-PE"}, "brx": {"value" : "brx-Deva-IN"}, "und-Samr": {"value" : "smp-Samr-IL"}, "brz": {"value" : "brz-Latn-ZZ"}, "stk": {"value"
    : "stk-Latn-ZZ"}, "und-Hano": {"value" : "hnn-Hano-PH"}, "kde": {"value" : "kde-Latn-TZ"}, "kdh": {"value" : "kdh-Arab-TG"}, "stq": {"value" : "stq-Latn-DE"}, "kdl": {"value" : "kdl-Latn-ZZ"}, "bsj": {"value" : "bsj-Latn-ZZ"}, "und-Hanb": {"value" : "zh-Hanb-TW"}, "kdt": {"value" : "kdt-Thai-TH"}, "rm": {"value" : "rm-Latn-CH"}, "rn": {"value" : "rn-Latn-BI"}, "ro": {"value" : "ro-Latn-RO"}, "sua": {"value" : "sua-Latn-ZZ"}, "und-Deva-BT": {"value" : "ne-Deva-BT"}, "bsq": {"value" : "bsq-Bass-LR"}, "bst":
    {"value" : "bst-Ethi-ZZ"}, "sue": {"value" : "sue-Latn-ZZ"}, "bss": {"value" : "bss-Latn-CM"}, "ru": {"value" : "ru-Cyrl-RU"}, "und-Buhd": {"value" : "bku-Buhd-PH"}, "rw": {"value" : "rw-Latn-RW"}, "kea": {"value" : "kea-Latn-CV"}, "suk": {"value" : "suk-Latn-TZ"}, "grc-Linb": {"value" : "grc-Linb-GR"}, "sa": {"value" : "sa-Deva-IN"}, "sc": {"value" : "sc-Latn-IT"}, "sus": {"value" : "sus-Latn-GN"}, "sd": {"value" : "sd-Arab-PK"}, "sur": {"value" : "sur-Latn-ZZ"}, "se": {"value" : "se-Latn-NO"}, "sg": {"value"
    : "sg-Latn-CF"}, "ken": {"value" : "ken-Latn-CM"}, "si": {"value" : "si-Sinh-LK"}, "und-Hant": {"value" : "zh-Hant-TW"}, "und-Hans": {"value" : "zh-Hans-CN"}, "sk": {"value" : "sk-Latn-SK"}, "sl": {"value" : "sl-Latn-SI"}, "sm": {"value" : "sm-Latn-WS"}, "sn": {"value" : "sn-Latn-ZW"}, "bto": {"value" : "bto-Latn-PH"}, "so": {"value" : "so-Latn-SO"}, "sq": {"value" : "sq-Latn-AL"}, "sr": {"value" : "sr-Cyrl-RS"}, "ss": {"value" : "ss-Latn-ZA"}, "kez": {"value" : "kez-Latn-ZZ"}, "st": {"value" : "st-Latn-ZA"}
    , "su": {"value" : "su-Latn-ID"}, "btt": {"value" : "btt-Latn-ZZ"}, "sv": {"value" : "sv-Latn-SE"}, "sw": {"value" : "sw-Latn-TZ"}, "btv": {"value" : "btv-Deva-PK"}, "ong": {"value" : "ong-Latn-ZZ"}, "ta": {"value" : "ta-Taml-IN"}, "onn": {"value" : "onn-Latn-ZZ"}, "bua": {"value" : "bua-Cyrl-RU"}, "bud": {"value" : "bud-Latn-ZZ"}, "buc": {"value" : "buc-Latn-YT"}, "te": {"value" : "te-Telu-IN"}, "tg": {"value" : "tg-Cyrl-TJ"}, "th": {"value" : "th-Thai-TH"}, "und-Gong": {"value" : "wsg-Gong-IN"}, "bug":
    {"value" : "bug-Latn-ID"}, "kfo": {"value" : "kfo-Latn-CI"}, "ons": {"value" : "ons-Latn-ZZ"}, "ti": {"value" : "ti-Ethi-ET"}, "kfr": {"value" : "kfr-Deva-IN"}, "tk": {"value" : "tk-Latn-TM"}, "tl": {"value" : "tl-Latn-PH"}, "und-Lisu": {"value" : "lis-Lisu-CN"}, "buk": {"value" : "buk-Latn-ZZ"}, "tn": {"value" : "tn-Latn-ZA"}, "bum": {"value" : "bum-Latn-CM"}, "to": {"value" : "to-Latn-TO"}, "buo": {"value" : "buo-Latn-ZZ"}, "swc": {"value" : "swc-Latn-CD"}, "tr": {"value" : "tr-Latn-TR"}, "und-Gonm": {"value"
    : "esg-Gonm-IN"}, "kfy": {"value" : "kfy-Deva-IN"}, "swb": {"value" : "swb-Arab-YT"}, "ts": {"value" : "ts-Latn-ZA"}, "tt": {"value" : "tt-Cyrl-RU"}, "bus": {"value" : "bus-Latn-ZZ"}, "swg": {"value" : "swg-Latn-DE"}, "buu": {"value" : "buu-Latn-ZZ"}, "ty": {"value" : "ty-Latn-PF"}, "kge": {"value" : "kge-Latn-ID"}, "kgf": {"value" : "kgf-Latn-ZZ"}, "swp": {"value" : "swp-Latn-ZZ"}, "bvb": {"value" : "bvb-Latn-GQ"}, "ug": {"value" : "ug-Arab-CN"}, "swv": {"value" : "swv-Deva-IN"}, "kgp": {"value" : "kgp-Latn-BR"}
    , "uk": {"value" : "uk-Cyrl-UA"}, "ur": {"value" : "ur-Arab-PK"}, "kk-IR": {"value" : "kk-Arab-IR"}, "khb": {"value" : "khb-Talu-CN"}, "kha": {"value" : "kha-Latn-IN"}, "uz": {"value" : "uz-Latn-UZ"}, "sxn": {"value" : "sxn-Latn-ID"}, "xav": {"value" : "xav-Latn-BR"}, "opm": {"value" : "opm-Latn-ZZ"}, "bwd": {"value" : "bwd-Latn-ZZ"}, "und-Mlym": {"value" : "ml-Mlym-IN"}, "ve": {"value" : "ve-Latn-ZA"}, "khn": {"value" : "khn-Deva-IN"}, "sxw": {"value" : "sxw-Latn-ZZ"}, "vi": {"value" : "vi-Latn-VN"}, "khq":
    {"value" : "khq-Latn-ML"}, "kht": {"value" : "kht-Mymr-IN"}, "khs": {"value" : "khs-Latn-ZZ"}, "vo": {"value" : "vo-Latn-001"}, "khw": {"value" : "khw-Arab-PK"}, "bwr": {"value" : "bwr-Latn-ZZ"}, "khz": {"value" : "khz-Latn-ZZ"}, "und-ZW": {"value" : "sn-Latn-ZW"}, "xbi": {"value" : "xbi-Latn-ZZ"}, "gaa": {"value" : "gaa-Latn-GH"}, "syl": {"value" : "syl-Beng-BD"}, "wa": {"value" : "wa-Latn-BE"}, "gag": {"value" : "gag-Latn-MD"}, "gaf": {"value" : "gaf-Latn-ZZ"}, "kij": {"value" : "kij-Latn-ZZ"}, "syr":
    {"value" : "syr-Syrc-IQ"}, "und-YE": {"value" : "ar-Arab-YE"}, "gah": {"value" : "gah-Latn-ZZ"}, "gaj": {"value" : "gaj-Latn-ZZ"}, "gam": {"value" : "gam-Latn-ZZ"}, "bxh": {"value" : "bxh-Latn-ZZ"}, "gan": {"value" : "gan-Hans-CN"}, "kiu": {"value" : "kiu-Latn-TR"}, "kiw": {"value" : "kiw-Latn-ZZ"}, "wo": {"value" : "wo-Latn-SN"}, "gaw": {"value" : "gaw-Latn-ZZ"}, "und-Sarb": {"value" : "xsa-Sarb-YE"}, "gay": {"value" : "gay-Latn-ID"}, "und-YT": {"value" : "fr-Latn-YT"}, "kjd": {"value" : "kjd-Latn-ZZ"}
    , "szl": {"value" : "szl-Latn-PL"}, "xco": {"value" : "xco-Chrs-UZ"}, "xcr": {"value" : "xcr-Cari-TR"}, "gba": {"value" : "gba-Latn-ZZ"}, "und-Mult": {"value" : "skr-Mult-PK"}, "kjg": {"value" : "kjg-Laoo-LA"}, "gbf": {"value" : "gbf-Latn-ZZ"}, "oro": {"value" : "oro-Latn-ZZ"}, "und-Hatr": {"value" : "mis-Hatr-IQ"}, "bye": {"value" : "bye-Latn-ZZ"}, "xh": {"value" : "xh-Latn-ZA"}, "gbm": {"value" : "gbm-Deva-IN"}, "oru": {"value" : "oru-Arab-ZZ"}, "kjs": {"value" : "kjs-Latn-ZZ"}, "byn": {"value" : "byn-Ethi-ER"}
    , "und-XK": {"value" : "sq-Latn-XK"}, "yue-CN": {"value" : "yue-Hans-CN"}, "und-Lepc": {"value" : "lep-Lepc-IN"}, "byr": {"value" : "byr-Latn-ZZ"}, "kjy": {"value" : "kjy-Latn-ZZ"}, "osa": {"value" : "osa-Osge-US"}, "bys": {"value" : "bys-Latn-ZZ"}, "byv": {"value" : "byv-Latn-CM"}, "gbz": {"value" : "gbz-Arab-IR"}, "gby": {"value" : "gby-Latn-ZZ"}, "byx": {"value" : "byx-Latn-ZZ"}, "kkc": {"value" : "kkc-Latn-ZZ"}, "und-VU": {"value" : "bi-Latn-VU"}, "bza": {"value" : "bza-Latn-ZZ"}, "und-Goth": {"value"
    : "got-Goth-UA"}, "kkj": {"value" : "kkj-Latn-CM"}, "bze": {"value" : "bze-Latn-ML"}, "und-Avst": {"value" : "ae-Avst-IR"}, "bzf": {"value" : "bzf-Latn-ZZ"}, "yi": {"value" : "yi-Hebr-001"}, "bzh": {"value" : "bzh-Latn-ZZ"}, "und-WF": {"value" : "fr-Latn-WF"}, "yo": {"value" : "yo-Latn-NG"}, "gcr": {"value" : "gcr-Latn-GF"}, "ota": {"value" : "ota-Arab-ZZ"}, "und-WS": {"value" : "sm-Latn-WS"}, "bzw": {"value" : "bzw-Latn-ZZ"}, "und-UZ": {"value" : "uz-Latn-UZ"}, "und-UY": {"value" : "es-Latn-UY"}, "otk":
    {"value" : "otk-Orkh-MN"}, "xes": {"value" : "xes-Latn-ZZ"}, "za": {"value" : "za-Latn-CN"}, "gde": {"value" : "gde-Latn-ZZ"}, "kln": {"value" : "kln-Latn-KE"}, "und-VA": {"value" : "it-Latn-VA"}, "zh": {"value" : "zh-Hans-CN"}, "gdn": {"value" : "gdn-Latn-ZZ"}, "klq": {"value" : "klq-Latn-ZZ"}, "und-Saur": {"value" : "saz-Saur-IN"}, "klt": {"value" : "klt-Latn-ZZ"}, "und-VE": {"value" : "es-Latn-VE"}, "gdr": {"value" : "gdr-Latn-ZZ"}, "klx": {"value" : "klx-Latn-ZZ"}, "und-VN": {"value" : "vi-Latn-VN"}
    , "kk-MN": {"value" : "kk-Arab-MN"}, "zu": {"value" : "zu-Latn-ZA"}, "und-Armn": {"value" : "hy-Armn-AM"}, "kmb": {"value" : "kmb-Latn-AO"}, "und-TR": {"value" : "tr-Latn-TR"}, "geb": {"value" : "geb-Latn-ZZ"}, "und-TW": {"value" : "zh-Hant-TW"}, "kmh": {"value" : "kmh-Latn-ZZ"}, "und-TV": {"value" : "tvl-Latn-TV"}, "und-TZ": {"value" : "sw-Latn-TZ"}, "kmo": {"value" : "kmo-Latn-ZZ"}, "gej": {"value" : "gej-Latn-ZZ"}, "und-UA": {"value" : "uk-Cyrl-UA"}, "gel": {"value" : "gel-Latn-ZZ"}, "kms": {"value" :
    "kms-Latn-ZZ"}, "kmu": {"value" : "kmu-Latn-ZZ"}, "kmw": {"value" : "kmw-Latn-ZZ"}, "und-Tibt": {"value" : "bo-Tibt-CN"}, "und-UG": {"value" : "sw-Latn-UG"}, "und-Armi": {"value" : "arc-Armi-IR"}, "gez": {"value" : "gez-Ethi-ET"}, "und-ST": {"value" : "pt-Latn-ST"}, "knf": {"value" : "knf-Latn-GW"}, "und-SR": {"value" : "nl-Latn-SR"}, "und-SV": {"value" : "es-Latn-SV"}, "und-SY": {"value" : "ar-Arab-SY"}, "knp": {"value" : "knp-Latn-ZZ"}, "gfk": {"value" : "gfk-Latn-ZZ"}, "und-TD": {"value" : "fr-Latn-TD"}
    , "und-TH": {"value" : "th-Thai-TH"}, "und-TG": {"value" : "fr-Latn-TG"}, "und-TF": {"value" : "fr-Latn-TF"}, "und-TM": {"value" : "tk-Latn-TM"}, "und-TL": {"value" : "pt-Latn-TL"}, "und-TK": {"value" : "tkl-Latn-TK"}, "und-TJ": {"value" : "tg-Cyrl-TJ"}, "und-TO": {"value" : "to-Latn-TO"}, "und-TN": {"value" : "ar-Arab-TN"}, "und-RS": {"value" : "sr-Cyrl-RS"}, "koi": {"value" : "koi-Cyrl-RU"}, "und-RW": {"value" : "rw-Latn-RW"}, "kok": {"value" : "kok-Deva-IN"}, "und-RU": {"value" : "ru-Cyrl-RU"}, "kol":
    {"value" : "kol-Latn-ZZ"}, "kos": {"value" : "kos-Latn-FM"}, "ggn": {"value" : "ggn-Deva-NP"}, "und-SD": {"value" : "ar-Arab-SD"}, "und-SC": {"value" : "fr-Latn-SC"}, "und-SA": {"value" : "ar-Arab-SA"}, "koz": {"value" : "koz-Latn-ZZ"}, "und-SE": {"value" : "sv-Latn-SE"}, "und-SK": {"value" : "sk-Latn-SK"}, "und-SJ": {"value" : "nb-Latn-SJ"}, "und-SI": {"value" : "sl-Latn-SI"}, "taj": {"value" : "taj-Deva-NP"}, "und-SO": {"value" : "so-Latn-SO"}, "tal": {"value" : "tal-Latn-ZZ"}, "und-SN": {"value" : "fr-Latn-SN"}
    , "und-Osge": {"value" : "osa-Osge-US"}, "und-SM": {"value" : "it-Latn-SM"}, "kpf": {"value" : "kpf-Latn-ZZ"}, "tan": {"value" : "tan-Latn-ZZ"}, "kpe": {"value" : "kpe-Latn-LR"}, "und-QO": {"value" : "en-Latn-DG"}, "taq": {"value" : "taq-Latn-ZZ"}, "kpo": {"value" : "kpo-Latn-ZZ"}, "kpr": {"value" : "kpr-Latn-ZZ"}, "kpx": {"value" : "kpx-Latn-ZZ"}, "ghs": {"value" : "ghs-Latn-ZZ"}, "und-Lana": {"value" : "nod-Lana-TH"}, "tbc": {"value" : "tbc-Latn-ZZ"}, "und-RE": {"value" : "fr-Latn-RE"}, "tbd": {"value"
    : "tbd-Latn-ZZ"}, "tbg": {"value" : "tbg-Latn-ZZ"}, "tbf": {"value" : "tbf-Latn-ZZ"}, "und-RO": {"value" : "ro-Latn-RO"}, "kqb": {"value" : "kqb-Latn-ZZ"}, "tbo": {"value" : "tbo-Latn-ZZ"}, "kqf": {"value" : "kqf-Latn-ZZ"}, "und-PT": {"value" : "pt-Latn-PT"}, "und-PS": {"value" : "ar-Arab-PS"}, "cad": {"value" : "cad-Latn-US"}, "und-PR": {"value" : "es-Latn-PR"}, "tbw": {"value" : "tbw-Latn-PH"}, "und-PY": {"value" : "gn-Latn-PY"}, "gim": {"value" : "gim-Latn-ZZ"}, "und-PW": {"value" : "pau-Latn-PW"}, "gil":
    {"value" : "gil-Latn-KI"}, "kqs": {"value" : "kqs-Latn-ZZ"}, "tbz": {"value" : "tbz-Latn-ZZ"}, "und-Laoo": {"value" : "lo-Laoo-LA"}, "can": {"value" : "can-Latn-ZZ"}, "und-QA": {"value" : "ar-Arab-QA"}, "kqy": {"value" : "kqy-Ethi-ZZ"}, "ms-CC": {"value" : "ms-Arab-CC"}, "tci": {"value" : "tci-Latn-ZZ"}, "krc": {"value" : "krc-Cyrl-RU"}, "krj": {"value" : "krj-Latn-PH"}, "kri": {"value" : "kri-Latn-SL"}, "ozm": {"value" : "ozm-Latn-ZZ"}, "und-OM": {"value" : "ar-Arab-OM"}, "krl": {"value" : "krl-Latn-RU"}
    , "gjk": {"value" : "gjk-Arab-PK"}, "cbj": {"value" : "cbj-Latn-ZZ"}, "gjn": {"value" : "gjn-Latn-ZZ"}, "tcy": {"value" : "tcy-Knda-IN"}, "xla": {"value" : "xla-Latn-ZZ"}, "krs": {"value" : "krs-Latn-ZZ"}, "xlc": {"value" : "xlc-Lyci-TR"}, "kru": {"value" : "kru-Deva-IN"}, "und-PA": {"value" : "es-Latn-PA"}, "xld": {"value" : "xld-Lydi-TR"}, "gju": {"value" : "gju-Arab-PK"}, "und-PE": {"value" : "es-Latn-PE"}, "tdd": {"value" : "tdd-Tale-CN"}, "tdg": {"value" : "tdg-Deva-NP"}, "tdh": {"value" : "tdh-Deva-NP"}
    , "und-PH": {"value" : "fil-Latn-PH"}, "und-PG": {"value" : "tpi-Latn-PG"}, "ksb": {"value" : "ksb-Latn-TZ"}, "und-PF": {"value" : "fr-Latn-PF"}, "und-PM": {"value" : "fr-Latn-PM"}, "ksd": {"value" : "ksd-Latn-ZZ"}, "und-PL": {"value" : "pl-Latn-PL"}, "und-PK": {"value" : "ur-Arab-PK"}, "ksf": {"value" : "ksf-Latn-CM"}};
},
otciu_CLDRHelper_getDefaultLocale$$create = () => {
    return {"value" : "en_GB"};
},
otciu_CLDRHelper_getNumberFormatMap$$create = () => {
    return {"root": {"value" : "#,##0.###"}, "en": {"value" : "#,##0.###"}};
},
otciu_CLDRHelper_getDecimalDataMap$$create = () => {
    return {"root": {"exponentSeparator" : "E", "minusSign" : 45, "perMille" : 8240, "decimalSeparator" : 46, "listSeparator" : 59, "naN" : "NaN", "infinity" : "∞", "groupingSeparator" : 44, "percent" : 37}, "en": {"exponentSeparator" : "E", "minusSign" : 45, "perMille" : 8240, "decimalSeparator" : 46, "listSeparator" : 59, "naN" : "NaN", "infinity" : "∞", "groupingSeparator" : 44, "percent" : 37}};
},
otciu_CLDRHelper_getCurrencyMap$$create = () => {
    return {"root": {"UGS": {"symbol" : "UGS", "name" : "UGS"}, "FJD": {"symbol" : "FJD", "name" : "FJD"}, "MXN": {"symbol" : "MX$", "name" : "MXN"}, "STD": {"symbol" : "STD", "name" : "STD"}, "BRR": {"symbol" : "BRR", "name" : "BRR"}, "LVL": {"symbol" : "LVL", "name" : "LVL"}, "SCR": {"symbol" : "SCR", "name" : "SCR"}, "CDF": {"symbol" : "CDF", "name" : "CDF"}, "MXP": {"symbol" : "MXP", "name" : "MXP"}, "ZAL": {"symbol" : "ZAL", "name" : "ZAL"}, "BBD": {"symbol" : "BBD", "name" : "BBD"}, "HNL": {"symbol" :
    "HNL", "name" : "HNL"}, "UGX": {"symbol" : "UGX", "name" : "UGX"}, "LVR": {"symbol" : "LVR", "name" : "LVR"}, "MXV": {"symbol" : "MXV", "name" : "MXV"}, "ZAR": {"symbol" : "ZAR", "name" : "ZAR"}, "BRZ": {"symbol" : "BRZ", "name" : "BRZ"}, "STN": {"symbol" : "STN", "name" : "STN"}, "CUC": {"symbol" : "CUC", "name" : "CUC"}, "BSD": {"symbol" : "BSD", "name" : "BSD"}, "SDD": {"symbol" : "SDD", "name" : "SDD"}, "SDG": {"symbol" : "SDG", "name" : "SDG"}, "ZRN": {"symbol" : "ZRN", "name" : "ZRN"}, "IQD": {"symbol"
    : "IQD", "name" : "IQD"}, "SDP": {"symbol" : "SDP", "name" : "SDP"}, "CUP": {"symbol" : "CUP", "name" : "CUP"}, "GMD": {"symbol" : "GMD", "name" : "GMD"}, "TWD": {"symbol" : "NT$", "name" : "TWD"}, "RSD": {"symbol" : "RSD", "name" : "RSD"}, "ZRZ": {"symbol" : "ZRZ", "name" : "ZRZ"}, "UYI": {"symbol" : "UYI", "name" : "UYI"}, "MYR": {"symbol" : "MYR", "name" : "MYR"}, "FKP": {"symbol" : "FKP", "name" : "FKP"}, "UYP": {"symbol" : "UYP", "name" : "UYP"}, "XOF": {"symbol" : "CFA", "name" : "XOF"}, "ARA": {"symbol"
    : "ARA", "name" : "ARA"}, "UYU": {"symbol" : "UYU", "name" : "UYU"}, "SUR": {"symbol" : "SUR", "name" : "SUR"}, "UYW": {"symbol" : "UYW", "name" : "UYW"}, "CVE": {"symbol" : "CVE", "name" : "CVE"}, "OMR": {"symbol" : "OMR", "name" : "OMR"}, "KES": {"symbol" : "KES", "name" : "KES"}, "SEK": {"symbol" : "SEK", "name" : "SEK"}, "MZE": {"symbol" : "MZE", "name" : "MZE"}, "ARL": {"symbol" : "ARL", "name" : "ARL"}, "ARM": {"symbol" : "ARM", "name" : "ARM"}, "BTN": {"symbol" : "BTN", "name" : "BTN"}, "GNF": {"symbol"
    : "GNF", "name" : "GNF"}, "ARP": {"symbol" : "ARP", "name" : "ARP"}, "MZN": {"symbol" : "MZN", "name" : "MZN"}, "MZM": {"symbol" : "MZM", "name" : "MZM"}, "SVC": {"symbol" : "SVC", "name" : "SVC"}, "ARS": {"symbol" : "ARS", "name" : "ARS"}, "QAR": {"symbol" : "QAR", "name" : "QAR"}, "IRR": {"symbol" : "IRR", "name" : "IRR"}, "NLG": {"symbol" : "NLG", "name" : "NLG"}, "GNS": {"symbol" : "GNS", "name" : "GNS"}, "XPD": {"symbol" : "XPD", "name" : "XPD"}, "THB": {"symbol" : "THB", "name" : "THB"}, "UZS": {"symbol"
    : "UZS", "name" : "UZS"}, "XPF": {"symbol" : "CFPF", "name" : "XPF"}, "BDT": {"symbol" : "BDT", "name" : "BDT"}, "LYD": {"symbol" : "LYD", "name" : "LYD"}, "BUK": {"symbol" : "BUK", "name" : "BUK"}, "KWD": {"symbol" : "KWD", "name" : "KWD"}, "XPT": {"symbol" : "XPT", "name" : "XPT"}, "RUB": {"symbol" : "RUB", "name" : "RUB"}, "ISK": {"symbol" : "ISK", "name" : "ISK"}, "BEC": {"symbol" : "BEC", "name" : "BEC"}, "ISJ": {"symbol" : "ISJ", "name" : "ISJ"}, "BEF": {"symbol" : "BEF", "name" : "BEF"}, "MKD": {"symbol"
    : "MKD", "name" : "MKD"}, "BEL": {"symbol" : "BEL", "name" : "BEL"}, "RUR": {"symbol" : "RUR", "name" : "RUR"}, "DZD": {"symbol" : "DZD", "name" : "DZD"}, "PAB": {"symbol" : "PAB", "name" : "PAB"}, "MKN": {"symbol" : "MKN", "name" : "MKN"}, "SGD": {"symbol" : "SGD", "name" : "SGD"}, "KGS": {"symbol" : "KGS", "name" : "KGS"}, "HRD": {"symbol" : "HRD", "name" : "HRD"}, "XAF": {"symbol" : "FCFA", "name" : "XAF"}, "XAG": {"symbol" : "XAG", "name" : "XAG"}, "ATS": {"symbol" : "ATS", "name" : "ATS"}, "CHF": {"symbol"
    : "CHF", "name" : "CHF"}, "HRK": {"symbol" : "HRK", "name" : "HRK"}, "ITL": {"symbol" : "ITL", "name" : "ITL"}, "CHE": {"symbol" : "CHE", "name" : "CHE"}, "DJF": {"symbol" : "DJF", "name" : "DJF"}, "MLF": {"symbol" : "MLF", "name" : "MLF"}, "XRE": {"symbol" : "XRE", "name" : "XRE"}, "TZS": {"symbol" : "TZS", "name" : "TZS"}, "ADP": {"symbol" : "ADP", "name" : "ADP"}, "VND": {"symbol" : "₫", "name" : "VND"}, "XAU": {"symbol" : "XAU", "name" : "XAU"}, "AUD": {"symbol" : "A$", "name" : "AUD"}, "CHW": {"symbol"
    : "CHW", "name" : "CHW"}, "KHR": {"symbol" : "KHR", "name" : "KHR"}, "IDR": {"symbol" : "IDR", "name" : "IDR"}, "XBA": {"symbol" : "XBA", "name" : "XBA"}, "KYD": {"symbol" : "KYD", "name" : "KYD"}, "VNN": {"symbol" : "VNN", "name" : "VNN"}, "XBC": {"symbol" : "XBC", "name" : "XBC"}, "YDD": {"symbol" : "YDD", "name" : "YDD"}, "XBB": {"symbol" : "XBB", "name" : "XBB"}, "BWP": {"symbol" : "BWP", "name" : "BWP"}, "GQE": {"symbol" : "GQE", "name" : "GQE"}, "SHP": {"symbol" : "SHP", "name" : "SHP"}, "CYP": {"symbol"
    : "CYP", "name" : "CYP"}, "XBD": {"symbol" : "XBD", "name" : "XBD"}, "TJS": {"symbol" : "TJS", "name" : "TJS"}, "TJR": {"symbol" : "TJR", "name" : "TJR"}, "AED": {"symbol" : "AED", "name" : "AED"}, "RWF": {"symbol" : "RWF", "name" : "RWF"}, "DKK": {"symbol" : "DKK", "name" : "DKK"}, "BGL": {"symbol" : "BGL", "name" : "BGL"}, "ZWD": {"symbol" : "ZWD", "name" : "ZWD"}, "BGN": {"symbol" : "BGN", "name" : "BGN"}, "BGM": {"symbol" : "BGM", "name" : "BGM"}, "YUD": {"symbol" : "YUD", "name" : "YUD"}, "MMK": {"symbol"
    : "MMK", "name" : "MMK"}, "BGO": {"symbol" : "BGO", "name" : "BGO"}, "NOK": {"symbol" : "NOK", "name" : "NOK"}, "SYP": {"symbol" : "SYP", "name" : "SYP"}, "ZWL": {"symbol" : "ZWL", "name" : "ZWL"}, "YUM": {"symbol" : "YUM", "name" : "YUM"}, "LKR": {"symbol" : "LKR", "name" : "LKR"}, "YUN": {"symbol" : "YUN", "name" : "YUN"}, "ZWR": {"symbol" : "ZWR", "name" : "ZWR"}, "CZK": {"symbol" : "CZK", "name" : "CZK"}, "IEP": {"symbol" : "IEP", "name" : "IEP"}, "YUR": {"symbol" : "YUR", "name" : "YUR"}, "GRD": {"symbol"
    : "GRD", "name" : "GRD"}, "XCD": {"symbol" : "EC$", "name" : "XCD"}, "HTG": {"symbol" : "HTG", "name" : "HTG"}, "XSU": {"symbol" : "XSU", "name" : "XSU"}, "AFA": {"symbol" : "AFA", "name" : "AFA"}, "BHD": {"symbol" : "BHD", "name" : "BHD"}, "SIT": {"symbol" : "SIT", "name" : "SIT"}, "PTE": {"symbol" : "PTE", "name" : "PTE"}, "KZT": {"symbol" : "KZT", "name" : "KZT"}, "SZL": {"symbol" : "SZL", "name" : "SZL"}, "YER": {"symbol" : "YER", "name" : "YER"}, "AFN": {"symbol" : "AFN", "name" : "AFN"}, "BYB": {"symbol"
    : "BYB", "name" : "BYB"}, "RHD": {"symbol" : "RHD", "name" : "RHD"}, "AWG": {"symbol" : "AWG", "name" : "AWG"}, "NPR": {"symbol" : "NPR", "name" : "NPR"}, "MNT": {"symbol" : "MNT", "name" : "MNT"}, "GBP": {"symbol" : "£", "name" : "GBP"}, "BYN": {"symbol" : "BYN", "name" : "BYN"}, "XTS": {"symbol" : "XTS", "name" : "XTS"}, "HUF": {"symbol" : "HUF", "name" : "HUF"}, "BYR": {"symbol" : "BYR", "name" : "BYR"}, "BIF": {"symbol" : "BIF", "name" : "BIF"}, "XUA": {"symbol" : "XUA", "name" : "XUA"}, "XDR": {"symbol"
    : "XDR", "name" : "XDR"}, "BZD": {"symbol" : "BZD", "name" : "BZD"}, "MOP": {"symbol" : "MOP", "name" : "MOP"}, "NAD": {"symbol" : "NAD", "name" : "NAD"}, "SKK": {"symbol" : "SKK", "name" : "SKK"}, "PEI": {"symbol" : "PEI", "name" : "PEI"}, "TMM": {"symbol" : "TMM", "name" : "TMM"}, "PEN": {"symbol" : "PEN", "name" : "PEN"}, "WST": {"symbol" : "WST", "name" : "WST"}, "TMT": {"symbol" : "TMT", "name" : "TMT"}, "FRF": {"symbol" : "FRF", "name" : "FRF"}, "CLF": {"symbol" : "CLF", "name" : "CLF"}, "CLE": {"symbol"
    : "CLE", "name" : "CLE"}, "PES": {"symbol" : "PES", "name" : "PES"}, "GTQ": {"symbol" : "GTQ", "name" : "GTQ"}, "CLP": {"symbol" : "CLP", "name" : "CLP"}, "XEU": {"symbol" : "XEU", "name" : "XEU"}, "TND": {"symbol" : "TND", "name" : "TND"}, "SLL": {"symbol" : "SLL", "name" : "SLL"}, "XFO": {"symbol" : "XFO", "name" : "XFO"}, "DOP": {"symbol" : "DOP", "name" : "DOP"}, "KMF": {"symbol" : "KMF", "name" : "KMF"}, "XFU": {"symbol" : "XFU", "name" : "XFU"}, "GEK": {"symbol" : "GEK", "name" : "GEK"}, "GEL": {"symbol"
    : "GEL", "name" : "GEL"}, "MAD": {"symbol" : "MAD", "name" : "MAD"}, "MAF": {"symbol" : "MAF", "name" : "MAF"}, "AZM": {"symbol" : "AZM", "name" : "AZM"}, "TOP": {"symbol" : "TOP", "name" : "TOP"}, "AZN": {"symbol" : "AZN", "name" : "AZN"}, "PGK": {"symbol" : "PGK", "name" : "PGK"}, "CNH": {"symbol" : "CNH", "name" : "CNH"}, "UAH": {"symbol" : "UAH", "name" : "UAH"}, "UAK": {"symbol" : "UAK", "name" : "UAK"}, "ERN": {"symbol" : "ERN", "name" : "ERN"}, "TPE": {"symbol" : "TPE", "name" : "TPE"}, "MRO": {"symbol"
    : "MRO", "name" : "MRO"}, "CNX": {"symbol" : "CNX", "name" : "CNX"}, "CNY": {"symbol" : "CN¥", "name" : "CNY"}, "MRU": {"symbol" : "MRU", "name" : "MRU"}, "ESA": {"symbol" : "ESA", "name" : "ESA"}, "GWE": {"symbol" : "GWE", "name" : "GWE"}, "ESB": {"symbol" : "ESB", "name" : "ESB"}, "BMD": {"symbol" : "BMD", "name" : "BMD"}, "PHP": {"symbol" : "PHP", "name" : "PHP"}, "XXX": {"symbol" : "¤", "name" : "XXX"}, "PYG": {"symbol" : "PYG", "name" : "PYG"}, "JMD": {"symbol" : "JMD", "name" : "JMD"}, "GWP": {"symbol"
    : "GWP", "name" : "GWP"}, "ESP": {"symbol" : "ESP", "name" : "ESP"}, "COP": {"symbol" : "COP", "name" : "COP"}, "USD": {"symbol" : "US$", "name" : "USD"}, "COU": {"symbol" : "COU", "name" : "COU"}, "MCF": {"symbol" : "MCF", "name" : "MCF"}, "USN": {"symbol" : "USN", "name" : "USN"}, "ETB": {"symbol" : "ETB", "name" : "ETB"}, "VEB": {"symbol" : "VEB", "name" : "VEB"}, "ECS": {"symbol" : "ECS", "name" : "ECS"}, "USS": {"symbol" : "USS", "name" : "USS"}, "SOS": {"symbol" : "SOS", "name" : "SOS"}, "VEF": {"symbol"
    : "VEF", "name" : "VEF"}, "VUV": {"symbol" : "VUV", "name" : "VUV"}, "LAK": {"symbol" : "LAK", "name" : "LAK"}, "BND": {"symbol" : "BND", "name" : "BND"}, "ECV": {"symbol" : "ECV", "name" : "ECV"}, "ZMK": {"symbol" : "ZMK", "name" : "ZMK"}, "LRD": {"symbol" : "LRD", "name" : "LRD"}, "ALK": {"symbol" : "ALK", "name" : "ALK"}, "ALL": {"symbol" : "ALL", "name" : "ALL"}, "GHC": {"symbol" : "GHC", "name" : "GHC"}, "MTL": {"symbol" : "MTL", "name" : "MTL"}, "VES": {"symbol" : "VES", "name" : "VES"}, "ZMW": {"symbol"
    : "ZMW", "name" : "ZMW"}, "MTP": {"symbol" : "MTP", "name" : "MTP"}, "ILP": {"symbol" : "ILP", "name" : "ILP"}, "MDC": {"symbol" : "MDC", "name" : "MDC"}, "ILR": {"symbol" : "ILR", "name" : "ILR"}, "TRL": {"symbol" : "TRL", "name" : "TRL"}, "ILS": {"symbol" : "₪", "name" : "ILS"}, "GHS": {"symbol" : "GHS", "name" : "GHS"}, "GYD": {"symbol" : "GYD", "name" : "GYD"}, "KPW": {"symbol" : "KPW", "name" : "KPW"}, "BOB": {"symbol" : "BOB", "name" : "BOB"}, "MDL": {"symbol" : "MDL", "name" : "MDL"}, "AMD": {"symbol"
    : "AMD", "name" : "AMD"}, "TRY": {"symbol" : "TRY", "name" : "TRY"}, "LBP": {"symbol" : "LBP", "name" : "LBP"}, "BOL": {"symbol" : "BOL", "name" : "BOL"}, "JOD": {"symbol" : "JOD", "name" : "JOD"}, "HKD": {"symbol" : "HK$", "name" : "HKD"}, "BOP": {"symbol" : "BOP", "name" : "BOP"}, "EUR": {"symbol" : "€", "name" : "EUR"}, "LSL": {"symbol" : "LSL", "name" : "LSL"}, "CAD": {"symbol" : "CA$", "name" : "CAD"}, "BOV": {"symbol" : "BOV", "name" : "BOV"}, "EEK": {"symbol" : "EEK", "name" : "EEK"}, "MUR": {"symbol"
    : "MUR", "name" : "MUR"}, "ROL": {"symbol" : "ROL", "name" : "ROL"}, "GIP": {"symbol" : "GIP", "name" : "GIP"}, "RON": {"symbol" : "RON", "name" : "RON"}, "NGN": {"symbol" : "NGN", "name" : "NGN"}, "CRC": {"symbol" : "CRC", "name" : "CRC"}, "PKR": {"symbol" : "PKR", "name" : "PKR"}, "ANG": {"symbol" : "ANG", "name" : "ANG"}, "KRH": {"symbol" : "KRH", "name" : "KRH"}, "SRD": {"symbol" : "SRD", "name" : "SRD"}, "LTL": {"symbol" : "LTL", "name" : "LTL"}, "SAR": {"symbol" : "SAR", "name" : "SAR"}, "TTD": {"symbol"
    : "TTD", "name" : "TTD"}, "MVP": {"symbol" : "MVP", "name" : "MVP"}, "MVR": {"symbol" : "MVR", "name" : "MVR"}, "KRO": {"symbol" : "KRO", "name" : "KRO"}, "SRG": {"symbol" : "SRG", "name" : "SRG"}, "DDM": {"symbol" : "DDM", "name" : "DDM"}, "INR": {"symbol" : "₹", "name" : "INR"}, "LTT": {"symbol" : "LTT", "name" : "LTT"}, "KRW": {"symbol" : "₩", "name" : "KRW"}, "JPY": {"symbol" : "JP¥", "name" : "JPY"}, "AOA": {"symbol" : "AOA", "name" : "AOA"}, "PLN": {"symbol" : "PLN", "name" : "PLN"}, "SBD": {"symbol"
    : "SBD", "name" : "SBD"}, "CSD": {"symbol" : "CSD", "name" : "CSD"}, "CSK": {"symbol" : "CSK", "name" : "CSK"}, "LUC": {"symbol" : "LUC", "name" : "LUC"}, "LUF": {"symbol" : "LUF", "name" : "LUF"}, "AOK": {"symbol" : "AOK", "name" : "AOK"}, "PLZ": {"symbol" : "PLZ", "name" : "PLZ"}, "AON": {"symbol" : "AON", "name" : "AON"}, "MWK": {"symbol" : "MWK", "name" : "MWK"}, "LUL": {"symbol" : "LUL", "name" : "LUL"}, "AOR": {"symbol" : "AOR", "name" : "AOR"}, "BAD": {"symbol" : "BAD", "name" : "BAD"}, "MGA": {"symbol"
    : "MGA", "name" : "MGA"}, "NIC": {"symbol" : "NIC", "name" : "NIC"}, "FIM": {"symbol" : "FIM", "name" : "FIM"}, "DEM": {"symbol" : "DEM", "name" : "DEM"}, "MGF": {"symbol" : "MGF", "name" : "MGF"}, "BAM": {"symbol" : "BAM", "name" : "BAM"}, "BAN": {"symbol" : "BAN", "name" : "BAN"}, "EGP": {"symbol" : "EGP", "name" : "EGP"}, "SSP": {"symbol" : "SSP", "name" : "SSP"}, "BRC": {"symbol" : "BRC", "name" : "BRC"}, "BRB": {"symbol" : "BRB", "name" : "BRB"}, "BRE": {"symbol" : "BRE", "name" : "BRE"}, "NIO": {"symbol"
    : "NIO", "name" : "NIO"}, "NZD": {"symbol" : "NZ$", "name" : "NZD"}, "BRL": {"symbol" : "R$", "name" : "BRL"}, "BRN": {"symbol" : "BRN", "name" : "BRN"}}, "en": {"UGS": {"symbol" : "UGS", "name" : "Ugandan Shilling (1966–1987)"}, "FJD": {"symbol" : "FJD", "name" : "Fijian Dollar"}, "MXN": {"symbol" : "MX$", "name" : "Mexican Peso"}, "STD": {"symbol" : "STD", "name" : "São Tomé & Príncipe Dobra (1977–2017)"}, "BRR": {"symbol" : "BRR", "name" : "Brazilian Cruzeiro (1993–1994)"}, "LVL": {"symbol" : "LVL", "name"
    : "Latvian Lats"}, "SCR": {"symbol" : "SCR", "name" : "Seychellois Rupee"}, "CDF": {"symbol" : "CDF", "name" : "Congolese Franc"}, "MXP": {"symbol" : "MXP", "name" : "Mexican Silver Peso (1861–1992)"}, "ZAL": {"symbol" : "ZAL", "name" : "South African Rand (financial)"}, "BBD": {"symbol" : "BBD", "name" : "Barbadian Dollar"}, "HNL": {"symbol" : "HNL", "name" : "Honduran Lempira"}, "UGX": {"symbol" : "UGX", "name" : "Ugandan Shilling"}, "LVR": {"symbol" : "LVR", "name" : "Latvian Ruble"}, "MXV": {"symbol"
    : "MXV", "name" : "Mexican Investment Unit"}, "ZAR": {"symbol" : "ZAR", "name" : "South African Rand"}, "BRZ": {"symbol" : "BRZ", "name" : "Brazilian Cruzeiro (1942–1967)"}, "STN": {"symbol" : "STN", "name" : "São Tomé & Príncipe Dobra"}, "CUC": {"symbol" : "CUC", "name" : "Cuban Convertible Peso"}, "BSD": {"symbol" : "BSD", "name" : "Bahamian Dollar"}, "SDD": {"symbol" : "SDD", "name" : "Sudanese Dinar (1992–2007)"}, "SDG": {"symbol" : "SDG", "name" : "Sudanese Pound"}, "ZRN": {"symbol" : "ZRN", "name"
    : "Zairean New Zaire (1993–1998)"}, "IQD": {"symbol" : "IQD", "name" : "Iraqi Dinar"}, "SDP": {"symbol" : "SDP", "name" : "Sudanese Pound (1957–1998)"}, "CUP": {"symbol" : "CUP", "name" : "Cuban Peso"}, "GMD": {"symbol" : "GMD", "name" : "Gambian Dalasi"}, "TWD": {"symbol" : "NT$", "name" : "New Taiwan Dollar"}, "RSD": {"symbol" : "RSD", "name" : "Serbian Dinar"}, "ZRZ": {"symbol" : "ZRZ", "name" : "Zairean Zaire (1971–1993)"}, "UYI": {"symbol" : "UYI", "name" : "Uruguayan Peso (Indexed Units)"}, "MYR":
    {"symbol" : "MYR", "name" : "Malaysian Ringgit"}, "FKP": {"symbol" : "FKP", "name" : "Falkland Islands Pound"}, "UYP": {"symbol" : "UYP", "name" : "Uruguayan Peso (1975–1993)"}, "XOF": {"symbol" : "CFA", "name" : "West African CFA Franc"}, "ARA": {"symbol" : "ARA", "name" : "Argentine Austral"}, "UYU": {"symbol" : "UYU", "name" : "Uruguayan Peso"}, "SUR": {"symbol" : "SUR", "name" : "Soviet Rouble"}, "UYW": {"symbol" : "UYW", "name" : "Uruguayan Nominal Wage Index Unit"}, "CVE": {"symbol" : "CVE", "name"
    : "Cape Verdean Escudo"}, "OMR": {"symbol" : "OMR", "name" : "Omani Rial"}, "KES": {"symbol" : "KES", "name" : "Kenyan Shilling"}, "SEK": {"symbol" : "SEK", "name" : "Swedish Krona"}, "MZE": {"symbol" : "MZE", "name" : "Mozambican Escudo"}, "ARL": {"symbol" : "ARL", "name" : "Argentine Peso Ley (1970–1983)"}, "ARM": {"symbol" : "ARM", "name" : "Argentine Peso (1881–1970)"}, "BTN": {"symbol" : "BTN", "name" : "Bhutanese Ngultrum"}, "GNF": {"symbol" : "GNF", "name" : "Guinean Franc"}, "ARP": {"symbol" : "ARP",
    "name" : "Argentine Peso (1983–1985)"}, "MZN": {"symbol" : "MZN", "name" : "Mozambican Metical"}, "MZM": {"symbol" : "MZM", "name" : "Mozambican Metical (1980–2006)"}, "SVC": {"symbol" : "SVC", "name" : "Salvadoran Colón"}, "ARS": {"symbol" : "ARS", "name" : "Argentine Peso"}, "QAR": {"symbol" : "QAR", "name" : "Qatari Rial"}, "IRR": {"symbol" : "IRR", "name" : "Iranian Rial"}, "NLG": {"symbol" : "NLG", "name" : "Dutch Guilder"}, "GNS": {"symbol" : "GNS", "name" : "Guinean Syli"}, "XPD": {"symbol" : "XPD",
    "name" : "Palladium"}, "THB": {"symbol" : "THB", "name" : "Thai Baht"}, "UZS": {"symbol" : "UZS", "name" : "Uzbekistani Som"}, "XPF": {"symbol" : "CFPF", "name" : "CFP Franc"}, "BDT": {"symbol" : "BDT", "name" : "Bangladeshi Taka"}, "LYD": {"symbol" : "LYD", "name" : "Libyan Dinar"}, "BUK": {"symbol" : "BUK", "name" : "Burmese Kyat"}, "KWD": {"symbol" : "KWD", "name" : "Kuwaiti Dinar"}, "XPT": {"symbol" : "XPT", "name" : "Platinum"}, "RUB": {"symbol" : "RUB", "name" : "Russian Ruble"}, "ISK": {"symbol" :
    "ISK", "name" : "Icelandic Króna"}, "BEC": {"symbol" : "BEC", "name" : "Belgian Franc (convertible)"}, "ISJ": {"symbol" : "ISJ", "name" : "Icelandic Króna (1918–1981)"}, "BEF": {"symbol" : "BEF", "name" : "Belgian Franc"}, "MKD": {"symbol" : "MKD", "name" : "Macedonian Denar"}, "BEL": {"symbol" : "BEL", "name" : "Belgian Franc (financial)"}, "RUR": {"symbol" : "RUR", "name" : "Russian Ruble (1991–1998)"}, "DZD": {"symbol" : "DZD", "name" : "Algerian Dinar"}, "PAB": {"symbol" : "PAB", "name" : "Panamanian Balboa"}
    , "MKN": {"symbol" : "MKN", "name" : "Macedonian Denar (1992–1993)"}, "SGD": {"symbol" : "SGD", "name" : "Singapore Dollar"}, "KGS": {"symbol" : "KGS", "name" : "Kyrgystani Som"}, "HRD": {"symbol" : "HRD", "name" : "Croatian Dinar"}, "XAF": {"symbol" : "FCFA", "name" : "Central African CFA Franc"}, "XAG": {"symbol" : "XAG", "name" : "Silver"}, "ATS": {"symbol" : "ATS", "name" : "Austrian Schilling"}, "CHF": {"symbol" : "CHF", "name" : "Swiss Franc"}, "HRK": {"symbol" : "HRK", "name" : "Croatian Kuna"}, "ITL":
    {"symbol" : "ITL", "name" : "Italian Lira"}, "CHE": {"symbol" : "CHE", "name" : "WIR Euro"}, "DJF": {"symbol" : "DJF", "name" : "Djiboutian Franc"}, "MLF": {"symbol" : "MLF", "name" : "Malian Franc"}, "XRE": {"symbol" : "XRE", "name" : "RINET Funds"}, "TZS": {"symbol" : "TZS", "name" : "Tanzanian Shilling"}, "ADP": {"symbol" : "ADP", "name" : "Andorran Peseta"}, "VND": {"symbol" : "₫", "name" : "Vietnamese Dong"}, "XAU": {"symbol" : "XAU", "name" : "Gold"}, "AUD": {"symbol" : "A$", "name" : "Australian Dollar"}
    , "CHW": {"symbol" : "CHW", "name" : "WIR Franc"}, "KHR": {"symbol" : "KHR", "name" : "Cambodian Riel"}, "IDR": {"symbol" : "IDR", "name" : "Indonesian Rupiah"}, "XBA": {"symbol" : "XBA", "name" : "European Composite Unit"}, "KYD": {"symbol" : "KYD", "name" : "Cayman Islands Dollar"}, "VNN": {"symbol" : "VNN", "name" : "Vietnamese Dong (1978–1985)"}, "XBC": {"symbol" : "XBC", "name" : "European Unit of Account (XBC)"}, "YDD": {"symbol" : "YDD", "name" : "Yemeni Dinar"}, "XBB": {"symbol" : "XBB", "name" :
    "European Monetary Unit"}, "BWP": {"symbol" : "BWP", "name" : "Botswanan Pula"}, "GQE": {"symbol" : "GQE", "name" : "Equatorial Guinean Ekwele"}, "SHP": {"symbol" : "SHP", "name" : "St. Helena Pound"}, "CYP": {"symbol" : "CYP", "name" : "Cypriot Pound"}, "XBD": {"symbol" : "XBD", "name" : "European Unit of Account (XBD)"}, "TJS": {"symbol" : "TJS", "name" : "Tajikistani Somoni"}, "TJR": {"symbol" : "TJR", "name" : "Tajikistani Ruble"}, "AED": {"symbol" : "AED", "name" : "United Arab Emirates Dirham"}, "RWF":
    {"symbol" : "RWF", "name" : "Rwandan Franc"}, "DKK": {"symbol" : "DKK", "name" : "Danish Krone"}, "BGL": {"symbol" : "BGL", "name" : "Bulgarian Hard Lev"}, "ZWD": {"symbol" : "ZWD", "name" : "Zimbabwean Dollar (1980–2008)"}, "BGN": {"symbol" : "BGN", "name" : "Bulgarian Lev"}, "BGM": {"symbol" : "BGM", "name" : "Bulgarian Socialist Lev"}, "YUD": {"symbol" : "YUD", "name" : "Yugoslavian Hard Dinar (1966–1990)"}, "MMK": {"symbol" : "MMK", "name" : "Myanmar Kyat"}, "BGO": {"symbol" : "BGO", "name" : "Bulgarian Lev (1879–1952)"}
    , "NOK": {"symbol" : "NOK", "name" : "Norwegian Krone"}, "SYP": {"symbol" : "SYP", "name" : "Syrian Pound"}, "ZWL": {"symbol" : "ZWL", "name" : "Zimbabwean Dollar (2009)"}, "YUM": {"symbol" : "YUM", "name" : "Yugoslavian New Dinar (1994–2002)"}, "LKR": {"symbol" : "LKR", "name" : "Sri Lankan Rupee"}, "YUN": {"symbol" : "YUN", "name" : "Yugoslavian Convertible Dinar (1990–1992)"}, "ZWR": {"symbol" : "ZWR", "name" : "Zimbabwean Dollar (2008)"}, "CZK": {"symbol" : "CZK", "name" : "Czech Koruna"}, "IEP": {"symbol"
    : "IEP", "name" : "Irish Pound"}, "YUR": {"symbol" : "YUR", "name" : "Yugoslavian Reformed Dinar (1992–1993)"}, "GRD": {"symbol" : "GRD", "name" : "Greek Drachma"}, "XCD": {"symbol" : "EC$", "name" : "East Caribbean Dollar"}, "HTG": {"symbol" : "HTG", "name" : "Haitian Gourde"}, "XSU": {"symbol" : "XSU", "name" : "Sucre"}, "AFA": {"symbol" : "AFA", "name" : "Afghan Afghani (1927–2002)"}, "BHD": {"symbol" : "BHD", "name" : "Bahraini Dinar"}, "SIT": {"symbol" : "SIT", "name" : "Slovenian Tolar"}, "PTE": {"symbol"
    : "PTE", "name" : "Portuguese Escudo"}, "KZT": {"symbol" : "KZT", "name" : "Kazakhstani Tenge"}, "SZL": {"symbol" : "SZL", "name" : "Swazi Lilangeni"}, "YER": {"symbol" : "YER", "name" : "Yemeni Rial"}, "AFN": {"symbol" : "AFN", "name" : "Afghan Afghani"}, "BYB": {"symbol" : "BYB", "name" : "Belarusian Ruble (1994–1999)"}, "RHD": {"symbol" : "RHD", "name" : "Rhodesian Dollar"}, "AWG": {"symbol" : "AWG", "name" : "Aruban Florin"}, "NPR": {"symbol" : "NPR", "name" : "Nepalese Rupee"}, "MNT": {"symbol" : "MNT",
    "name" : "Mongolian Tugrik"}, "GBP": {"symbol" : "£", "name" : "British Pound"}, "BYN": {"symbol" : "BYN", "name" : "Belarusian Ruble"}, "XTS": {"symbol" : "XTS", "name" : "Testing Currency Code"}, "HUF": {"symbol" : "HUF", "name" : "Hungarian Forint"}, "BYR": {"symbol" : "BYR", "name" : "Belarusian Ruble (2000–2016)"}, "BIF": {"symbol" : "BIF", "name" : "Burundian Franc"}, "XUA": {"symbol" : "XUA", "name" : "ADB Unit of Account"}, "XDR": {"symbol" : "XDR", "name" : "Special Drawing Rights"}, "BZD": {"symbol"
    : "BZD", "name" : "Belize Dollar"}, "MOP": {"symbol" : "MOP", "name" : "Macanese Pataca"}, "NAD": {"symbol" : "NAD", "name" : "Namibian Dollar"}, "SKK": {"symbol" : "SKK", "name" : "Slovak Koruna"}, "PEI": {"symbol" : "PEI", "name" : "Peruvian Inti"}, "TMM": {"symbol" : "TMM", "name" : "Turkmenistani Manat (1993–2009)"}, "PEN": {"symbol" : "PEN", "name" : "Peruvian Sol"}, "WST": {"symbol" : "WST", "name" : "Samoan Tala"}, "TMT": {"symbol" : "TMT", "name" : "Turkmenistani Manat"}, "FRF": {"symbol" : "FRF",
    "name" : "French Franc"}, "CLF": {"symbol" : "CLF", "name" : "Chilean Unit of Account (UF)"}, "CLE": {"symbol" : "CLE", "name" : "Chilean Escudo"}, "PES": {"symbol" : "PES", "name" : "Peruvian Sol (1863–1965)"}, "GTQ": {"symbol" : "GTQ", "name" : "Guatemalan Quetzal"}, "CLP": {"symbol" : "CLP", "name" : "Chilean Peso"}, "XEU": {"symbol" : "XEU", "name" : "European Currency Unit"}, "TND": {"symbol" : "TND", "name" : "Tunisian Dinar"}, "SLL": {"symbol" : "SLL", "name" : "Sierra Leonean Leone"}, "XFO": {"symbol"
    : "XFO", "name" : "French Gold Franc"}, "DOP": {"symbol" : "DOP", "name" : "Dominican Peso"}, "KMF": {"symbol" : "KMF", "name" : "Comorian Franc"}, "XFU": {"symbol" : "XFU", "name" : "French UIC-Franc"}, "GEK": {"symbol" : "GEK", "name" : "Georgian Kupon Larit"}, "GEL": {"symbol" : "GEL", "name" : "Georgian Lari"}, "MAD": {"symbol" : "MAD", "name" : "Moroccan Dirham"}, "MAF": {"symbol" : "MAF", "name" : "Moroccan Franc"}, "AZM": {"symbol" : "AZM", "name" : "Azerbaijani Manat (1993–2006)"}, "TOP": {"symbol"
    : "TOP", "name" : "Tongan Paʻanga"}, "AZN": {"symbol" : "AZN", "name" : "Azerbaijani Manat"}, "PGK": {"symbol" : "PGK", "name" : "Papua New Guinean Kina"}, "CNH": {"symbol" : "CNH", "name" : "Chinese Yuan (offshore)"}, "UAH": {"symbol" : "UAH", "name" : "Ukrainian Hryvnia"}, "UAK": {"symbol" : "UAK", "name" : "Ukrainian Karbovanets"}, "ERN": {"symbol" : "ERN", "name" : "Eritrean Nakfa"}, "TPE": {"symbol" : "TPE", "name" : "Timorese Escudo"}, "MRO": {"symbol" : "MRO", "name" : "Mauritanian Ouguiya (1973–2017)"}
    , "CNX": {"symbol" : "CNX", "name" : "Chinese People’s Bank Dollar"}, "CNY": {"symbol" : "CN¥", "name" : "Chinese Yuan"}, "MRU": {"symbol" : "MRU", "name" : "Mauritanian Ouguiya"}, "ESA": {"symbol" : "ESA", "name" : "Spanish Peseta (A account)"}, "GWE": {"symbol" : "GWE", "name" : "Portuguese Guinea Escudo"}, "ESB": {"symbol" : "ESB", "name" : "Spanish Peseta (convertible account)"}, "BMD": {"symbol" : "BMD", "name" : "Bermudan Dollar"}, "PHP": {"symbol" : "PHP", "name" : "Philippine Piso"}, "XXX": {"symbol"
    : "¤", "name" : "Unknown Currency"}, "PYG": {"symbol" : "PYG", "name" : "Paraguayan Guarani"}, "JMD": {"symbol" : "JMD", "name" : "Jamaican Dollar"}, "GWP": {"symbol" : "GWP", "name" : "Guinea-Bissau Peso"}, "ESP": {"symbol" : "ESP", "name" : "Spanish Peseta"}, "COP": {"symbol" : "COP", "name" : "Colombian Peso"}, "USD": {"symbol" : "$", "name" : "US Dollar"}, "COU": {"symbol" : "COU", "name" : "Colombian Real Value Unit"}, "MCF": {"symbol" : "MCF", "name" : "Monegasque Franc"}, "USN": {"symbol" : "USN",
    "name" : "US Dollar (Next day)"}, "ETB": {"symbol" : "ETB", "name" : "Ethiopian Birr"}, "VEB": {"symbol" : "VEB", "name" : "Venezuelan Bolívar (1871–2008)"}, "ECS": {"symbol" : "ECS", "name" : "Ecuadorian Sucre"}, "USS": {"symbol" : "USS", "name" : "US Dollar (Same day)"}, "SOS": {"symbol" : "SOS", "name" : "Somali Shilling"}, "VEF": {"symbol" : "VEF", "name" : "Venezuelan Bolívar (2008–2018)"}, "VUV": {"symbol" : "VUV", "name" : "Vanuatu Vatu"}, "LAK": {"symbol" : "LAK", "name" : "Laotian Kip"}, "BND":
    {"symbol" : "BND", "name" : "Brunei Dollar"}, "ECV": {"symbol" : "ECV", "name" : "Ecuadorian Unit of Constant Value"}, "ZMK": {"symbol" : "ZMK", "name" : "Zambian Kwacha (1968–2012)"}, "LRD": {"symbol" : "LRD", "name" : "Liberian Dollar"}, "ALK": {"symbol" : "ALK", "name" : "Albanian Lek (1946–1965)"}, "ALL": {"symbol" : "ALL", "name" : "Albanian Lek"}, "GHC": {"symbol" : "GHC", "name" : "Ghanaian Cedi (1979–2007)"}, "MTL": {"symbol" : "MTL", "name" : "Maltese Lira"}, "VES": {"symbol" : "VES", "name" : "Venezuelan Bolívar"}
    , "ZMW": {"symbol" : "ZMW", "name" : "Zambian Kwacha"}, "MTP": {"symbol" : "MTP", "name" : "Maltese Pound"}, "ILP": {"symbol" : "ILP", "name" : "Israeli Pound"}, "MDC": {"symbol" : "MDC", "name" : "Moldovan Cupon"}, "ILR": {"symbol" : "ILR", "name" : "Israeli Shekel (1980–1985)"}, "TRL": {"symbol" : "TRL", "name" : "Turkish Lira (1922–2005)"}, "ILS": {"symbol" : "₪", "name" : "Israeli New Shekel"}, "GHS": {"symbol" : "GHS", "name" : "Ghanaian Cedi"}, "GYD": {"symbol" : "GYD", "name" : "Guyanaese Dollar"}
    , "KPW": {"symbol" : "KPW", "name" : "North Korean Won"}, "BOB": {"symbol" : "BOB", "name" : "Bolivian Boliviano"}, "MDL": {"symbol" : "MDL", "name" : "Moldovan Leu"}, "AMD": {"symbol" : "AMD", "name" : "Armenian Dram"}, "TRY": {"symbol" : "TRY", "name" : "Turkish Lira"}, "LBP": {"symbol" : "LBP", "name" : "Lebanese Pound"}, "BOL": {"symbol" : "BOL", "name" : "Bolivian Boliviano (1863–1963)"}, "JOD": {"symbol" : "JOD", "name" : "Jordanian Dinar"}, "HKD": {"symbol" : "HK$", "name" : "Hong Kong Dollar"}, "BOP":
    {"symbol" : "BOP", "name" : "Bolivian Peso"}, "EUR": {"symbol" : "€", "name" : "Euro"}, "LSL": {"symbol" : "LSL", "name" : "Lesotho Loti"}, "CAD": {"symbol" : "CA$", "name" : "Canadian Dollar"}, "BOV": {"symbol" : "BOV", "name" : "Bolivian Mvdol"}, "EEK": {"symbol" : "EEK", "name" : "Estonian Kroon"}, "MUR": {"symbol" : "MUR", "name" : "Mauritian Rupee"}, "ROL": {"symbol" : "ROL", "name" : "Romanian Leu (1952–2006)"}, "GIP": {"symbol" : "GIP", "name" : "Gibraltar Pound"}, "RON": {"symbol" : "RON", "name"
    : "Romanian Leu"}, "NGN": {"symbol" : "NGN", "name" : "Nigerian Naira"}, "CRC": {"symbol" : "CRC", "name" : "Costa Rican Colón"}, "PKR": {"symbol" : "PKR", "name" : "Pakistani Rupee"}, "ANG": {"symbol" : "ANG", "name" : "Netherlands Antillean Guilder"}, "KRH": {"symbol" : "KRH", "name" : "South Korean Hwan (1953–1962)"}, "SRD": {"symbol" : "SRD", "name" : "Surinamese Dollar"}, "LTL": {"symbol" : "LTL", "name" : "Lithuanian Litas"}, "SAR": {"symbol" : "SAR", "name" : "Saudi Riyal"}, "TTD": {"symbol" : "TTD",
    "name" : "Trinidad & Tobago Dollar"}, "MVP": {"symbol" : "MVP", "name" : "Maldivian Rupee (1947–1981)"}, "MVR": {"symbol" : "MVR", "name" : "Maldivian Rufiyaa"}, "KRO": {"symbol" : "KRO", "name" : "South Korean Won (1945–1953)"}, "SRG": {"symbol" : "SRG", "name" : "Surinamese Guilder"}, "DDM": {"symbol" : "DDM", "name" : "East German Mark"}, "INR": {"symbol" : "₹", "name" : "Indian Rupee"}, "LTT": {"symbol" : "LTT", "name" : "Lithuanian Talonas"}, "KRW": {"symbol" : "₩", "name" : "South Korean Won"}, "JPY":
    {"symbol" : "¥", "name" : "Japanese Yen"}, "AOA": {"symbol" : "AOA", "name" : "Angolan Kwanza"}, "PLN": {"symbol" : "PLN", "name" : "Polish Zloty"}, "SBD": {"symbol" : "SBD", "name" : "Solomon Islands Dollar"}, "CSD": {"symbol" : "CSD", "name" : "Serbian Dinar (2002–2006)"}, "CSK": {"symbol" : "CSK", "name" : "Czechoslovak Hard Koruna"}, "LUC": {"symbol" : "LUC", "name" : "Luxembourgian Convertible Franc"}, "LUF": {"symbol" : "LUF", "name" : "Luxembourgian Franc"}, "AOK": {"symbol" : "AOK", "name" : "Angolan Kwanza (1977–1991)"}
    , "PLZ": {"symbol" : "PLZ", "name" : "Polish Zloty (1950–1995)"}, "AON": {"symbol" : "AON", "name" : "Angolan New Kwanza (1990–2000)"}, "MWK": {"symbol" : "MWK", "name" : "Malawian Kwacha"}, "LUL": {"symbol" : "LUL", "name" : "Luxembourg Financial Franc"}, "AOR": {"symbol" : "AOR", "name" : "Angolan Readjusted Kwanza (1995–1999)"}, "BAD": {"symbol" : "BAD", "name" : "Bosnia-Herzegovina Dinar (1992–1994)"}, "MGA": {"symbol" : "MGA", "name" : "Malagasy Ariary"}, "NIC": {"symbol" : "NIC", "name" : "Nicaraguan Córdoba (1988–1991)"}
    , "FIM": {"symbol" : "FIM", "name" : "Finnish Markka"}, "DEM": {"symbol" : "DEM", "name" : "German Mark"}, "MGF": {"symbol" : "MGF", "name" : "Malagasy Franc"}, "BAM": {"symbol" : "BAM", "name" : "Bosnia-Herzegovina Convertible Mark"}, "BAN": {"symbol" : "BAN", "name" : "Bosnia-Herzegovina New Dinar (1994–1997)"}, "EGP": {"symbol" : "EGP", "name" : "Egyptian Pound"}, "SSP": {"symbol" : "SSP", "name" : "South Sudanese Pound"}, "BRC": {"symbol" : "BRC", "name" : "Brazilian Cruzado (1986–1989)"}, "BRB": {"symbol"
    : "BRB", "name" : "Brazilian New Cruzeiro (1967–1986)"}, "BRE": {"symbol" : "BRE", "name" : "Brazilian Cruzeiro (1990–1993)"}, "NIO": {"symbol" : "NIO", "name" : "Nicaraguan Córdoba"}, "NZD": {"symbol" : "NZ$", "name" : "New Zealand Dollar"}, "BRL": {"symbol" : "R$", "name" : "Brazilian Real"}, "BRN": {"symbol" : "BRN", "name" : "Brazilian New Cruzado (1989–1990)"}}};
},
jt_DecimalFormat$FormatField = $rt_classWithoutFields(0),
jt_DecimalFormat$CurrencyField = $rt_classWithoutFields(),
jt_DecimalFormat$CurrencyField__init_ = $this => {
    jl_Object__init_($this);
},
jt_DecimalFormat$CurrencyField__init_0 = () => {
    let var_0 = new jt_DecimalFormat$CurrencyField();
    jt_DecimalFormat$CurrencyField__init_(var_0);
    return var_0;
},
jt_DecimalFormat$CurrencyField_render = ($this, $format, $buffer) => {
    if ($format.$getCurrency() === null)
        $buffer.$append4(164);
    else
        $buffer.$append5(ju_Currency_getSymbol($format.$getCurrency(), $format.$symbols.$getLocale()));
},
jt_DecimalFormat$CurrencyField_equals = ($this, $obj) => {
    return $obj instanceof jt_DecimalFormat$CurrencyField;
},
jt_DecimalFormat$CurrencyField_hashCode = $this => {
    return 0;
},
jl_CharSequence = $rt_classWithoutFields(0),
jl_StringIndexOutOfBoundsException = $rt_classWithoutFields(jl_IndexOutOfBoundsException),
jl_StringIndexOutOfBoundsException__init_0 = $this => {
    jl_IndexOutOfBoundsException__init_0($this);
},
jl_StringIndexOutOfBoundsException__init_ = () => {
    let var_0 = new jl_StringIndexOutOfBoundsException();
    jl_StringIndexOutOfBoundsException__init_0(var_0);
    return var_0;
},
otcic_CurrencyHelper = $rt_classWithoutFields(),
otcic_CurrencyHelper_$$metadata$$0 = null,
otcic_CurrencyHelper_$$metadata$$1 = null,
otcic_CurrencyHelper_getCurrencies = () => {
    if (otcic_CurrencyHelper_$$metadata$$0 === null)
        otcic_CurrencyHelper_$$metadata$$0 = otcic_CurrencyHelper_getCurrencies$$create();
    return otcic_CurrencyHelper_$$metadata$$0;
},
otcic_CurrencyHelper_getCountryToCurrencyMap = () => {
    if (otcic_CurrencyHelper_$$metadata$$1 === null)
        otcic_CurrencyHelper_$$metadata$$1 = otcic_CurrencyHelper_getCountryToCurrencyMap$$create();
    return otcic_CurrencyHelper_$$metadata$$1;
},
otcic_CurrencyHelper_getCurrencies$$create = () => {
    return [{"code" : "AFN", "fractionDigits" : 2, "numericCode" : 971}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "ALL", "fractionDigits" : 2, "numericCode" : 8}, {"code" : "DZD", "fractionDigits" : 2, "numericCode" : 12}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "AOA", "fractionDigits" : 2, "numericCode" : 973}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : null,
    "fractionDigits" : 0, "numericCode" : 0}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "ARS", "fractionDigits" : 2, "numericCode" : 32}, {"code" : "AMD", "fractionDigits" : 2, "numericCode" : 51}, {"code" : "AWG", "fractionDigits" : 2, "numericCode" : 533}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "AZN", "fractionDigits" : 2, "numericCode" : 944}, {"code" : "BSD", "fractionDigits" : 2, "numericCode"
    : 44}, {"code" : "BHD", "fractionDigits" : 3, "numericCode" : 48}, {"code" : "BDT", "fractionDigits" : 2, "numericCode" : 50}, {"code" : "BBD", "fractionDigits" : 2, "numericCode" : 52}, {"code" : "BYR", "fractionDigits" : 0, "numericCode" : 974}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "BZD", "fractionDigits" : 2, "numericCode" : 84}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "BMD", "fractionDigits" : 2, "numericCode" : 60}, {"code" : "BTN", "fractionDigits"
    : 2, "numericCode" : 64}, {"code" : "INR", "fractionDigits" : 2, "numericCode" : 356}, {"code" : "BOB", "fractionDigits" : 2, "numericCode" : 68}, {"code" : "BOV", "fractionDigits" : 2, "numericCode" : 984}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "BAM", "fractionDigits" : 2, "numericCode" : 977}, {"code" : "BWP", "fractionDigits" : 2, "numericCode" : 72}, {"code" : "NOK", "fractionDigits" : 2, "numericCode" : 578}, {"code" : "BRL", "fractionDigits" : 2, "numericCode" : 986}
    , {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "BND", "fractionDigits" : 2, "numericCode" : 96}, {"code" : "BGN", "fractionDigits" : 2, "numericCode" : 975}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "BIF", "fractionDigits" : 0, "numericCode" : 108}, {"code" : "KHR", "fractionDigits" : 2, "numericCode" : 116}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "CAD", "fractionDigits" : 2, "numericCode" : 124}, {"code" : "CVE", "fractionDigits"
    : 2, "numericCode" : 132}, {"code" : "KYD", "fractionDigits" : 2, "numericCode" : 136}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "CLF", "fractionDigits" : 4, "numericCode" : 990}, {"code" : "CLP", "fractionDigits" : 0, "numericCode" : 152}, {"code" : "CNY", "fractionDigits" : 2, "numericCode" : 156}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}
    , {"code" : "COP", "fractionDigits" : 2, "numericCode" : 170}, {"code" : "COU", "fractionDigits" : 2, "numericCode" : 970}, {"code" : "KMF", "fractionDigits" : 0, "numericCode" : 174}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "CDF", "fractionDigits" : 2, "numericCode" : 976}, {"code" : "NZD", "fractionDigits" : 2, "numericCode" : 554}, {"code" : "CRC", "fractionDigits" : 2, "numericCode" : 188}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "HRK", "fractionDigits"
    : 2, "numericCode" : 191}, {"code" : "CUC", "fractionDigits" : 2, "numericCode" : 931}, {"code" : "CUP", "fractionDigits" : 2, "numericCode" : 192}, {"code" : "ANG", "fractionDigits" : 2, "numericCode" : 532}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "CZK", "fractionDigits" : 2, "numericCode" : 203}, {"code" : "DKK", "fractionDigits" : 2, "numericCode" : 208}, {"code" : "DJF", "fractionDigits" : 0, "numericCode" : 262}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" :
    951}, {"code" : "DOP", "fractionDigits" : 2, "numericCode" : 214}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "EGP", "fractionDigits" : 2, "numericCode" : 818}, {"code" : "SVC", "fractionDigits" : 2, "numericCode" : 222}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "ERN", "fractionDigits" : 2, "numericCode" : 232}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "ETB",
    "fractionDigits" : 2, "numericCode" : 230}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "FKP", "fractionDigits" : 2, "numericCode" : 238}, {"code" : "DKK", "fractionDigits" : 2, "numericCode" : 208}, {"code" : "FJD", "fractionDigits" : 2, "numericCode" : 242}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "XPF", "fractionDigits" : 0,
    "numericCode" : 953}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "XAF", "fractionDigits" : 0, "numericCode" : 950}, {"code" : "GMD", "fractionDigits" : 2, "numericCode" : 270}, {"code" : "GEL", "fractionDigits" : 2, "numericCode" : 981}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "GHS", "fractionDigits" : 2, "numericCode" : 936}, {"code" : "GIP", "fractionDigits" : 2, "numericCode" : 292}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}
    , {"code" : "DKK", "fractionDigits" : 2, "numericCode" : 208}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "GTQ", "fractionDigits" : 2, "numericCode" : 320}, {"code" : "GBP", "fractionDigits" : 2, "numericCode" : 826}, {"code" : "GNF", "fractionDigits" : 0, "numericCode" : 324}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "GYD", "fractionDigits"
    : 2, "numericCode" : 328}, {"code" : "HTG", "fractionDigits" : 2, "numericCode" : 332}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "HNL", "fractionDigits" : 2, "numericCode" : 340}, {"code" : "HKD", "fractionDigits" : 2, "numericCode" : 344}, {"code" : "HUF", "fractionDigits" : 2, "numericCode" : 348}, {"code" : "ISK", "fractionDigits" : 0, "numericCode" : 352}
    , {"code" : "INR", "fractionDigits" : 2, "numericCode" : 356}, {"code" : "IDR", "fractionDigits" : 2, "numericCode" : 360}, {"code" : "XDR", "fractionDigits" : -1, "numericCode" : 960}, {"code" : "IRR", "fractionDigits" : 2, "numericCode" : 364}, {"code" : "IQD", "fractionDigits" : 3, "numericCode" : 368}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "GBP", "fractionDigits" : 2, "numericCode" : 826}, {"code" : "ILS", "fractionDigits" : 2, "numericCode" : 376}, {"code" : "EUR", "fractionDigits"
    : 2, "numericCode" : 978}, {"code" : "JMD", "fractionDigits" : 2, "numericCode" : 388}, {"code" : "JPY", "fractionDigits" : 0, "numericCode" : 392}, {"code" : "GBP", "fractionDigits" : 2, "numericCode" : 826}, {"code" : "JOD", "fractionDigits" : 3, "numericCode" : 400}, {"code" : "KZT", "fractionDigits" : 2, "numericCode" : 398}, {"code" : "KES", "fractionDigits" : 2, "numericCode" : 404}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "KPW", "fractionDigits" : 2, "numericCode" : 408}
    , {"code" : "KRW", "fractionDigits" : 0, "numericCode" : 410}, {"code" : "KWD", "fractionDigits" : 3, "numericCode" : 414}, {"code" : "KGS", "fractionDigits" : 2, "numericCode" : 417}, {"code" : "LAK", "fractionDigits" : 2, "numericCode" : 418}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "LBP", "fractionDigits" : 2, "numericCode" : 422}, {"code" : "LSL", "fractionDigits" : 2, "numericCode" : 426}, {"code" : "ZAR", "fractionDigits" : 2, "numericCode" : 710}, {"code" : "LRD", "fractionDigits"
    : 2, "numericCode" : 430}, {"code" : "LYD", "fractionDigits" : 3, "numericCode" : 434}, {"code" : "CHF", "fractionDigits" : 2, "numericCode" : 756}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "MOP", "fractionDigits" : 2, "numericCode" : 446}, {"code" : "MKD", "fractionDigits" : 2, "numericCode" : 807}, {"code" : "MGA", "fractionDigits" : 2, "numericCode" : 969}, {"code" : "MWK", "fractionDigits" : 2, "numericCode" :
    454}, {"code" : "MYR", "fractionDigits" : 2, "numericCode" : 458}, {"code" : "MVR", "fractionDigits" : 2, "numericCode" : 462}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "MRO", "fractionDigits" : 2, "numericCode" : 478}, {"code" : "MUR", "fractionDigits" : 2, "numericCode" : 480}, {"code" : "EUR",
    "fractionDigits" : 2, "numericCode" : 978}, {"code" : "XUA", "fractionDigits" : -1, "numericCode" : 965}, {"code" : "MXN", "fractionDigits" : 2, "numericCode" : 484}, {"code" : "MXV", "fractionDigits" : 2, "numericCode" : 979}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "MDL", "fractionDigits" : 2, "numericCode" : 498}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "MNT", "fractionDigits" : 2, "numericCode" : 496}, {"code" : "EUR", "fractionDigits" : 2,
    "numericCode" : 978}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "MAD", "fractionDigits" : 2, "numericCode" : 504}, {"code" : "MZN", "fractionDigits" : 2, "numericCode" : 943}, {"code" : "MMK", "fractionDigits" : 2, "numericCode" : 104}, {"code" : "NAD", "fractionDigits" : 2, "numericCode" : 516}, {"code" : "ZAR", "fractionDigits" : 2, "numericCode" : 710}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "NPR", "fractionDigits" : 2, "numericCode" : 524},
    {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "XPF", "fractionDigits" : 0, "numericCode" : 953}, {"code" : "NZD", "fractionDigits" : 2, "numericCode" : 554}, {"code" : "NIO", "fractionDigits" : 2, "numericCode" : 558}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "NGN", "fractionDigits" : 2, "numericCode" : 566}, {"code" : "NZD", "fractionDigits" : 2, "numericCode" : 554}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "USD", "fractionDigits"
    : 2, "numericCode" : 840}, {"code" : "NOK", "fractionDigits" : 2, "numericCode" : 578}, {"code" : "OMR", "fractionDigits" : 3, "numericCode" : 512}, {"code" : "PKR", "fractionDigits" : 2, "numericCode" : 586}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : null, "fractionDigits" : 0, "numericCode" : 0}, {"code" : "PAB", "fractionDigits" : 2, "numericCode" : 590}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "PGK", "fractionDigits" : 2, "numericCode" : 598}
    , {"code" : "PYG", "fractionDigits" : 0, "numericCode" : 600}, {"code" : "PEN", "fractionDigits" : 2, "numericCode" : 604}, {"code" : "PHP", "fractionDigits" : 2, "numericCode" : 608}, {"code" : "NZD", "fractionDigits" : 2, "numericCode" : 554}, {"code" : "PLN", "fractionDigits" : 2, "numericCode" : 985}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "QAR", "fractionDigits" : 2, "numericCode" : 634}, {"code" : "EUR", "fractionDigits"
    : 2, "numericCode" : 978}, {"code" : "RON", "fractionDigits" : 2, "numericCode" : 946}, {"code" : "RUB", "fractionDigits" : 2, "numericCode" : 643}, {"code" : "RWF", "fractionDigits" : 0, "numericCode" : 646}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "SHP", "fractionDigits" : 2, "numericCode" : 654}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" :
    978}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "XCD", "fractionDigits" : 2, "numericCode" : 951}, {"code" : "WST", "fractionDigits" : 2, "numericCode" : 882}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "STD", "fractionDigits" : 2, "numericCode" : 678}, {"code" : "SAR", "fractionDigits" : 2, "numericCode" : 682}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "RSD", "fractionDigits" : 2, "numericCode" : 941}, {"code" : "SCR",
    "fractionDigits" : 2, "numericCode" : 690}, {"code" : "SLL", "fractionDigits" : 2, "numericCode" : 694}, {"code" : "SGD", "fractionDigits" : 2, "numericCode" : 702}, {"code" : "ANG", "fractionDigits" : 2, "numericCode" : 532}, {"code" : "XSU", "fractionDigits" : -1, "numericCode" : 994}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "SBD", "fractionDigits" : 2, "numericCode" : 90}, {"code" : "SOS", "fractionDigits" : 2,
    "numericCode" : 706}, {"code" : "ZAR", "fractionDigits" : 2, "numericCode" : 710}, {"code" : null, "fractionDigits" : 0, "numericCode" : 0}, {"code" : "SSP", "fractionDigits" : 2, "numericCode" : 728}, {"code" : "EUR", "fractionDigits" : 2, "numericCode" : 978}, {"code" : "LKR", "fractionDigits" : 2, "numericCode" : 144}, {"code" : "SDG", "fractionDigits" : 2, "numericCode" : 938}, {"code" : "SRD", "fractionDigits" : 2, "numericCode" : 968}, {"code" : "NOK", "fractionDigits" : 2, "numericCode" : 578}, {"code"
    : "SZL", "fractionDigits" : 2, "numericCode" : 748}, {"code" : "SEK", "fractionDigits" : 2, "numericCode" : 752}, {"code" : "CHE", "fractionDigits" : 2, "numericCode" : 947}, {"code" : "CHF", "fractionDigits" : 2, "numericCode" : 756}, {"code" : "CHW", "fractionDigits" : 2, "numericCode" : 948}, {"code" : "SYP", "fractionDigits" : 2, "numericCode" : 760}, {"code" : "TWD", "fractionDigits" : 2, "numericCode" : 901}, {"code" : "TJS", "fractionDigits" : 2, "numericCode" : 972}, {"code" : "TZS", "fractionDigits"
    : 2, "numericCode" : 834}, {"code" : "THB", "fractionDigits" : 2, "numericCode" : 764}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "XOF", "fractionDigits" : 0, "numericCode" : 952}, {"code" : "NZD", "fractionDigits" : 2, "numericCode" : 554}, {"code" : "TOP", "fractionDigits" : 2, "numericCode" : 776}, {"code" : "TTD", "fractionDigits" : 2, "numericCode" : 780}, {"code" : "TND", "fractionDigits" : 3, "numericCode" : 788}, {"code" : "TRY", "fractionDigits" : 2, "numericCode" :
    949}, {"code" : "TMT", "fractionDigits" : 2, "numericCode" : 934}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "AUD", "fractionDigits" : 2, "numericCode" : 36}, {"code" : "UGX", "fractionDigits" : 0, "numericCode" : 800}, {"code" : "UAH", "fractionDigits" : 2, "numericCode" : 980}, {"code" : "AED", "fractionDigits" : 2, "numericCode" : 784}, {"code" : "GBP", "fractionDigits" : 2, "numericCode" : 826}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "USN",
    "fractionDigits" : 2, "numericCode" : 997}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "UYI", "fractionDigits" : 0, "numericCode" : 940}, {"code" : "UYU", "fractionDigits" : 2, "numericCode" : 858}, {"code" : "UZS", "fractionDigits" : 2, "numericCode" : 860}, {"code" : "VUV", "fractionDigits" : 0, "numericCode" : 548}, {"code" : "VEF", "fractionDigits" : 2, "numericCode" : 937}, {"code" : "VND", "fractionDigits" : 0, "numericCode" : 704}, {"code" : "USD", "fractionDigits" : 2,
    "numericCode" : 840}, {"code" : "USD", "fractionDigits" : 2, "numericCode" : 840}, {"code" : "XPF", "fractionDigits" : 0, "numericCode" : 953}, {"code" : "MAD", "fractionDigits" : 2, "numericCode" : 504}, {"code" : "YER", "fractionDigits" : 2, "numericCode" : 886}, {"code" : "ZMW", "fractionDigits" : 2, "numericCode" : 967}, {"code" : "ZWL", "fractionDigits" : 2, "numericCode" : 932}, {"code" : "XBA", "fractionDigits" : -1, "numericCode" : 955}, {"code" : "XBB", "fractionDigits" : -1, "numericCode" : 956}
    , {"code" : "XBC", "fractionDigits" : -1, "numericCode" : 957}, {"code" : "XBD", "fractionDigits" : -1, "numericCode" : 958}, {"code" : "XTS", "fractionDigits" : -1, "numericCode" : 963}, {"code" : "XXX", "fractionDigits" : -1, "numericCode" : 999}, {"code" : "XAU", "fractionDigits" : -1, "numericCode" : 959}, {"code" : "XPD", "fractionDigits" : -1, "numericCode" : 964}, {"code" : "XPT", "fractionDigits" : -1, "numericCode" : 962}, {"code" : "XAG", "fractionDigits" : -1, "numericCode" : 961}];
},
otcic_CurrencyHelper_getCountryToCurrencyMap$$create = () => {
    return {"": {"value" : "CYP"}, "PR": {"value" : "USD"}, "PT": {"value" : "EUR"}, "PW": {"value" : "USD"}, "PY": {"value" : "PYG"}, "QA": {"value" : "QAR"}, "AC": {"value" : "SHP"}, "AD": {"value" : "EUR"}, "AE": {"value" : "AED"}, "AF": {"value" : "AFN"}, "AG": {"value" : "XCD"}, "AI": {"value" : "XCD"}, "AL": {"value" : "ALL"}, "AM": {"value" : "AMD"}, "AN": {"value" : "ANG"}, "AO": {"value" : "AOA"}, "242": {"value" : "Brazzaville"}, "AQ": {"value" : ""}, "AR": {"value" : "ARS"}, "243": {"value" : "Kinshasa"}
    , "AS": {"value" : "USD"}, "AT": {"value" : "EUR"}, "RE": {"value" : "EUR"}, "AU": {"value" : ""}, "AW": {"value" : "AWG"}, "AX": {"value" : "EUR"}, "AZ": {"value" : "AMD"}, "RO": {"value" : "RON"}, "BA": {"value" : "BAM"}, "BB": {"value" : "BBD"}, "RS": {"value" : "RSD"}, "BD": {"value" : "BDT"}, "BE": {"value" : "EUR"}, "RU": {"value" : "RUB"}, "BF": {"value" : "XOF"}, "BG": {"value" : "BGN"}, "RW": {"value" : "RWF"}, "27": {"value" : ""}, "BH": {"value" : "BHD"}, "BI": {"value" : "BIF"}, "BJ": {"value"
    : "XOF"}, "BM": {"value" : "BMD"}, "BN": {"value" : "BND"}, "BO": {"value" : "BOB"}, "SA": {"value" : "SAR"}, "SB": {"value" : "SBD"}, "BR": {"value" : "BRL"}, "SC": {"value" : "SCR"}, "SD": {"value" : "SDD"}, "BT": {"value" : "BTN"}, "SE": {"value" : "SEK"}, "SG": {"value" : "SGD"}, "BV": {"value" : ""}, "BW": {"value" : "BWP"}, "SH": {"value" : "SHP"}, "SI": {"value" : "EUR"}, "BY": {"value" : "BYR"}, "SJ": {"value" : "NOK"}, "BZ": {"value" : "BZD"}, "SK": {"value" : "SKK"}, "SL": {"value" : "SLL"}, "SM":
    {"value" : "EUR"}, "SN": {"value" : "XOF"}, "SO": {"value" : ""}, "CA": {"value" : "CAD"}, "SR": {"value" : "SRD"}, "CC": {"value" : "AUD"}, "ST": {"value" : "STD"}, "CF": {"value" : "XAF"}, "SV": {"value" : "USD"}, "CH": {"value" : "CHF"}, "CI": {"value" : "XOF"}, "SY": {"value" : "SYP"}, "SZ": {"value" : "SZL"}, "CK": {"value" : "NZD"}, "CL": {"value" : "CLP"}, "CM": {"value" : "XAF"}, "CO": {"value" : "COP"}, "TA": {"value" : "SHP"}, "CR": {"value" : "CRC"}, "TC": {"value" : "USD"}, "TD": {"value" : "XAF"}
    , "CU": {"value" : "CUP"}, "TF": {"value" : ""}, "CV": {"value" : "CVE"}, "TG": {"value" : "XOF"}, "TH": {"value" : "THB"}, "CX": {"value" : "AUD"}, "CY": {"value" : "TRY"}, "TJ": {"value" : "TJS"}, "CZ": {"value" : "CZK"}, "TK": {"value" : "NZD"}, "TL": {"value" : "USD"}, "TM": {"value" : "TMM"}, "TN": {"value" : "TND"}, "TO": {"value" : "TOP"}, "TR": {"value" : "TRY"}, "TT": {"value" : "TTD"}, "DE": {"value" : "EUR"}, "TV": {"value" : "AUD"}, "DJ": {"value" : "DJF"}, "TZ": {"value" : "TZS"}, "DK": {"value"
    : "DKK"}, "DM": {"value" : "XCD"}, "DO": {"value" : "DOP"}, "UA": {"value" : "UAH"}, "UG": {"value" : "UGX"}, "DZ": {"value" : "DZD"}, "UM": {"value" : ""}, "EC": {"value" : "USD"}, "US": {"value" : "USD"}, "EE": {"value" : "EEK"}, "EG": {"value" : "EGP"}, "UY": {"value" : "UYU"}, "UZ": {"value" : "UZS"}, "VA": {"value" : "EUR"}, "ER": {"value" : "ERN"}, "VC": {"value" : "XCD"}, "ES": {"value" : "EUR"}, "ET": {"value" : "ETB"}, "VE": {"value" : "VEB"}, "VG": {"value" : "USD"}, "VI": {"value" : "USD"}, "VN":
    {"value" : "VND"}, "VU": {"value" : "VUV"}, "FI": {"value" : "EUR"}, "FJ": {"value" : "FJD"}, "FK": {"value" : "FKP"}, "FM": {"value" : "USD"}, "FO": {"value" : "DKK"}, "FR": {"value" : "EUR"}, "WF": {"value" : "XPF"}, "850": {"value" : "Pyongyang"}, "GA": {"value" : "XAF"}, "GB": {"value" : "GBP"}, "WS": {"value" : "WST"}, "GD": {"value" : "XCD"}, "GE": {"value" : "RUB and GEL"}, "GF": {"value" : "EUR"}, "GG": {"value" : "GGP"}, "GH": {"value" : "GHC"}, "GI": {"value" : "GIP"}, "GL": {"value" : "DKK"},
    "GN": {"value" : "GNF"}, "GP": {"value" : "EUR"}, "GQ": {"value" : "XAF"}, "GR": {"value" : "EUR"}, "GS": {"value" : ""}, "GT": {"value" : "GTQ"}, "GU": {"value" : "USD"}, "GW": {"value" : "XOF"}, "GY": {"value" : "GYD"}, "-241": {"value" : "Nassau"}, "82": {"value" : "Seoul"}, "86": {"value" : "Beijing"}, "HK": {"value" : "HKD"}, "HM": {"value" : ""}, "HN": {"value" : "HNL"}, "HR": {"value" : "HRK"}, "HT": {"value" : "HTG"}, "YE": {"value" : "YER"}, "HU": {"value" : "HUF"}, "ID": {"value" : "IDR"}, "YT":
    {"value" : "EUR"}, "IE": {"value" : "EUR"}, "IL": {"value" : "ILS"}, "IM": {"value" : "IMP"}, "IN": {"value" : "INR"}, "IO": {"value" : ""}, "IQ": {"value" : "IQD"}, "IR": {"value" : "IRR"}, "IS": {"value" : "ISK"}, "IT": {"value" : "EUR"}, "ZM": {"value" : "ZMK"}, "886": {"value" : "Taipei"}, "JE": {"value" : "JEP"}, "ZW": {"value" : "ZWD"}, "JM": {"value" : "JMD"}, "JO": {"value" : "JOD"}, "JP": {"value" : "JPY"}, "KE": {"value" : "KES"}, "KG": {"value" : "KGS"}, "KH": {"value" : "KHR"}, "KI": {"value"
    : "AUD"}, "KM": {"value" : "KMF"}, "KN": {"value" : "XCD"}, "KW": {"value" : "KWD"}, "KY": {"value" : "KYD"}, "KZ": {"value" : "KZT"}, "LA": {"value" : "LAK"}, "LB": {"value" : "LBP"}, "LC": {"value" : "XCD"}, "LI": {"value" : "CHF"}, "LK": {"value" : "LKR"}, "LR": {"value" : "LRD"}, "LS": {"value" : "LSL"}, "LT": {"value" : "LTL"}, "LU": {"value" : "EUR"}, "LV": {"value" : "LVL"}, "LY": {"value" : "LYD"}, "MA": {"value" : "MAD"}, "MC": {"value" : "EUR"}, "MD": {"value" : ""}, "ME": {"value" : "EUR"}, "MG":
    {"value" : "MGA"}, "MH": {"value" : "USD"}, "MK": {"value" : "MKD"}, "ML": {"value" : "XOF"}, "MM": {"value" : "MMK"}, "MN": {"value" : "MNT"}, "MO": {"value" : "MOP"}, "MP": {"value" : "USD"}, "MQ": {"value" : "EUR"}, "MR": {"value" : "MRO"}, "MS": {"value" : "XCD"}, "MT": {"value" : "MTL"}, "MU": {"value" : "MUR"}, "MV": {"value" : "MVR"}, "MW": {"value" : "MWK"}, "MX": {"value" : "MXN"}, "MY": {"value" : "MYR"}, "MZ": {"value" : "MZM"}, "NA": {"value" : "NAD"}, "NC": {"value" : "XPF"}, "NE": {"value"
    : "XOF"}, "NF": {"value" : "AUD"}, "NG": {"value" : "NGN"}, "NI": {"value" : "NIO"}, "NL": {"value" : "EUR"}, "NO": {"value" : "NOK"}, "NP": {"value" : "NPR"}, "NR": {"value" : "AUD"}, "NU": {"value" : "NZD"}, "NZ": {"value" : "NZD"}, "OM": {"value" : "OMR"}, "220": {"value" : "Banjul"}, "PA": {"value" : "PAB"}, "PE": {"value" : "PEN"}, "PF": {"value" : ""}, "PG": {"value" : "PGK"}, "PH": {"value" : "PHP"}, "PK": {"value" : "PKR"}, "PL": {"value" : "PLN"}, "PM": {"value" : "EUR"}, "PN": {"value" : "NZD"}
    };
},
otci_Base46 = $rt_classWithoutFields(),
otci_Base46_decodeUnsigned = $seq => {
    let $number, $pos, var$4, var$5, $digit, $hasMore;
    $number = 0;
    $pos = 1;
    while (true) {
        var$4 = $seq.$characters.data;
        var$5 = $seq.$pointer;
        $seq.$pointer = var$5 + 1 | 0;
        $digit = otci_Base46_decodeDigit(var$4[var$5]);
        $hasMore = ($digit % 2 | 0) != 1 ? 0 : 1;
        $number = $number + $rt_imul($pos, $digit / 2 | 0) | 0;
        $pos = $pos * 46 | 0;
        if (!$hasMore)
            break;
    }
    return $number;
},
otci_Base46_decode = $seq => {
    let $number, $result;
    $number = otci_Base46_decodeUnsigned($seq);
    $result = $number / 2 | 0;
    if ($number % 2 | 0)
        $result =  -$result | 0;
    return $result;
};
let otci_Base46_decodeDigit = $c => {
    if ($c < 34)
        return $c - 32 | 0;
    if ($c >= 92)
        return ($c - 32 | 0) - 2 | 0;
    return ($c - 32 | 0) - 1 | 0;
},
rcei_JSBridge$FrameCallback = $rt_classWithoutFields(0);
function jl_AbstractStringBuilder() {
    let a = this; jl_Object.call(a);
    a.$buffer = null;
    a.$length0 = 0;
}
let jl_AbstractStringBuilder__init_0 = $this => {
    jl_AbstractStringBuilder__init_($this, 16);
},
jl_AbstractStringBuilder__init_2 = () => {
    let var_0 = new jl_AbstractStringBuilder();
    jl_AbstractStringBuilder__init_0(var_0);
    return var_0;
},
jl_AbstractStringBuilder__init_ = ($this, $capacity) => {
    jl_Object__init_($this);
    $this.$buffer = $rt_createCharArray($capacity);
},
jl_AbstractStringBuilder__init_1 = var_0 => {
    let var_1 = new jl_AbstractStringBuilder();
    jl_AbstractStringBuilder__init_(var_1, var_0);
    return var_1;
},
jl_AbstractStringBuilder_append7 = ($this, $obj) => {
    return $this.$insert($this.$length0, $obj);
},
jl_AbstractStringBuilder_append = ($this, $string) => {
    return $this.$insert0($this.$length0, $string);
},
jl_AbstractStringBuilder_insert2 = ($this, $index, $string) => {
    let $i, var$4, var$5;
    if ($index >= 0 && $index <= $this.$length0) {
        if ($string === null)
            $string = $rt_s(7);
        else if ($string.$isEmpty())
            return $this;
        $this.$ensureCapacity($this.$length0 + $string.$length() | 0);
        $i = $this.$length0 - 1 | 0;
        while ($i >= $index) {
            $this.$buffer.data[$i + $string.$length() | 0] = $this.$buffer.data[$i];
            $i = $i + (-1) | 0;
        }
        $this.$length0 = $this.$length0 + $string.$length() | 0;
        $i = 0;
        while ($i < $string.$length()) {
            var$4 = $this.$buffer.data;
            var$5 = $index + 1 | 0;
            var$4[$index] = $string.$charAt($i);
            $i = $i + 1 | 0;
            $index = var$5;
        }
        return $this;
    }
    $rt_throw(jl_StringIndexOutOfBoundsException__init_());
},
jl_AbstractStringBuilder_append3 = ($this, $value) => {
    return $this.$append1($value, 10);
},
jl_AbstractStringBuilder_append8 = ($this, $value, $radix) => {
    return $this.$insert1($this.$length0, $value, $radix);
},
jl_AbstractStringBuilder_insert7 = ($this, $target, $value, $radix) => {
    let $positive, var$5, var$6, $pos, $sz, $posLimit, var$10, var$11;
    $positive = 1;
    if ($value < 0) {
        $positive = 0;
        $value =  -$value | 0;
    }
    a: {
        if ($rt_ucmp($value, $radix) < 0) {
            if ($positive)
                jl_AbstractStringBuilder_insertSpace($this, $target, $target + 1 | 0);
            else {
                jl_AbstractStringBuilder_insertSpace($this, $target, $target + 2 | 0);
                var$5 = $this.$buffer.data;
                var$6 = $target + 1 | 0;
                var$5[$target] = 45;
                $target = var$6;
            }
            $this.$buffer.data[$target] = jl_Character_forDigit($value, $radix);
        } else {
            $pos = 1;
            $sz = 1;
            $posLimit = $rt_udiv((-1), $radix);
            b: {
                while (true) {
                    var$10 = $rt_imul($pos, $radix);
                    if ($rt_ucmp(var$10, $value) > 0) {
                        var$10 = $pos;
                        break b;
                    }
                    $sz = $sz + 1 | 0;
                    if ($rt_ucmp(var$10, $posLimit) > 0)
                        break;
                    $pos = var$10;
                }
            }
            if (!$positive)
                $sz = $sz + 1 | 0;
            jl_AbstractStringBuilder_insertSpace($this, $target, $target + $sz | 0);
            if ($positive)
                var$11 = $target;
            else {
                var$5 = $this.$buffer.data;
                var$11 = $target + 1 | 0;
                var$5[$target] = 45;
            }
            while (true) {
                if (!var$10)
                    break a;
                var$5 = $this.$buffer.data;
                var$6 = var$11 + 1 | 0;
                var$5[var$11] = jl_Character_forDigit($rt_udiv($value, var$10), $radix);
                $value = $rt_umod($value, var$10);
                var$10 = $rt_udiv(var$10, $radix);
                var$11 = var$6;
            }
        }
    }
    return $this;
},
jl_AbstractStringBuilder_append5 = ($this, $value) => {
    return $this.$insert2($this.$length0, $value);
},
jl_AbstractStringBuilder_insert5 = ($this, $target, $value) => {
    return $this.$insert3($target, $value, 10);
},
jl_AbstractStringBuilder_insert6 = ($this, $target, $value, $radix) => {
    let $positive, var$5, var$6, var$7, $sz, $pos, $posLimit, var$11, var$12;
    $positive = 1;
    if (Long_lt($value, Long_ZERO)) {
        $positive = 0;
        $value = Long_neg($value);
    }
    a: {
        var$5 = Long_fromInt($radix);
        if (jl_Long_compareUnsigned($value, var$5) < 0) {
            if ($positive)
                jl_AbstractStringBuilder_insertSpace($this, $target, $target + 1 | 0);
            else {
                jl_AbstractStringBuilder_insertSpace($this, $target, $target + 2 | 0);
                var$6 = $this.$buffer.data;
                var$7 = $target + 1 | 0;
                var$6[$target] = 45;
                $target = var$7;
            }
            $this.$buffer.data[$target] = jl_Character_forDigit(Long_lo($value), $radix);
        } else {
            $sz = 1;
            $pos = Long_fromInt(1);
            $posLimit = jl_Long_divideUnsigned(Long_fromInt(-1), var$5);
            b: {
                while (true) {
                    var$11 = Long_mul($pos, var$5);
                    if (jl_Long_compareUnsigned(var$11, $value) > 0) {
                        var$11 = $pos;
                        break b;
                    }
                    $sz = $sz + 1 | 0;
                    if (jl_Long_compareUnsigned(var$11, $posLimit) > 0)
                        break;
                    $pos = var$11;
                }
            }
            if (!$positive)
                $sz = $sz + 1 | 0;
            jl_AbstractStringBuilder_insertSpace($this, $target, $target + $sz | 0);
            if ($positive)
                var$12 = $target;
            else {
                var$6 = $this.$buffer.data;
                var$12 = $target + 1 | 0;
                var$6[$target] = 45;
            }
            while (true) {
                if (Long_eq(var$11, Long_ZERO))
                    break a;
                var$6 = $this.$buffer.data;
                var$7 = var$12 + 1 | 0;
                var$6[var$12] = jl_Character_forDigit(Long_lo((jl_Long_divideUnsigned($value, var$11))), $radix);
                $value = jl_Long_remainderUnsigned($value, var$11);
                var$11 = jl_Long_divideUnsigned(var$11, var$5);
                var$12 = var$7;
            }
        }
    }
    return $this;
},
jl_AbstractStringBuilder_append4 = ($this, $value) => {
    return $this.$insert4($this.$length0, $value);
},
jl_AbstractStringBuilder_insert1 = ($this, $target, $value) => {
    let var$3, var$4, var$5, $number, $mantissa, $exp, $negative, $intPart, $sz, $digits, $zeros, $leadingZeros, $leadingZero, var$16, $pos, $i, $intDigit, var$20;
    var$3 = $rt_compare($value, 0.0);
    if (!var$3) {
        if (1.0 / $value === Infinity) {
            jl_AbstractStringBuilder_insertSpace($this, $target, $target + 3 | 0);
            var$4 = $this.$buffer.data;
            var$3 = $target + 1 | 0;
            var$4[$target] = 48;
            var$4 = $this.$buffer.data;
            var$5 = var$3 + 1 | 0;
            var$4[var$3] = 46;
            $this.$buffer.data[var$5] = 48;
            return $this;
        }
        jl_AbstractStringBuilder_insertSpace($this, $target, $target + 4 | 0);
        var$4 = $this.$buffer.data;
        var$3 = $target + 1 | 0;
        var$4[$target] = 45;
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 48;
        var$4 = $this.$buffer.data;
        var$3 = var$5 + 1 | 0;
        var$4[var$5] = 46;
        $this.$buffer.data[var$3] = 48;
        return $this;
    }
    if (isNaN($value) ? 1 : 0) {
        jl_AbstractStringBuilder_insertSpace($this, $target, $target + 3 | 0);
        var$4 = $this.$buffer.data;
        var$3 = $target + 1 | 0;
        var$4[$target] = 78;
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 97;
        $this.$buffer.data[var$5] = 78;
        return $this;
    }
    if (!isFinite($value) ? 1 : 0) {
        if (var$3 > 0) {
            jl_AbstractStringBuilder_insertSpace($this, $target, $target + 8 | 0);
            var$3 = $target;
        } else {
            jl_AbstractStringBuilder_insertSpace($this, $target, $target + 9 | 0);
            var$4 = $this.$buffer.data;
            var$3 = $target + 1 | 0;
            var$4[$target] = 45;
        }
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 73;
        var$4 = $this.$buffer.data;
        var$3 = var$5 + 1 | 0;
        var$4[var$5] = 110;
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 102;
        var$4 = $this.$buffer.data;
        var$3 = var$5 + 1 | 0;
        var$4[var$5] = 105;
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 110;
        var$4 = $this.$buffer.data;
        var$3 = var$5 + 1 | 0;
        var$4[var$5] = 105;
        var$4 = $this.$buffer.data;
        var$5 = var$3 + 1 | 0;
        var$4[var$3] = 116;
        $this.$buffer.data[var$5] = 121;
        return $this;
    }
    jl_AbstractStringBuilder$Constants_$callClinit();
    $number = jl_AbstractStringBuilder$Constants_doubleAnalysisResult;
    otcit_DoubleAnalyzer_analyze($value, $number);
    $mantissa = $number.$mantissa;
    $exp = $number.$exponent;
    $negative = $number.$sign0;
    $intPart = 1;
    $sz = 1;
    if ($negative)
        $sz = 2;
    $digits = 18;
    $zeros = jl_AbstractStringBuilder_trailingDecimalZeros($mantissa);
    if ($zeros > 0)
        $digits = $digits - $zeros | 0;
    $leadingZeros = 0;
    $leadingZero = 0;
    if ($exp < 7 && $exp >= (-3)) {
        if ($exp >= 0) {
            $intPart = $exp + 1 | 0;
            $digits = jl_Math_max($digits, $intPart + 1 | 0);
            $exp = 0;
        } else {
            $intPart = 0;
            $leadingZeros = ( -$exp | 0) - 1 | 0;
            $leadingZero = 1;
            $sz = $sz + 1 | 0;
            $exp = 0;
        }
    }
    if ($exp) {
        $sz = $sz + 2 | 0;
        if (!($exp > (-10) && $exp < 10))
            $sz = $sz + 1 | 0;
        if (!($exp > (-100) && $exp < 100))
            $sz = $sz + 1 | 0;
        if ($exp < 0)
            $sz = $sz + 1 | 0;
    }
    if ($exp && $digits == $intPart)
        $digits = $digits + 1 | 0;
    var$3 = $sz + ($digits + $leadingZeros | 0) | 0;
    jl_AbstractStringBuilder_insertSpace($this, $target, $target + var$3 | 0);
    if (!$negative)
        var$16 = $target;
    else {
        var$4 = $this.$buffer.data;
        var$16 = $target + 1 | 0;
        var$4[$target] = 45;
    }
    $pos = Long_create(1569325056, 23283064);
    if ($leadingZero) {
        var$4 = $this.$buffer.data;
        var$3 = var$16 + 1 | 0;
        var$4[var$16] = 48;
        var$4 = $this.$buffer.data;
        var$16 = var$3 + 1 | 0;
        var$4[var$3] = 46;
        while (true) {
            var$3 = $leadingZeros + (-1) | 0;
            if ($leadingZeros <= 0)
                break;
            var$4 = $this.$buffer.data;
            var$5 = var$16 + 1 | 0;
            var$4[var$16] = 48;
            $leadingZeros = var$3;
            var$16 = var$5;
        }
    }
    $i = 0;
    while ($i < $digits) {
        if (Long_le($pos, Long_ZERO))
            $intDigit = 0;
        else {
            $intDigit = Long_lo(Long_div($mantissa, $pos));
            $mantissa = Long_rem($mantissa, $pos);
        }
        var$4 = $this.$buffer.data;
        var$3 = var$16 + 1 | 0;
        var$4[var$16] = (48 + $intDigit | 0) & 65535;
        $intPart = $intPart + (-1) | 0;
        if ($intPart)
            var$16 = var$3;
        else {
            var$4 = $this.$buffer.data;
            var$16 = var$3 + 1 | 0;
            var$4[var$3] = 46;
        }
        $pos = Long_div($pos, Long_fromInt(10));
        $i = $i + 1 | 0;
    }
    if ($exp) {
        var$4 = $this.$buffer.data;
        var$5 = var$16 + 1 | 0;
        var$4[var$16] = 69;
        if ($exp >= 0)
            var$20 = var$5;
        else {
            $exp =  -$exp | 0;
            var$4 = $this.$buffer.data;
            var$20 = var$5 + 1 | 0;
            var$4[var$5] = 45;
        }
        if ($exp >= 100) {
            var$4 = $this.$buffer.data;
            var$3 = var$20 + 1 | 0;
            var$4[var$20] = (48 + ($exp / 100 | 0) | 0) & 65535;
            $exp = $exp % 100 | 0;
            var$4 = $this.$buffer.data;
            var$5 = var$3 + 1 | 0;
            var$4[var$3] = (48 + ($exp / 10 | 0) | 0) & 65535;
        } else if ($exp < 10)
            var$5 = var$20;
        else {
            var$4 = $this.$buffer.data;
            var$5 = var$20 + 1 | 0;
            var$4[var$20] = (48 + ($exp / 10 | 0) | 0) & 65535;
        }
        $this.$buffer.data[var$5] = (48 + ($exp % 10 | 0) | 0) & 65535;
    }
    return $this;
},
jl_AbstractStringBuilder_trailingDecimalZeros = $n => {
    let $zeros, $result, $bit, $i;
    $zeros = Long_fromInt(1);
    $result = 0;
    $bit = 16;
    jl_AbstractStringBuilder$Constants_$callClinit();
    $i = jl_AbstractStringBuilder$Constants_longLogPowersOfTen.data.length - 1 | 0;
    while ($i >= 0) {
        if (Long_eq(Long_rem($n, Long_mul($zeros, jl_AbstractStringBuilder$Constants_longLogPowersOfTen.data[$i])), Long_ZERO)) {
            $result = $result | $bit;
            $zeros = Long_mul($zeros, jl_AbstractStringBuilder$Constants_longLogPowersOfTen.data[$i]);
        }
        $bit = $bit >>> 1 | 0;
        $i = $i + (-1) | 0;
    }
    return $result;
},
jl_AbstractStringBuilder_append1 = ($this, $c) => {
    return $this.$insert5($this.$length0, $c);
},
jl_AbstractStringBuilder_insert4 = ($this, $index, $c) => {
    jl_AbstractStringBuilder_insertSpace($this, $index, $index + 1 | 0);
    $this.$buffer.data[$index] = $c;
    return $this;
},
jl_AbstractStringBuilder_insert3 = ($this, $index, $obj) => {
    return $this.$insert0($index, $obj === null ? $rt_s(7) : $obj.$toString());
},
jl_AbstractStringBuilder_ensureCapacity = ($this, $capacity) => {
    let $newLength;
    if ($this.$buffer.data.length >= $capacity)
        return;
    $newLength = $this.$buffer.data.length >= 1073741823 ? 2147483647 : jl_Math_max($capacity, jl_Math_max($this.$buffer.data.length * 2 | 0, 5));
    $this.$buffer = ju_Arrays_copyOf($this.$buffer, $newLength);
},
jl_AbstractStringBuilder_toString = $this => {
    return jl_String__init_($this.$buffer, 0, $this.$length0);
},
jl_AbstractStringBuilder_length = $this => {
    return $this.$length0;
},
jl_AbstractStringBuilder_charAt = ($this, $index) => {
    if ($index >= 0 && $index < $this.$length0)
        return $this.$buffer.data[$index];
    $rt_throw(jl_IndexOutOfBoundsException__init_());
},
jl_AbstractStringBuilder_append0 = ($this, $s, $start, $end) => {
    return $this.$insert6($this.$length0, $s, $start, $end);
},
jl_AbstractStringBuilder_insert = ($this, $index, $s, $i, $end) => {
    let var$5, var$6;
    if ($i <= $end && $end <= $s.$length() && $i >= 0) {
        jl_AbstractStringBuilder_insertSpace($this, $index, ($index + $end | 0) - $i | 0);
        while ($i < $end) {
            var$5 = $this.$buffer.data;
            var$6 = $index + 1 | 0;
            var$5[$index] = $s.$charAt($i);
            $i = $i + 1 | 0;
            $index = var$6;
        }
        return $this;
    }
    $rt_throw(jl_IndexOutOfBoundsException__init_());
},
jl_AbstractStringBuilder_append2 = ($this, $s) => {
    return $this.$append6($s, 0, $s.$length());
},
jl_AbstractStringBuilder_append6 = ($this, $chars, $offset, $len) => {
    return $this.$insert7($this.$length0, $chars, $offset, $len);
},
jl_AbstractStringBuilder_insert0 = ($this, $index, $chars, $offset, $len) => {
    let var$5, var$6, var$7, var$8, var$9;
    jl_AbstractStringBuilder_insertSpace($this, $index, $index + $len | 0);
    var$5 = $len + $offset | 0;
    while ($offset < var$5) {
        var$6 = $chars.data;
        var$7 = $this.$buffer.data;
        var$8 = $index + 1 | 0;
        var$9 = $offset + 1 | 0;
        var$7[$index] = var$6[$offset];
        $index = var$8;
        $offset = var$9;
    }
    return $this;
},
jl_AbstractStringBuilder_setLength = ($this, $newLength) => {
    $this.$length0 = $newLength;
},
jl_AbstractStringBuilder_insertSpace = ($this, $start, $end) => {
    let $sz, $i;
    $sz = $this.$length0 - $start | 0;
    $this.$ensureCapacity(($this.$length0 + $end | 0) - $start | 0);
    $i = $sz - 1 | 0;
    while ($i >= 0) {
        $this.$buffer.data[$end + $i | 0] = $this.$buffer.data[$start + $i | 0];
        $i = $i + (-1) | 0;
    }
    $this.$length0 = $this.$length0 + ($end - $start | 0) | 0;
},
jl_Appendable = $rt_classWithoutFields(0),
jl_StringBuilder = $rt_classWithoutFields(jl_AbstractStringBuilder),
jl_StringBuilder__init_2 = ($this, $capacity) => {
    jl_AbstractStringBuilder__init_($this, $capacity);
},
jl_StringBuilder__init_0 = var_0 => {
    let var_1 = new jl_StringBuilder();
    jl_StringBuilder__init_2(var_1, var_0);
    return var_1;
},
jl_StringBuilder__init_1 = $this => {
    jl_AbstractStringBuilder__init_0($this);
},
jl_StringBuilder__init_ = () => {
    let var_0 = new jl_StringBuilder();
    jl_StringBuilder__init_1(var_0);
    return var_0;
},
jl_StringBuilder_append = ($this, $obj) => {
    jl_AbstractStringBuilder_append7($this, $obj);
    return $this;
},
jl_StringBuilder_append4 = ($this, $string) => {
    jl_AbstractStringBuilder_append($this, $string);
    return $this;
},
jl_StringBuilder_append0 = ($this, $value) => {
    jl_AbstractStringBuilder_append3($this, $value);
    return $this;
},
jl_StringBuilder_append8 = ($this, $value) => {
    jl_AbstractStringBuilder_append5($this, $value);
    return $this;
},
jl_StringBuilder_append2 = ($this, $value) => {
    jl_AbstractStringBuilder_append4($this, $value);
    return $this;
},
jl_StringBuilder_append1 = ($this, $c) => {
    jl_AbstractStringBuilder_append1($this, $c);
    return $this;
},
jl_StringBuilder_append5 = ($this, $chars, $offset, $len) => {
    jl_AbstractStringBuilder_append6($this, $chars, $offset, $len);
    return $this;
},
jl_StringBuilder_append9 = ($this, $s, $start, $end) => {
    jl_AbstractStringBuilder_append0($this, $s, $start, $end);
    return $this;
},
jl_StringBuilder_append7 = ($this, $s) => {
    jl_AbstractStringBuilder_append2($this, $s);
    return $this;
},
jl_StringBuilder_insert7 = ($this, $target, $value) => {
    jl_AbstractStringBuilder_insert5($this, $target, $value);
    return $this;
},
jl_StringBuilder_insert8 = ($this, $target, $value) => {
    jl_AbstractStringBuilder_insert1($this, $target, $value);
    return $this;
},
jl_StringBuilder_insert1 = ($this, $index, $s, $start, $end) => {
    jl_AbstractStringBuilder_insert($this, $index, $s, $start, $end);
    return $this;
},
jl_StringBuilder_insert5 = ($this, $index, $chars, $offset, $len) => {
    jl_AbstractStringBuilder_insert0($this, $index, $chars, $offset, $len);
    return $this;
},
jl_StringBuilder_insert9 = ($this, $index, $obj) => {
    jl_AbstractStringBuilder_insert3($this, $index, $obj);
    return $this;
};
let jl_StringBuilder_insert2 = ($this, $index, $c) => {
    jl_AbstractStringBuilder_insert4($this, $index, $c);
    return $this;
},
jl_StringBuilder_insert11 = ($this, $index, $string) => {
    jl_AbstractStringBuilder_insert2($this, $index, $string);
    return $this;
},
jl_StringBuilder_setLength = ($this, var$1) => {
    jl_AbstractStringBuilder_setLength($this, var$1);
},
jl_StringBuilder_insert10 = ($this, var$1, var$2, var$3, var$4) => {
    return $this.$insert8(var$1, var$2, var$3, var$4);
},
jl_StringBuilder_insert3 = ($this, var$1, var$2, var$3, var$4) => {
    return $this.$insert9(var$1, var$2, var$3, var$4);
},
jl_StringBuilder_append6 = ($this, var$1, var$2, var$3) => {
    return $this.$append15(var$1, var$2, var$3);
},
jl_StringBuilder_charAt = ($this, var$1) => {
    return jl_AbstractStringBuilder_charAt($this, var$1);
},
jl_StringBuilder_length = $this => {
    return jl_AbstractStringBuilder_length($this);
},
jl_StringBuilder_toString = $this => {
    return jl_AbstractStringBuilder_toString($this);
},
jl_StringBuilder_ensureCapacity = ($this, var$1) => {
    jl_AbstractStringBuilder_ensureCapacity($this, var$1);
},
jl_StringBuilder_insert0 = ($this, var$1, var$2) => {
    return $this.$insert10(var$1, var$2);
},
jl_StringBuilder_insert = ($this, var$1, var$2) => {
    return $this.$insert11(var$1, var$2);
},
jl_StringBuilder_insert6 = ($this, var$1, var$2) => {
    return $this.$insert12(var$1, var$2);
},
jl_StringBuilder_insert4 = ($this, var$1, var$2) => {
    return $this.$insert13(var$1, var$2);
},
jl_StringBuilder_insert12 = ($this, var$1, var$2) => {
    return $this.$insert14(var$1, var$2);
},
jl_StringBuilder_append3 = ($this, var$1) => {
    return $this.$append16(var$1);
},
ju_ConcurrentModificationException = $rt_classWithoutFields(jl_RuntimeException),
ju_ConcurrentModificationException__init_0 = $this => {
    jl_RuntimeException__init_($this);
},
ju_ConcurrentModificationException__init_ = () => {
    let var_0 = new ju_ConcurrentModificationException();
    ju_ConcurrentModificationException__init_0(var_0);
    return var_0;
};
function ju_Currency() {
    jl_Object.call(this);
    this.$resource = null;
}
let ju_Currency_currencies = null,
ju_Currency__init_0 = ($this, $resource) => {
    jl_Object__init_($this);
    $this.$resource = $resource;
},
ju_Currency__init_ = var_0 => {
    let var_1 = new ju_Currency();
    ju_Currency__init_0(var_1, var_0);
    return var_1;
},
ju_Currency_initCurrencies = () => {
    let $resources, $i, $resource;
    if (ju_Currency_currencies !== null)
        return;
    ju_Currency_currencies = ju_HashMap__init_();
    $resources = otcic_CurrencyHelper_getCurrencies();
    $i = 0;
    while ($i < $resources.length) {
        $resource = $resources[$i];
        ju_Currency_currencies.$put(($resource.code !== null ? $rt_str($resource.code) : null), ju_Currency__init_($resource));
        $i = $i + 1 | 0;
    }
},
ju_Currency_getInstance0 = $currencyCode => {
    let $currency, var$3, var$4;
    if ($currencyCode === null)
        $rt_throw(jl_NullPointerException__init_());
    ju_Currency_initCurrencies();
    $currency = ju_Currency_currencies.$get($currencyCode);
    if ($currency !== null)
        return $currency;
    var$3 = new jl_IllegalArgumentException;
    var$4 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$4, $rt_s(8)), $currencyCode);
    jl_IllegalArgumentException__init_(var$3, jl_StringBuilder_toString(var$4));
    $rt_throw(var$3);
},
ju_Currency_getInstance = $locale => {
    let $coutry, $countryMap, var$4;
    if ($locale === null)
        $rt_throw(jl_NullPointerException__init_());
    $coutry = otciu_CLDRHelper_resolveCountry(ju_Locale_getLanguage($locale), ju_Locale_getCountry($locale));
    $countryMap = otcic_CurrencyHelper_getCountryToCurrencyMap();
    if (!$countryMap.hasOwnProperty($rt_ustr($coutry)))
        return null;
    var$4 = ($countryMap[$rt_ustr($coutry)].value !== null ? $rt_str($countryMap[$rt_ustr($coutry)].value) : null);
    return ju_Currency_getInstance0(var$4);
},
ju_Currency_getCurrencyCode = $this => {
    return ($this.$resource.code !== null ? $rt_str($this.$resource.code) : null);
},
ju_Currency_getSymbol = ($this, $locale) => {
    let var$2, var$3, var$4, $localization;
    var$2 = ju_Locale_getLanguage($locale);
    var$3 = ju_Locale_getCountry($locale);
    var$4 = ju_Currency_getCurrencyCode($this);
    $localization = otciu_CLDRHelper_resolveCurrency(var$2, var$3, var$4);
    return $localization !== null && !($localization.symbol !== null ? $rt_str($localization.symbol) : null).$isEmpty() ? ($localization.symbol !== null ? $rt_str($localization.symbol) : null) : ju_Currency_getCurrencyCode($this);
},
ju_Currency_toString = $this => {
    return ($this.$resource.code !== null ? $rt_str($this.$resource.code) : null);
},
jl_ClassCastException = $rt_classWithoutFields(jl_RuntimeException);
function jt_AttributedCharacterIterator$Attribute() {
    jl_Object.call(this);
    this.$name2 = null;
}
let jt_AttributedCharacterIterator$Attribute_INPUT_METHOD_SEGMENT = null,
jt_AttributedCharacterIterator$Attribute_LANGUAGE = null,
jt_AttributedCharacterIterator$Attribute_READING = null,
jt_AttributedCharacterIterator$Attribute_$callClinit = () => {
    jt_AttributedCharacterIterator$Attribute_$callClinit = $rt_eraseClinit(jt_AttributedCharacterIterator$Attribute);
    jt_AttributedCharacterIterator$Attribute__clinit_();
},
jt_AttributedCharacterIterator$Attribute__init_0 = ($this, $name) => {
    jt_AttributedCharacterIterator$Attribute_$callClinit();
    jl_Object__init_($this);
    $this.$name2 = $name;
},
jt_AttributedCharacterIterator$Attribute__init_ = var_0 => {
    let var_1 = new jt_AttributedCharacterIterator$Attribute();
    jt_AttributedCharacterIterator$Attribute__init_0(var_1, var_0);
    return var_1;
},
jt_AttributedCharacterIterator$Attribute_equals = ($this, $object) => {
    return $this !== $object ? 0 : 1;
},
jt_AttributedCharacterIterator$Attribute_getName = $this => {
    return $this.$name2;
},
jt_AttributedCharacterIterator$Attribute_hashCode = $this => {
    return jl_Object_hashCode($this);
},
jt_AttributedCharacterIterator$Attribute_toString = $this => {
    let var$1, var$2, var$3;
    var$1 = (jl_Object_getClass($this)).$getName();
    var$2 = $this.$getName();
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append1(jl_StringBuilder_append(jl_StringBuilder_append1(jl_StringBuilder_append(var$3, var$1), 40), var$2), 41);
    return jl_StringBuilder_toString(var$3);
},
jt_AttributedCharacterIterator$Attribute__clinit_ = () => {
    jt_AttributedCharacterIterator$Attribute_INPUT_METHOD_SEGMENT = jt_AttributedCharacterIterator$Attribute__init_($rt_s(9));
    jt_AttributedCharacterIterator$Attribute_LANGUAGE = jt_AttributedCharacterIterator$Attribute__init_($rt_s(10));
    jt_AttributedCharacterIterator$Attribute_READING = jt_AttributedCharacterIterator$Attribute__init_($rt_s(11));
},
jl_StringBuffer = $rt_classWithoutFields(jl_AbstractStringBuilder),
jl_StringBuffer__init_ = $this => {
    jl_AbstractStringBuilder__init_0($this);
},
jl_StringBuffer__init_0 = () => {
    let var_0 = new jl_StringBuffer();
    jl_StringBuffer__init_(var_0);
    return var_0;
},
jl_StringBuffer_append2 = ($this, $string) => {
    jl_AbstractStringBuilder_append($this, $string);
    return $this;
},
jl_StringBuffer_append3 = ($this, $c) => {
    jl_AbstractStringBuilder_append1($this, $c);
    return $this;
},
jl_StringBuffer_append0 = ($this, $s, $start, $end) => {
    jl_AbstractStringBuilder_append0($this, $s, $start, $end);
    return $this;
},
jl_StringBuffer_append4 = ($this, $s) => {
    jl_AbstractStringBuilder_append2($this, $s);
    return $this;
},
jl_StringBuffer_insert12 = ($this, $target, $value) => {
    jl_AbstractStringBuilder_insert5($this, $target, $value);
    return $this;
},
jl_StringBuffer_insert7 = ($this, $target, $value) => {
    jl_AbstractStringBuilder_insert1($this, $target, $value);
    return $this;
},
jl_StringBuffer_insert0 = ($this, $index, $s, $start, $end) => {
    jl_AbstractStringBuilder_insert($this, $index, $s, $start, $end);
    return $this;
},
jl_StringBuffer_insert2 = ($this, $index, $chars, $offset, $len) => {
    jl_AbstractStringBuilder_insert0($this, $index, $chars, $offset, $len);
    return $this;
},
jl_StringBuffer_insert4 = ($this, $index, $obj) => {
    jl_AbstractStringBuilder_insert3($this, $index, $obj);
    return $this;
},
jl_StringBuffer_insert10 = ($this, $index, $c) => {
    jl_AbstractStringBuilder_insert4($this, $index, $c);
    return $this;
},
jl_StringBuffer_insert3 = ($this, $index, $string) => {
    jl_AbstractStringBuilder_insert2($this, $index, $string);
    return $this;
},
jl_StringBuffer_insert6 = ($this, var$1, var$2, var$3, var$4) => {
    return $this.$insert15(var$1, var$2, var$3, var$4);
},
jl_StringBuffer_insert8 = ($this, var$1, var$2, var$3, var$4) => {
    return $this.$insert16(var$1, var$2, var$3, var$4);
},
jl_StringBuffer_append1 = ($this, var$1, var$2, var$3) => {
    return $this.$append17(var$1, var$2, var$3);
},
jl_StringBuffer_charAt = ($this, var$1) => {
    return jl_AbstractStringBuilder_charAt($this, var$1);
},
jl_StringBuffer_length = $this => {
    return jl_AbstractStringBuilder_length($this);
},
jl_StringBuffer_toString = $this => {
    return jl_AbstractStringBuilder_toString($this);
},
jl_StringBuffer_ensureCapacity = ($this, var$1) => {
    jl_AbstractStringBuilder_ensureCapacity($this, var$1);
},
jl_StringBuffer_insert11 = ($this, var$1, var$2) => {
    return $this.$insert17(var$1, var$2);
},
jl_StringBuffer_insert5 = ($this, var$1, var$2) => {
    return $this.$insert18(var$1, var$2);
},
jl_StringBuffer_insert = ($this, var$1, var$2) => {
    return $this.$insert19(var$1, var$2);
},
jl_StringBuffer_insert9 = ($this, var$1, var$2) => {
    return $this.$insert20(var$1, var$2);
},
jl_StringBuffer_insert1 = ($this, var$1, var$2) => {
    return $this.$insert21(var$1, var$2);
},
jl_StringBuffer_append = ($this, var$1) => {
    return $this.$append18(var$1);
};
function rce_GameObject() {
    let a = this; jl_Object.call(a);
    a.$x = 0.0;
    a.$y = 0.0;
    a.$vx = 0.0;
    a.$vy = 0.0;
    a.$width0 = 0.0;
    a.$height = 0.0;
    a.$color = null;
    a.$tag = null;
    a.$visible = 0;
    a.$active = 0;
    a.$solid = 0;
    a.$gravityScale = 0.0;
    a.$friction = 0.0;
    a.$destroyed = 0;
    a.$customProperties = null;
    a.$collisionHandler = null;
}
let rce_GameObject__init_ = ($this, $x, $y, $width, $height) => {
    jl_Object__init_($this);
    $this.$width0 = 32.0;
    $this.$height = 32.0;
    rce_Color_$callClinit();
    $this.$color = rce_Color_WHITE;
    $this.$tag = $rt_s(12);
    $this.$visible = 1;
    $this.$active = 1;
    $this.$solid = 0;
    $this.$gravityScale = 0.0;
    $this.$friction = 0.98;
    $this.$destroyed = 0;
    $this.$customProperties = ju_HashMap__init_();
    $this.$x = $x;
    $this.$y = $y;
    $this.$width0 = $width;
    $this.$height = $height;
},
rce_GameObject__init_0 = (var_0, var_1, var_2, var_3) => {
    let var_4 = new rce_GameObject();
    rce_GameObject__init_(var_4, var_0, var_1, var_2, var_3);
    return var_4;
},
rce_GameObject_update = ($this, $delta) => {
    if ($this.$active && !$this.$destroyed) {
        if ($this.$gravityScale > 0.0)
            $this.$vy = $this.$vy + 980.0 * $this.$gravityScale * $delta;
        $this.$x = $this.$x + $this.$vx * $delta;
        $this.$y = $this.$y + $this.$vy * $delta;
        $this.$vx = $this.$vx * jl_Math_pow($this.$friction, $delta * 60.0);
        return;
    }
},
rce_GameObject_collidesWith = ($this, $other) => {
    if ($other !== null && $other.$active && !$other.$destroyed && $other !== $this)
        return $this.$x < $other.$x + $other.$width0 && $this.$x + $this.$width0 > $other.$x && $this.$y < $other.$y + $other.$height && $this.$y + $this.$height > $other.$y ? 1 : 0;
    return 0;
},
rce_GameObject_handleCollision = ($this, $other) => {
    if ($this.$collisionHandler !== null)
        $this.$collisionHandler.$accept($other);
},
rce_GameObject_isDestroyed = $this => {
    return $this.$destroyed;
};
function rcg_Player() {
    let a = this; rce_GameObject.call(a);
    a.$lives = 0;
    a.$speed = 0.0;
}
let rcg_Player__init_ = (var$0, var$1, var$2) => {
    rce_GameObject__init_(var$0, var$1, var$2, 32.0, 32.0);
    var$0.$lives = 3;
    var$0.$speed = 160.0;
},
rcg_Player__init_0 = (var_0, var_1) => {
    let var_2 = new rcg_Player();
    rcg_Player__init_(var_2, var_0, var_1);
    return var_2;
},
rcg_Player_takeDamage = var$0 => {
    if (var$0.$lives <= 0)
        return 0;
    var$0.$lives = var$0.$lives - 1 | 0;
    return 1;
},
rcg_Player_draw = (var$0, var$1) => {
    var$1.$drawRect(var$0.$x, var$0.$y, var$0.$width0, var$0.$height, rce_Color__init_(52, 152, 219));
    var$1.$drawRect(var$0.$x + 6.0, var$0.$y + 8.0, 6.0, 6.0, rce_Color_WHITE);
    var$1.$drawRect(var$0.$x + 20.0, var$0.$y + 8.0, 6.0, 6.0, rce_Color_WHITE);
    var$1.$drawRect(var$0.$x + 8.0, var$0.$y + 10.0, 3.0, 3.0, rce_Color_BLACK);
    var$1.$drawRect(var$0.$x + 22.0, var$0.$y + 10.0, 3.0, 3.0, rce_Color_BLACK);
},
ji_Flushable = $rt_classWithoutFields(0),
juf_ToIntFunction = $rt_classWithoutFields(0),
ji_IOException = $rt_classWithoutFields(jl_Exception),
rcg_Main = $rt_classWithoutFields(),
rcg_Main_$callClinit = () => {
    rcg_Main_$callClinit = $rt_eraseClinit(rcg_Main);
    rcg_Main__clinit_();
},
rcg_Main_main = var$1 => {
    rcg_Main_$callClinit();
    rce_Game_launch(rcg_MyGame__init_0());
},
rcg_Main__clinit_ = () => {
    return;
},
juf_Predicate = $rt_classWithoutFields(0),
rce_Game$step$lambda$_31_0 = $rt_classWithoutFields(),
rce_Game$step$lambda$_31_0__init_ = var$0 => {
    jl_Object__init_(var$0);
},
rce_Game$step$lambda$_31_0__init_0 = () => {
    let var_0 = new rce_Game$step$lambda$_31_0();
    rce_Game$step$lambda$_31_0__init_(var_0);
    return var_0;
},
rce_Game$step$lambda$_31_0_test0 = (var$0, var$1) => {
    return rce_Game$step$lambda$_31_0_test(var$0, var$1);
},
rce_Game$step$lambda$_31_0_test = (var$0, var$1) => {
    return var$1.$isDestroyed();
},
ju_Iterator = $rt_classWithoutFields(0);
function ju_AbstractList$1() {
    let a = this; jl_Object.call(a);
    a.$index2 = 0;
    a.$modCount1 = 0;
    a.$size1 = 0;
    a.$removeIndex = 0;
    a.$this$00 = null;
}
let ju_AbstractList$1__init_ = ($this, $this$0) => {
    $this.$this$00 = $this$0;
    jl_Object__init_($this);
    $this.$modCount1 = $this.$this$00.$modCount;
    $this.$size1 = $this.$this$00.$size();
    $this.$removeIndex = (-1);
},
ju_AbstractList$1__init_0 = var_0 => {
    let var_1 = new ju_AbstractList$1();
    ju_AbstractList$1__init_(var_1, var_0);
    return var_1;
},
ju_AbstractList$1_hasNext = $this => {
    return $this.$index2 >= $this.$size1 ? 0 : 1;
},
ju_AbstractList$1_next = $this => {
    let var$1, var$2;
    ju_AbstractList$1_checkConcurrentModification($this);
    $this.$removeIndex = $this.$index2;
    var$1 = $this.$this$00;
    var$2 = $this.$index2;
    $this.$index2 = var$2 + 1 | 0;
    return var$1.$get0(var$2);
},
ju_AbstractList$1_remove = $this => {
    if ($this.$removeIndex < 0)
        $rt_throw(jl_IllegalStateException__init_());
    ju_AbstractList$1_checkConcurrentModification($this);
    $this.$this$00.$remove($this.$removeIndex);
    $this.$modCount1 = $this.$this$00.$modCount;
    if ($this.$removeIndex < $this.$index2)
        $this.$index2 = $this.$index2 - 1 | 0;
    $this.$size1 = $this.$size1 - 1 | 0;
    $this.$removeIndex = (-1);
},
ju_AbstractList$1_checkConcurrentModification = $this => {
    if ($this.$modCount1 >= $this.$this$00.$modCount)
        return;
    $rt_throw(ju_ConcurrentModificationException__init_());
};
function jl_Enum() {
    let a = this; jl_Object.call(a);
    a.$name0 = null;
    a.$ordinal0 = 0;
}
let jl_Enum__init_ = ($this, $name, $ordinal) => {
    jl_Object__init_($this);
    $this.$name0 = $name;
    $this.$ordinal0 = $ordinal;
},
jl_Enum_name = $this => {
    return $this.$name0;
},
jl_Enum_ordinal = $this => {
    return $this.$ordinal0;
},
jl_Enum_toString = $this => {
    return $this.$name0.$toString();
},
jl_Enum_equals = ($this, $other) => {
    return $this !== $other ? 0 : 1;
},
jl_Enum_hashCode = $this => {
    return jl_Object_hashCode($this);
},
jl_Enum_getDeclaringClass = $this => {
    let $result;
    $result = jl_Object_getClass($this);
    if (!($result.$getSuperclass()).$equals($rt_cls(jl_Enum)))
        $result = $result.$getSuperclass();
    return $result;
},
jl_Enum_compareTo = ($this, $o) => {
    let var$2, var$3, var$4, var$5;
    if (jl_Enum_getDeclaringClass($o) === jl_Enum_getDeclaringClass($this))
        return jl_Integer_compare($this.$ordinal0, jl_Enum_ordinal($o));
    var$2 = new jl_IllegalArgumentException;
    var$3 = jl_Enum_getDeclaringClass($this);
    var$4 = jl_Enum_getDeclaringClass($o);
    var$5 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(var$5, $rt_s(13)), var$3), $rt_s(14)), var$4);
    jl_IllegalArgumentException__init_(var$2, jl_StringBuilder_toString(var$5));
    $rt_throw(var$2);
},
jl_Enum_compareTo0 = ($this, var$1) => {
    return jl_Enum_compareTo($this, var$1);
};
function rceh_VirtualPin$State() {
    let a = this; jl_Enum.call(a);
    a.$digitalValue = 0;
    a.$voltage = 0.0;
}
let rceh_VirtualPin$State_LOW = null,
rceh_VirtualPin$State_HIGH = null,
rceh_VirtualPin$State_$VALUES = null,
rceh_VirtualPin$State_$callClinit = () => {
    rceh_VirtualPin$State_$callClinit = $rt_eraseClinit(rceh_VirtualPin$State);
    rceh_VirtualPin$State__clinit_();
},
rceh_VirtualPin$State__init_0 = ($this, var$1, var$2, $digitalValue, $voltage) => {
    rceh_VirtualPin$State_$callClinit();
    jl_Enum__init_($this, var$1, var$2);
    $this.$digitalValue = $digitalValue;
    $this.$voltage = $voltage;
},
rceh_VirtualPin$State__init_ = (var_0, var_1, var_2, var_3) => {
    let var_4 = new rceh_VirtualPin$State();
    rceh_VirtualPin$State__init_0(var_4, var_0, var_1, var_2, var_3);
    return var_4;
},
rceh_VirtualPin$State_$values = () => {
    let var$1, var$2;
    rceh_VirtualPin$State_$callClinit();
    var$1 = $rt_createArray(rceh_VirtualPin$State, 2);
    var$2 = var$1.data;
    var$2[0] = rceh_VirtualPin$State_LOW;
    var$2[1] = rceh_VirtualPin$State_HIGH;
    return var$1;
},
rceh_VirtualPin$State__clinit_ = () => {
    rceh_VirtualPin$State_LOW = rceh_VirtualPin$State__init_($rt_s(15), 0, 0, 0.0);
    rceh_VirtualPin$State_HIGH = rceh_VirtualPin$State__init_($rt_s(16), 1, 1, 5.0);
    rceh_VirtualPin$State_$VALUES = rceh_VirtualPin$State_$values();
};
function rceh_InterruptController() {
    let a = this; jl_Object.call(a);
    a.$globalInterruptEnable = 0;
    a.$vectorTable = null;
    a.$pendingQueue = null;
    a.$interruptCount = Long_ZERO;
    a.$lastHandledVector = 0;
}
let rceh_InterruptController__init_ = $this => {
    jl_Object__init_($this);
    $this.$globalInterruptEnable = 1;
    $this.$vectorTable = ju_HashMap__init_();
    $this.$pendingQueue = ju_ArrayList__init_();
    $this.$interruptCount = Long_ZERO;
    $this.$lastHandledVector = 0;
},
rceh_InterruptController__init_0 = () => {
    let var_0 = new rceh_InterruptController();
    rceh_InterruptController__init_(var_0);
    return var_0;
},
rceh_InterruptController_trigger0 = ($this, $vector, $context) => {
    let $isr, $priority;
    $isr = $this.$vectorTable.$get(jl_Integer_valueOf($vector));
    $priority = $isr === null ? 10 : $isr.$priority0;
    $this.$pendingQueue.$add0(rceh_InterruptController$PendingInterrupt__init_0($vector, $context, $priority));
},
rceh_InterruptController_trigger = ($this, $vector) => {
    $this.$trigger($vector, null);
},
rceh_InterruptController_processInterrupts = $this => {
    let $processing, var$2, $pi, $isr, $$je;
    if ($this.$globalInterruptEnable && !$this.$pendingQueue.$isEmpty()) {
        $this.$pendingQueue.$sort(ju_Comparator_comparingInt(rceh_InterruptController$processInterrupts$lambda$_9_0__init_0()));
        $processing = ju_ArrayList__init_3($this.$pendingQueue);
        $this.$pendingQueue.$clear();
        var$2 = $processing.$iterator();
        while (var$2.$hasNext()) {
            a: {
                $pi = var$2.$next();
                $isr = $this.$vectorTable.$get(jl_Integer_valueOf($pi.$vector));
                if ($isr !== null && $isr.$handler !== null) {
                    $this.$lastHandledVector = $pi.$vector;
                    $this.$interruptCount = Long_add($this.$interruptCount, Long_fromInt(1));
                    try {
                        $isr.$handler.$handle($pi.$vector, $pi.$context);
                        break a;
                    } catch ($$e) {
                        $$je = $rt_wrapException($$e);
                        if ($$je instanceof jl_Throwable) {
                        } else {
                            throw $$e;
                        }
                    }
                }
            }
        }
        return;
    }
},
rceh_InterruptController_lambda$processInterrupts$0 = $a => {
    return $a.$priority;
};
function rceh_InterruptController$PendingInterrupt() {
    let a = this; jl_Object.call(a);
    a.$vector = 0;
    a.$context = null;
    a.$priority = 0;
}
let rceh_InterruptController$PendingInterrupt__init_ = ($this, $vector, $context, $priority) => {
    jl_Object__init_($this);
    $this.$vector = $vector;
    $this.$context = $context;
    $this.$priority = $priority;
},
rceh_InterruptController$PendingInterrupt__init_0 = (var_0, var_1, var_2) => {
    let var_3 = new rceh_InterruptController$PendingInterrupt();
    rceh_InterruptController$PendingInterrupt__init_(var_3, var_0, var_1, var_2);
    return var_3;
},
jlr_Array = $rt_classWithoutFields(),
jlr_Array_getLength = var$1 => {
    if (var$1 === null || var$1.constructor.$meta.item === 'undefined') {
        $rt_throw(jl_IllegalArgumentException__init_0());
    }
    return var$1.data.length;
},
jlr_Array_newInstance = (var$1, $length) => {
    if (var$1 === null)
        $rt_throw(jl_NullPointerException__init_());
    if (var$1 === $rt_cls($rt_voidcls))
        $rt_throw(jl_IllegalArgumentException__init_0());
    if ($length < 0)
        $rt_throw(jl_NegativeArraySizeException__init_0());
    return jlr_Array_newInstanceImpl(var$1.$getPlatformClass(), $length);
},
jlr_Array_newInstanceImpl = (var$1, var$2) => {
    if (var$1.$meta.primitive) {
        switch (var$1) {
            case $rt_booleanArrayCls: return $rt_createBooleanArray(var$2);
            case $rt_charArrayCls: return $rt_createCharArray(var$2);
            case $rt_shortArrayCls: return $rt_createShortArray(var$2);
            case $rt_intArrayCls: return $rt_createIntArray(var$2);
            case $rt_longArrayCls: return $rt_createLongArray(var$2);
        }
        ;
    }
    return $rt_createArray(var$1, var$2);
};
function otcit_DoubleAnalyzer$Result() {
    let a = this; jl_Object.call(a);
    a.$mantissa = Long_ZERO;
    a.$exponent = 0;
    a.$sign0 = 0;
}
let otcit_DoubleAnalyzer$Result__init_0 = $this => {
    jl_Object__init_($this);
},
otcit_DoubleAnalyzer$Result__init_ = () => {
    let var_0 = new otcit_DoubleAnalyzer$Result();
    otcit_DoubleAnalyzer$Result__init_0(var_0);
    return var_0;
},
otpp_ResourceAccessor = $rt_classWithoutFields(),
jl_Iterable = $rt_classWithoutFields(0),
ju_Collection = $rt_classWithoutFields(0),
ju_Collection_removeIf = ($this, $filter) => {
    let $iterator, $removed, $element, $match;
    $iterator = $this.$iterator();
    $removed = 0;
    while ($iterator.$hasNext()) {
        $element = $iterator.$next();
        $match = $filter.$test0($element);
        if ($match) {
            $iterator.$remove0();
            $removed = 1;
        }
    }
    return $removed;
},
ju_AbstractCollection = $rt_classWithoutFields(),
ju_AbstractCollection__init_ = $this => {
    jl_Object__init_($this);
},
ju_AbstractCollection_isEmpty = $this => {
    return $this.$size() ? 0 : 1;
},
ju_AbstractCollection_contains = ($this, $o) => {
    let $iter, $e;
    $iter = $this.$iterator();
    while ($iter.$hasNext()) {
        $e = $iter.$next();
        if (ju_Objects_equals($e, $o))
            return 1;
    }
    return 0;
},
ju_AbstractCollection_toArray = ($this, $a) => {
    let var$2, $i, var$4, $iter;
    var$2 = $a.data;
    $i = $this.$size();
    var$4 = var$2.length;
    if (var$4 < $i)
        $a = jlr_Array_newInstance((jl_Object_getClass($a)).$getComponentType(), $i);
    else
        while ($i < var$4) {
            var$2[$i] = null;
            $i = $i + 1 | 0;
        }
    $i = 0;
    $iter = $this.$iterator();
    while ($iter.$hasNext()) {
        var$2 = $a.data;
        var$4 = $i + 1 | 0;
        var$2[$i] = $iter.$next();
        $i = var$4;
    }
    return $a;
},
ju_AbstractCollection_add = ($this, $e) => {
    $rt_throw(jl_UnsupportedOperationException__init_0());
},
ju_AbstractCollection_addAll = ($this, $c) => {
    let $changed, $iter;
    $changed = 0;
    $iter = $c.$iterator();
    while ($iter.$hasNext()) {
        if (!$this.$add0($iter.$next()))
            continue;
        $changed = 1;
    }
    return $changed;
},
ju_AbstractCollection_removeAll = ($this, $c) => {
    let $changed, $iter, $e;
    ju_Objects_requireNonNull($c);
    $changed = 0;
    $iter = $this.$iterator();
    while ($iter.$hasNext()) {
        $e = $iter.$next();
        if ($c.$contains($e)) {
            $iter.$remove0();
            $changed = 1;
        }
    }
    return $changed;
},
ju_AbstractCollection_toString = $this => {
    let $sb, $iter, $e, var$4;
    $sb = jl_StringBuilder__init_();
    $sb.$append0(91);
    $iter = $this.$iterator();
    if ($iter.$hasNext()) {
        $e = $iter.$next();
        if ($e === $this)
            $e = $rt_s(17);
        $sb.$append($e);
    }
    while ($iter.$hasNext()) {
        $e = $iter.$next();
        var$4 = $sb.$append19($rt_s(18));
        if ($e === $this)
            $e = $rt_s(17);
        var$4.$append($e);
    }
    $sb.$append0(93);
    return $sb.$toString();
},
otci_IntegerUtil = $rt_classWithoutFields(),
otci_IntegerUtil_toUnsignedLogRadixString = ($value, $radixLog2) => {
    let $radix, $mask, $sz, $chars, $pos, $target, var$9, $target_0;
    if (!$value)
        return $rt_s(19);
    $radix = 1 << $radixLog2;
    $mask = $radix - 1 | 0;
    $sz = (((32 - jl_Integer_numberOfLeadingZeros($value) | 0) + $radixLog2 | 0) - 1 | 0) / $radixLog2 | 0;
    $chars = $rt_createCharArray($sz);
    $pos = $rt_imul($sz - 1 | 0, $radixLog2);
    $target = 0;
    while ($pos >= 0) {
        var$9 = $chars.data;
        $target_0 = $target + 1 | 0;
        var$9[$target] = jl_Character_forDigit(($value >>> $pos | 0) & $mask, $radix);
        $pos = $pos - $radixLog2 | 0;
        $target = $target_0;
    }
    return jl_String__init_0($chars);
},
otci_IntegerUtil_toUnsignedLogRadixString0 = ($value, $radixLog2) => {
    let $radix, $mask, $sz, $chars, $pos, $target, var$9, $target_0;
    if (Long_eq($value, Long_ZERO))
        return $rt_s(19);
    $radix = 1 << $radixLog2;
    $mask = $radix - 1 | 0;
    $sz = (((64 - jl_Long_numberOfLeadingZeros($value) | 0) + $radixLog2 | 0) - 1 | 0) / $radixLog2 | 0;
    $chars = $rt_createCharArray($sz);
    $pos = $rt_imul($sz - 1 | 0, $radixLog2);
    $target = 0;
    while ($pos >= 0) {
        var$9 = $chars.data;
        $target_0 = $target + 1 | 0;
        var$9[$target] = jl_Character_forDigit(Long_lo(Long_shru($value, $pos)) & $mask, $radix);
        $pos = $pos - $radixLog2 | 0;
        $target = $target_0;
    }
    return jl_String__init_0($chars);
};
function ju_Locale() {
    let a = this; jl_Object.call(a);
    a.$countryCode = null;
    a.$languageCode = null;
    a.$variantCode = null;
}
let ju_Locale_defaultLocale = null,
ju_Locale_CANADA = null,
ju_Locale_CANADA_FRENCH = null,
ju_Locale_CHINA = null,
ju_Locale_CHINESE = null,
ju_Locale_ENGLISH = null,
ju_Locale_FRANCE = null,
ju_Locale_FRENCH = null,
ju_Locale_GERMAN = null,
ju_Locale_GERMANY = null,
ju_Locale_ITALIAN = null,
ju_Locale_ITALY = null,
ju_Locale_JAPAN = null,
ju_Locale_JAPANESE = null,
ju_Locale_KOREA = null,
ju_Locale_KOREAN = null,
ju_Locale_PRC = null,
ju_Locale_SIMPLIFIED_CHINESE = null,
ju_Locale_TAIWAN = null,
ju_Locale_TRADITIONAL_CHINESE = null,
ju_Locale_UK = null,
ju_Locale_US = null,
ju_Locale_ROOT = null,
ju_Locale_$callClinit = () => {
    ju_Locale_$callClinit = $rt_eraseClinit(ju_Locale);
    ju_Locale__clinit_();
},
ju_Locale__init_1 = ($this, $language, $country) => {
    ju_Locale_$callClinit();
    ju_Locale__init_0($this, $language, $country, $rt_s(1));
},
ju_Locale__init_ = (var_0, var_1) => {
    let var_2 = new ju_Locale();
    ju_Locale__init_1(var_2, var_0, var_1);
    return var_2;
},
ju_Locale__init_0 = ($this, $language, $country, $variant) => {
    ju_Locale_$callClinit();
    jl_Object__init_($this);
    if ($language !== null && $country !== null && $variant !== null) {
        if ($language.$isEmpty() && $country.$isEmpty()) {
            $this.$languageCode = $rt_s(1);
            $this.$countryCode = $rt_s(1);
            $this.$variantCode = $variant;
            return;
        }
        $this.$languageCode = $language;
        $this.$countryCode = $country;
        $this.$variantCode = $variant;
        return;
    }
    $rt_throw(jl_NullPointerException__init_());
},
ju_Locale__init_2 = (var_0, var_1, var_2) => {
    let var_3 = new ju_Locale();
    ju_Locale__init_0(var_3, var_0, var_1, var_2);
    return var_3;
},
ju_Locale_equals = ($this, $object) => {
    let $o, var$3, var$4, var$5;
    if ($object === $this)
        return 1;
    if (!($object instanceof ju_Locale))
        return 0;
    a: {
        $o = $object;
        if ($this.$languageCode.$equals($o.$languageCode) && $this.$countryCode.$equals($o.$countryCode)) {
            var$3 = $this.$variantCode;
            var$4 = $o.$variantCode;
            if (var$3.$equals(var$4)) {
                var$5 = 1;
                break a;
            }
        }
        var$5 = 0;
    }
    return var$5;
},
ju_Locale_getCountry = $this => {
    return $this.$countryCode;
},
ju_Locale_getDefault = () => {
    ju_Locale_$callClinit();
    return ju_Locale_defaultLocale;
},
ju_Locale_getLanguage = $this => {
    return $this.$languageCode;
},
ju_Locale_hashCode = $this => {
    return ($this.$countryCode.$hashCode0() + $this.$languageCode.$hashCode0() | 0) + $this.$variantCode.$hashCode0() | 0;
},
ju_Locale_toString = $this => {
    let $result;
    $result = jl_StringBuilder__init_();
    $result.$append19($this.$languageCode);
    if (!$this.$countryCode.$isEmpty()) {
        $result.$append0(95);
        $result.$append19($this.$countryCode);
    }
    if (!$this.$variantCode.$isEmpty() && $result.$length() > 0) {
        if (!$this.$countryCode.$isEmpty())
            $result.$append0(95);
        else
            $result.$append19($rt_s(20));
        $result.$append19($this.$variantCode);
    }
    return $result.$toString();
},
ju_Locale__clinit_ = () => {
    let $localeName, $countryIndex;
    ju_Locale_CANADA = ju_Locale__init_($rt_s(21), $rt_s(22));
    ju_Locale_CANADA_FRENCH = ju_Locale__init_($rt_s(23), $rt_s(22));
    ju_Locale_CHINA = ju_Locale__init_($rt_s(24), $rt_s(25));
    ju_Locale_CHINESE = ju_Locale__init_($rt_s(24), $rt_s(1));
    ju_Locale_ENGLISH = ju_Locale__init_($rt_s(21), $rt_s(1));
    ju_Locale_FRANCE = ju_Locale__init_($rt_s(23), $rt_s(26));
    ju_Locale_FRENCH = ju_Locale__init_($rt_s(23), $rt_s(1));
    ju_Locale_GERMAN = ju_Locale__init_($rt_s(27), $rt_s(1));
    ju_Locale_GERMANY = ju_Locale__init_($rt_s(27), $rt_s(28));
    ju_Locale_ITALIAN = ju_Locale__init_($rt_s(29), $rt_s(1));
    ju_Locale_ITALY = ju_Locale__init_($rt_s(29), $rt_s(30));
    ju_Locale_JAPAN = ju_Locale__init_($rt_s(31), $rt_s(32));
    ju_Locale_JAPANESE = ju_Locale__init_($rt_s(31), $rt_s(1));
    ju_Locale_KOREA = ju_Locale__init_($rt_s(33), $rt_s(34));
    ju_Locale_KOREAN = ju_Locale__init_($rt_s(33), $rt_s(1));
    ju_Locale_PRC = ju_Locale__init_($rt_s(24), $rt_s(25));
    ju_Locale_SIMPLIFIED_CHINESE = ju_Locale__init_($rt_s(24), $rt_s(25));
    ju_Locale_TAIWAN = ju_Locale__init_($rt_s(24), $rt_s(35));
    ju_Locale_TRADITIONAL_CHINESE = ju_Locale__init_($rt_s(24), $rt_s(35));
    ju_Locale_UK = ju_Locale__init_($rt_s(21), $rt_s(36));
    ju_Locale_US = ju_Locale__init_($rt_s(21), $rt_s(37));
    ju_Locale_ROOT = ju_Locale__init_($rt_s(1), $rt_s(1));
    $localeName = ((otciu_CLDRHelper_getDefaultLocale()).value !== null ? $rt_str((otciu_CLDRHelper_getDefaultLocale()).value) : null);
    $countryIndex = $localeName.$indexOf(95);
    ju_Locale_defaultLocale = ju_Locale__init_2($localeName.$substring0(0, $countryIndex), $localeName.$substring($countryIndex + 1 | 0), $rt_s(1));
},
jl_Short = $rt_classWithoutFields(jl_Number),
jl_Thread$UncaughtExceptionHandler = $rt_classWithoutFields(0),
jl_DefaultUncaughtExceptionHandler = $rt_classWithoutFields(),
jl_DefaultUncaughtExceptionHandler__init_ = $this => {
    jl_Object__init_($this);
},
jl_DefaultUncaughtExceptionHandler__init_0 = () => {
    let var_0 = new jl_DefaultUncaughtExceptionHandler();
    jl_DefaultUncaughtExceptionHandler__init_(var_0);
    return var_0;
},
jt_DecimalFormat$1 = $rt_classWithoutFields(),
jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode = null,
jt_DecimalFormat$1_$callClinit = () => {
    jt_DecimalFormat$1_$callClinit = $rt_eraseClinit(jt_DecimalFormat$1);
    jt_DecimalFormat$1__clinit_();
},
jt_DecimalFormat$1__clinit_ = () => {
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode = $rt_createIntArray((jm_RoundingMode_values()).data.length);
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_CEILING)] = 1;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_FLOOR)] = 2;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_UP)] = 3;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_DOWN)] = 4;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_UNNECESSARY)] = 5;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_HALF_DOWN)] = 6;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_HALF_UP)] = 7;
    jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal(jm_RoundingMode_HALF_EVEN)] = 8;
},
otjc_JSObjects = $rt_classWithoutFields(),
otji_JS = $rt_classWithoutFields(),
otji_JS_wrap = $array => {
    let var$2, var$3, $result, $i, var$6;
    if ($array === null)
        return null;
    var$2 = $array.data;
    var$3 = var$2.length;
    $result = new Array(var$3);
    $i = 0;
    while ($i < var$3) {
        var$6 = var$2[$i];
        $result[$i] = var$6;
        $i = $i + 1 | 0;
    }
    return $result;
},
otji_JS_function = (var$1, var$2) => {
    let name = 'jso$functor$' + var$2;
    let result = var$1[name];
    if (typeof result !== 'function') {
        let fn = function() {
            return var$1[var$2].apply(var$1, arguments);
        };
        result = () => fn;
        var$1[name] = result;
    }
    return result();
},
otjc_JSFinalizationRegistryConsumer = $rt_classWithoutFields(0),
otji_JSWrapper$_clinit_$lambda$_33_0 = $rt_classWithoutFields();
let otji_JSWrapper$_clinit_$lambda$_33_0__init_ = var$0 => {
    jl_Object__init_(var$0);
},
otji_JSWrapper$_clinit_$lambda$_33_0__init_0 = () => {
    let var_0 = new otji_JSWrapper$_clinit_$lambda$_33_0();
    otji_JSWrapper$_clinit_$lambda$_33_0__init_(var_0);
    return var_0;
},
otji_JSWrapper$_clinit_$lambda$_33_0_accept = (var$0, var$1) => {
    otji_JSWrapper_lambda$static$0(var$1);
},
otji_JSWrapper$_clinit_$lambda$_33_0_accept$exported$0 = (var$0, var$1) => {
    var$0.$accept(otji_JSWrapper_jsToJava(var$1));
},
otp_PlatformRunnable = $rt_classWithoutFields(0),
otciu_UnicodeHelper = $rt_classWithoutFields(),
otciu_UnicodeHelper_decodeCaseMapping = $text => {
    let $flow, $sz, $data, $last, $i, var$7, var$8;
    $flow = otci_CharFlow__init_0($text.$toCharArray());
    $sz = otci_Base46_decodeUnsigned($flow);
    $data = $rt_createIntArray($sz * 2 | 0);
    $last = 0;
    $i = 0;
    while ($i < $sz) {
        var$7 = $data.data;
        $last = $last + otci_Base46_decodeUnsigned($flow) | 0;
        var$8 = $i * 2 | 0;
        var$7[var$8] = $last;
        var$7[var$8 + 1 | 0] = otci_Base46_decode($flow);
        $i = $i + 1 | 0;
    }
    return $data;
},
otciu_UnicodeHelper_createCharMapping = $data => {
    let $result, $last, $lastValue, $i, var$6, var$7, $key, $value, var$10;
    $result = $rt_createIntArray(65536);
    $last = 0;
    $lastValue = 0;
    $i = 0;
    a: {
        while (true) {
            var$6 = $data.data;
            if ($i >= var$6.length)
                break a;
            var$7 = $result.data;
            $key = var$6[$i];
            $value = var$6[$i + 1 | 0];
            var$10 = var$7.length;
            if ($key < var$10)
                var$10 = $key;
            else if ($key == $last)
                break;
            ju_Arrays_fill0($result, $last, var$10, $lastValue);
            $i = $i + 2 | 0;
            $last = var$10;
            $lastValue = $value;
        }
    }
    return otciu_CharMapping__init_0($data, $result);
};
function jl_Object$monitorEnterWait$lambda$_6_0() {
    let a = this; jl_Object.call(a);
    a.$_00 = null;
    a.$_1 = null;
    a.$_2 = 0;
    a.$_3 = null;
}
let jl_Object$monitorEnterWait$lambda$_6_0__init_ = (var$0, var$1, var$2, var$3, var$4) => {
    jl_Object__init_(var$0);
    var$0.$_00 = var$1;
    var$0.$_1 = var$2;
    var$0.$_2 = var$3;
    var$0.$_3 = var$4;
},
jl_Object$monitorEnterWait$lambda$_6_0__init_0 = (var_0, var_1, var_2, var_3) => {
    let var_4 = new jl_Object$monitorEnterWait$lambda$_6_0();
    jl_Object$monitorEnterWait$lambda$_6_0__init_(var_4, var_0, var_1, var_2, var_3);
    return var_4;
},
jl_Object$monitorEnterWait$lambda$_6_0_run = var$0 => {
    jl_Object_lambda$monitorEnterWait$0(var$0.$_00, var$0.$_1, var$0.$_2, var$0.$_3);
},
rcei_JSBridge$MouseCallback = $rt_classWithoutFields(0),
rce_Game$launch$lambda$_36_3 = $rt_classWithoutFields(),
rce_Game$launch$lambda$_36_3__init_ = var$0 => {
    jl_Object__init_(var$0);
},
rce_Game$launch$lambda$_36_3__init_0 = () => {
    let var_0 = new rce_Game$launch$lambda$_36_3();
    rce_Game$launch$lambda$_36_3__init_(var_0);
    return var_0;
},
rce_Game$launch$lambda$_36_3_onMouse = (var$0, var$1, var$2, var$3) => {
    rce_Game_lambda$launch$6(var$1, var$2, var$3);
},
rce_Game$launch$lambda$_36_3_onMouse$exported$0 = (var$0, var$1, var$2, var$3) => {
    var$0.$onMouse(var$1, var$2, var$3);
},
ju_Objects = $rt_classWithoutFields(),
ju_Objects_equals = ($a, $b) => {
    if ($a === $b)
        return 1;
    return $a !== null ? $a.$equals($b) : $b !== null ? 0 : 1;
},
ju_Objects_hashCode = $o => {
    return $o !== null ? $o.$hashCode0() : 0;
},
ju_Objects_requireNonNull = $obj => {
    return ju_Objects_requireNonNull0($obj, $rt_s(1));
},
ju_Objects_requireNonNull0 = ($obj, $message) => {
    if ($obj !== null)
        return $obj;
    $rt_throw(jl_NullPointerException__init_1($message));
},
ju_Objects_checkFromIndexSize = ($fromIndex, $size, $length) => {
    if ($fromIndex >= 0 && $size >= 0 && $size <= ($length - $fromIndex | 0))
        return $fromIndex;
    $rt_throw(jl_IndexOutOfBoundsException__init_());
},
rcei_JSBridge$KeyCallback = $rt_classWithoutFields(0);
function rce_Game$launch$lambda$_36_1() {
    jl_Object.call(this);
    this.$_04 = null;
}
let rce_Game$launch$lambda$_36_1__init_ = (var$0, var$1) => {
    jl_Object__init_(var$0);
    var$0.$_04 = var$1;
},
rce_Game$launch$lambda$_36_1__init_0 = var_0 => {
    let var_1 = new rce_Game$launch$lambda$_36_1();
    rce_Game$launch$lambda$_36_1__init_(var_1, var_0);
    return var_1;
},
rce_Game$launch$lambda$_36_1_onKey = (var$0, var$1, var$2) => {
    rce_Game_lambda$launch$4(var$0.$_04, var$1, var$2);
},
rce_Game$launch$lambda$_36_1_onKey$exported$0 = (var$0, var$1, var$2) => {
    var$0.$onKey($rt_str(var$1), $rt_str(var$2));
};
function rce_Game$launch$lambda$_36_2() {
    jl_Object.call(this);
    this.$_01 = null;
}
let rce_Game$launch$lambda$_36_2__init_ = (var$0, var$1) => {
    jl_Object__init_(var$0);
    var$0.$_01 = var$1;
},
rce_Game$launch$lambda$_36_2__init_0 = var_0 => {
    let var_1 = new rce_Game$launch$lambda$_36_2();
    rce_Game$launch$lambda$_36_2__init_(var_1, var_0);
    return var_1;
},
rce_Game$launch$lambda$_36_2_onMouse = (var$0, var$1, var$2, var$3) => {
    rce_Game_lambda$launch$5(var$0.$_01, var$1, var$2, var$3);
},
rce_Game$launch$lambda$_36_2_onMouse$exported$0 = (var$0, var$1, var$2, var$3) => {
    var$0.$onMouse(var$1, var$2, var$3);
},
otjc_JSUndefined = $rt_classWithoutFields(),
ju_Map$Entry = $rt_classWithoutFields(0);
function ju_MapEntry() {
    let a = this; jl_Object.call(a);
    a.$key = null;
    a.$value1 = null;
}
let ju_MapEntry__init_ = ($this, $theKey, $theValue) => {
    jl_Object__init_($this);
    $this.$key = $theKey;
    $this.$value1 = $theValue;
},
ju_MapEntry__init_0 = (var_0, var_1) => {
    let var_2 = new ju_MapEntry();
    ju_MapEntry__init_(var_2, var_0, var_1);
    return var_2;
},
ju_MapEntry_equals = ($this, $object) => {
    let $entry;
    if ($this === $object)
        return 1;
    if (!$rt_isInstance($object, ju_Map$Entry))
        return 0;
    $entry = $object;
    return ju_Objects_equals($this.$key, $entry.$getKey()) && ju_Objects_equals($this.$value1, $entry.$getValue()) ? 1 : 0;
},
ju_MapEntry_getKey = $this => {
    return $this.$key;
},
ju_MapEntry_getValue = $this => {
    return $this.$value1;
},
ju_MapEntry_hashCode = $this => {
    return ju_Objects_hashCode($this.$key) ^ ju_Objects_hashCode($this.$value1);
},
ju_MapEntry_toString = $this => {
    let var$1, var$2, var$3;
    var$1 = $this.$key;
    var$2 = $this.$value1;
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append1(jl_StringBuilder_append(var$3, var$1), 61), var$2);
    return jl_StringBuilder_toString(var$3);
};
function ju_HashMap$HashEntry() {
    let a = this; ju_MapEntry.call(a);
    a.$origKeyHash = 0;
    a.$next1 = null;
}
let ju_HashMap$HashEntry__init_ = ($this, $theKey, $hash) => {
    ju_MapEntry__init_($this, $theKey, null);
    $this.$origKeyHash = $hash;
},
ju_HashMap$HashEntry__init_0 = (var_0, var_1) => {
    let var_2 = new ju_HashMap$HashEntry();
    ju_HashMap$HashEntry__init_(var_2, var_0, var_1);
    return var_2;
},
ju_Comparator = $rt_classWithoutFields(0),
ju_Comparator_comparingInt = $keyExtractor => {
    return ju_Comparator$comparingInt$lambda$_14_0__init_0($keyExtractor);
},
ju_Comparator_lambda$comparingInt$10 = ($keyExtractor, $a, $b) => {
    return jl_Integer_compare($keyExtractor.$applyAsInt($a), $keyExtractor.$applyAsInt($b));
},
ju_Comparator$NaturalOrder = $rt_classWithoutFields(),
ju_Comparator$NaturalOrder_INSTANCE = null,
ju_Comparator$NaturalOrder_$callClinit = () => {
    ju_Comparator$NaturalOrder_$callClinit = $rt_eraseClinit(ju_Comparator$NaturalOrder);
    ju_Comparator$NaturalOrder__clinit_();
},
ju_Comparator$NaturalOrder__init_ = $this => {
    ju_Comparator$NaturalOrder_$callClinit();
    jl_Object__init_($this);
},
ju_Comparator$NaturalOrder__init_0 = () => {
    let var_0 = new ju_Comparator$NaturalOrder();
    ju_Comparator$NaturalOrder__init_(var_0);
    return var_0;
},
ju_Comparator$NaturalOrder_compare = ($this, $o1, $o2) => {
    return $o1.$compareTo2($o2);
},
ju_Comparator$NaturalOrder_instance = () => {
    ju_Comparator$NaturalOrder_$callClinit();
    return ju_Comparator$NaturalOrder_INSTANCE;
},
ju_Comparator$NaturalOrder__clinit_ = () => {
    ju_Comparator$NaturalOrder_INSTANCE = ju_Comparator$NaturalOrder__init_0();
},
ju_Queue = $rt_classWithoutFields(0),
jl_ArrayStoreException = $rt_classWithoutFields(jl_RuntimeException),
jl_ArrayStoreException__init_0 = $this => {
    jl_RuntimeException__init_($this);
},
jl_ArrayStoreException__init_ = () => {
    let var_0 = new jl_ArrayStoreException();
    jl_ArrayStoreException__init_0(var_0);
    return var_0;
},
ju_SequencedCollection = $rt_classWithoutFields(0),
rcei_JSBridge = $rt_classWithoutFields(),
rcei_JSBridge_browserEnvironment = 0,
rcei_JSBridge_$callClinit = () => {
    rcei_JSBridge_$callClinit = $rt_eraseClinit(rcei_JSBridge);
    rcei_JSBridge__clinit_();
},
rcei_JSBridge_checkBrowserEnvironment = () => {
    let var$1, $$je;
    rcei_JSBridge_$callClinit();
    a: {
        try {
            var$1 = typeof window !== 'undefined' && typeof document !== 'undefined' ? 1 : 0;
        } catch ($$e) {
            $$je = $rt_wrapException($$e);
            if ($$je instanceof jl_Throwable) {
                break a;
            } else {
                throw $$e;
            }
        }
        return var$1;
    }
    return 0;
},
rcei_JSBridge_isBrowser = () => {
    rcei_JSBridge_$callClinit();
    return rcei_JSBridge_browserEnvironment;
},
rcei_JSBridge__clinit_ = () => {
    rcei_JSBridge_browserEnvironment = rcei_JSBridge_checkBrowserEnvironment();
},
rcei_JSBridge_initCanvas$js_body$_4 = (var$1, var$2, var$3, var$4) => {
    var c = document.getElementById(var$1);
    if (!c) {
        c = document.createElement('canvas');
        c.id = var$1;
        var container = document.getElementById('game-container') || document.body;
        container.appendChild(c);
    }
    c.width = var$2;
    c.height = var$3;
    c.style.backgroundColor = var$4;
    window.__collegeCanvas = c;
    window.__collegeCtx = c.getContext('2d');
},
rcei_JSBridge_clearCanvas$js_body$_5 = var$1 => {
    var ctx = window.__collegeCtx;
    if (ctx) {
        ctx.fillStyle = var$1;
        ctx.fillRect(0, 0, window.__collegeCanvas.width, window.__collegeCanvas.height);
    }
},
rcei_JSBridge_drawRect$js_body$_6 = (var$1, var$2, var$3, var$4, var$5, var$6) => {
    var ctx = window.__collegeCtx;
    if (ctx) {
        ctx.fillStyle = var$5;
        ctx.strokeStyle = var$5;
        if (var$6) {
            ctx.fillRect(var$1, var$2, var$3, var$4);
        } else {
            ctx.strokeRect(var$1, var$2, var$3, var$4);
        }
    }
},
rcei_JSBridge_drawCircle$js_body$_7 = (var$1, var$2, var$3, var$4, var$5) => {
    var ctx = window.__collegeCtx;
    if (ctx) {
        ctx.beginPath();
        ctx.arc(var$1, var$2, var$3, 0, Math.PI * 2);
        if (var$5) {
            ctx.fillStyle = var$4;
            ctx.fill();
        } else {
            ctx.strokeStyle = var$4;
            ctx.stroke();
        }
    }
},
rcei_JSBridge_drawLine$js_body$_8 = (var$1, var$2, var$3, var$4, var$5, var$6) => {
    var ctx = window.__collegeCtx;
    if (ctx) {
        ctx.beginPath();
        ctx.moveTo(var$1, var$2);
        ctx.lineTo(var$3, var$4);
        ctx.strokeStyle = var$5;
        ctx.lineWidth = var$6;
        ctx.stroke();
    }
},
rcei_JSBridge_drawText$js_body$_9 = (var$1, var$2, var$3, var$4, var$5, var$6) => {
    var ctx = window.__collegeCtx;
    if (ctx) {
        ctx.fillStyle = var$5;
        ctx.font = var$4 + 'px ' + (var$6 || 'Courier New, monospace');
        ctx.fillText(var$1, var$2, var$3);
    }
},
rcei_JSBridge_playTone$js_body$_10 = (var$1, var$2, var$3) => {
    try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!window.__collegeAudioCtx && AudioCtx) {
            window.__collegeAudioCtx = new AudioCtx();
        }
        var actx = window.__collegeAudioCtx;
        if (actx) {
            if (actx.state === 'suspended') {
                actx.resume();
            }
            var osc = actx.createOscillator();
            var gain = actx.createGain();
            osc.type = var$3 || 'square';
            osc.frequency.setValueAtTime(var$1, actx.currentTime);
            gain.gain.setValueAtTime(0.12, actx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + var$2 / 1000.0);
            osc.connect(gain);
            gain.connect(actx.destination);
            osc.start();
            osc.stop(actx.currentTime + var$2 / 1000.0);
        }
    } catch (e){
    }
},
rcei_JSBridge_requestAnimationFrame$js_body$_11 = var$1 => {
    window.requestAnimationFrame(function(t) {
        var$1(t);
    });
},
rcei_JSBridge_setupKeyboardListeners$js_body$_12 = (var$1, var$2) => {
    window.addEventListener('keydown', function(e) {
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].indexOf(e.code) !==  -1) {
            e.preventDefault();
        }
        if (var$1) var$1(e.key, e.code);
    });
    window.addEventListener('keyup', function(e) {
        if (var$2) var$2(e.key, e.code);
    });
},
rcei_JSBridge_setupMouseListeners$js_body$_13 = (var$1, var$2, var$3) => {
    var c = document.getElementById(var$1) || window.__collegeCanvas;
    if (c) {
        if (var$2) {
            c.addEventListener('mousedown', function(e) {
                var rect = c.getBoundingClientRect();
                var$2(e.clientX - rect.left, e.clientY - rect.top, e.button);
            });
        }
        if (var$3) {
            c.addEventListener('mousemove', function(e) {
                var rect = c.getBoundingClientRect();
                var$3(e.clientX - rect.left, e.clientY - rect.top, 0);
            });
        }
    }
};
function otji_JSWrapper() {
    jl_Object.call(this);
    this.$js = null;
}
let otji_JSWrapper_hashCodes = null,
otji_JSWrapper_wrappers = null,
otji_JSWrapper_stringWrappers = null,
otji_JSWrapper_numberWrappers = null,
otji_JSWrapper_undefinedWrapper = null,
otji_JSWrapper_stringFinalizationRegistry = null,
otji_JSWrapper_numberFinalizationRegistry = null,
otji_JSWrapper_hashCodeGen = 0,
otji_JSWrapper_$callClinit = () => {
    otji_JSWrapper_$callClinit = $rt_eraseClinit(otji_JSWrapper);
    otji_JSWrapper__clinit_();
},
otji_JSWrapper__init_0 = ($this, var$1) => {
    otji_JSWrapper_$callClinit();
    jl_Object__init_($this);
    $this.$js = var$1;
},
otji_JSWrapper__init_ = var_0 => {
    let var_1 = new otji_JSWrapper();
    otji_JSWrapper__init_0(var_1, var_0);
    return var_1;
},
otji_JSWrapper_wrap = $o => {
    let $js, $type, $isObject, $existingRef, $existing, $wrapper, $jsString, $wrapperAsJs, $jsNumber;
    otji_JSWrapper_$callClinit();
    if ($o === null)
        return null;
    $js = $o;
    $type = $rt_str(typeof $js);
    $isObject = !$type.$equals($rt_s(38)) && !$type.$equals($rt_s(39)) ? 0 : 1;
    if ($isObject && $o[$rt_jso_marker] === true)
        return $o;
    if (otji_JSWrapper_wrappers !== null) {
        if ($isObject) {
            $existingRef = otji_JSWrapper_wrappers.get($js);
            $existing = (typeof $existingRef == 'undefined' ? 1 : 0) ? void 0 : $existingRef.deref();
            if (!(typeof $existing == 'undefined' ? 1 : 0))
                return $existing;
            $wrapper = otji_JSWrapper__init_($js);
            otji_JSWrapper_wrappers.set($js, new WeakRef($wrapper));
            return $wrapper;
        }
        if ($type.$equals($rt_s(40))) {
            $jsString = $js;
            $existingRef = otji_JSWrapper_stringWrappers.get($jsString);
            $existing = (typeof $existingRef == 'undefined' ? 1 : 0) ? void 0 : $existingRef.deref();
            if (!(typeof $existing == 'undefined' ? 1 : 0))
                return $existing;
            $wrapper = otji_JSWrapper__init_($js);
            $wrapperAsJs = $wrapper;
            otji_JSWrapper_stringWrappers.set($jsString, new WeakRef($wrapperAsJs));
            otji_JSWrapper_register$js_body$_4(otji_JSWrapper_stringFinalizationRegistry, $wrapperAsJs, $jsString);
            return $wrapper;
        }
        if ($type.$equals($rt_s(41))) {
            $jsNumber = $js;
            $existingRef = otji_JSWrapper_numberWrappers.get($jsNumber);
            $existing = (typeof $existingRef == 'undefined' ? 1 : 0) ? void 0 : $existingRef.deref();
            if (!(typeof $existing == 'undefined' ? 1 : 0))
                return $existing;
            $wrapper = otji_JSWrapper__init_($js);
            $wrapperAsJs = $wrapper;
            otji_JSWrapper_numberWrappers.set($jsNumber, new WeakRef($wrapperAsJs));
            otji_JSWrapper_register$js_body$_4(otji_JSWrapper_numberFinalizationRegistry, $wrapperAsJs, $jsNumber);
            return $wrapper;
        }
        if ($type.$equals($rt_s(42))) {
            $existingRef = otji_JSWrapper_undefinedWrapper;
            $existing = $existingRef === null ? void 0 : $existingRef.deref();
            if (!(typeof $existing == 'undefined' ? 1 : 0))
                return $existing;
            $wrapper = otji_JSWrapper__init_($js);
            $wrapperAsJs = $wrapper;
            otji_JSWrapper_undefinedWrapper = new WeakRef($wrapperAsJs);
            return $wrapper;
        }
    }
    return otji_JSWrapper__init_($js);
},
otji_JSWrapper_maybeWrap = $o => {
    otji_JSWrapper_$callClinit();
    if ($o !== null && !($o instanceof $rt_objcls()))
        $o = otji_JSWrapper_wrap($o);
    return $o;
},
otji_JSWrapper_unwrap = $o => {
    otji_JSWrapper_$callClinit();
    if ($o === null)
        return null;
    return $o[$rt_jso_marker] === true ? $o : $o.$js;
},
otji_JSWrapper_maybeUnwrap = $o => {
    otji_JSWrapper_$callClinit();
    if ($o === null)
        return null;
    return !($o instanceof $rt_objcls()) ? $o : otji_JSWrapper_unwrap($o);
},
otji_JSWrapper_jsToJava = $o => {
    otji_JSWrapper_$callClinit();
    if ($o === null)
        return null;
    return $o instanceof $rt_objcls() ? $o : otji_JSWrapper_wrap($o);
},
otji_JSWrapper_hashCode = $this => {
    let $type, $s, $hashCode, $i, $code, var$6;
    $type = $rt_str(typeof $this.$js);
    if (!$type.$equals($rt_s(38)) && !$type.$equals($rt_s(43)) && !$type.$equals($rt_s(39))) {
        if ($type.$equals($rt_s(41)))
            return otjc_JSNumber_intValue$static($this.$js);
        if ($type.$equals($rt_s(44)))
            return BigInt.asIntN($this.$js, 32);
        if (!$type.$equals($rt_s(40))) {
            if (!$type.$equals($rt_s(45)))
                return 0;
            return $this.$js !== !!1 ? 0 : 1;
        }
        $s = $this.$js;
        $hashCode = 0;
        $i = 0;
        while ($i < $s.length) {
            $hashCode = (31 * $hashCode | 0) + $s.charCodeAt($i) | 0;
            $i = $i + 1 | 0;
        }
        return $hashCode;
    }
    otji_JSWrapper_$callClinit();
    $code = otji_JSWrapper_maybeUnwrap(otji_JSWrapper_hashCodes.get($this.$js));
    if (typeof $code == 'undefined' ? 1 : 0) {
        var$6 = otji_JSWrapper_hashCodeGen + 1 | 0;
        otji_JSWrapper_hashCodeGen = var$6;
        $code = var$6;
        otji_JSWrapper_hashCodes.set($this.$js, $code);
    }
    return $code;
},
otji_JSWrapper_equals = ($this, $obj) => {
    if ($obj === $this)
        return 1;
    if ($obj === null)
        return 0;
    if (!($obj instanceof otji_JSWrapper))
        return 0;
    return $this.$js !== $obj.$js ? 0 : 1;
},
otji_JSWrapper_toString = $this => {
    return (typeof $this.$js == 'undefined' ? 1 : 0) ? $rt_s(42) : $rt_str($this.$js.toString());
},
otji_JSWrapper_lambda$static$1 = $token => {
    let var$2, var$3;
    otji_JSWrapper_$callClinit();
    var$2 = otji_JSWrapper_numberWrappers;
    var$3 = otji_JSWrapper_unwrap($token);
    var$2.delete(var$3);
},
otji_JSWrapper_lambda$static$0 = $token => {
    let var$2, var$3;
    otji_JSWrapper_$callClinit();
    var$2 = otji_JSWrapper_stringWrappers;
    var$3 = otji_JSWrapper_unwrap($token);
    var$2.delete(var$3);
},
otji_JSWrapper__clinit_ = () => {
    let var$1, var$2;
    otji_JSWrapper_hashCodes = new WeakMap();
    var$1 = !(typeof WeakRef !== 'undefined' ? 1 : 0) ? null : new WeakMap();
    otji_JSWrapper_wrappers = var$1;
    var$1 = !(typeof WeakRef !== 'undefined' ? 1 : 0) ? null : new Map();
    otji_JSWrapper_stringWrappers = var$1;
    var$1 = !(typeof WeakRef !== 'undefined' ? 1 : 0) ? null : new Map();
    otji_JSWrapper_numberWrappers = var$1;
    if (otji_JSWrapper_stringWrappers === null)
        var$1 = null;
    else {
        var$2 = otji_JSWrapper$_clinit_$lambda$_33_0__init_0();
        var$1 = new FinalizationRegistry(otji_JS_function(var$2, "accept"));
    }
    otji_JSWrapper_stringFinalizationRegistry = var$1;
    if (otji_JSWrapper_numberWrappers === null)
        var$1 = null;
    else {
        var$2 = otji_JSWrapper$_clinit_$lambda$_33_1__init_0();
        var$1 = new FinalizationRegistry(otji_JS_function(var$2, "accept"));
    }
    otji_JSWrapper_numberFinalizationRegistry = var$1;
},
otji_JSWrapper_register$js_body$_4 = (var$1, var$2, var$3) => {
    return var$1.register(var$2, var$3);
},
otp_Platform = $rt_classWithoutFields(),
otp_Platform_clone = var$1 => {
    let copy = new var$1.constructor();
    for (let field in var$1) {
        if (var$1.hasOwnProperty(field)) {
            copy[field] = var$1[field];
        }
    }
    return copy;
},
otp_Platform_isInstance = (var$1, var$2) => {
    return var$1 !== null && !(typeof var$1.constructor.$meta === 'undefined' ? 1 : 0) && otp_Platform_isAssignable(var$1.constructor, var$2) ? 1 : 0;
},
otp_Platform_isAssignable = ($from, $to) => {
    let $supertypes, $i;
    if ($from === $to)
        return 1;
    $supertypes = $from.$meta.supertypes;
    $i = 0;
    while ($i < $supertypes.length) {
        if (otp_Platform_isAssignable($supertypes[$i], $to))
            return 1;
        $i = $i + 1 | 0;
    }
    return 0;
},
otp_Platform_launchThread = $runnable => {
    $runnable.$run();
},
otp_Platform_postpone = $runnable => {
    otp_Platform_schedule($runnable, 0);
},
otp_Platform_schedule = (var$1, var$2) => {
    setTimeout(() => {
        otp_Platform_launchThread(var$1);
    }, var$2);
},
otp_Platform_createQueue = () => {
    return otp_Platform_createQueueJs$js_body$_30();
},
otp_Platform_isPrimitive = $cls => {
    return $cls.$meta.primitive ? 1 : 0;
},
otp_Platform_getArrayItem = $cls => {
    return $cls.$meta.item;
},
otp_Platform_getName = $cls => {
    return $rt_str($cls.$meta.name);
},
otp_Platform_createQueueJs$js_body$_30 = () => {
    return [];
};
function jl_Boolean() {
    jl_Object.call(this);
    this.$value2 = 0;
}
let jl_Boolean_TRUE = null,
jl_Boolean_FALSE = null,
jl_Boolean_TYPE = null,
jl_Boolean_$callClinit = () => {
    jl_Boolean_$callClinit = $rt_eraseClinit(jl_Boolean);
    jl_Boolean__clinit_();
},
jl_Boolean__init_0 = ($this, $value) => {
    jl_Boolean_$callClinit();
    jl_Object__init_($this);
    $this.$value2 = $value;
},
jl_Boolean__init_ = var_0 => {
    let var_1 = new jl_Boolean();
    jl_Boolean__init_0(var_1, var_0);
    return var_1;
},
jl_Boolean_compareTo = ($this, $other) => {
    return jl_Boolean_compare($this.$value2, $other.$value2);
},
jl_Boolean_compare = ($x, $y) => {
    jl_Boolean_$callClinit();
    return $x == $y ? 0 : !$x ? (-1) : 1;
},
jl_Boolean_booleanValue = $this => {
    return $this.$value2;
},
jl_Boolean_toString = $value => {
    jl_Boolean_$callClinit();
    return !$value ? $rt_s(46) : $rt_s(47);
},
jl_Boolean_toString0 = $this => {
    return jl_Boolean_toString($this.$value2);
},
jl_Boolean_hashCode = $this => {
    return jl_Boolean_hashCode0($this.$value2);
},
jl_Boolean_hashCode0 = $value => {
    jl_Boolean_$callClinit();
    return !$value ? 1237 : 1231;
},
jl_Boolean_equals = ($this, $obj) => {
    if ($this === $obj)
        return 1;
    return $obj instanceof jl_Boolean && $obj.$value2 == $this.$value2 ? 1 : 0;
},
jl_Boolean_compareTo0 = ($this, var$1) => {
    return $this.$compareTo3(var$1);
},
jl_Boolean__clinit_ = () => {
    jl_Boolean_TRUE = jl_Boolean__init_(1);
    jl_Boolean_FALSE = jl_Boolean__init_(0);
    jl_Boolean_TYPE = $rt_cls($rt_booleancls);
},
rceh_InterruptController$processInterrupts$lambda$_9_0 = $rt_classWithoutFields(),
rceh_InterruptController$processInterrupts$lambda$_9_0__init_ = var$0 => {
    jl_Object__init_(var$0);
},
rceh_InterruptController$processInterrupts$lambda$_9_0__init_0 = () => {
    let var_0 = new rceh_InterruptController$processInterrupts$lambda$_9_0();
    rceh_InterruptController$processInterrupts$lambda$_9_0__init_(var_0);
    return var_0;
},
rceh_InterruptController$processInterrupts$lambda$_9_0_applyAsInt0 = (var$0, var$1) => {
    return rceh_InterruptController$processInterrupts$lambda$_9_0_applyAsInt(var$0, var$1);
},
rceh_InterruptController$processInterrupts$lambda$_9_0_applyAsInt = (var$0, var$1) => {
    return rceh_InterruptController_lambda$processInterrupts$0(var$1);
},
otji_JSWrapper$_clinit_$lambda$_33_1 = $rt_classWithoutFields(),
otji_JSWrapper$_clinit_$lambda$_33_1__init_ = var$0 => {
    jl_Object__init_(var$0);
},
otji_JSWrapper$_clinit_$lambda$_33_1__init_0 = () => {
    let var_0 = new otji_JSWrapper$_clinit_$lambda$_33_1();
    otji_JSWrapper$_clinit_$lambda$_33_1__init_(var_0);
    return var_0;
},
otji_JSWrapper$_clinit_$lambda$_33_1_accept = (var$0, var$1) => {
    otji_JSWrapper_lambda$static$1(var$1);
},
otji_JSWrapper$_clinit_$lambda$_33_1_accept$exported$0 = (var$0, var$1) => {
    var$0.$accept(otji_JSWrapper_jsToJava(var$1));
},
ju_NoSuchElementException = $rt_classWithoutFields(jl_RuntimeException),
ju_NoSuchElementException__init_ = $this => {
    jl_RuntimeException__init_($this);
},
ju_NoSuchElementException__init_0 = () => {
    let var_0 = new ju_NoSuchElementException();
    ju_NoSuchElementException__init_(var_0);
    return var_0;
},
jt_DecimalFormat$Constants = $rt_classWithoutFields(),
jt_DecimalFormat$Constants_doubleAnalysisResult = null,
jt_DecimalFormat$Constants_floatAnalysisResult = null,
jt_DecimalFormat$Constants_$callClinit = () => {
    jt_DecimalFormat$Constants_$callClinit = $rt_eraseClinit(jt_DecimalFormat$Constants);
    jt_DecimalFormat$Constants__clinit_();
},
jt_DecimalFormat$Constants__clinit_ = () => {
    jt_DecimalFormat$Constants_doubleAnalysisResult = otcit_DoubleAnalyzer$Result__init_();
    jt_DecimalFormat$Constants_floatAnalysisResult = otcit_FloatAnalyzer$Result__init_0();
},
oti_AsyncCallback = $rt_classWithoutFields(0),
jl_IllegalArgumentException = $rt_classWithoutFields(jl_RuntimeException),
jl_IllegalArgumentException__init_1 = $this => {
    jl_RuntimeException__init_($this);
},
jl_IllegalArgumentException__init_0 = () => {
    let var_0 = new jl_IllegalArgumentException();
    jl_IllegalArgumentException__init_1(var_0);
    return var_0;
},
jl_IllegalArgumentException__init_ = ($this, $message) => {
    jl_RuntimeException__init_0($this, $message);
},
jl_IllegalArgumentException__init_2 = var_0 => {
    let var_1 = new jl_IllegalArgumentException();
    jl_IllegalArgumentException__init_(var_1, var_0);
    return var_1;
},
ju_IllegalFormatException = $rt_classWithoutFields(jl_IllegalArgumentException),
ju_IllegalFormatException__init_ = ($this, $s) => {
    jl_IllegalArgumentException__init_($this, $s);
},
ju_IllegalFormatException__init_0 = var_0 => {
    let var_1 = new ju_IllegalFormatException();
    ju_IllegalFormatException__init_(var_1, var_0);
    return var_1;
};
function ju_UnknownFormatConversionException() {
    ju_IllegalFormatException.call(this);
    this.$conversion1 = null;
}
let ju_UnknownFormatConversionException__init_0 = ($this, $conversion) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$2, $rt_s(48)), $conversion);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$conversion1 = $conversion;
},
ju_UnknownFormatConversionException__init_ = var_0 => {
    let var_1 = new ju_UnknownFormatConversionException();
    ju_UnknownFormatConversionException__init_0(var_1, var_0);
    return var_1;
};
function jt_NumberFormat() {
    let a = this; jt_Format.call(a);
    a.$groupingUsed = 0;
    a.$parseIntegerOnly = 0;
    a.$maximumIntegerDigits = 0;
    a.$minimumIntegerDigits = 0;
    a.$maximumFractionDigits = 0;
    a.$minimumFractionDigits = 0;
    a.$roundingMode = null;
    a.$currency = null;
}
let jt_NumberFormat__init_ = $this => {
    jt_Format__init_($this);
    $this.$groupingUsed = 1;
    $this.$maximumIntegerDigits = 40;
    $this.$minimumIntegerDigits = 1;
    $this.$maximumFractionDigits = 3;
    jm_RoundingMode_$callClinit();
    $this.$roundingMode = jm_RoundingMode_HALF_EVEN;
    $this.$currency = ju_Currency_getInstance(ju_Locale_getDefault());
},
jt_NumberFormat_getCurrency = $this => {
    return $this.$currency;
},
jt_NumberFormat_equals = ($this, $object) => {
    let $obj;
    if ($object === $this)
        return 1;
    if (!($object instanceof jt_NumberFormat))
        return 0;
    $obj = $object;
    return $this.$groupingUsed == $obj.$groupingUsed && $this.$parseIntegerOnly == $obj.$parseIntegerOnly && $this.$maximumFractionDigits == $obj.$maximumFractionDigits && $this.$maximumIntegerDigits == $obj.$maximumIntegerDigits && $this.$minimumFractionDigits == $obj.$minimumFractionDigits && $this.$minimumIntegerDigits == $obj.$minimumIntegerDigits && $this.$roundingMode === $obj.$roundingMode && $this.$currency === $obj.$currency ? 1 : 0;
},
jt_NumberFormat_format = ($this, $object, $buffer, $field) => {
    let var$4, $dv, $lv;
    if (!($object instanceof jl_Number))
        $rt_throw(jl_IllegalArgumentException__init_0());
    var$4 = $object;
    $dv = var$4.$doubleValue();
    $lv = var$4.$longValue();
    if ($dv !== Long_toNumber($lv))
        return $this.$format0($dv, $buffer, $field);
    return $this.$format1($lv, $buffer, $field);
},
jt_NumberFormat_getMaximumFractionDigits = $this => {
    return $this.$maximumFractionDigits;
},
jt_NumberFormat_getMaximumIntegerDigits = $this => {
    return $this.$maximumIntegerDigits;
},
jt_NumberFormat_getMinimumFractionDigits = $this => {
    return $this.$minimumFractionDigits;
},
jt_NumberFormat_getMinimumIntegerDigits = $this => {
    return $this.$minimumIntegerDigits;
},
jt_NumberFormat_getNumberInstance = $locale => {
    let $pattern;
    $pattern = otciu_CLDRHelper_resolveNumberFormat(ju_Locale_getLanguage($locale), ju_Locale_getCountry($locale));
    return jt_DecimalFormat__init_2($pattern, jt_DecimalFormatSymbols__init_($locale));
},
jt_NumberFormat_hashCode = $this => {
    let var$1, var$2;
    var$1 = (((((!$this.$groupingUsed ? 1237 : 1231) + (!$this.$parseIntegerOnly ? 1237 : 1231) | 0) + $this.$maximumFractionDigits | 0) + $this.$maximumIntegerDigits | 0) + $this.$minimumFractionDigits | 0) + $this.$minimumIntegerDigits | 0;
    var$2 = $this.$roundingMode;
    var$1 = (var$1 + jl_Enum_hashCode(var$2) | 0) + ju_Objects_hashCode($this.$currency) | 0;
    return var$1;
},
jt_NumberFormat_isGroupingUsed = $this => {
    return $this.$groupingUsed;
},
jt_NumberFormat_setGroupingUsed = ($this, $value) => {
    $this.$groupingUsed = $value;
},
jt_NumberFormat_setMaximumFractionDigits = ($this, $value) => {
    if ($value < 0)
        $value = 0;
    $this.$maximumFractionDigits = $value;
    if ($this.$maximumFractionDigits < $this.$minimumFractionDigits)
        $this.$minimumFractionDigits = $this.$maximumFractionDigits;
},
jt_NumberFormat_setMaximumIntegerDigits = ($this, $value) => {
    if ($value < 0)
        $value = 0;
    $this.$maximumIntegerDigits = $value;
    if ($this.$maximumIntegerDigits < $this.$minimumIntegerDigits)
        $this.$minimumIntegerDigits = $this.$maximumIntegerDigits;
},
jt_NumberFormat_setMinimumFractionDigits = ($this, $value) => {
    if ($value < 0)
        $value = 0;
    $this.$minimumFractionDigits = $value;
    if ($this.$maximumFractionDigits < $this.$minimumFractionDigits)
        $this.$maximumFractionDigits = $this.$minimumFractionDigits;
},
jt_NumberFormat_setMinimumIntegerDigits = ($this, $value) => {
    if ($value < 0)
        $value = 0;
    $this.$minimumIntegerDigits = $value;
    if ($this.$maximumIntegerDigits < $this.$minimumIntegerDigits)
        $this.$maximumIntegerDigits = $this.$minimumIntegerDigits;
},
jt_NumberFormat_getRoundingMode = $this => {
    return $this.$roundingMode;
};
function jt_DecimalFormat() {
    let a = this; jt_NumberFormat.call(a);
    a.$symbols = null;
    a.$positivePrefix = null;
    a.$negativePrefix = null;
    a.$positiveSuffix = null;
    a.$negativeSuffix = null;
    a.$multiplier = 0;
    a.$groupingSize = 0;
    a.$decimalSeparatorAlwaysShown = 0;
    a.$parseBigDecimal = 0;
    a.$exponentDigits = 0;
    a.$pattern = null;
}
let jt_DecimalFormat_POW10_ARRAY = null,
jt_DecimalFormat_POW10_INT_ARRAY = null,
jt_DecimalFormat_$callClinit = () => {
    jt_DecimalFormat_$callClinit = $rt_eraseClinit(jt_DecimalFormat);
    jt_DecimalFormat__clinit_();
},
jt_DecimalFormat__init_1 = $this => {
    jt_DecimalFormat_$callClinit();
    jt_DecimalFormat__init_0($this, otciu_CLDRHelper_resolveNumberFormat(ju_Locale_getLanguage(ju_Locale_getDefault()), ju_Locale_getCountry(ju_Locale_getDefault())));
},
jt_DecimalFormat__init_3 = () => {
    let var_0 = new jt_DecimalFormat();
    jt_DecimalFormat__init_1(var_0);
    return var_0;
},
jt_DecimalFormat__init_0 = ($this, $pattern) => {
    jt_DecimalFormat_$callClinit();
    jt_DecimalFormat__init_($this, $pattern, jt_DecimalFormatSymbols__init_2());
},
jt_DecimalFormat__init_4 = var_0 => {
    let var_1 = new jt_DecimalFormat();
    jt_DecimalFormat__init_0(var_1, var_0);
    return var_1;
},
jt_DecimalFormat__init_ = ($this, $pattern, $value) => {
    let var$3;
    jt_DecimalFormat_$callClinit();
    jt_NumberFormat__init_($this);
    $this.$positivePrefix = $rt_createArray(jt_DecimalFormat$FormatField, 0);
    var$3 = $rt_createArray(jt_DecimalFormat$FormatField, 1);
    var$3.data[0] = jt_DecimalFormat$TextField__init_($rt_s(49));
    $this.$negativePrefix = var$3;
    $this.$positiveSuffix = $rt_createArray(jt_DecimalFormat$FormatField, 0);
    $this.$negativeSuffix = $rt_createArray(jt_DecimalFormat$FormatField, 0);
    $this.$multiplier = 1;
    $this.$symbols = $value.$clone0();
    $this.$applyPattern($pattern);
},
jt_DecimalFormat__init_2 = (var_0, var_1) => {
    let var_2 = new jt_DecimalFormat();
    jt_DecimalFormat__init_(var_2, var_0, var_1);
    return var_2;
},
jt_DecimalFormat_applyPattern = ($this, $pattern) => {
    let $parser;
    $parser = jt_DecimalFormatParser__init_0();
    $parser.$parse($pattern);
    $parser.$apply($this);
    $this.$pattern = $pattern;
},
jt_DecimalFormat_setDecimalFormatSymbols = ($this, $symbols) => {
    $this.$symbols = $symbols.$clone0();
},
jt_DecimalFormat_fieldsToText = ($this, $fields, $buffer) => {
    let var$3, var$4, var$5, $field;
    var$3 = $fields.data;
    var$4 = var$3.length;
    var$5 = 0;
    while (var$5 < var$4) {
        $field = var$3[var$5];
        $field.$render($this, $buffer);
        var$5 = var$5 + 1 | 0;
    }
    return $buffer;
},
jt_DecimalFormat_textToFields = ($this, $text) => {
    let var$2;
    var$2 = $rt_createArray(jt_DecimalFormat$FormatField, 1);
    var$2.data[0] = jt_DecimalFormat$TextField__init_($text);
    return var$2;
},
jt_DecimalFormat_setPositivePrefix = ($this, $newValue) => {
    $this.$positivePrefix = jt_DecimalFormat_textToFields($this, $newValue);
},
jt_DecimalFormat_setNegativePrefix = ($this, $newValue) => {
    $this.$negativePrefix = jt_DecimalFormat_textToFields($this, $newValue);
},
jt_DecimalFormat_setNegativeSuffix = ($this, $newValue) => {
    $this.$negativeSuffix = jt_DecimalFormat_textToFields($this, $newValue);
},
jt_DecimalFormat_setMultiplier = ($this, $newValue) => {
    $this.$multiplier = $newValue;
},
jt_DecimalFormat_getGroupingSize = $this => {
    return $this.$groupingSize;
},
jt_DecimalFormat_setGroupingSize = ($this, $newValue) => {
    $this.$groupingSize = $newValue;
},
jt_DecimalFormat_isDecimalSeparatorAlwaysShown = $this => {
    return $this.$decimalSeparatorAlwaysShown;
},
jt_DecimalFormat_setDecimalSeparatorAlwaysShown = ($this, $newValue) => {
    $this.$decimalSeparatorAlwaysShown = $newValue;
},
jt_DecimalFormat_equals = ($this, $obj) => {
    let $other, var$3, var$4, var$5;
    if ($obj === $this)
        return 1;
    if (!($obj instanceof jt_DecimalFormat))
        return 0;
    $other = $obj;
    if (!jt_NumberFormat_equals($this, $obj))
        return 0;
    a: {
        b: {
            if (!ju_Arrays_equals($this.$positivePrefix, $other.$positivePrefix))
                break b;
            var$3 = $this.$positiveSuffix;
            var$4 = $other.$positiveSuffix;
            if (!ju_Arrays_equals(var$3, var$4))
                break b;
            var$3 = $this.$negativePrefix;
            var$4 = $other.$negativePrefix;
            if (!ju_Arrays_equals(var$3, var$4))
                break b;
            var$3 = $this.$negativeSuffix;
            var$4 = $other.$negativeSuffix;
            if (!ju_Arrays_equals(var$3, var$4))
                break b;
            if ($this.$multiplier != $other.$multiplier)
                break b;
            if ($this.$groupingSize != $other.$groupingSize)
                break b;
            if ($this.$decimalSeparatorAlwaysShown != $other.$decimalSeparatorAlwaysShown)
                break b;
            if ($this.$parseBigDecimal != $other.$parseBigDecimal)
                break b;
            if ($this.$exponentDigits == $other.$exponentDigits) {
                var$5 = 1;
                break a;
            }
        }
        var$5 = 0;
    }
    return var$5;
},
jt_DecimalFormat_hashCode = $this => {
    let $result, var$2;
    $result = jt_NumberFormat_hashCode($this);
    var$2 = ($result * 31 | 0) + ju_Arrays_hashCode($this.$positivePrefix) | 0;
    var$2 = (var$2 * 31 | 0) + ju_Arrays_hashCode($this.$positiveSuffix) | 0;
    var$2 = (var$2 * 31 | 0) + ju_Arrays_hashCode($this.$negativePrefix) | 0;
    var$2 = (var$2 * 31 | 0) + ju_Arrays_hashCode($this.$negativeSuffix) | 0;
    var$2 = (var$2 * 31 | 0) + $this.$multiplier | 0;
    var$2 = (var$2 * 31 | 0) + $this.$groupingSize | 0;
    var$2 = (var$2 * 31 | 0) + (!$this.$decimalSeparatorAlwaysShown ? 0 : 1) | 0;
    var$2 = (var$2 * 31 | 0) + (!$this.$parseBigDecimal ? 0 : 1) | 0;
    var$2 = (var$2 * 31 | 0) + $this.$exponentDigits | 0;
    return var$2;
},
jt_DecimalFormat_format3 = ($this, $object, $buffer, $field) => {
    if ($object instanceof jm_BigDecimal)
        return jt_DecimalFormat_format($this, $object, $buffer, $field);
    if (!($object instanceof jm_BigInteger))
        return jt_NumberFormat_format($this, $object, $buffer, $field);
    return jt_DecimalFormat_format0($this, $object, $buffer, $field);
},
jt_DecimalFormat_format0 = ($this, $value, $buffer, $field) => {
    return jt_DecimalFormat_format($this, jm_BigDecimal__init_6($value), $buffer, $field);
},
jt_DecimalFormat_format = ($this, $value, $buffer, $field) => {
    if ($this.$exponentDigits <= 0)
        jt_DecimalFormat_formatRegular($this, $value, $buffer);
    else
        jt_DecimalFormat_formatExponent($this, $value, $buffer);
    return $buffer;
},
jt_DecimalFormat_format2 = ($this, $value, $buffer, $field) => {
    if ($this.$exponentDigits <= 0)
        jt_DecimalFormat_formatRegular1($this, $value, $buffer);
    else
        jt_DecimalFormat_formatExponent1($this, $value, $buffer);
    return $buffer;
},
jt_DecimalFormat_format1 = ($this, $value, $buffer, $field) => {
    let $analysisResult, var$5, var$6;
    if (isNaN($value) ? 1 : 0) {
        (jt_DecimalFormat_fieldsToText($this, $this.$positivePrefix, $buffer)).$append5($this.$symbols.$getNaN());
        jt_DecimalFormat_appendSuffix($this, 1, $buffer);
    } else if (!(!isFinite($value) ? 1 : 0)) {
        jt_DecimalFormat$Constants_$callClinit();
        $analysisResult = jt_DecimalFormat$Constants_doubleAnalysisResult;
        otcit_DoubleAnalyzer_analyze($value, $analysisResult);
        if ($this.$exponentDigits <= 0)
            jt_DecimalFormat_formatRegular0($this, $analysisResult.$mantissa, $analysisResult.$exponent, $analysisResult.$sign0 ? 0 : 1, $buffer);
        else
            jt_DecimalFormat_formatExponent0($this, $analysisResult.$mantissa, $analysisResult.$exponent, $analysisResult.$sign0 ? 0 : 1, $buffer);
    } else {
        var$5 = $rt_compare($value, 0.0);
        var$6 = var$5 <= 0 ? $this.$negativePrefix : $this.$positivePrefix;
        (jt_DecimalFormat_fieldsToText($this, var$6, $buffer)).$append5($this.$symbols.$getInfinity());
        jt_DecimalFormat_appendSuffix($this, var$5 <= 0 ? 0 : 1, $buffer);
    }
    return $buffer;
},
jt_DecimalFormat_formatExponent1 = ($this, $value, $buffer) => {
    let $absValue, $exponent;
    $absValue = jl_Math_abs0($value);
    $exponent = jt_DecimalFormat_fastLn10($this, $absValue);
    jt_DecimalFormat_formatExponent0($this, $absValue, $exponent, Long_lt($value, Long_ZERO) ? 0 : 1, $buffer);
},
jt_DecimalFormat_formatRegular1 = ($this, $value, $buffer) => {
    let $absValue, $exponent;
    $absValue = jl_Math_abs0($value);
    $exponent = jt_DecimalFormat_fastLn10($this, $absValue);
    jt_DecimalFormat_formatRegular0($this, $absValue, $exponent, Long_lt($value, Long_ZERO) ? 0 : 1, $buffer);
},
jt_DecimalFormat_formatExponent0 = ($this, $mantissa, $exponent, $sign, $buffer) => {
    let $visibleExponent, $mantissaLength, $multiplierDigits, $tenMultiplier, $significantSize, $exponentMultiplier, $delta, var$12, var$13, $newMantissaLength, $exponentPos, $i, $mantissaDigitMask, var$18, $requiredSize, $limit, $count, $exponentLength, $exponentDigit;
    $visibleExponent = jt_DecimalFormat_fastLn10($this, $mantissa);
    $mantissaLength = $visibleExponent + 1 | 0;
    if ($this.$multiplier != 1) {
        $multiplierDigits = jt_DecimalFormat_fastLn100($this, $this.$multiplier);
        $tenMultiplier = jt_DecimalFormat_POW10_INT_ARRAY.data[$multiplierDigits];
        if ($tenMultiplier == $this.$multiplier)
            $exponent = $exponent + $multiplierDigits | 0;
        else {
            if (Long_ge($mantissa, Long_div(Long_create(4294967295, 2147483647), Long_fromInt($this.$multiplier)))) {
                jt_DecimalFormat_formatExponent($this, jm_BigDecimal__init_1(jm_BigInteger_valueOf($mantissa), $visibleExponent - $exponent | 0), $buffer);
                return;
            }
            $mantissa = Long_mul($mantissa, Long_fromInt($this.$multiplier));
            $visibleExponent = jt_DecimalFormat_fastLn10($this, $mantissa);
            $mantissaLength = $visibleExponent + 1 | 0;
        }
    }
    $significantSize = $this.$getMinimumIntegerDigits() + $this.$getMaximumFractionDigits() | 0;
    $exponentMultiplier = ($this.$getMaximumIntegerDigits() - $this.$getMinimumIntegerDigits() | 0) + 1 | 0;
    if ($exponentMultiplier > 1) {
        $delta = $exponent - $rt_imul($exponent / $exponentMultiplier | 0, $exponentMultiplier) | 0;
        var$12 = $exponent - $delta | 0;
        var$13 = $visibleExponent - $delta | 0;
    } else {
        var$12 = $exponent - ($this.$getMinimumIntegerDigits() - 1 | 0) | 0;
        var$13 = $visibleExponent - ($this.$getMinimumIntegerDigits() - 1 | 0) | 0;
    }
    if ($significantSize < 0)
        $mantissa = Long_ZERO;
    else if ($significantSize < $mantissaLength) {
        $mantissa = jt_DecimalFormat_applyRounding0($this, $mantissa, $mantissaLength, $significantSize, $sign);
        $newMantissaLength = jt_DecimalFormat_fastLn10($this, $mantissa) + 1 | 0;
        if ($newMantissaLength > $mantissaLength) {
            var$12 = var$12 + 1 | 0;
            var$13 = var$13 + 1 | 0;
            $mantissaLength = $newMantissaLength;
        }
    }
    jt_DecimalFormat_fieldsToText($this, !$sign ? $this.$negativePrefix : $this.$positivePrefix, $buffer);
    $exponentPos = jl_Math_max(var$13, 0);
    $i = $mantissaLength - 1 | 0;
    while ($i >= $exponentPos) {
        $mantissaDigitMask = jt_DecimalFormat_POW10_ARRAY.data[$i];
        $buffer.$append4(jt_DecimalFormat_forDigit($this, Long_lo(Long_div($mantissa, $mantissaDigitMask))));
        $mantissa = Long_rem($mantissa, $mantissaDigitMask);
        $i = $i + (-1) | 0;
    }
    $i = $exponentPos - 1 | 0;
    while ($i >= var$13) {
        $buffer.$append4(48);
        $i = $i + (-1) | 0;
    }
    a: {
        var$18 = $significantSize - ($mantissaLength - var$13 | 0) | 0;
        $requiredSize = var$18 - ($this.$getMaximumFractionDigits() - $this.$getMinimumFractionDigits() | 0) | 0;
        if ($requiredSize <= 0) {
            if (Long_eq($mantissa, Long_ZERO))
                break a;
            if (var$18 <= 0)
                break a;
        }
        $buffer.$append4($this.$symbols.$getDecimalSeparator());
        $limit = jl_Math_max(0, var$13 - var$18 | 0);
        $count = 0;
        $i = var$13 - 1 | 0;
        b: {
            while ($i >= $limit) {
                $mantissaDigitMask = jt_DecimalFormat_POW10_ARRAY.data[$i];
                $buffer.$append4(jt_DecimalFormat_forDigit($this, Long_lo(Long_div($mantissa, $mantissaDigitMask))));
                $mantissa = Long_rem($mantissa, $mantissaDigitMask);
                $count = $count + 1 | 0;
                if (Long_eq($mantissa, Long_ZERO))
                    break b;
                $i = $i + (-1) | 0;
            }
        }
        while (true) {
            var$18 = $count + 1 | 0;
            if ($count >= $requiredSize)
                break a;
            $buffer.$append4(48);
            $count = var$18;
        }
    }
    $buffer.$append5($this.$symbols.$getExponentSeparator());
    if (var$12 < 0) {
        var$12 =  -var$12 | 0;
        $buffer.$append4($this.$symbols.$getMinusSign());
    }
    $exponentLength = jl_Math_max($this.$exponentDigits, jt_DecimalFormat_fastLn100($this, var$12) + 1 | 0);
    $i = $exponentLength - 1 | 0;
    while ($i >= 0) {
        $exponentDigit = jt_DecimalFormat_POW10_INT_ARRAY.data[$i];
        $buffer.$append4(jt_DecimalFormat_forDigit($this, var$12 / $exponentDigit | 0));
        var$12 = var$12 % $exponentDigit | 0;
        $i = $i + (-1) | 0;
    }
    jt_DecimalFormat_appendSuffix($this, $sign, $buffer);
},
jt_DecimalFormat_formatRegular0 = ($this, $mantissa, $exponent, $sign, $buffer) => {
    let $mantissaLength, var$6, $multiplierDigits, $tenMultiplier, $roundingPos, $newMantissaLength, $intLength, $digitPos, $i, $significantIntDigits, $mantissaDigit, var$16, var$17, $mantissaDigitMask, var$19, $fracZeros, $i_0, $significantFracDigits;
    $mantissaLength = jt_DecimalFormat_fastLn10($this, $mantissa) + 1 | 0;
    var$6 = $exponent + 1 | 0;
    if ($this.$multiplier != 1) {
        $multiplierDigits = jt_DecimalFormat_fastLn100($this, $this.$multiplier);
        $tenMultiplier = jt_DecimalFormat_POW10_INT_ARRAY.data[$multiplierDigits];
        if ($tenMultiplier == $this.$multiplier)
            var$6 = var$6 + $multiplierDigits | 0;
        else {
            if (Long_ge($mantissa, Long_div(Long_create(4294967295, 2147483647), Long_fromInt($this.$multiplier)))) {
                jt_DecimalFormat_formatRegular($this, jm_BigDecimal__init_1(jm_BigInteger_valueOf($mantissa), $mantissaLength - var$6 | 0), $buffer);
                return;
            }
            $mantissa = Long_mul($mantissa, Long_fromInt($this.$multiplier));
            $mantissaLength = jt_DecimalFormat_fastLn10($this, $mantissa) + 1 | 0;
        }
    }
    $roundingPos = var$6 + $this.$getMaximumFractionDigits() | 0;
    if ($roundingPos < 0)
        $mantissa = Long_ZERO;
    else if ($roundingPos < $mantissaLength) {
        $mantissa = jt_DecimalFormat_applyRounding0($this, $mantissa, $mantissaLength, $roundingPos, $sign);
        $newMantissaLength = jt_DecimalFormat_fastLn10($this, $mantissa) + 1 | 0;
        if ($newMantissaLength > $mantissaLength) {
            var$6 = var$6 + 1 | 0;
            $mantissaLength = $newMantissaLength;
        }
    }
    jt_DecimalFormat_fieldsToText($this, !$sign ? $this.$negativePrefix : $this.$positivePrefix, $buffer);
    $intLength = jl_Math_max(0, var$6);
    $digitPos = jl_Math_max($intLength, $this.$getMinimumIntegerDigits()) - 1 | 0;
    $i = $this.$getMinimumIntegerDigits() - 1 | 0;
    while ($i >= $intLength) {
        $buffer.$append4(48);
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $i = $i + (-1) | 0;
    }
    $significantIntDigits = jl_Math_min($mantissaLength, $intLength);
    $mantissaDigit = $mantissaLength - 1 | 0;
    $i = 0;
    while ($i < $significantIntDigits) {
        var$16 = jt_DecimalFormat_POW10_ARRAY.data;
        var$17 = $mantissaDigit + (-1) | 0;
        $mantissaDigitMask = var$16[$mantissaDigit];
        $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(Long_lo(Long_div($mantissa, $mantissaDigitMask)))));
        $mantissa = Long_rem($mantissa, $mantissaDigitMask);
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $i = $i + 1 | 0;
        $mantissaDigit = var$17;
    }
    var$19 = $intLength - $significantIntDigits | 0;
    $i = 0;
    while ($i < var$19) {
        $buffer.$append4(48);
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $i = $i + 1 | 0;
    }
    a: {
        if (Long_eq($mantissa, Long_ZERO)) {
            if ($this.$getMinimumFractionDigits()) {
                $buffer.$append4($this.$symbols.$getDecimalSeparator());
                $i = 0;
                while ($i < $this.$getMinimumFractionDigits()) {
                    $buffer.$append4(48);
                    $i = $i + 1 | 0;
                }
            } else if ($this.$isDecimalSeparatorAlwaysShown())
                $buffer.$append4($this.$symbols.$getDecimalSeparator());
        } else {
            $buffer.$append4($this.$symbols.$getDecimalSeparator());
            $fracZeros = jl_Math_min($this.$getMaximumFractionDigits(), jl_Math_max(0,  -var$6 | 0));
            $i_0 = 0;
            $i = 0;
            while ($i < $fracZeros) {
                $i_0 = $i_0 + 1 | 0;
                $buffer.$append4(48);
                $i = $i + 1 | 0;
            }
            $significantFracDigits = jl_Math_min($this.$getMaximumFractionDigits() - $i_0 | 0, $mantissaDigit);
            $i = 0;
            b: {
                while (true) {
                    if ($i >= $significantFracDigits)
                        break b;
                    if (Long_eq($mantissa, Long_ZERO))
                        break;
                    $i_0 = $i_0 + 1 | 0;
                    $mantissaDigitMask = jt_DecimalFormat_POW10_ARRAY.data[$mantissaDigit];
                    $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(Long_lo(Long_div($mantissa, $mantissaDigitMask)))));
                    $mantissa = Long_rem($mantissa, $mantissaDigitMask);
                    $mantissaDigit = $mantissaDigit + (-1) | 0;
                    $i = $i + 1 | 0;
                }
            }
            while (true) {
                if ($i_0 >= $this.$getMinimumFractionDigits())
                    break a;
                $buffer.$append4(48);
                $i_0 = $i_0 + 1 | 0;
            }
        }
    }
    jt_DecimalFormat_appendSuffix($this, $sign, $buffer);
},
jt_DecimalFormat_formatExponent = ($this, $value, $buffer) => {
    let $positive, $mantissaLength, $i, $exponent, $mantissa, $significantSize, $exponentMultiplier, $delta, var$11, var$12, $exponentPos, $mantissaDigitMask, $parts, var$16, var$17, $requiredSize, $limit, $count, var$21, $exponentLength, $exponentDigit;
    if ($this.$multiplier != 1)
        $value = $value.$multiply1(jm_BigDecimal_valueOf(Long_fromInt($this.$multiplier)));
    jm_BigDecimal_$callClinit();
    $positive = $value.$compareTo4(jm_BigDecimal_ZERO) < 0 ? 0 : 1;
    $mantissaLength = $value.$precision();
    $i = $mantissaLength - 1 | 0;
    $exponent = $i - $value.$scale() | 0;
    $mantissa = $value.$unscaledValue();
    $significantSize = $this.$getMinimumIntegerDigits() + $this.$getMaximumFractionDigits() | 0;
    $exponentMultiplier = ($this.$getMaximumIntegerDigits() - $this.$getMinimumIntegerDigits() | 0) + 1 | 0;
    if ($exponentMultiplier > 1) {
        $delta = $exponent - $rt_imul($exponent / $exponentMultiplier | 0, $exponentMultiplier) | 0;
        var$11 = $exponent - $delta | 0;
        var$12 = $i - $delta | 0;
    } else {
        var$11 = $exponent - ($this.$getMinimumIntegerDigits() - 1 | 0) | 0;
        var$12 = $i - ($this.$getMinimumIntegerDigits() - 1 | 0) | 0;
    }
    if ($significantSize < 0) {
        jm_BigInteger_$callClinit();
        $mantissa = jm_BigInteger_ZERO;
    } else if ($significantSize < $mantissaLength)
        $mantissa = jt_DecimalFormat_applyRounding($this, $mantissa, $mantissaLength, $significantSize);
    jt_DecimalFormat_fieldsToText($this, !$positive ? $this.$negativePrefix : $this.$positivePrefix, $buffer);
    $exponentPos = jl_Math_max(var$12, 0);
    jm_BigInteger_$callClinit();
    $mantissaDigitMask = jt_DecimalFormat_pow10($this, jm_BigInteger_ONE, $i);
    while ($i >= $exponentPos) {
        $parts = $mantissa.$divideAndRemainder($mantissaDigitMask);
        var$16 = $parts.data;
        $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(var$16[0].$intValue())));
        $mantissa = var$16[1];
        $mantissaDigitMask = $mantissaDigitMask.$divide0(jm_BigInteger_TEN);
        $i = $i + (-1) | 0;
    }
    $i = $exponentPos - 1 | 0;
    while ($i >= var$12) {
        $buffer.$append4(48);
        $i = $i + (-1) | 0;
    }
    a: {
        var$17 = $significantSize - ($mantissaLength - var$12 | 0) | 0;
        $requiredSize = var$17 - ($this.$getMaximumFractionDigits() - $this.$getMinimumFractionDigits() | 0) | 0;
        if ($requiredSize <= 0) {
            if ($mantissa.$equals(jm_BigInteger_ZERO))
                break a;
            if (var$17 <= 0)
                break a;
        }
        $buffer.$append4($this.$symbols.$getDecimalSeparator());
        $limit = jl_Math_max(0, var$12 - var$17 | 0);
        $count = 0;
        $i = var$12 - 1 | 0;
        b: {
            while ($i >= $limit) {
                $parts = $mantissa.$divideAndRemainder($mantissaDigitMask);
                var$16 = $parts.data;
                $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(var$16[0].$intValue())));
                $mantissa = var$16[1];
                $count = $count + 1 | 0;
                if ($mantissa.$equals(jm_BigInteger_ZERO))
                    break b;
                $mantissaDigitMask = $mantissaDigitMask.$divide0(jm_BigInteger_TEN);
                $i = $i + (-1) | 0;
            }
        }
        while (true) {
            var$21 = $count + 1 | 0;
            if ($count >= $requiredSize)
                break a;
            $buffer.$append4(48);
            $count = var$21;
        }
    }
    $buffer.$append5($this.$symbols.$getExponentSeparator());
    if (var$11 < 0) {
        var$11 =  -var$11 | 0;
        $buffer.$append4($this.$symbols.$getMinusSign());
    }
    $exponentLength = jl_Math_max($this.$exponentDigits, jt_DecimalFormat_fastLn100($this, var$11) + 1 | 0);
    $i = $exponentLength - 1 | 0;
    while ($i >= 0) {
        $exponentDigit = jt_DecimalFormat_POW10_INT_ARRAY.data[$i];
        $buffer.$append4(jt_DecimalFormat_forDigit($this, var$11 / $exponentDigit | 0));
        var$11 = var$11 % $exponentDigit | 0;
        $i = $i + (-1) | 0;
    }
    jt_DecimalFormat_appendSuffix($this, $positive, $buffer);
},
jt_DecimalFormat_appendSuffix = ($this, $positive, $buffer) => {
    if (!$positive)
        jt_DecimalFormat_fieldsToText($this, $this.$negativeSuffix !== null ? $this.$negativeSuffix : $this.$positiveSuffix !== null ? $this.$positiveSuffix : $rt_createArray(jt_DecimalFormat$FormatField, 0), $buffer);
    else if ($this.$positiveSuffix !== null)
        jt_DecimalFormat_fieldsToText($this, $this.$positiveSuffix, $buffer);
},
jt_DecimalFormat_formatRegular = ($this, $value, $buffer) => {
    let $mantissa, $positive, $mantissaLength, $exponent, $roundingPos, $intLength, $digitPos, $i, $significantIntDigits, $mantissaDigitMask, $parts, var$14, var$15, $fracZeros, $i_0, $significantFracDigits;
    if ($this.$multiplier != 1)
        $value = $value.$multiply1(jm_BigDecimal_valueOf(Long_fromInt($this.$multiplier)));
    $mantissa = $value.$unscaledValue();
    jm_BigInteger_$callClinit();
    $positive = $mantissa.$compareTo0(jm_BigInteger_ZERO) < 0 ? 0 : 1;
    $mantissaLength = $value.$precision();
    $exponent = $value.$precision() - $value.$scale() | 0;
    $roundingPos = $exponent + $this.$getMaximumFractionDigits() | 0;
    if ($roundingPos < 0)
        $mantissa = jm_BigInteger_ZERO;
    else if ($roundingPos < $mantissaLength)
        $mantissa = jt_DecimalFormat_applyRounding($this, $mantissa, $mantissaLength, $roundingPos);
    jt_DecimalFormat_fieldsToText($this, !$positive ? $this.$negativePrefix : $this.$positivePrefix, $buffer);
    $intLength = jl_Math_max(0, $exponent);
    $digitPos = jl_Math_max($intLength, $this.$getMinimumIntegerDigits()) - 1 | 0;
    $i = $this.$getMinimumIntegerDigits() - 1 | 0;
    while ($i >= $intLength) {
        $buffer.$append4(48);
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $i = $i + (-1) | 0;
    }
    $significantIntDigits = jl_Math_min($mantissaLength, $intLength);
    $mantissaDigitMask = jt_DecimalFormat_pow10($this, jm_BigInteger_ONE, $mantissaLength - 1 | 0);
    $i = 0;
    while ($i < $significantIntDigits) {
        $parts = $mantissa.$divideAndRemainder($mantissaDigitMask);
        var$14 = $parts.data;
        $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(var$14[0].$intValue())));
        $mantissa = var$14[1];
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $mantissaLength = $mantissaLength + (-1) | 0;
        $mantissaDigitMask = $mantissaDigitMask.$divide0(jm_BigInteger_TEN);
        $i = $i + 1 | 0;
    }
    var$15 = $intLength - $significantIntDigits | 0;
    $i = 0;
    while ($i < var$15) {
        $buffer.$append4(48);
        if ($this.$isGroupingUsed() && $this.$groupingSize > 0 && !($digitPos % $this.$groupingSize | 0) && $digitPos > 0)
            $buffer.$append4($this.$symbols.$getGroupingSeparator());
        $digitPos = $digitPos + (-1) | 0;
        $i = $i + 1 | 0;
    }
    a: {
        if ($mantissa.$equals(jm_BigInteger_ZERO)) {
            if ($this.$getMinimumFractionDigits()) {
                $buffer.$append4($this.$symbols.$getDecimalSeparator());
                $i = 0;
                while ($i < $this.$getMinimumFractionDigits()) {
                    $buffer.$append4(48);
                    $i = $i + 1 | 0;
                }
            } else if ($this.$isDecimalSeparatorAlwaysShown())
                $buffer.$append4($this.$symbols.$getDecimalSeparator());
        } else {
            $buffer.$append4($this.$symbols.$getDecimalSeparator());
            $fracZeros = jl_Math_min($this.$getMaximumFractionDigits(), jl_Math_max(0,  -$exponent | 0));
            $i_0 = 0;
            $i = 0;
            while ($i < $fracZeros) {
                $i_0 = $i_0 + 1 | 0;
                $buffer.$append4(48);
                $i = $i + 1 | 0;
            }
            $significantFracDigits = jl_Math_min($this.$getMaximumFractionDigits() - $i_0 | 0, $mantissaLength);
            $i = 0;
            b: {
                while (true) {
                    if ($i >= $significantFracDigits)
                        break b;
                    if ($mantissa.$equals(jm_BigInteger_ZERO))
                        break;
                    $i_0 = $i_0 + 1 | 0;
                    $parts = $mantissa.$divideAndRemainder($mantissaDigitMask);
                    var$14 = $parts.data;
                    $buffer.$append4(jt_DecimalFormat_forDigit($this, jl_Math_abs(var$14[0].$intValue())));
                    $mantissa = var$14[1];
                    $mantissaDigitMask = $mantissaDigitMask.$divide0(jm_BigInteger_TEN);
                    $i = $i + 1 | 0;
                }
            }
            while (true) {
                if ($i_0 >= $this.$getMinimumFractionDigits())
                    break a;
                $buffer.$append4(48);
                $i_0 = $i_0 + 1 | 0;
            }
        }
    }
    jt_DecimalFormat_appendSuffix($this, $positive, $buffer);
},
jt_DecimalFormat_applyRounding0 = ($this, $mantissa, $mantissaLength, $exponent, $sign) => {
    let $rounding, var$6, var$7;
    a: {
        jt_DecimalFormat_$callClinit();
        $rounding = jt_DecimalFormat_POW10_ARRAY.data[$mantissaLength - $exponent | 0];
        jt_DecimalFormat$1_$callClinit();
        switch (jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal($this.$getRoundingMode())]) {
            case 1:
                $mantissa = Long_mul(Long_div($mantissa, $rounding), $rounding);
                if (!$sign)
                    break a;
                $mantissa = Long_add($mantissa, $rounding);
                break a;
            case 2:
                $mantissa = Long_mul(Long_div($mantissa, $rounding), $rounding);
                if ($sign)
                    break a;
                $mantissa = Long_add($mantissa, $rounding);
                break a;
            case 3:
                $mantissa = Long_add(Long_mul(Long_div($mantissa, $rounding), $rounding), $rounding);
                break a;
            case 4:
                $mantissa = Long_mul(Long_div($mantissa, $rounding), $rounding);
                break a;
            case 5:
                if (Long_eq(Long_rem($mantissa, $rounding), Long_ZERO))
                    break a;
                $rt_throw(jl_ArithmeticException__init_($rt_s(50)));
            case 6:
                var$6 = Long_rem($mantissa, $rounding);
                var$7 = Long_div($rounding, Long_fromInt(2));
                if (Long_eq(var$6, var$7)) {
                    $mantissa = Long_mul(Long_div($mantissa, $rounding), $rounding);
                    break a;
                }
                $mantissa = Long_mul(Long_div(Long_add($mantissa, var$7), $rounding), $rounding);
                break a;
            case 7:
                var$7 = Long_rem($mantissa, $rounding);
                var$6 = Long_div($rounding, Long_fromInt(2));
                if (Long_ne(var$7, var$6)) {
                    $mantissa = Long_mul(Long_div(Long_add($mantissa, var$6), $rounding), $rounding);
                    break a;
                }
                $mantissa = Long_add(Long_mul(Long_div($mantissa, $rounding), $rounding), $rounding);
                break a;
            case 8:
                var$7 = Long_rem($mantissa, $rounding);
                var$6 = Long_div($rounding, Long_fromInt(2));
                if (Long_ne(var$7, var$6)) {
                    $mantissa = Long_mul(Long_div(Long_add($mantissa, var$6), $rounding), $rounding);
                    break a;
                }
                $mantissa = Long_mul(Long_div($mantissa, $rounding), $rounding);
                if (Long_eq(Long_rem(Long_div($mantissa, $rounding), Long_fromInt(2)), Long_ZERO))
                    break a;
                $mantissa = Long_add($mantissa, $rounding);
                break a;
            default:
        }
    }
    return $mantissa;
},
jt_DecimalFormat_applyRounding = ($this, $mantissa, $mantissaLength, $exponent) => {
    let $rounding, $signedRounding, var$6;
    jm_BigInteger_$callClinit();
    $rounding = jt_DecimalFormat_pow10($this, jm_BigInteger_ONE, $mantissaLength - $exponent | 0);
    $signedRounding = $mantissa.$compareTo0(jm_BigInteger_ZERO) < 0 ? $rounding.$negate() : $rounding;
    a: {
        jt_DecimalFormat$1_$callClinit();
        switch (jt_DecimalFormat$1_$SwitchMap$java$math$RoundingMode.data[jl_Enum_ordinal($this.$getRoundingMode())]) {
            case 1:
                $mantissa = ($mantissa.$divide0($rounding)).$multiply0($rounding);
                if ($mantissa.$compareTo0(jm_BigInteger_ZERO) < 0)
                    break a;
                $mantissa = $mantissa.$add1($rounding);
                break a;
            case 2:
                $mantissa = ($mantissa.$divide0($rounding)).$multiply0($rounding);
                if ($mantissa.$compareTo0(jm_BigInteger_ZERO) > 0)
                    break a;
                $mantissa = $mantissa.$subtract0($rounding);
                break a;
            case 3:
                $mantissa = (($mantissa.$divide0($rounding)).$multiply0($rounding)).$add1($signedRounding);
                break a;
            case 4:
                $mantissa = ($mantissa.$divide0($rounding)).$multiply0($rounding);
                break a;
            case 5:
                if (!($mantissa.$remainder($rounding)).$equals(jm_BigInteger_ZERO))
                    break a;
                $rt_throw(jl_ArithmeticException__init_($rt_s(50)));
            case 6:
                if (($mantissa.$remainder($rounding)).$equals($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))))) {
                    $mantissa = ($mantissa.$divide0($rounding)).$multiply0($rounding);
                    break a;
                }
                var$6 = $mantissa.$add1($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))));
                $mantissa = (var$6.$divide0($rounding)).$multiply0($rounding);
                break a;
            case 7:
                if (($mantissa.$remainder($rounding)).$equals($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))))) {
                    $mantissa = (($mantissa.$divide0($rounding)).$multiply0($rounding)).$add1($signedRounding);
                    break a;
                }
                var$6 = $mantissa.$add1($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))));
                $mantissa = (var$6.$divide0($rounding)).$multiply0($rounding);
                break a;
            case 8:
                if (!($mantissa.$remainder($rounding)).$equals($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))))) {
                    var$6 = $mantissa.$add1($signedRounding.$divide0(jm_BigInteger_valueOf(Long_fromInt(2))));
                    $mantissa = (var$6.$divide0($rounding)).$multiply0($rounding);
                    break a;
                }
                $mantissa = ($mantissa.$divide0($rounding)).$multiply0($rounding);
                if ((($mantissa.$divide0($rounding)).$remainder(jm_BigInteger_valueOf(Long_fromInt(2)))).$equals(jm_BigInteger_ZERO))
                    break a;
                $mantissa = $mantissa.$add1($signedRounding);
                break a;
            default:
        }
    }
    return $mantissa;
},
jt_DecimalFormat_fastLn10 = ($this, $value) => {
    let $result;
    if (Long_eq($value, Long_create(0, 2147483648)))
        return 18;
    $result = 0;
    if (Long_ge($value, Long_create(1874919424, 2328306))) {
        $result = 16;
        $value = Long_div($value, Long_create(1874919424, 2328306));
    }
    if (Long_ge($value, Long_fromInt(100000000))) {
        $result = $result + 8 | 0;
        $value = Long_div($value, Long_fromInt(100000000));
    }
    if (Long_ge($value, Long_fromInt(10000))) {
        $result = $result + 4 | 0;
        $value = Long_div($value, Long_fromInt(10000));
    }
    if (Long_ge($value, Long_fromInt(100))) {
        $result = $result + 2 | 0;
        $value = Long_div($value, Long_fromInt(100));
    }
    if (Long_ge($value, Long_fromInt(10)))
        $result = $result + 1 | 0;
    return $result;
},
jt_DecimalFormat_fastLn100 = ($this, $value) => {
    let $result;
    $result = 0;
    if ($value >= 100000000) {
        $result = 8;
        $value = $value / 100000000 | 0;
    }
    if ($value >= 10000) {
        $result = $result + 4 | 0;
        $value = $value / 10000 | 0;
    }
    if ($value >= 100) {
        $result = $result + 2 | 0;
        $value = $value / 100 | 0;
    }
    if ($value >= 10)
        $result = $result + 1 | 0;
    return $result;
},
jt_DecimalFormat_pow10 = ($this, $value, $power) => {
    let $digit;
    jm_BigInteger_$callClinit();
    $digit = jm_BigInteger_TEN;
    while ($power) {
        if ($power & 1)
            $value = $value.$multiply0($digit);
        $digit = $digit.$multiply0($digit);
        $power = $power >>> 1 | 0;
    }
    return $value;
},
jt_DecimalFormat_forDigit = ($this, $n) => {
    return ($this.$symbols.$getZeroDigit() + $n | 0) & 65535;
},
jt_DecimalFormat__clinit_ = () => {
    jt_DecimalFormat_POW10_ARRAY = $rt_createLongArrayFromData([Long_fromInt(1), Long_fromInt(10), Long_fromInt(100), Long_fromInt(1000), Long_fromInt(10000), Long_fromInt(100000), Long_fromInt(1000000), Long_fromInt(10000000), Long_fromInt(100000000), Long_fromInt(1000000000), Long_create(1410065408, 2), Long_create(1215752192, 23), Long_create(3567587328, 232), Long_create(1316134912, 2328), Long_create(276447232, 23283), Long_create(2764472320, 232830), Long_create(1874919424, 2328306), Long_create(1569325056, 23283064),
    Long_create(2808348672, 232830643)]);
    jt_DecimalFormat_POW10_INT_ARRAY = $rt_createIntArrayFromData([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]);
},
jt_DecimalFormat$PerMillField = $rt_classWithoutFields(),
jt_DecimalFormat$PerMillField__init_ = $this => {
    jl_Object__init_($this);
},
jt_DecimalFormat$PerMillField__init_0 = () => {
    let var_0 = new jt_DecimalFormat$PerMillField();
    jt_DecimalFormat$PerMillField__init_(var_0);
    return var_0;
},
jt_DecimalFormat$PerMillField_render = ($this, $format, $buffer) => {
    $buffer.$append4($format.$symbols.$getPerMill());
},
jt_DecimalFormat$PerMillField_equals = ($this, $obj) => {
    return $obj instanceof jt_DecimalFormat$PerMillField;
},
jt_DecimalFormat$PerMillField_hashCode = $this => {
    return 2;
};
function ju_IllegalFormatConversionException() {
    let a = this; ju_IllegalFormatException.call(a);
    a.$conversion = 0;
    a.$argumentClass = null;
}
let ju_IllegalFormatConversionException__init_0 = ($this, $conversion, $argumentClass) => {
    let var$3;
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append1(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(var$3, $rt_s(51)), $argumentClass), $rt_s(52)), $conversion), $rt_s(53));
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$3));
    $this.$conversion = $conversion;
    $this.$argumentClass = $argumentClass;
},
ju_IllegalFormatConversionException__init_ = (var_0, var_1) => {
    let var_2 = new ju_IllegalFormatConversionException();
    ju_IllegalFormatConversionException__init_0(var_2, var_0, var_1);
    return var_2;
},
jt_DecimalFormat$PercentField = $rt_classWithoutFields(),
jt_DecimalFormat$PercentField__init_ = $this => {
    jl_Object__init_($this);
},
jt_DecimalFormat$PercentField__init_0 = () => {
    let var_0 = new jt_DecimalFormat$PercentField();
    jt_DecimalFormat$PercentField__init_(var_0);
    return var_0;
},
jt_DecimalFormat$PercentField_render = ($this, $format, $buffer) => {
    $buffer.$append4($format.$symbols.$getPercent());
},
jt_DecimalFormat$PercentField_equals = ($this, $obj) => {
    return $obj instanceof jt_DecimalFormat$PercentField;
},
jt_DecimalFormat$PercentField_hashCode = $this => {
    return 1;
},
rcek_Kaboom = $rt_classWithoutFields(),
rcek_Kaboom_init$js_body$_2 = (var$1, var$2, var$3, var$4) => {
    if (typeof kaboom === 'function') {
        return kaboom({ width : var$1, height : var$2, scale : var$3 || 1, background : var$4 || [15, 18, 26], canvas : document.getElementById('game-canvas') || undefined });
    }
    return null;
},
ju_AbstractMap = $rt_classWithoutFields(),
ju_AbstractMap__init_ = $this => {
    jl_Object__init_($this);
},
ju_AbstractMap_equals = ($this, $obj) => {
    let $other, $it, $entry, $$je;
    if ($this === $obj)
        return 1;
    if (!$rt_isInstance($obj, ju_Map))
        return 0;
    $other = $obj;
    if ($this.$size() != $other.$size())
        return 0;
    a: {
        try {
            $it = ($this.$entrySet()).$iterator();
        } catch ($$e) {
            $$je = $rt_wrapException($$e);
            if ($$je instanceof jl_ClassCastException) {
                break a;
            } else if ($$je instanceof jl_NullPointerException) {
                break a;
            } else {
                throw $$e;
            }
        }
        b: {
            c: {
                try {
                    while ($it.$hasNext()) {
                        $entry = $it.$next();
                        if (!$other.$containsKey($entry.$getKey()))
                            break b;
                        if (!ju_Objects_equals($entry.$getValue(), $other.$get($entry.$getKey())))
                            break c;
                    }
                } catch ($$e) {
                    $$je = $rt_wrapException($$e);
                    if ($$je instanceof jl_ClassCastException) {
                        break a;
                    } else if ($$je instanceof jl_NullPointerException) {
                        break a;
                    } else {
                        throw $$e;
                    }
                }
                return 1;
            }
            try {
            } catch ($$e) {
                $$je = $rt_wrapException($$e);
                if ($$je instanceof jl_ClassCastException) {
                    break a;
                } else if ($$je instanceof jl_NullPointerException) {
                    break a;
                } else {
                    throw $$e;
                }
            }
            return 0;
        }
        try {
        } catch ($$e) {
            $$je = $rt_wrapException($$e);
            if ($$je instanceof jl_ClassCastException) {
                break a;
            } else if ($$je instanceof jl_NullPointerException) {
                break a;
            } else {
                throw $$e;
            }
        }
        return 0;
    }
    return 0;
},
ju_AbstractMap_hashCode = $this => {
    let $result, $iter, $entry;
    $result = 0;
    $iter = ($this.$entrySet()).$iterator();
    while ($iter.$hasNext()) {
        $entry = $iter.$next();
        $result = $result + $entry.$hashCode0() | 0;
    }
    return $result;
},
ju_AbstractMap_toString = $this => {
    let $sb, $iter, $e;
    $sb = jl_StringBuilder__init_();
    $sb.$append0(123);
    $iter = ($this.$entrySet()).$iterator();
    if ($iter.$hasNext()) {
        $e = $iter.$next();
        $sb.$append($e.$getKey() !== $this ? $e.$getKey() : $rt_s(54));
        $sb.$append0(61);
        $sb.$append($e.$getValue() !== $this ? $e.$getValue() : $rt_s(54));
    }
    while ($iter.$hasNext()) {
        $sb.$append19($rt_s(18));
        $e = $iter.$next();
        $sb.$append($e.$getKey() !== $this ? $e.$getKey() : $rt_s(54));
        $sb.$append0(61);
        $sb.$append($e.$getValue() !== $this ? $e.$getValue() : $rt_s(54));
    }
    $sb.$append0(125);
    return $sb.$toString();
};
function rce_Game() {
    let a = this; jl_Object.call(a);
    a.$width1 = 0;
    a.$height0 = 0;
    a.$backgroundColor = null;
    a.$showGrid = 0;
    a.$objects = null;
    a.$toAdd = null;
    a.$toRemove = null;
    a.$gamepad = null;
    a.$interruptController = null;
    a.$dataBus = null;
    a.$gpioPorts = null;
    a.$keyDownHandlers = null;
    a.$keyUpHandlers = null;
    a.$clickHandlers = null;
    a.$timerTasks = null;
    a.$graphics = null;
    a.$lastTimestamp = 0.0;
    a.$running = 0;
}
let rce_Game_instance = null,
rce_Game__init_ = ($this, $width, $height) => {
    jl_Object__init_($this);
    $this.$width1 = 800;
    $this.$height0 = 600;
    rce_Color_$callClinit();
    $this.$backgroundColor = rce_Color_RETRO_BACKGROUND;
    $this.$showGrid = 1;
    $this.$objects = ju_ArrayList__init_();
    $this.$toAdd = ju_ArrayList__init_();
    $this.$toRemove = ju_ArrayList__init_();
    $this.$gamepad = rceh_VirtualGamepad__init_0();
    $this.$interruptController = rceh_InterruptController__init_0();
    $this.$dataBus = rceb_DataBus__init_0();
    $this.$gpioPorts = ju_HashMap__init_();
    $this.$keyDownHandlers = ju_HashMap__init_();
    $this.$keyUpHandlers = ju_HashMap__init_();
    $this.$clickHandlers = ju_ArrayList__init_();
    $this.$timerTasks = ju_ArrayList__init_();
    $this.$graphics = rce_Graphics__init_0();
    $this.$lastTimestamp = 0.0;
    $this.$running = 0;
    $this.$width1 = $width;
    $this.$height0 = $height;
    rce_Game_instance = $this;
    $this.$gpioPorts.$put($rt_s(55), rceh_GpioPort__init_0($rt_s(56)));
    $this.$gpioPorts.$put($rt_s(57), rceh_GpioPort__init_0($rt_s(58)));
},
rce_Game_add = ($this, $obj) => {
    if ($obj !== null)
        $this.$toAdd.$add0($obj);
},
rce_Game_setBackgroundColor = ($this, $color) => {
    if ($color === null) {
        rce_Color_$callClinit();
        $color = rce_Color_BLACK;
    }
    $this.$backgroundColor = $color;
},
rce_Game_isKeyPressed = ($this, $key) => {
    return $this.$gamepad.$isPressed($key);
},
rce_Game_step = ($this, $delta) => {
    let $i, $t, var$4, $obj, $a, $j, $b, $$je;
    if (!$this.$toAdd.$isEmpty()) {
        $this.$objects.$addAll($this.$toAdd);
        $this.$toAdd.$clear();
    }
    if (!$this.$toRemove.$isEmpty()) {
        $this.$objects.$removeAll($this.$toRemove);
        $this.$toRemove.$clear();
    }
    $i = $this.$timerTasks.$size() - 1 | 0;
    while ($i >= 0) {
        $t = $this.$timerTasks.$get0($i);
        $t.$elapsed = $t.$elapsed + $delta;
        if ($t.$elapsed >= $t.$interval) {
            $t.$elapsed = 0.0;
            $this.$interruptController.$trigger0(1);
            a: {
                try {
                    $t.$action.$run();
                    break a;
                } catch ($$e) {
                    $$je = $rt_wrapException($$e);
                    if ($$je instanceof jl_Throwable) {
                    } else {
                        throw $$e;
                    }
                }
            }
            if (!$t.$recurring)
                $this.$timerTasks.$remove($i);
        }
        $i = $i + (-1) | 0;
    }
    var$4 = $this.$objects.$iterator();
    while (var$4.$hasNext()) {
        $obj = var$4.$next();
        if ($obj.$active && !$obj.$isDestroyed())
            $obj.$update($delta);
    }
    $i = 0;
    while ($i < $this.$objects.$size()) {
        b: {
            $a = $this.$objects.$get0($i);
            if ($a.$active && !$a.$isDestroyed()) {
                $j = $i + 1 | 0;
                while (true) {
                    if ($j >= $this.$objects.$size())
                        break b;
                    $b = $this.$objects.$get0($j);
                    if ($b.$active && !$b.$isDestroyed() && $a.$collidesWith($b)) {
                        $this.$interruptController.$trigger(3, $a);
                        $a.$handleCollision($b);
                        $b.$handleCollision($a);
                    }
                    $j = $j + 1 | 0;
                }
            }
        }
        $i = $i + 1 | 0;
    }
    $this.$interruptController.$processInterrupts();
    $this.$update($delta);
    $this.$objects.$removeIf(rce_Game$step$lambda$_31_0__init_0());
},
rce_Game_renderFrame = $this => {
    let var$1, $obj;
    if (!rcei_JSBridge_isBrowser())
        return;
    rcei_JSBridge_clearCanvas$js_body$_5($rt_ustr($this.$backgroundColor.$toCssRgba()));
    if ($this.$showGrid)
        $this.$graphics.$drawGrid($this.$width1, $this.$height0, 40, rce_Color_GRID_LINE);
    var$1 = $this.$objects.$iterator();
    while (var$1.$hasNext()) {
        $obj = var$1.$next();
        if ($obj.$visible && !$obj.$isDestroyed())
            $obj.$draw($this.$graphics);
    }
    $this.$render0($this.$graphics);
},
rce_Game_onBrowserKeyDown = ($this, $keyStr, $codeStr) => {
    let $key, $handlers, var$5, $h, $$je;
    if ($codeStr !== null)
        $keyStr = $codeStr;
    a: {
        $key = rce_Key_fromCodeOrKey($keyStr);
        if ($key !== null) {
            $this.$gamepad.$onKeyDown($key);
            $this.$interruptController.$trigger(2, $key);
            $handlers = $this.$keyDownHandlers.$get($key);
            if ($handlers !== null) {
                var$5 = $handlers.$iterator();
                while (true) {
                    if (!var$5.$hasNext())
                        break a;
                    $h = var$5.$next();
                    b: {
                        try {
                            $h.$run();
                            break b;
                        } catch ($$e) {
                            $$je = $rt_wrapException($$e);
                            if ($$je instanceof jl_Throwable) {
                            } else {
                                throw $$e;
                            }
                        }
                    }
                }
            }
        }
    }
},
rce_Game_onBrowserKeyUp = ($this, $keyStr, $codeStr) => {
    let $key, $handlers, var$5, $h, $$je;
    if ($codeStr !== null)
        $keyStr = $codeStr;
    a: {
        $key = rce_Key_fromCodeOrKey($keyStr);
        if ($key !== null) {
            $this.$gamepad.$onKeyUp($key);
            $handlers = $this.$keyUpHandlers.$get($key);
            if ($handlers !== null) {
                var$5 = $handlers.$iterator();
                while (true) {
                    if (!var$5.$hasNext())
                        break a;
                    $h = var$5.$next();
                    b: {
                        try {
                            $h.$run();
                            break b;
                        } catch ($$e) {
                            $$je = $rt_wrapException($$e);
                            if ($$je instanceof jl_Throwable) {
                            } else {
                                throw $$e;
                            }
                        }
                    }
                }
            }
        }
    }
},
rce_Game_onBrowserClick = ($this, $x, $y, $btn) => {
    let var$4, $handler, $$je;
    var$4 = $this.$clickHandlers.$iterator();
    while (var$4.$hasNext()) {
        $handler = var$4.$next();
        a: {
            try {
                $handler.$accept0(jl_Double_valueOf($x), jl_Double_valueOf($y));
                break a;
            } catch ($$e) {
                $$je = $rt_wrapException($$e);
                if ($$je instanceof jl_Throwable) {
                } else {
                    throw $$e;
                }
            }
        }
    }
},
rce_Game_launch = $game => {
    let var$2, var$3, var$4, $loopCallback;
    if ($game === null)
        return;
    rce_Game_instance = $game;
    if (!rcei_JSBridge_isBrowser())
        $game.$init();
    else {
        console.log('[\u041a\u0421\u041a 09.02.01 Engine] ' + "Инициализация движка ru.college.engine (КСК 09.02.01)...");
        rcek_KaboomBridge_tryInit($game.$width1, $game.$height0);
        rcei_JSBridge_initCanvas$js_body$_4("game-canvas", $game.$width1, $game.$height0, $rt_ustr($game.$backgroundColor.$toCssRgba()));
        var$2 = rce_Game$launch$lambda$_36_0__init_0($game);
        var$3 = rce_Game$launch$lambda$_36_1__init_0($game);
        rcei_JSBridge_setupKeyboardListeners$js_body$_12(otji_JS_function(var$2, "onKey"), otji_JS_function(var$3, "onKey"));
        var$3 = rce_Game$launch$lambda$_36_2__init_0($game);
        var$4 = rce_Game$launch$lambda$_36_3__init_0();
        rcei_JSBridge_setupMouseListeners$js_body$_13("game-canvas", otji_JS_function(var$3, "onMouse"), otji_JS_function(var$4, "onMouse"));
        $game.$init();
        $game.$running = 1;
        $game.$lastTimestamp = Date.now();
        $loopCallback = rce_Game$1__init_0($game);
        rcei_JSBridge_requestAnimationFrame$js_body$_11(otji_JS_function($loopCallback, "onFrame"));
    }
},
rce_Game_lambda$launch$6 = ($x, $y, $btn) => {
    return;
},
rce_Game_lambda$launch$5 = ($game, $x, $y, $btn) => {
    rce_Game_onBrowserClick($game, $x, $y, $btn);
},
rce_Game_lambda$launch$4 = ($game, $key, $code) => {
    rce_Game_onBrowserKeyUp($game, $key, $code);
},
rce_Game_lambda$launch$3 = ($game, $key, $code) => {
    rce_Game_onBrowserKeyDown($game, $key, $code);
};
function rcg_MyGame() {
    let a = this; rce_Game.call(a);
    a.$player = null;
    a.$score = 0;
    a.$isGameOver = 0;
    a.$isWin = 0;
    a.$map = null;
}
let rcg_MyGame_COLOR_BG = null,
rcg_MyGame_COLOR_WALL = null,
rcg_MyGame_COLOR_FLOOR = null,
rcg_MyGame_COLOR_COIN = null,
rcg_MyGame_COLOR_TRAP = null,
rcg_MyGame_COLOR_EXIT = null,
rcg_MyGame_$callClinit = () => {
    rcg_MyGame_$callClinit = $rt_eraseClinit(rcg_MyGame);
    rcg_MyGame__clinit_();
},
rcg_MyGame__init_ = var$0 => {
    let var$1, var$2;
    rcg_MyGame_$callClinit();
    rce_Game__init_(var$0, 800, 600);
    var$0.$score = 0;
    var$0.$isGameOver = 0;
    var$0.$isWin = 0;
    var$1 = $rt_createArray($rt_arraycls($rt_intcls), 9);
    var$2 = var$1.data;
    var$2[0] = $rt_createIntArrayFromData([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]);
    var$2[1] = $rt_createIntArrayFromData([1, 0, 2, 0, 1, 2, 0, 0, 0, 1, 2, 0, 0, 2, 1]);
    var$2[2] = $rt_createIntArrayFromData([1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1]);
    var$2[3] = $rt_createIntArrayFromData([1, 2, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1]);
    var$2[4] = $rt_createIntArrayFromData([1, 0, 1, 1, 1, 3, 0, 1, 0, 1, 1, 3, 1, 0, 1]);
    var$2[5] = $rt_createIntArrayFromData([1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    var$2[6] = $rt_createIntArrayFromData([1, 1, 1, 0, 1, 2, 1, 1, 0, 1, 2, 1, 1, 0, 1]);
    var$2[7] = $rt_createIntArrayFromData([1, 2, 0, 0, 0, 0, 1, 4, 0, 0, 0, 0, 0, 2, 1]);
    var$2[8] = $rt_createIntArrayFromData([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]);
    var$0.$map = var$1;
},
rcg_MyGame__init_0 = () => {
    let var_0 = new rcg_MyGame();
    rcg_MyGame__init_(var_0);
    return var_0;
},
rcg_MyGame_init = var$0 => {
    rcg_MyGame_$callClinit();
    var$0.$setBackgroundColor(rcg_MyGame_COLOR_BG);
    var$0.$showGrid = 0;
    var$0.$player = rcg_Player__init_0(48.0, 48.0);
    var$0.$add2(var$0.$player);
},
rcg_MyGame_update = (var$0, var$1) => {
    let var$2, var$3;
    if (!var$0.$isGameOver && !var$0.$isWin) {
        var$2 = 0.0;
        var$3 = 0.0;
        rce_Key_$callClinit();
        if (var$0.$isKeyPressed(rce_Key_LEFT))
            var$2 = (-1.0);
        if (var$0.$isKeyPressed(rce_Key_RIGHT))
            var$2 = var$2 + 1.0;
        if (var$0.$isKeyPressed(rce_Key_UP))
            var$3 = (-1.0);
        if (var$0.$isKeyPressed(rce_Key_DOWN))
            var$3 = var$3 + 1.0;
        var$2 = var$0.$player.$x + var$2 * var$0.$player.$speed * var$1;
        var$1 = var$0.$player.$y + var$3 * var$0.$player.$speed * var$1;
        if (rcg_MyGame_canMoveTo(var$0, var$2, var$0.$player.$y))
            var$0.$player.$x = var$2;
        if (rcg_MyGame_canMoveTo(var$0, var$0.$player.$x, var$1))
            var$0.$player.$y = var$1;
        rcg_MyGame_checkTileInteraction(var$0);
        return;
    }
},
rcg_MyGame_canMoveTo = (var$0, var$1, var$2) => {
    let var$3, var$4, var$5, var$6;
    var$3 = var$1 / 40.0 | 0;
    var$4 = (var$1 + var$0.$player.$width0 - 1.0) / 40.0 | 0;
    var$5 = var$2 / 40.0 | 0;
    var$6 = (var$2 + var$0.$player.$height - 1.0) / 40.0 | 0;
    return rcg_MyGame_isWalkable(var$0, var$5, var$3) && rcg_MyGame_isWalkable(var$0, var$5, var$4) && rcg_MyGame_isWalkable(var$0, var$6, var$3) && rcg_MyGame_isWalkable(var$0, var$6, var$4) ? 1 : 0;
},
rcg_MyGame_isWalkable = (var$0, var$1, var$2) => {
    if (var$1 >= 0 && var$1 < var$0.$map.data.length && var$2 >= 0 && var$2 < var$0.$map.data[0].data.length)
        return var$0.$map.data[var$1].data[var$2] == 1 ? 0 : 1;
    return 0;
},
rcg_MyGame_checkTileInteraction = var$0 => {
    let var$1, var$2;
    var$1 = (var$0.$player.$x + var$0.$player.$width0 / 2.0) / 40.0 | 0;
    var$2 = (var$0.$player.$y + var$0.$player.$height / 2.0) / 40.0 | 0;
    if (var$2 >= 0 && var$2 < var$0.$map.data.length && var$1 >= 0 && var$1 < var$0.$map.data[0].data.length) {
        a: {
            b: {
                switch (var$0.$map.data[var$2].data[var$1]) {
                    case 2:
                        break b;
                    case 3:
                        var$0.$map.data[var$2].data[var$1] = 0;
                        var$0.$player.$takeDamage();
                        rce_Sound_playDamage();
                        if (var$0.$player.$lives > 0)
                            break a;
                        var$0.$isGameOver = 1;
                        rce_Sound_playGameOver();
                        break a;
                    case 4:
                        break;
                    default:
                        break a;
                }
                if (rcg_MyGame_countRemainingCoins(var$0))
                    break a;
                var$0.$isWin = 1;
                rce_Sound_playCoin();
                break a;
            }
            var$0.$map.data[var$2].data[var$1] = 0;
            var$0.$score = var$0.$score + 10 | 0;
            rce_Sound_playCoin();
        }
        return;
    }
},
rcg_MyGame_countRemainingCoins = var$0 => {
    let var$1, var$2, var$3;
    var$1 = 0;
    var$2 = 0;
    while (var$2 < var$0.$map.data.length) {
        var$3 = 0;
        while (var$3 < var$0.$map.data[var$2].data.length) {
            if (var$0.$map.data[var$2].data[var$3] == 2)
                var$1 = var$1 + 1 | 0;
            var$3 = var$3 + 1 | 0;
        }
        var$2 = var$2 + 1 | 0;
    }
    return var$1;
},
rcg_MyGame_render = (var$0, var$1) => {
    let var$2, var$3, var$4, var$5, var$6, var$7, var$8, var$9;
    var$2 = rcg_MyGame_countRemainingCoins(var$0);
    var$3 = 0;
    while (var$3 < var$0.$map.data.length) {
        var$4 = 0;
        while (var$4 < var$0.$map.data[var$3].data.length) {
            a: {
                var$5 = var$4 * 40 | 0;
                var$6 = var$3 * 40 | 0;
                var$7 = var$5;
                var$8 = var$6;
                var$1.$drawRect(var$7, var$8, 40.0, 40.0, rcg_MyGame_COLOR_FLOOR);
                switch (var$0.$map.data[var$3].data[var$4]) {
                    case 1:
                        var$1.$drawRect(var$7, var$8, 40.0, 40.0, rcg_MyGame_COLOR_WALL);
                        var$1.$drawRect(var$5 + 2 | 0, var$6 + 2 | 0, 36.0, 36.0, rce_Color__init_(90, 105, 120));
                        break a;
                    case 2:
                        break;
                    case 3:
                        var$1.$drawRect(var$5 + 10 | 0, var$6 + 10 | 0, 20.0, 20.0, rcg_MyGame_COLOR_TRAP);
                        break a;
                    case 4:
                        var$1.$drawRect(var$5 + 4 | 0, var$6 + 4 | 0, 32.0, 32.0, !var$2 ? rcg_MyGame_COLOR_EXIT : rce_Color__init_(100, 100, 100));
                        break a;
                    default:
                        break a;
                }
                var$1.$drawCircle(var$5 + 20 | 0, var$6 + 20 | 0, 8.0, rcg_MyGame_COLOR_COIN);
            }
            var$4 = var$4 + 1 | 0;
        }
        var$3 = var$3 + 1 | 0;
    }
    var$0.$player.$draw(var$1);
    var$1.$drawRect(620.0, 20.0, 160.0, 180.0, rce_Color__init_1(0, 0, 0, 0.6));
    var$1.$drawText($rt_s(59), 640.0, 50.0, 18, rce_Color_WHITE);
    var$3 = var$0.$score;
    var$9 = jl_StringBuilder__init_();
    jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(60)), var$3);
    var$1.$drawText(jl_StringBuilder_toString(var$9), 640.0, 85.0, 16, rcg_MyGame_COLOR_COIN);
    var$3 = var$0.$player.$lives;
    var$9 = jl_StringBuilder__init_();
    jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(61)), var$3);
    var$1.$drawText(jl_StringBuilder_toString(var$9), 640.0, 115.0, 16, rce_Color__init_(255, 100, 100));
    var$9 = jl_StringBuilder__init_();
    jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(62)), var$2);
    var$1.$drawText(jl_StringBuilder_toString(var$9), 640.0, 145.0, 16, rce_Color_WHITE);
    if (var$0.$isGameOver) {
        var$1.$drawRect(180.0, 220.0, 300.0, 100.0, rce_Color__init_1(0, 0, 0, 0.85));
        var$1.$drawText($rt_s(63), 210.0, 265.0, 24, rce_Color_RED);
        var$1.$drawText($rt_s(64), 235.0, 295.0, 16, rce_Color_WHITE);
    } else if (var$0.$isWin) {
        var$1.$drawRect(180.0, 220.0, 300.0, 100.0, rce_Color__init_1(0, 0, 0, 0.85));
        var$1.$drawText($rt_s(65), 265.0, 265.0, 24, rcg_MyGame_COLOR_EXIT);
        var$1.$drawText($rt_s(66), 205.0, 295.0, 16, rce_Color_WHITE);
    }
},
rcg_MyGame__clinit_ = () => {
    rcg_MyGame_COLOR_BG = rce_Color__init_(30, 39, 46);
    rcg_MyGame_COLOR_WALL = rce_Color__init_(72, 84, 96);
    rcg_MyGame_COLOR_FLOOR = rce_Color__init_(47, 53, 66);
    rcg_MyGame_COLOR_COIN = rce_Color__init_(255, 211, 42);
    rcg_MyGame_COLOR_TRAP = rce_Color__init_(235, 77, 75);
    rcg_MyGame_COLOR_EXIT = rce_Color__init_(46, 213, 115);
};
function ju_IllegalFormatCodePointException() {
    ju_IllegalFormatException.call(this);
    this.$codePoint = 0;
}
let ju_IllegalFormatCodePointException__init_ = ($this, $codePoint) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$2, $rt_s(67)), $codePoint), $rt_s(68));
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$codePoint = $codePoint;
},
ju_IllegalFormatCodePointException__init_0 = var_0 => {
    let var_1 = new ju_IllegalFormatCodePointException();
    ju_IllegalFormatCodePointException__init_(var_1, var_0);
    return var_1;
},
jlr_AnnotatedElement = $rt_classWithoutFields(0),
jlr_Type = $rt_classWithoutFields(0);
function jl_Class() {
    let a = this; jl_Object.call(a);
    a.$name1 = null;
    a.$platformClass = null;
}
let jl_Class__init_0 = ($this, $platformClass) => {
    let var$2;
    jl_Object__init_($this);
    $this.$platformClass = $platformClass;
    var$2 = $this;
    $platformClass.classObject = var$2;
},
jl_Class__init_ = var_0 => {
    let var_1 = new jl_Class();
    jl_Class__init_0(var_1, var_0);
    return var_1;
},
jl_Class_getClass = $cls => {
    let $result;
    if ($cls === null)
        return null;
    $result = $cls.classObject;
    if ($result === null)
        $result = jl_Class__init_($cls);
    return $result;
},
jl_Class_toString = $this => {
    let var$1, var$2, var$3;
    var$1 = $this.$isInterface() ? $rt_s(69) : !$this.$isPrimitive() ? $rt_s(70) : $rt_s(1);
    var$2 = $this.$getName();
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$3, var$1), var$2);
    return jl_StringBuilder_toString(var$3);
},
jl_Class_getPlatformClass = $this => {
    return $this.$platformClass;
},
jl_Class_isInstance = ($this, $obj) => {
    return otp_Platform_isInstance($obj, $this.$platformClass);
},
jl_Class_getName = $this => {
    if ($this.$name1 === null)
        $this.$name1 = otp_Platform_getName($this.$platformClass);
    return $this.$name1;
},
jl_Class_isPrimitive = $this => {
    return otp_Platform_isPrimitive($this.$platformClass);
},
jl_Class_isInterface = $this => {
    return !($this.$platformClass.$meta.flags & 2) ? 0 : 1;
},
jl_Class_getComponentType = $this => {
    return jl_Class_getClass(otp_Platform_getArrayItem($this.$platformClass));
},
jl_Class_getSuperclass = $this => {
    return jl_Class_getClass($this.$platformClass.$meta.superclass);
},
rceh_VirtualPin$InterruptTrigger = $rt_classWithoutFields(jl_Enum),
rceh_VirtualPin$InterruptTrigger_RISING = null,
rceh_VirtualPin$InterruptTrigger_FALLING = null,
rceh_VirtualPin$InterruptTrigger_CHANGE = null,
rceh_VirtualPin$InterruptTrigger_$VALUES = null,
rceh_VirtualPin$InterruptTrigger_$callClinit = () => {
    rceh_VirtualPin$InterruptTrigger_$callClinit = $rt_eraseClinit(rceh_VirtualPin$InterruptTrigger);
    rceh_VirtualPin$InterruptTrigger__clinit_();
},
rceh_VirtualPin$InterruptTrigger__init_0 = ($this, var$1, var$2) => {
    rceh_VirtualPin$InterruptTrigger_$callClinit();
    jl_Enum__init_($this, var$1, var$2);
},
rceh_VirtualPin$InterruptTrigger__init_ = (var_0, var_1) => {
    let var_2 = new rceh_VirtualPin$InterruptTrigger();
    rceh_VirtualPin$InterruptTrigger__init_0(var_2, var_0, var_1);
    return var_2;
},
rceh_VirtualPin$InterruptTrigger_$values = () => {
    let var$1, var$2;
    rceh_VirtualPin$InterruptTrigger_$callClinit();
    var$1 = $rt_createArray(rceh_VirtualPin$InterruptTrigger, 3);
    var$2 = var$1.data;
    var$2[0] = rceh_VirtualPin$InterruptTrigger_RISING;
    var$2[1] = rceh_VirtualPin$InterruptTrigger_FALLING;
    var$2[2] = rceh_VirtualPin$InterruptTrigger_CHANGE;
    return var$1;
},
rceh_VirtualPin$InterruptTrigger__clinit_ = () => {
    rceh_VirtualPin$InterruptTrigger_RISING = rceh_VirtualPin$InterruptTrigger__init_($rt_s(71), 0);
    rceh_VirtualPin$InterruptTrigger_FALLING = rceh_VirtualPin$InterruptTrigger__init_($rt_s(72), 1);
    rceh_VirtualPin$InterruptTrigger_CHANGE = rceh_VirtualPin$InterruptTrigger__init_($rt_s(73), 2);
    rceh_VirtualPin$InterruptTrigger_$VALUES = rceh_VirtualPin$InterruptTrigger_$values();
},
otji_JSWrapper$JSTransparentInt = $rt_classWithoutFields(),
jl_Float = $rt_classWithoutFields(jl_Number),
rceh_VirtualPin$Mode = $rt_classWithoutFields(jl_Enum),
rceh_VirtualPin$Mode_INPUT = null,
rceh_VirtualPin$Mode_OUTPUT = null,
rceh_VirtualPin$Mode_PWM = null,
rceh_VirtualPin$Mode_$VALUES = null,
rceh_VirtualPin$Mode_$callClinit = () => {
    rceh_VirtualPin$Mode_$callClinit = $rt_eraseClinit(rceh_VirtualPin$Mode);
    rceh_VirtualPin$Mode__clinit_();
},
rceh_VirtualPin$Mode__init_0 = ($this, var$1, var$2) => {
    rceh_VirtualPin$Mode_$callClinit();
    jl_Enum__init_($this, var$1, var$2);
},
rceh_VirtualPin$Mode__init_ = (var_0, var_1) => {
    let var_2 = new rceh_VirtualPin$Mode();
    rceh_VirtualPin$Mode__init_0(var_2, var_0, var_1);
    return var_2;
},
rceh_VirtualPin$Mode_$values = () => {
    let var$1, var$2;
    rceh_VirtualPin$Mode_$callClinit();
    var$1 = $rt_createArray(rceh_VirtualPin$Mode, 3);
    var$2 = var$1.data;
    var$2[0] = rceh_VirtualPin$Mode_INPUT;
    var$2[1] = rceh_VirtualPin$Mode_OUTPUT;
    var$2[2] = rceh_VirtualPin$Mode_PWM;
    return var$1;
},
rceh_VirtualPin$Mode__clinit_ = () => {
    rceh_VirtualPin$Mode_INPUT = rceh_VirtualPin$Mode__init_($rt_s(74), 0);
    rceh_VirtualPin$Mode_OUTPUT = rceh_VirtualPin$Mode__init_($rt_s(75), 1);
    rceh_VirtualPin$Mode_PWM = rceh_VirtualPin$Mode__init_($rt_s(76), 2);
    rceh_VirtualPin$Mode_$VALUES = rceh_VirtualPin$Mode_$values();
},
ju_Arrays = $rt_classWithoutFields(),
ju_Arrays_copyOf = ($array, $length) => {
    let var$3, $result, $sz, $i;
    var$3 = $array.data;
    $result = $rt_createCharArray($length);
    $sz = jl_Math_min($length, var$3.length);
    $i = 0;
    while ($i < $sz) {
        $result.data[$i] = var$3[$i];
        $i = $i + 1 | 0;
    }
    return $result;
},
ju_Arrays_copyOf0 = ($original, $newLength) => {
    let var$3, $result, $sz, $i;
    var$3 = $original.data;
    $result = jlr_Array_newInstance((jl_Object_getClass($original)).$getComponentType(), $newLength);
    $sz = jl_Math_min($newLength, var$3.length);
    $i = 0;
    while ($i < $sz) {
        $result.data[$i] = var$3[$i];
        $i = $i + 1 | 0;
    }
    return $result;
},
ju_Arrays_fill0 = ($a, $fromIndex, $toIndex, $val) => {
    let var$5, var$6;
    if ($fromIndex > $toIndex)
        $rt_throw(jl_IllegalArgumentException__init_0());
    while ($fromIndex < $toIndex) {
        var$5 = $a.data;
        var$6 = $fromIndex + 1 | 0;
        var$5[$fromIndex] = $val;
        $fromIndex = var$6;
    }
},
ju_Arrays_fill = ($a, $fromIndex, $toIndex, $val) => {
    let var$5, var$6;
    if ($fromIndex > $toIndex)
        $rt_throw(jl_IllegalArgumentException__init_0());
    while ($fromIndex < $toIndex) {
        var$5 = $a.data;
        var$6 = $fromIndex + 1 | 0;
        var$5[$fromIndex] = $val;
        $fromIndex = var$6;
    }
},
ju_Arrays_sort = ($a, $fromIndex, $toIndex, $c) => {
    let $subarray, $i, var$7, var$8;
    if ($fromIndex > $toIndex)
        $rt_throw(jl_IllegalArgumentException__init_0());
    if ($c === null)
        $c = ju_Comparator$NaturalOrder_instance();
    $subarray = $rt_createArray(jl_Object, $toIndex - $fromIndex | 0);
    $i = $fromIndex;
    while ($i < $toIndex) {
        var$7 = $subarray.data;
        var$8 = $a.data;
        var$7[$i - $fromIndex | 0] = var$8[$i];
        $i = $i + 1 | 0;
    }
    ju_Arrays_sort0($subarray, $c);
    $i = $fromIndex;
    while ($i < $toIndex) {
        $a.data[$i] = $subarray.data[$i - $fromIndex | 0];
        $i = $i + 1 | 0;
    }
},
ju_Arrays_sort0 = ($a, $c) => {
    let var$3, $second, $chunkSize, var$6, $i, var$8, var$9, $i_0, var$11, var$12;
    var$3 = $a.data.length;
    if (!var$3)
        return;
    if ($c === null)
        $c = ju_Comparator$NaturalOrder_instance();
    $second = $rt_createArray(jl_Object, var$3);
    $chunkSize = 1;
    var$6 = $a;
    while ($chunkSize < var$3) {
        $i = 0;
        while (true) {
            var$8 = var$6.data.length;
            if ($i >= var$8)
                break;
            var$9 = jl_Math_min(var$8, $i + $chunkSize | 0);
            $i_0 = $i + (2 * $chunkSize | 0) | 0;
            var$11 = jl_Math_min(var$8, $i_0);
            ju_Arrays_merge(var$6, $second, $i, var$9, var$11, $c);
            $i = $i_0;
        }
        $chunkSize = $chunkSize * 2 | 0;
        var$12 = var$6;
        var$6 = $second;
        $second = var$12;
    }
    a: {
        if (var$6 !== $a) {
            $i = 0;
            while (true) {
                var$12 = var$6.data;
                if ($i >= var$12.length)
                    break a;
                $second.data[$i] = var$12[$i];
                $i = $i + 1 | 0;
            }
        }
    }
},
ju_Arrays_merge = ($a, $b, $from, $split, $to, $comp) => {
    let var$7, $from2, var$9, $p, $q, var$12, var$13, var$14;
    var$7 = $from;
    $from2 = $split;
    a: {
        b: {
            while ($from != $split) {
                if ($from2 == $to)
                    break b;
                var$9 = $a.data;
                $p = var$9[$from];
                $q = var$9[$from2];
                if ($comp.$compare1($p, $q) > 0) {
                    var$9 = $b.data;
                    var$12 = var$7 + 1 | 0;
                    var$9[var$7] = $q;
                    $from2 = $from2 + 1 | 0;
                } else {
                    var$9 = $b.data;
                    var$12 = var$7 + 1 | 0;
                    var$9[var$7] = $p;
                    $from = $from + 1 | 0;
                }
                var$7 = var$12;
            }
            while (true) {
                if ($from2 >= $to)
                    break a;
                var$13 = $b.data;
                var$9 = $a.data;
                var$12 = var$7 + 1 | 0;
                var$14 = $from2 + 1 | 0;
                var$13[var$7] = var$9[$from2];
                var$7 = var$12;
                $from2 = var$14;
            }
        }
        while (true) {
            if ($from >= $split)
                break a;
            var$13 = $b.data;
            var$9 = $a.data;
            var$14 = var$7 + 1 | 0;
            var$12 = $from + 1 | 0;
            var$13[var$7] = var$9[$from];
            var$7 = var$14;
            $from = var$12;
        }
    }
},
ju_Arrays_binarySearch = ($a, $key) => {
    return ju_Arrays_binarySearch0($a, 0, $a.data.length, $key);
},
ju_Arrays_binarySearch0 = ($a, $fromIndex, $toIndex, $key) => {
    let $u, var$6, $i, $e, var$9;
    if ($fromIndex > $toIndex)
        $rt_throw(jl_IllegalArgumentException__init_0());
    $u = $toIndex - 1 | 0;
    while (true) {
        if ($fromIndex > $u)
            return ( -$fromIndex | 0) - 1 | 0;
        var$6 = $a.data;
        $i = ($fromIndex + $u | 0) / 2 | 0;
        $e = var$6[$i];
        var$9 = $rt_compare($e, $key);
        if (!var$9)
            break;
        if (var$9 <= 0)
            $fromIndex = $i + 1 | 0;
        else
            $u = $i - 1 | 0;
    }
    return $i;
},
ju_Arrays_mismatchImpl = ($a, $aStart, $a2, $a2Start, $length) => {
    let $i, var$7;
    $i = 0;
    while (true) {
        if ($i >= $length)
            return (-1);
        var$7 = $a2.data;
        if (!ju_Objects_equals($a.data[$i + $aStart | 0], var$7[$i + $a2Start | 0]))
            break;
        $i = $i + 1 | 0;
    }
    return $i;
},
ju_Arrays_equals = ($a, $a2) => {
    let var$3, var$4;
    if ($a === $a2)
        return 1;
    if ($a !== null && $a2 !== null) {
        var$3 = $a2.data;
        var$4 = $a.data.length;
        if (var$4 == var$3.length)
            return ju_Arrays_mismatchImpl($a, 0, $a2, 0, var$4) >= 0 ? 0 : 1;
    }
    return 0;
},
ju_Arrays_hashCode = $a => {
    let $hash, $i, var$4;
    if ($a === null)
        return 0;
    $hash = 1;
    $i = 0;
    while (true) {
        var$4 = $a.data;
        if ($i >= var$4.length)
            break;
        $hash = (31 * $hash | 0) + ju_Objects_hashCode(var$4[$i]) | 0;
        $i = $i + 1 | 0;
    }
    return $hash;
},
jl_System = $rt_classWithoutFields(),
jl_System_arraycopy = ($src, $srcPos, $dest, $destPos, $length) => {
    let var$6, $srcType, $targetType, $srcArray, $i, var$11, var$12, $elem;
    if ($src !== null && $dest !== null) {
        if ($srcPos >= 0 && $destPos >= 0 && $length >= 0 && ($srcPos + $length | 0) <= jlr_Array_getLength($src)) {
            var$6 = $destPos + $length | 0;
            if (var$6 <= jlr_Array_getLength($dest)) {
                a: {
                    b: {
                        if ($src !== $dest) {
                            $srcType = (jl_Object_getClass($src)).$getComponentType();
                            $targetType = (jl_Object_getClass($dest)).$getComponentType();
                            if ($srcType !== null && $targetType !== null) {
                                if ($srcType === $targetType)
                                    break b;
                                if (!$srcType.$isPrimitive() && !$targetType.$isPrimitive()) {
                                    $srcArray = $src;
                                    $i = 0;
                                    var$6 = $srcPos;
                                    while ($i < $length) {
                                        var$11 = $srcArray.data;
                                        var$12 = var$6 + 1 | 0;
                                        $elem = var$11[var$6];
                                        if (!$targetType.$isInstance0($elem)) {
                                            jl_System_doArrayCopy($src, $srcPos, $dest, $destPos, $i);
                                            $rt_throw(jl_ArrayStoreException__init_());
                                        }
                                        $i = $i + 1 | 0;
                                        var$6 = var$12;
                                    }
                                    jl_System_doArrayCopy($src, $srcPos, $dest, $destPos, $length);
                                    return;
                                }
                                if (!$srcType.$isPrimitive())
                                    break a;
                                if ($targetType.$isPrimitive())
                                    break b;
                                else
                                    break a;
                            }
                            $rt_throw(jl_ArrayStoreException__init_());
                        }
                    }
                    jl_System_doArrayCopy($src, $srcPos, $dest, $destPos, $length);
                    return;
                }
                $rt_throw(jl_ArrayStoreException__init_());
            }
        }
        $rt_throw(jl_IndexOutOfBoundsException__init_());
    }
    $rt_throw(jl_NullPointerException__init_1($rt_s(77)));
},
jl_System_fastArraycopy = ($src, $srcPos, $dest, $destPos, $length) => {
    let var$6;
    if ($srcPos >= 0 && $destPos >= 0 && $length >= 0 && ($srcPos + $length | 0) <= jlr_Array_getLength($src)) {
        var$6 = $destPos + $length | 0;
        if (var$6 <= jlr_Array_getLength($dest)) {
            jl_System_doArrayCopy($src, $srcPos, $dest, $destPos, $length);
            return;
        }
    }
    $rt_throw(jl_IndexOutOfBoundsException__init_());
},
jl_System_doArrayCopy = (var$1, var$2, var$3, var$4, var$5) => {
    if (var$5 !== 0) {
        if (typeof var$1.data.buffer !== 'undefined') {
            var$3.data.set(var$1.data.subarray(var$2, var$2 + var$5), var$4);
        } else if (var$1 !== var$3 || var$4 < var$2) {
            for (let i = 0;i < var$5;i = i + 1 | 0) {
                var$3.data[var$4++] = var$1.data[var$2++];
            }
        } else {
            var$2 = var$2 + var$5 | 0;
            var$4 = var$4 + var$5 | 0;
            for (let i = 0;i < var$5;i = i + 1 | 0) {
                var$3.data[ --var$4] = var$1.data[ --var$2];
            }
        }
    }
};
let jl_System_currentTimeMillis = () => {
    return Long_fromNumber((new Date()).getTime());
},
jm_Conversion = $rt_classWithoutFields(),
jm_Conversion_digitFitInInt = null,
jm_Conversion_bigRadices = null,
jm_Conversion_$callClinit = () => {
    jm_Conversion_$callClinit = $rt_eraseClinit(jm_Conversion);
    jm_Conversion__clinit_();
},
jm_Conversion_toDecimalScaledString = (var$1, var$2) => {
    let var$3, var$4, var$5, $result1, $resLengthInChars, $result, $v, var$10, var$11, $v_0, $v_1, $v_2, $temp, var$16, $result11, $j, $i1, $temp1, $res, $resDigit, $delta, $i, $negNumber, $exponent, $insertPoint, $startPoint;
    jm_Conversion_$callClinit();
    var$3 = var$1.$sign;
    var$4 = var$1.$numberLength;
    var$5 = var$1.$digits;
    if (!var$3) {
        switch (var$2) {
            case 0:
                break;
            case 1:
                return $rt_s(78);
            case 2:
                return $rt_s(79);
            case 3:
                return $rt_s(80);
            case 4:
                return $rt_s(81);
            case 5:
                return $rt_s(82);
            case 6:
                return $rt_s(83);
            default:
                $result1 = jl_StringBuilder__init_();
                if (var$2 >= 0)
                    $result1.$append19($rt_s(84));
                else
                    $result1.$append19($rt_s(85));
                $result1.$append3( -var$2 | 0);
                return $result1.$toString();
        }
        return $rt_s(19);
    }
    $resLengthInChars = ((var$4 * 10 | 0) + 1 | 0) + 7 | 0;
    $result = $rt_createCharArray($resLengthInChars + 1 | 0);
    if (var$4 == 1) {
        $v = var$5.data[0];
        if ($v >= 0) {
            var$10 = $resLengthInChars;
            while (true) {
                var$11 = $result.data;
                $v_0 = $v / 10 | 0;
                var$10 = var$10 + (-1) | 0;
                var$11[var$10] = (48 + ($v - ($v_0 * 10 | 0) | 0) | 0) & 65535;
                if (!$v_0)
                    break;
                $v = $v_0;
            }
        } else {
            $v_1 = Long_and(Long_fromInt($v), Long_create(4294967295, 0));
            var$10 = $resLengthInChars;
            while (true) {
                var$11 = $result.data;
                $v_2 = Long_div($v_1, Long_fromInt(10));
                var$10 = var$10 + (-1) | 0;
                var$11[var$10] = (48 + Long_lo(Long_sub($v_1, Long_mul($v_2, Long_fromInt(10)))) | 0) & 65535;
                if (Long_eq($v_2, Long_ZERO))
                    break;
                $v_1 = $v_2;
            }
        }
    } else {
        $temp = $rt_createIntArray(var$4);
        jl_System_fastArraycopy(var$5, 0, $temp, 0, var$4);
        var$16 = $resLengthInChars;
        a: while (true) {
            $result11 = Long_ZERO;
            $j = var$4 - 1 | 0;
            $i1 = $j;
            while ($i1 >= 0) {
                var$11 = $temp.data;
                $temp1 = Long_add(Long_shl($result11, 32), Long_and(Long_fromInt(var$11[$i1]), Long_create(4294967295, 0)));
                $res = jm_Conversion_divideLongByBillion($temp1);
                var$11[$i1] = Long_lo($res);
                $result11 = Long_fromInt(Long_hi($res));
                $i1 = $i1 + (-1) | 0;
            }
            $resDigit = Long_lo($result11);
            var$10 = var$16;
            while (true) {
                var$11 = $result.data;
                var$10 = var$10 + (-1) | 0;
                var$11[var$10] = (48 + ($resDigit % 10 | 0) | 0) & 65535;
                $resDigit = $resDigit / 10 | 0;
                if (!$resDigit)
                    break;
                if (!var$10)
                    break;
            }
            $delta = (9 - var$16 | 0) + var$10 | 0;
            $i = 0;
            while ($i < $delta && var$10 > 0) {
                var$10 = var$10 + (-1) | 0;
                var$11[var$10] = 48;
                $i = $i + 1 | 0;
            }
            while (!$temp.data[$j]) {
                if (!$j)
                    break a;
                $j = $j + (-1) | 0;
            }
            var$4 = $j + 1 | 0;
            var$16 = var$10;
        }
        while (var$11[var$10] == 48) {
            var$10 = var$10 + 1 | 0;
        }
    }
    $negNumber = var$3 >= 0 ? 0 : 1;
    var$16 = $resLengthInChars - var$10 | 0;
    $exponent = (var$16 - var$2 | 0) - 1 | 0;
    if (!var$2) {
        if ($negNumber) {
            var$11 = $result.data;
            var$10 = var$10 + (-1) | 0;
            var$11[var$10] = 45;
        }
        return jl_String__init_($result, var$10, $resLengthInChars - var$10 | 0);
    }
    if (var$2 > 0 && $exponent >= (-6)) {
        if ($exponent < 0) {
            $j = 2;
            while ($j < (( -$exponent | 0) + 1 | 0)) {
                var$11 = $result.data;
                var$10 = var$10 + (-1) | 0;
                var$11[var$10] = 48;
                $j = $j + 1 | 0;
            }
            var$11 = $result.data;
            var$16 = var$10 + (-1) | 0;
            var$11[var$16] = 46;
            var$16 = var$16 + (-1) | 0;
            var$11[var$16] = 48;
            if ($negNumber) {
                var$16 = var$16 + (-1) | 0;
                var$11[var$16] = 45;
            }
            return jl_String__init_($result, var$16, $resLengthInChars - var$16 | 0);
        }
        $insertPoint = var$10 + $exponent | 0;
        $j = $resLengthInChars - 1 | 0;
        while ($j >= $insertPoint) {
            var$11 = $result.data;
            var$11[$j + 1 | 0] = var$11[$j];
            $j = $j + (-1) | 0;
        }
        var$11 = $result.data;
        var$11[$insertPoint + 1 | 0] = 46;
        if ($negNumber) {
            var$10 = var$10 + (-1) | 0;
            var$11[var$10] = 45;
        }
        return jl_String__init_($result, var$10, ($resLengthInChars - var$10 | 0) + 1 | 0);
    }
    $startPoint = var$10 + 1 | 0;
    $result1 = jl_StringBuilder__init_0((16 + $resLengthInChars | 0) - $startPoint | 0);
    if ($negNumber)
        $result1.$append0(45);
    if (($resLengthInChars - $startPoint | 0) < 1)
        $result1.$append20($result, var$10, var$16);
    else {
        $result1.$append0($result.data[var$10]);
        $result1.$append0(46);
        $result1.$append20($result, $startPoint, var$16 - 1 | 0);
    }
    $result1.$append0(69);
    if ($exponent > 0)
        $result1.$append0(43);
    $result1.$append19(jl_Integer_toString($exponent));
    return $result1.$toString();
},
jm_Conversion_toDecimalScaledString0 = ($v, $scale) => {
    let $negNumber, $result1, $resLengthInChars, $result, var$7, var$8, $v_0, $exponent, $j, var$12, $insertPoint, $startPoint;
    jm_Conversion_$callClinit();
    $negNumber = Long_ge($v, Long_ZERO) ? 0 : 1;
    if ($negNumber)
        $v = Long_neg($v);
    if (Long_eq($v, Long_ZERO)) {
        switch ($scale) {
            case 0:
                break;
            case 1:
                return $rt_s(78);
            case 2:
                return $rt_s(79);
            case 3:
                return $rt_s(80);
            case 4:
                return $rt_s(81);
            case 5:
                return $rt_s(82);
            case 6:
                return $rt_s(83);
            default:
                $result1 = jl_StringBuilder__init_();
                if ($scale >= 0)
                    $result1.$append19($rt_s(84));
                else
                    $result1.$append19($rt_s(85));
                $result1.$append19($scale == (-2147483648) ? $rt_s(86) : jl_Integer_toString( -$scale | 0));
                return $result1.$toString();
        }
        return $rt_s(19);
    }
    $resLengthInChars = 18;
    $result = $rt_createCharArray(19);
    var$7 = $resLengthInChars;
    while (true) {
        var$8 = $result.data;
        $v_0 = Long_div($v, Long_fromInt(10));
        var$7 = var$7 + (-1) | 0;
        var$8[var$7] = Long_lo(Long_add(Long_fromInt(48), Long_sub($v, Long_mul($v_0, Long_fromInt(10))))) & 65535;
        if (Long_eq($v_0, Long_ZERO))
            break;
        $v = $v_0;
    }
    $exponent = Long_sub(Long_sub(Long_sub(Long_fromInt(18), Long_fromInt(var$7)), Long_fromInt($scale)), Long_fromInt(1));
    if (!$scale) {
        if ($negNumber) {
            var$7 = var$7 + (-1) | 0;
            var$8[var$7] = 45;
        }
        return jl_String__init_($result, var$7, $resLengthInChars - var$7 | 0);
    }
    if ($scale > 0 && Long_ge($exponent, Long_fromInt(-6))) {
        if (Long_lt($exponent, Long_ZERO)) {
            $j = 2;
            while (Long_lt(Long_fromInt($j), Long_add(Long_neg($exponent), Long_fromInt(1)))) {
                var$7 = var$7 + (-1) | 0;
                var$8[var$7] = 48;
                $j = $j + 1 | 0;
            }
            var$12 = var$7 + (-1) | 0;
            var$8[var$12] = 46;
            var$12 = var$12 + (-1) | 0;
            var$8[var$12] = 48;
            if ($negNumber) {
                var$12 = var$12 + (-1) | 0;
                var$8[var$12] = 45;
            }
            return jl_String__init_($result, var$12, $resLengthInChars - var$12 | 0);
        }
        $insertPoint = var$7 + Long_lo($exponent) | 0;
        $j = 17;
        while ($j >= $insertPoint) {
            var$8[$j + 1 | 0] = var$8[$j];
            $j = $j + (-1) | 0;
        }
        var$8[$insertPoint + 1 | 0] = 46;
        if ($negNumber) {
            var$7 = var$7 + (-1) | 0;
            var$8[var$7] = 45;
        }
        return jl_String__init_($result, var$7, ($resLengthInChars - var$7 | 0) + 1 | 0);
    }
    $startPoint = var$7 + 1 | 0;
    $result1 = jl_StringBuilder__init_0(34 - $startPoint | 0);
    if ($negNumber)
        $result1.$append0(45);
    if (($resLengthInChars - $startPoint | 0) < 1)
        $result1.$append20($result, var$7, $resLengthInChars - var$7 | 0);
    else {
        $result1.$append0(var$8[var$7]);
        $result1.$append0(46);
        $result1.$append20($result, $startPoint, ($resLengthInChars - var$7 | 0) - 1 | 0);
    }
    $result1.$append0(69);
    if (Long_gt($exponent, Long_ZERO))
        $result1.$append0(43);
    $result1.$append19(jl_Long_toString($exponent));
    return $result1.$toString();
},
jm_Conversion_divideLongByBillion = $a => {
    let $bLong, $quot, $rem, $aPos, $bPos;
    jm_Conversion_$callClinit();
    if (Long_ge($a, Long_ZERO)) {
        $bLong = Long_fromInt(1000000000);
        $quot = Long_div($a, $bLong);
        $rem = Long_rem($a, $bLong);
    } else {
        $aPos = Long_shru($a, 1);
        $bPos = Long_fromInt(500000000);
        $quot = Long_div($aPos, $bPos);
        $rem = Long_rem($aPos, $bPos);
        $rem = Long_add(Long_shl($rem, 1), Long_and($a, Long_fromInt(1)));
    }
    return Long_or(Long_shl($rem, 32), Long_and($quot, Long_create(4294967295, 0)));
},
jm_Conversion_bigInteger2Double = $val => {
    let $bitLen, $exponent, $delta, $lVal, $mantissa, var$7, $resSign, var$9, $result;
    jm_Conversion_$callClinit();
    a: {
        if ($val.$numberLength >= 2) {
            if ($val.$numberLength != 2)
                break a;
            if ($val.$digits.data[1] <= 0)
                break a;
        }
        return Long_toNumber($val.$longValue());
    }
    if ($val.$numberLength > 32)
        return $val.$sign <= 0 ? (-Infinity) : Infinity;
    $bitLen = ($val.$abs1()).$bitLength0();
    $exponent = Long_fromInt($bitLen - 1 | 0);
    $delta = $bitLen - 54 | 0;
    $lVal = (($val.$abs1()).$shiftRight0($delta)).$longValue();
    $mantissa = Long_and($lVal, Long_create(4294967295, 2097151));
    if (Long_eq($exponent, Long_fromInt(1023))) {
        if (Long_eq($mantissa, Long_create(4294967295, 2097151)))
            return $val.$sign <= 0 ? (-Infinity) : Infinity;
        if (Long_eq($mantissa, Long_create(4294967294, 2097151)))
            return $val.$sign <= 0 ? (-1.7976931348623157E308) : 1.7976931348623157E308;
    }
    if (!(!(Long_eq(Long_and($mantissa, Long_fromInt(1)), Long_fromInt(1)) && Long_eq(Long_and($mantissa, Long_fromInt(2)), Long_fromInt(2))) && !jm_BitLevel_nonZeroDroppedBits($delta, $val.$digits)))
        $mantissa = Long_add($mantissa, Long_fromInt(2));
    var$7 = Long_shr($mantissa, 1);
    $resSign = $val.$sign >= 0 ? Long_ZERO : Long_create(0, 2147483648);
    var$9 = Long_and(Long_shl(Long_add(Long_fromInt(1023), $exponent), 52), Long_create(0, 2146435072));
    $result = Long_or(Long_or($resSign, var$9), var$7);
    return $rt_longBitsToDouble($result);
},
jm_Conversion__clinit_ = () => {
    jm_Conversion_digitFitInInt = $rt_createIntArrayFromData([(-1), (-1), 31, 19, 15, 13, 11, 11, 10, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 5]);
    jm_Conversion_bigRadices = $rt_createIntArrayFromData([(-2147483648), 1162261467, 1073741824, 1220703125, 362797056, 1977326743, 1073741824, 387420489, 1000000000, 214358881, 429981696, 815730721, 1475789056, 170859375, 268435456, 410338673, 612220032, 893871739, 1280000000, 1801088541, 113379904, 148035889, 191102976, 244140625, 308915776, 387420489, 481890304, 594823321, 729000000, 887503681, 1073741824, 1291467969, 1544804416, 1838265625, 60466176]);
};
function rceh_InterruptController$IsrEntry() {
    let a = this; jl_Object.call(a);
    a.$handler = null;
    a.$priority0 = 0;
}
function rceh_KeyRegister() {
    jl_Object.call(this);
    this.$rawValue = 0;
}
let rceh_KeyRegister__init_ = $this => {
    jl_Object__init_($this);
    $this.$rawValue = 0;
},
rceh_KeyRegister__init_0 = () => {
    let var_0 = new rceh_KeyRegister();
    rceh_KeyRegister__init_(var_0);
    return var_0;
},
rceh_KeyRegister_setKeyPressed = ($this, $key, $pressed) => {
    let $mask;
    if ($key === null)
        return;
    $mask = rce_Key_getBitMask($key);
    if ($pressed)
        $this.$rawValue = $this.$rawValue | $mask;
    else
        $this.$rawValue = $this.$rawValue & ($mask ^ (-1));
},
rceh_KeyRegister_isPressed = ($this, $key) => {
    if ($key === null)
        return 0;
    return !($this.$rawValue & rce_Key_getBitMask($key)) ? 0 : 1;
},
rceh_KeyRegister_getBinaryString = $this => {
    let $sb, $i;
    $sb = jl_StringBuilder__init_();
    $i = 15;
    while ($i >= 0) {
        $sb.$append3($this.$rawValue >> $i & 1);
        if (!($i % 4 | 0) && $i)
            $sb.$append19($rt_s(87));
        $i = $i + (-1) | 0;
    }
    return $sb.$toString();
},
rceh_KeyRegister_getHexDump = $this => {
    let var$1;
    var$1 = $rt_createArray(jl_Object, 1);
    var$1.data[0] = jl_Integer_valueOf($this.$rawValue & 65535);
    return jl_String_format($rt_s(88), var$1);
},
rceh_KeyRegister_toString = $this => {
    let var$1, var$2, var$3;
    var$1 = $this.$getHexDump();
    var$2 = $this.$getBinaryString();
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append1(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(var$3, var$1), $rt_s(89)), var$2), 93);
    return jl_StringBuilder_toString(var$3);
};
function jm_BigDecimal() {
    let a = this; jl_Number.call(a);
    a.$toStringImage = null;
    a.$hashCode5 = 0;
    a.$intVal = null;
    a.$bitLength3 = 0;
    a.$smallValue = Long_ZERO;
    a.$scale0 = 0;
    a.$precision1 = 0;
}
let jm_BigDecimal_ZERO = null,
jm_BigDecimal_ONE = null,
jm_BigDecimal_TEN = null,
jm_BigDecimal_FIVE_POW = null,
jm_BigDecimal_TEN_POW = null,
jm_BigDecimal_LONG_TEN_POW = null,
jm_BigDecimal_LONG_FIVE_POW = null,
jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH = null,
jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH = null,
jm_BigDecimal_BI_SCALED_BY_ZERO = null,
jm_BigDecimal_ZERO_SCALED_BY = null,
jm_BigDecimal_CH_ZEROS = null,
jm_BigDecimal_$callClinit = () => {
    jm_BigDecimal_$callClinit = $rt_eraseClinit(jm_BigDecimal);
    jm_BigDecimal__clinit_();
},
jm_BigDecimal__init_5 = ($this, $smallValue, $scale) => {
    jm_BigDecimal_$callClinit();
    jl_Number__init_($this);
    $this.$smallValue = $smallValue;
    $this.$scale0 = $scale;
    $this.$bitLength3 = jm_BigDecimal_bitLength($smallValue);
},
jm_BigDecimal__init_2 = (var_0, var_1) => {
    let var_2 = new jm_BigDecimal();
    jm_BigDecimal__init_5(var_2, var_0, var_1);
    return var_2;
},
jm_BigDecimal__init_4 = ($this, $smallValue, $scale) => {
    jm_BigDecimal_$callClinit();
    jl_Number__init_($this);
    $this.$smallValue = Long_fromInt($smallValue);
    $this.$scale0 = $scale;
    $this.$bitLength3 = jm_BigDecimal_bitLength0($smallValue);
},
jm_BigDecimal__init_ = (var_0, var_1) => {
    let var_2 = new jm_BigDecimal();
    jm_BigDecimal__init_4(var_2, var_0, var_1);
    return var_2;
},
jm_BigDecimal__init_3 = ($this, $val) => {
    jm_BigDecimal_$callClinit();
    jm_BigDecimal__init_0($this, $val, 0);
},
jm_BigDecimal__init_6 = var_0 => {
    let var_1 = new jm_BigDecimal();
    jm_BigDecimal__init_3(var_1, var_0);
    return var_1;
},
jm_BigDecimal__init_0 = ($this, $unscaledVal, $scale) => {
    jm_BigDecimal_$callClinit();
    jl_Number__init_($this);
    if ($unscaledVal !== null) {
        $this.$scale0 = $scale;
        jm_BigDecimal_setUnscaledValue($this, $unscaledVal);
        return;
    }
    $rt_throw(jl_NullPointerException__init_());
},
jm_BigDecimal__init_1 = (var_0, var_1) => {
    let var_2 = new jm_BigDecimal();
    jm_BigDecimal__init_0(var_2, var_0, var_1);
    return var_2;
},
jm_BigDecimal_valueOf0 = ($unscaledVal, $scale) => {
    jm_BigDecimal_$callClinit();
    if (!$scale)
        return jm_BigDecimal_valueOf($unscaledVal);
    if (Long_eq($unscaledVal, Long_ZERO) && $scale >= 0 && $scale < jm_BigDecimal_ZERO_SCALED_BY.data.length)
        return jm_BigDecimal_ZERO_SCALED_BY.data[$scale];
    return jm_BigDecimal__init_2($unscaledVal, $scale);
},
jm_BigDecimal_valueOf = $unscaledVal => {
    jm_BigDecimal_$callClinit();
    if (Long_ge($unscaledVal, Long_ZERO) && Long_lt($unscaledVal, Long_fromInt(11)))
        return jm_BigDecimal_BI_SCALED_BY_ZERO.data[Long_lo($unscaledVal)];
    return jm_BigDecimal__init_2($unscaledVal, 0);
},
jm_BigDecimal_multiply = ($this, $multiplicand) => {
    let $newScale, var$3, var$4, var$5;
    $newScale = Long_add(Long_fromInt($this.$scale0), Long_fromInt($multiplicand.$scale0));
    if (!jm_BigDecimal_isZero($this) && !jm_BigDecimal_isZero($multiplicand)) {
        if (($this.$bitLength3 + $multiplicand.$bitLength3 | 0) < 64)
            return jm_BigDecimal_valueOf0(Long_mul($this.$smallValue, $multiplicand.$smallValue), jm_BigDecimal_toIntScale($newScale));
        var$3 = new jm_BigDecimal;
        var$4 = jm_BigDecimal_getUnscaledValue($this);
        var$5 = jm_BigDecimal_getUnscaledValue($multiplicand);
        var$4 = var$4.$multiply0(var$5);
        jm_BigDecimal__init_0(var$3, var$4, jm_BigDecimal_toIntScale($newScale));
        return var$3;
    }
    return jm_BigDecimal_zeroScaledBy($newScale);
},
jm_BigDecimal_signum = $this => {
    if ($this.$bitLength3 >= 64)
        return (jm_BigDecimal_getUnscaledValue($this)).$signum();
    return jl_Long_signum($this.$smallValue);
},
jm_BigDecimal_isZero = $this => {
    return !$this.$bitLength3 && Long_ne($this.$smallValue, Long_fromInt(-1)) ? 1 : 0;
},
jm_BigDecimal_scale = $this => {
    return $this.$scale0;
},
jm_BigDecimal_precision = $this => {
    let $bitLength, $decimalDigits, $doubleUnsc, var$4;
    if ($this.$precision1 > 0)
        return $this.$precision1;
    $bitLength = $this.$bitLength3;
    $decimalDigits = 1;
    $doubleUnsc = 1.0;
    if ($bitLength >= 1024) {
        var$4 = 1.0 + ($bitLength - 1 | 0) * 0.3010299956639812 | 0;
        if (((jm_BigDecimal_getUnscaledValue($this)).$divide0(jm_Multiplication_powerOf10(Long_fromInt(var$4)))).$signum())
            var$4 = var$4 + 1 | 0;
    } else {
        if ($bitLength >= 64)
            $doubleUnsc = (jm_BigDecimal_getUnscaledValue($this)).$doubleValue();
        else if ($bitLength >= 1)
            $doubleUnsc = Long_toNumber($this.$smallValue);
        var$4 = $decimalDigits + otcit_DoubleAnalyzer_fastIntLog10(jl_Math_abs1($doubleUnsc)) | 0;
    }
    $this.$precision1 = var$4;
    return $this.$precision1;
},
jm_BigDecimal_unscaledValue = $this => {
    return jm_BigDecimal_getUnscaledValue($this);
},
jm_BigDecimal_compareTo = ($this, $val) => {
    let $thisSign, $valueSign, var$4, $diffScale, $diffPrecision, var$7, $thisUnscaled, $valUnscaled;
    $thisSign = $this.$signum();
    $valueSign = $val.$signum();
    var$4 = $rt_compare($thisSign, $valueSign);
    if (var$4) {
        if (var$4 >= 0)
            return 1;
        return (-1);
    }
    if ($this.$scale0 == $val.$scale0 && $this.$bitLength3 < 64 && $val.$bitLength3 < 64)
        return Long_lt($this.$smallValue, $val.$smallValue) ? (-1) : Long_le($this.$smallValue, $val.$smallValue) ? 0 : 1;
    $diffScale = Long_sub(Long_fromInt($this.$scale0), Long_fromInt($val.$scale0));
    $diffPrecision = jm_BigDecimal_aproxPrecision($this) - jm_BigDecimal_aproxPrecision($val) | 0;
    var$7 = Long_fromInt($diffPrecision);
    if (Long_gt(var$7, Long_add($diffScale, Long_fromInt(1))))
        return $thisSign;
    if (Long_lt(var$7, Long_sub($diffScale, Long_fromInt(1))))
        return  -$thisSign | 0;
    $thisUnscaled = jm_BigDecimal_getUnscaledValue($this);
    $valUnscaled = jm_BigDecimal_getUnscaledValue($val);
    var$4 = Long_compare($diffScale, Long_ZERO);
    if (var$4 < 0)
        $thisUnscaled = $thisUnscaled.$multiply0(jm_Multiplication_powerOf10(Long_neg($diffScale)));
    else if (var$4 > 0)
        $valUnscaled = $valUnscaled.$multiply0(jm_Multiplication_powerOf10($diffScale));
    return $thisUnscaled.$compareTo0($valUnscaled);
},
jm_BigDecimal_equals = ($this, $x) => {
    let $x1, var$3, var$4, var$5;
    if ($this === $x)
        return 1;
    if (!($x instanceof jm_BigDecimal))
        return 0;
    a: {
        b: {
            c: {
                $x1 = $x;
                if ($x1.$scale0 == $this.$scale0) {
                    if ($this.$bitLength3 >= 64) {
                        var$3 = $this.$intVal;
                        var$4 = $x1.$intVal;
                        if (!var$3.$equals(var$4))
                            break c;
                        else
                            break b;
                    }
                    if (Long_eq($x1.$smallValue, $this.$smallValue))
                        break b;
                }
            }
            var$5 = 0;
            break a;
        }
        var$5 = 1;
    }
    return var$5;
},
jm_BigDecimal_hashCode = $this => {
    if ($this.$hashCode5)
        return $this.$hashCode5;
    if ($this.$bitLength3 >= 64) {
        $this.$hashCode5 = (17 * $this.$intVal.$hashCode0() | 0) + $this.$scale0 | 0;
        return $this.$hashCode5;
    }
    $this.$hashCode5 = Long_lo($this.$smallValue);
    $this.$hashCode5 = (33 * $this.$hashCode5 | 0) + Long_hi($this.$smallValue) | 0;
    $this.$hashCode5 = (17 * $this.$hashCode5 | 0) + $this.$scale0 | 0;
    return $this.$hashCode5;
},
jm_BigDecimal_toString = $this => {
    let $intString, $begin, $end, $exponent, $result;
    if ($this.$toStringImage !== null)
        return $this.$toStringImage;
    if ($this.$bitLength3 < 32) {
        $this.$toStringImage = jm_Conversion_toDecimalScaledString0($this.$smallValue, $this.$scale0);
        return $this.$toStringImage;
    }
    $intString = (jm_BigDecimal_getUnscaledValue($this)).$toString();
    if (!$this.$scale0)
        return $intString;
    $begin = (jm_BigDecimal_getUnscaledValue($this)).$signum() >= 0 ? 1 : 2;
    $end = $intString.$length();
    $exponent = Long_sub(Long_add(Long_neg(Long_fromInt($this.$scale0)), Long_fromInt($end)), Long_fromInt($begin));
    $result = jl_StringBuilder__init_();
    $result.$append19($intString);
    if ($this.$scale0 > 0 && Long_ge($exponent, Long_fromInt(-6))) {
        if (Long_ge($exponent, Long_ZERO))
            $result.$insert11($end - $this.$scale0 | 0, 46);
        else {
            $result.$insert14($begin - 1 | 0, $rt_s(90));
            $result.$insert8($begin + 1 | 0, jm_BigDecimal_CH_ZEROS, 0, ( -Long_lo($exponent) | 0) - 1 | 0);
        }
    } else {
        if (($end - $begin | 0) >= 1) {
            $result.$insert11($begin, 46);
            $end = $end + 1 | 0;
        }
        $result.$insert11($end, 69);
        if (Long_gt($exponent, Long_ZERO)) {
            $end = $end + 1 | 0;
            $result.$insert11($end, 43);
        }
        $result.$insert14($end + 1 | 0, jl_Long_toString($exponent));
    }
    $this.$toStringImage = $result.$toString();
    return $this.$toStringImage;
},
jm_BigDecimal_toBigInteger = $this => {
    if ($this.$scale0 && !jm_BigDecimal_isZero($this)) {
        if ($this.$scale0 >= 0)
            return (jm_BigDecimal_getUnscaledValue($this)).$divide0(jm_Multiplication_powerOf10(Long_fromInt($this.$scale0)));
        return (jm_BigDecimal_getUnscaledValue($this)).$multiply0(jm_Multiplication_powerOf10(Long_neg(Long_fromInt($this.$scale0))));
    }
    return jm_BigDecimal_getUnscaledValue($this);
},
jm_BigDecimal_longValue = $this => {
    return $this.$scale0 > (-64) && $this.$scale0 <= jm_BigDecimal_aproxPrecision($this) ? ($this.$toBigInteger()).$longValue() : Long_ZERO;
},
jm_BigDecimal_intValue = $this => {
    return $this.$scale0 > (-32) && $this.$scale0 <= jm_BigDecimal_aproxPrecision($this) ? ($this.$toBigInteger()).$intValue() : 0;
},
jm_BigDecimal_doubleValue = $this => {
    let $sign, $exponent, $powerOfTwo, $mantisa, var$5, $powerOfTen, $k, $quotAndRem, var$9, $compRem, $lowestSetBit, $discardedSize, $bits, var$14, var$15, var$16, var$17;
    $sign = $this.$signum();
    $exponent = 1076;
    $powerOfTwo = Long_sub(Long_fromInt($this.$bitLength3), Long_fromNumber($this.$scale0 / 0.3010299956639812));
    if (Long_ge($powerOfTwo, Long_fromInt(-1074)) && $sign) {
        if (Long_gt($powerOfTwo, Long_fromInt(1025)))
            return $sign * Infinity;
        $mantisa = (jm_BigDecimal_getUnscaledValue($this)).$abs1();
        if ($this.$scale0 <= 0)
            var$5 = $mantisa.$multiply0(jm_Multiplication_powerOf10(Long_fromInt( -$this.$scale0 | 0)));
        else {
            $powerOfTen = jm_Multiplication_powerOf10(Long_fromInt($this.$scale0));
            $k = 100 - Long_lo($powerOfTwo) | 0;
            if ($k > 0) {
                $mantisa = $mantisa.$shiftLeft0($k);
                $exponent = $exponent - $k | 0;
            }
            $quotAndRem = $mantisa.$divideAndRemainder($powerOfTen);
            var$9 = $quotAndRem.data;
            $compRem = (var$9[1].$shiftLeftOneBit0()).$compareTo0($powerOfTen);
            var$5 = (var$9[0].$shiftLeft0(2)).$add1(jm_BigInteger_valueOf(Long_fromInt(($rt_imul($compRem, $compRem + 3 | 0) / 2 | 0) + 1 | 0)));
            $exponent = $exponent + (-2) | 0;
        }
        $lowestSetBit = var$5.$getLowestSetBit();
        $discardedSize = var$5.$bitLength0() - 54 | 0;
        if ($discardedSize <= 0) {
            $bits = Long_shl(var$5.$longValue(),  -$discardedSize | 0);
            var$14 = Long_ne(Long_and($bits, Long_fromInt(3)), Long_fromInt(3)) ? $bits : Long_add($bits, Long_fromInt(2));
        } else {
            $bits = (var$5.$shiftRight0($discardedSize)).$longValue();
            var$14 = !(Long_eq(Long_and($bits, Long_fromInt(1)), Long_fromInt(1)) && $lowestSetBit < $discardedSize) && Long_ne(Long_and($bits, Long_fromInt(3)), Long_fromInt(3)) ? $bits : Long_add($bits, Long_fromInt(2));
        }
        if (Long_eq(Long_and(var$14, Long_create(0, 4194304)), Long_ZERO)) {
            var$15 = Long_shr(var$14, 1);
            var$16 = $exponent + $discardedSize | 0;
        } else {
            var$15 = Long_shr(var$14, 2);
            var$16 = $exponent + ($discardedSize + 1 | 0) | 0;
        }
        if (var$16 > 2046)
            return $sign * Infinity;
        if (var$16 <= 0) {
            if (var$16 < (-53))
                return $sign * 0.0;
            a: {
                var$15 = Long_shr($bits, 1);
                var$17 = Long_and(var$15, Long_shru(Long_fromInt(-1), 63 + var$16 | 0));
                var$15 = Long_shr(var$15,  -var$16 | 0);
                if (Long_ne(Long_and(var$15, Long_fromInt(3)), Long_fromInt(3))) {
                    if (Long_ne(Long_and(var$15, Long_fromInt(1)), Long_fromInt(1)))
                        break a;
                    if (Long_eq(var$17, Long_ZERO))
                        break a;
                    if ($lowestSetBit >= $discardedSize)
                        break a;
                }
                var$15 = Long_add(var$15, Long_fromInt(1));
            }
            var$16 = 0;
            var$15 = Long_shr(var$15, 1);
        }
        var$15 = Long_or(Long_or(Long_and(Long_fromInt($sign), Long_create(0, 2147483648)), Long_shl(Long_fromInt(var$16), 52)), Long_and(var$15, Long_create(4294967295, 1048575)));
        return $rt_longBitsToDouble(var$15);
    }
    return $sign * 0.0;
},
jm_BigDecimal_aproxPrecision = $this => {
    return $this.$precision1 > 0 ? $this.$precision1 : (($this.$bitLength3 - 1 | 0) * 0.3010299956639812 | 0) + 1 | 0;
},
jm_BigDecimal_toIntScale = $longScale => {
    jm_BigDecimal_$callClinit();
    if (Long_lt($longScale, Long_fromInt(-2147483648)))
        $rt_throw(jl_ArithmeticException__init_($rt_s(91)));
    if (Long_le($longScale, Long_fromInt(2147483647)))
        return Long_lo($longScale);
    $rt_throw(jl_ArithmeticException__init_($rt_s(92)));
},
jm_BigDecimal_zeroScaledBy = $longScale => {
    let var$2;
    jm_BigDecimal_$callClinit();
    var$2 = Long_lo($longScale);
    if (Long_eq($longScale, Long_fromInt(var$2)))
        return jm_BigDecimal_valueOf0(Long_ZERO, var$2);
    if (Long_lt($longScale, Long_ZERO))
        return jm_BigDecimal__init_(0, (-2147483648));
    return jm_BigDecimal__init_(0, 2147483647);
},
jm_BigDecimal_getUnscaledValue = $this => {
    if ($this.$intVal === null)
        $this.$intVal = jm_BigInteger_valueOf($this.$smallValue);
    return $this.$intVal;
},
jm_BigDecimal_setUnscaledValue = ($this, $unscaledValue) => {
    $this.$intVal = $unscaledValue;
    $this.$bitLength3 = $unscaledValue.$bitLength0();
    if ($this.$bitLength3 < 64)
        $this.$smallValue = $unscaledValue.$longValue();
},
jm_BigDecimal_bitLength = $smallValue => {
    jm_BigDecimal_$callClinit();
    if (Long_lt($smallValue, Long_ZERO))
        $smallValue = Long_xor($smallValue, Long_fromInt(-1));
    return 64 - jl_Long_numberOfLeadingZeros($smallValue) | 0;
},
jm_BigDecimal_bitLength0 = $smallValue => {
    jm_BigDecimal_$callClinit();
    if ($smallValue < 0)
        $smallValue = $smallValue ^ (-1);
    return 32 - jl_Integer_numberOfLeadingZeros($smallValue) | 0;
},
jm_BigDecimal_compareTo0 = ($this, var$1) => {
    return $this.$compareTo4(var$1);
},
jm_BigDecimal__clinit_ = () => {
    let $i, $j;
    jm_BigDecimal_ZERO = jm_BigDecimal__init_(0, 0);
    jm_BigDecimal_ONE = jm_BigDecimal__init_(1, 0);
    jm_BigDecimal_TEN = jm_BigDecimal__init_(10, 0);
    jm_BigDecimal_LONG_TEN_POW = $rt_createLongArrayFromData([Long_fromInt(1), Long_fromInt(10), Long_fromInt(100), Long_fromInt(1000), Long_fromInt(10000), Long_fromInt(100000), Long_fromInt(1000000), Long_fromInt(10000000), Long_fromInt(100000000), Long_fromInt(1000000000), Long_create(1410065408, 2), Long_create(1215752192, 23), Long_create(3567587328, 232), Long_create(1316134912, 2328), Long_create(276447232, 23283), Long_create(2764472320, 232830), Long_create(1874919424, 2328306), Long_create(1569325056, 23283064),
    Long_create(2808348672, 232830643)]);
    jm_BigDecimal_LONG_FIVE_POW = $rt_createLongArrayFromData([Long_fromInt(1), Long_fromInt(5), Long_fromInt(25), Long_fromInt(125), Long_fromInt(625), Long_fromInt(3125), Long_fromInt(15625), Long_fromInt(78125), Long_fromInt(390625), Long_fromInt(1953125), Long_fromInt(9765625), Long_fromInt(48828125), Long_fromInt(244140625), Long_fromInt(1220703125), Long_create(1808548329, 1), Long_create(452807053, 7), Long_create(2264035265, 35), Long_create(2730241733, 177), Long_create(766306777, 888), Long_create(3831533885, 4440),
    Long_create(1977800241, 22204), Long_create(1299066613, 111022), Long_create(2200365769, 555111), Long_create(2411894253, 2775557), Long_create(3469536673, 13877787), Long_create(167814181, 69388939), Long_create(839070905, 346944695), Long_create(4195354525, 1734723475)]);
    jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH = $rt_createIntArray(jm_BigDecimal_LONG_FIVE_POW.data.length);
    jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH = $rt_createIntArray(jm_BigDecimal_LONG_TEN_POW.data.length);
    jm_BigDecimal_BI_SCALED_BY_ZERO = $rt_createArray(jm_BigDecimal, 11);
    jm_BigDecimal_ZERO_SCALED_BY = $rt_createArray(jm_BigDecimal, 11);
    jm_BigDecimal_CH_ZEROS = $rt_createCharArray(100);
    $i = 0;
    while ($i < jm_BigDecimal_ZERO_SCALED_BY.data.length) {
        jm_BigDecimal_BI_SCALED_BY_ZERO.data[$i] = jm_BigDecimal__init_($i, 0);
        jm_BigDecimal_ZERO_SCALED_BY.data[$i] = jm_BigDecimal__init_(0, $i);
        jm_BigDecimal_CH_ZEROS.data[$i] = 48;
        $i = $i + 1 | 0;
    }
    while ($i < jm_BigDecimal_CH_ZEROS.data.length) {
        jm_BigDecimal_CH_ZEROS.data[$i] = 48;
        $i = $i + 1 | 0;
    }
    $j = 0;
    while ($j < jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH.data.length) {
        jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH.data[$j] = jm_BigDecimal_bitLength(jm_BigDecimal_LONG_FIVE_POW.data[$j]);
        $j = $j + 1 | 0;
    }
    $j = 0;
    while ($j < jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH.data.length) {
        jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH.data[$j] = jm_BigDecimal_bitLength(jm_BigDecimal_LONG_TEN_POW.data[$j]);
        $j = $j + 1 | 0;
    }
    jm_Multiplication_$callClinit();
    jm_BigDecimal_TEN_POW = jm_Multiplication_bigTenPows;
    jm_BigDecimal_FIVE_POW = jm_Multiplication_bigFivePows;
},
jl_Character = $rt_classWithoutFields(),
jl_Character_TYPE = null,
jl_Character_lowerCaseMapping = null,
jl_Character_characterCache = null;
let jl_Character_$$metadata$$0 = null,
jl_Character_$callClinit = () => {
    jl_Character_$callClinit = $rt_eraseClinit(jl_Character);
    jl_Character__clinit_();
},
jl_Character_isValidCodePoint = $codePoint => {
    jl_Character_$callClinit();
    return $codePoint >= 0 && $codePoint <= 1114111 ? 1 : 0;
},
jl_Character_highSurrogate = $codePoint => {
    let var$2;
    jl_Character_$callClinit();
    var$2 = $codePoint - 65536 | 0;
    return (55296 | var$2 >> 10 & 1023) & 65535;
},
jl_Character_lowSurrogate = $codePoint => {
    jl_Character_$callClinit();
    return (56320 | $codePoint & 1023) & 65535;
},
jl_Character_toLowerCase = $ch => {
    jl_Character_$callClinit();
    return jl_Character_toLowerCase0($ch) & 65535;
},
jl_Character_toLowerCase0 = $ch => {
    jl_Character_$callClinit();
    return jl_Character_mapChar(jl_Character_getLowerCaseMapping(), $ch);
},
jl_Character_getLowerCaseMapping = () => {
    let var$1;
    jl_Character_$callClinit();
    if (jl_Character_lowerCaseMapping === null) {
        var$1 = otciu_UnicodeHelper_decodeCaseMapping(((jl_Character_acquireLowerCaseMapping()).value !== null ? $rt_str((jl_Character_acquireLowerCaseMapping()).value) : null));
        jl_Character_lowerCaseMapping = otciu_UnicodeHelper_createCharMapping(var$1);
    }
    return jl_Character_lowerCaseMapping;
},
jl_Character_acquireLowerCaseMapping = () => {
    jl_Character_$callClinit();
    if (jl_Character_$$metadata$$0 === null)
        jl_Character_$$metadata$$0 = jl_Character_acquireLowerCaseMapping$$create();
    return jl_Character_$$metadata$$0;
},
jl_Character_mapChar = ($table, $codePoint) => {
    let $binSearchTable, $index, var$5, var$6;
    jl_Character_$callClinit();
    if ($codePoint < $table.$fastTable.data.length)
        return $codePoint + $table.$fastTable.data[$codePoint] | 0;
    $binSearchTable = $table.$binarySearchTable0;
    $index = jl_Character_binarySearchTable($binSearchTable, $codePoint);
    if ($index >= 0) {
        var$5 = $binSearchTable.data;
        var$6 = $index * 2 | 0;
        if (var$6 < var$5.length)
            return $codePoint + var$5[var$6 + 1 | 0] | 0;
    }
    return 0;
},
jl_Character_binarySearchTable = ($data, $key) => {
    let var$3, $l, $u, $i, $e, var$8;
    jl_Character_$callClinit();
    var$3 = $data.data;
    $l = 0;
    $u = (var$3.length / 2 | 0) - 1 | 0;
    while (true) {
        $i = ($l + $u | 0) / 2 | 0;
        $e = var$3[$i * 2 | 0];
        var$8 = $rt_compare($e, $key);
        if (!var$8)
            break;
        if (var$8 <= 0) {
            $l = $i + 1 | 0;
            if ($l > $u)
                return $i;
        } else {
            $u = $i - 1 | 0;
            if ($u < $l)
                return $u;
        }
    }
    return $i;
},
jl_Character_forDigit = ($digit, $radix) => {
    jl_Character_$callClinit();
    if ($radix >= 2 && $radix <= 36 && $digit >= 0 && $digit < $radix)
        return $digit < 10 ? (48 + $digit | 0) & 65535 : ((97 + $digit | 0) - 10 | 0) & 65535;
    return 0;
},
jl_Character_toChars = $codePoint => {
    let var$2, var$3;
    jl_Character_$callClinit();
    if (!jl_Character_isValidCodePoint($codePoint))
        $rt_throw(jl_IllegalArgumentException__init_0());
    if ($codePoint < 65536) {
        var$2 = $rt_createCharArray(1);
        var$2.data[0] = $codePoint & 65535;
        return var$2;
    }
    var$2 = $rt_createCharArray(2);
    var$3 = var$2.data;
    var$3[0] = jl_Character_highSurrogate($codePoint);
    var$3[1] = jl_Character_lowSurrogate($codePoint);
    return var$2;
},
jl_Character__clinit_ = () => {
    jl_Character_TYPE = $rt_cls($rt_charcls);
    jl_Character_characterCache = $rt_createArray(jl_Character, 128);
},
jl_Character_acquireLowerCaseMapping$$create = () => {
    return {"value" : ">W  H#F#U 4%F#O #F#/ d%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #a1# #%# #%# #%# %%# #%# #%# #%# #%# #%# #%# #%# %%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #<+#%# #%# #%# \'.3#%# #%# #{1#%# #w1%%# %J\'#k1#o1#%# #w1#!3# #23#*3#%# \'23#:3# #>3#%# #%# #%# #N3#%# #N3# %%# #N3#%# #J3%%# #%# #R3#%# \'%# /)#%# #)#%# #)#%# #%# #%# #%# #%# #%# #%# #%# #%# %%# #%# #%# #%# #%# #%# #%# #%# #%# %)#%# #%# #8)#L%#%# #%# #%# #"
    + "%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #a+# #%# #%# #%# #%# #%# #%# #%# #%# #%# /B45#%# #,/#645# %%# #P1#!\'#*\'#%# #%# #%# #%# #%# <-%# #%# \'%# 1&++ %_## #Z#)k%%g%% #F#W hA# 1%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# +]%# %%# #?#%# %a+\'N\'AF#b &#%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# 3%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #^#%# #%# #%# #%# #%# #%# #%# %%# #%# #%# #%# #%# #%# #%# #%"
    + "# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# %*%r iB#oq-&# _?gejg#A1 o$#mo%&# {-%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# 3,4/# #%# #%# #%"
    + "# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# 3C1 1C1 1C1 1C1 1C1 3C/ 1C1 QC1 1C1 1C1 1C%8\'%G# 7i\')G# 7C%D)\' 7C%u)%?# 7X+%P+%G# L-q*/# \'Pw/#8m/# -6## |bA G%# kC.#U !r*%&# &#%# #,05#qX\'#H.5# %%# #%# #%# #e25#D05#q25#m25# #%# %%# 1865%%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# "
    + "#%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# 1%# #%# )%# (a=%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# G%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# y%%# #%# #%# #%# #%# #%# #%# \'%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #%# 5%# #%# #4Fd#%# #%# #%# #%# #%# )%# #<{p# %%# #%# \'%# #%# #%# #%# #%# #%# #%# #%# #%# #%# #P}p#}}p#m}p#D}p#P}p# #@yp#D{p#Lyp#Br#%# #%# #%# #%"
    + "# #%# #%# #%# #%# #,%#L}p#LJd#%# #%# -%# +%# #%# Y%# ,T5F#U TUg#r {%g#r >\'c#p Lnk%F# *J#F#b o@5F#b Jo=N#f "};
};
function jt_FieldPosition() {
    let a = this; jl_Object.call(a);
    a.$myField = 0;
    a.$beginIndex = 0;
    a.$endIndex = 0;
    a.$myAttribute = null;
}
let jt_FieldPosition__init_ = ($this, $field) => {
    jl_Object__init_($this);
    $this.$myField = $field;
},
jt_FieldPosition__init_0 = var_0 => {
    let var_1 = new jt_FieldPosition();
    jt_FieldPosition__init_(var_1, var_0);
    return var_1;
},
jt_FieldPosition_equals = ($this, $object) => {
    let $pos;
    if (!($object instanceof jt_FieldPosition))
        return 0;
    $pos = $object;
    return $this.$myField == $pos.$myField && $this.$myAttribute === $pos.$myAttribute && $this.$beginIndex == $pos.$beginIndex && $this.$endIndex == $pos.$endIndex ? 1 : 0;
},
jt_FieldPosition_hashCode = $this => {
    let $attributeHash;
    $attributeHash = $this.$myAttribute === null ? 0 : jt_AttributedCharacterIterator$Attribute_hashCode($this.$myAttribute);
    return (($attributeHash + ($this.$myField * 10 | 0) | 0) + ($this.$beginIndex * 100 | 0) | 0) + $this.$endIndex | 0;
},
jt_FieldPosition_toString = $this => {
    let var$1, var$2, var$3, var$4, var$5, var$6;
    var$1 = (jl_Object_getClass($this)).$getName();
    var$2 = $this.$myAttribute;
    var$3 = $this.$myField;
    var$4 = $this.$beginIndex;
    var$5 = $this.$endIndex;
    var$6 = jl_StringBuilder__init_();
    jl_StringBuilder_append1(jl_StringBuilder_append0(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(var$6, var$1), $rt_s(93)), var$2), $rt_s(94)), var$3), $rt_s(95)), var$4), $rt_s(96)), var$5), 93);
    return jl_StringBuilder_toString(var$6);
};
function jl_Object$monitorExit$lambda$_8_0() {
    jl_Object.call(this);
    this.$_03 = null;
}
let jl_Object$monitorExit$lambda$_8_0__init_ = (var$0, var$1) => {
    jl_Object__init_(var$0);
    var$0.$_03 = var$1;
},
jl_Object$monitorExit$lambda$_8_0__init_0 = var_0 => {
    let var_1 = new jl_Object$monitorExit$lambda$_8_0();
    jl_Object$monitorExit$lambda$_8_0__init_(var_1, var_0);
    return var_1;
},
jl_Object$monitorExit$lambda$_8_0_run = var$0 => {
    jl_Object_lambda$monitorExit$2(var$0.$_03);
},
otjc_JSNumber = $rt_classWithoutFields(),
otjc_JSNumber_intValue$static = $this => {
    return $this;
};
function ju_DuplicateFormatFlagsException() {
    ju_IllegalFormatException.call(this);
    this.$flags0 = null;
}
let ju_DuplicateFormatFlagsException__init_ = ($this, $flags) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$2, $rt_s(97)), $flags);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$flags0 = $flags;
},
ju_DuplicateFormatFlagsException__init_0 = var_0 => {
    let var_1 = new ju_DuplicateFormatFlagsException();
    ju_DuplicateFormatFlagsException__init_(var_1, var_0);
    return var_1;
};
function ju_MissingFormatWidthException() {
    ju_IllegalFormatException.call(this);
    this.$formatSpecifier = null;
}
let ju_MissingFormatWidthException__init_0 = ($this, $formatSpecifier) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$2, $rt_s(98)), $formatSpecifier);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$formatSpecifier = $formatSpecifier;
},
ju_MissingFormatWidthException__init_ = var_0 => {
    let var_1 = new ju_MissingFormatWidthException();
    ju_MissingFormatWidthException__init_0(var_1, var_0);
    return var_1;
};
function ju_ArrayDeque$1() {
    let a = this; jl_Object.call(a);
    a.$refVersion = 0;
    a.$index1 = 0;
    a.$lastIndex = 0;
    a.$left = 0;
    a.$this$0 = null;
}
let ju_ArrayDeque$1__init_ = ($this, $this$0) => {
    $this.$this$0 = $this$0;
    jl_Object__init_($this);
    $this.$refVersion = $this.$this$0.$version;
    $this.$index1 = $this.$this$0.$head;
    $this.$lastIndex = (-1);
    $this.$left = $this.$this$0.$size();
},
ju_ArrayDeque$1__init_0 = var_0 => {
    let var_1 = new ju_ArrayDeque$1();
    ju_ArrayDeque$1__init_(var_1, var_0);
    return var_1;
},
ju_ArrayDeque$1_hasNext = $this => {
    return $this.$left <= 0 ? 0 : 1;
},
ju_ArrayDeque$1_next = $this => {
    let var$1, $result;
    var$1 = $this.$left - 1 | 0;
    $this.$left = var$1;
    if (var$1 < 0)
        $rt_throw(ju_NoSuchElementException__init_0());
    if ($this.$this$0.$version > $this.$refVersion)
        $rt_throw(ju_ConcurrentModificationException__init_());
    $this.$lastIndex = $this.$index1;
    $result = $this.$this$0.$array.data[$this.$index1];
    $this.$index1 = ju_ArrayDeque_modInc($this.$index1, $this.$this$0.$array.data.length);
    return $result;
},
ju_ArrayDeque$1_remove = $this => {
    let $toLeft;
    if ($this.$lastIndex < 0)
        $rt_throw(jl_IllegalStateException__init_());
    $toLeft = ju_ArrayDeque_removeAt($this.$this$0, $this.$lastIndex);
    if ($toLeft)
        $this.$index1 = ju_ArrayDeque_modInc($this.$index1, $this.$this$0.$array.data.length);
    $this.$lastIndex = (-1);
},
ju_Set = $rt_classWithoutFields(0);
function rce_Game$TimerTask() {
    let a = this; jl_Object.call(a);
    a.$interval = 0.0;
    a.$action = null;
    a.$recurring = 0;
    a.$elapsed = 0.0;
}
let otjc_JSBoolean = $rt_classWithoutFields(),
jm_Multiplication = $rt_classWithoutFields(),
jm_Multiplication_tenPows = null,
jm_Multiplication_fivePows = null,
jm_Multiplication_bigTenPows = null,
jm_Multiplication_bigFivePows = null,
jm_Multiplication_$callClinit = () => {
    jm_Multiplication_$callClinit = $rt_eraseClinit(jm_Multiplication);
    jm_Multiplication__clinit_();
},
jm_Multiplication_multiply = ($x, $y) => {
    jm_Multiplication_$callClinit();
    return jm_Multiplication_karatsuba($x, $y);
},
jm_Multiplication_karatsuba = ($op1, $op2) => {
    let var$3, $ndiv2, $upperOp1, $upperOp2, $lowerOp1, $lowerOp2, $upper, $lower, $middle, var$12;
    jm_Multiplication_$callClinit();
    if ($op2.$numberLength <= $op1.$numberLength) {
        var$3 = $op2;
        $op2 = $op1;
        $op1 = var$3;
    }
    if ($op1.$numberLength < 63)
        return jm_Multiplication_multiplyPAP($op2, $op1);
    $ndiv2 = ($op2.$numberLength & (-2)) << 4;
    $upperOp1 = $op2.$shiftRight0($ndiv2);
    $upperOp2 = $op1.$shiftRight0($ndiv2);
    $lowerOp1 = $op2.$subtract0($upperOp1.$shiftLeft0($ndiv2));
    $lowerOp2 = $op1.$subtract0($upperOp2.$shiftLeft0($ndiv2));
    $upper = jm_Multiplication_karatsuba($upperOp1, $upperOp2);
    $lower = jm_Multiplication_karatsuba($lowerOp1, $lowerOp2);
    $middle = jm_Multiplication_karatsuba($upperOp1.$subtract0($lowerOp1), $lowerOp2.$subtract0($upperOp2));
    var$3 = ($middle.$add1($upper)).$add1($lower);
    var$3 = var$3.$shiftLeft0($ndiv2);
    var$12 = $upper.$shiftLeft0($ndiv2 << 1);
    return (var$12.$add1(var$3)).$add1($lower);
},
jm_Multiplication_multiplyPAP = ($a, $b) => {
    let $aLen, $bLen, $resLength, $resSign, $aDigits, $bDigits, $resDigits, $result, $val, $valueLo, $valueHi;
    jm_Multiplication_$callClinit();
    $aLen = $a.$numberLength;
    $bLen = $b.$numberLength;
    $resLength = $aLen + $bLen | 0;
    $resSign = $a.$sign == $b.$sign ? 1 : (-1);
    if ($resLength != 2) {
        $aDigits = $a.$digits;
        $bDigits = $b.$digits;
        $resDigits = $rt_createIntArray($resLength);
        jm_Multiplication_multArraysPAP($aDigits, $aLen, $bDigits, $bLen, $resDigits);
        $result = jm_BigInteger__init_($resSign, $resLength, $resDigits);
        jm_BigInteger_cutOffLeadingZeroes($result);
        return $result;
    }
    $val = jm_Multiplication_unsignedMultAddAdd($a.$digits.data[0], $b.$digits.data[0], 0, 0);
    $valueLo = Long_lo($val);
    $valueHi = Long_hi($val);
    return !$valueHi ? jm_BigInteger__init_0($resSign, $valueLo) : jm_BigInteger__init_($resSign, 2, $rt_createIntArrayFromData([$valueLo, $valueHi]));
},
jm_Multiplication_multArraysPAP = ($aDigits, $aLen, $bDigits, $bLen, $resDigits) => {
    jm_Multiplication_$callClinit();
    if ($aLen && $bLen) {
        if ($aLen == 1)
            $resDigits.data[$bLen] = jm_Multiplication_multiplyByInt($resDigits, $bDigits, $bLen, $aDigits.data[0]);
        else if ($bLen != 1)
            jm_Multiplication_multPAP($aDigits, $bDigits, $resDigits, $aLen, $bLen);
        else
            $resDigits.data[$aLen] = jm_Multiplication_multiplyByInt($resDigits, $aDigits, $aLen, $bDigits.data[0]);
        return;
    }
},
jm_Multiplication_multPAP = ($a, $b, $t, $aLen, $bLen) => {
    let $i, var$7, $carry, $aI, $j, var$11, var$12, var$13, var$14;
    jm_Multiplication_$callClinit();
    if ($a === $b && $aLen == $bLen) {
        jm_Multiplication_square($a, $aLen, $t);
        return;
    }
    $i = 0;
    while ($i < $aLen) {
        var$7 = $a.data;
        $carry = Long_ZERO;
        $aI = var$7[$i];
        $j = 0;
        while ($j < $bLen) {
            var$11 = $t.data;
            var$12 = $b.data[$j];
            var$13 = $i + $j | 0;
            var$14 = jm_Multiplication_unsignedMultAddAdd($aI, var$12, var$11[var$13], Long_lo($carry));
            var$11[var$13] = Long_lo(var$14);
            $carry = Long_shru(var$14, 32);
            $j = $j + 1 | 0;
        }
        $t.data[$i + $bLen | 0] = Long_lo($carry);
        $i = $i + 1 | 0;
    }
},
jm_Multiplication_multiplyByInt = ($res, $a, $aSize, $factor) => {
    let $carry, $i, var$7, var$8;
    jm_Multiplication_$callClinit();
    $carry = Long_ZERO;
    $i = 0;
    while ($i < $aSize) {
        var$7 = $res.data;
        var$8 = jm_Multiplication_unsignedMultAddAdd($a.data[$i], $factor, Long_lo($carry), 0);
        var$7[$i] = Long_lo(var$8);
        $carry = Long_shru(var$8, 32);
        $i = $i + 1 | 0;
    }
    return Long_lo($carry);
},
jm_Multiplication_pow = ($acc, $exponent) => {
    let $res, $acc_0, var$5;
    jm_Multiplication_$callClinit();
    jm_BigInteger_$callClinit();
    $res = jm_BigInteger_ONE;
    while ($exponent > 1) {
        if ($exponent & 1)
            $res = $res.$multiply0($acc);
        $acc_0 = $acc.$numberLength == 1 ? $acc.$multiply0($acc) : jm_BigInteger__init_6(1, jm_Multiplication_square($acc.$digits, $acc.$numberLength, $rt_createIntArray($acc.$numberLength << 1)));
        $exponent = $exponent >> 1;
        $acc = $acc_0;
    }
    var$5 = $res.$multiply0($acc);
    return var$5;
},
jm_Multiplication_square = ($a, $aLen, $res) => {
    let $i, $carry, $i_0, $j, var$8, var$9, var$10, var$11, var$12, var$13, $index;
    jm_Multiplication_$callClinit();
    $i = 0;
    while ($i < $aLen) {
        $carry = Long_ZERO;
        $i_0 = $i + 1 | 0;
        $j = $i_0;
        while ($j < $aLen) {
            var$8 = $res.data;
            var$9 = $a.data;
            var$10 = var$9[$i];
            var$11 = var$9[$j];
            var$12 = $i + $j | 0;
            var$13 = jm_Multiplication_unsignedMultAddAdd(var$10, var$11, var$8[var$12], Long_lo($carry));
            var$8[var$12] = Long_lo(var$13);
            $carry = Long_shru(var$13, 32);
            $j = $j + 1 | 0;
        }
        $res.data[$i + $aLen | 0] = Long_lo($carry);
        $i = $i_0;
    }
    jm_BitLevel_shiftLeftOneBit($res, $res, $aLen << 1);
    $carry = Long_ZERO;
    $i = 0;
    $index = 0;
    while ($i < $aLen) {
        var$8 = $res.data;
        var$9 = $a.data;
        var$13 = jm_Multiplication_unsignedMultAddAdd(var$9[$i], var$9[$i], var$8[$index], Long_lo($carry));
        var$8[$index] = Long_lo(var$13);
        var$13 = Long_shru(var$13, 32);
        var$11 = $index + 1 | 0;
        var$13 = Long_add(var$13, Long_and(Long_fromInt(var$8[var$11]), Long_create(4294967295, 0)));
        var$8[var$11] = Long_lo(var$13);
        $carry = Long_shru(var$13, 32);
        $i = $i + 1 | 0;
        $index = var$11 + 1 | 0;
    }
    return $res;
},
jm_Multiplication_powerOf10 = $exp => {
    let $intExp, $byteArraySize, $powerOfFive, $longExp, var$6, var$7, var$8;
    jm_Multiplication_$callClinit();
    $intExp = Long_lo($exp);
    if (Long_lt($exp, Long_fromInt(jm_Multiplication_bigTenPows.data.length)))
        return jm_Multiplication_bigTenPows.data[$intExp];
    if (Long_le($exp, Long_fromInt(50))) {
        jm_BigInteger_$callClinit();
        return jm_BigInteger_TEN.$pow0($intExp);
    }
    if (Long_le($exp, Long_fromInt(1000)))
        return (jm_Multiplication_bigFivePows.data[1].$pow0($intExp)).$shiftLeft0($intExp);
    $byteArraySize = Long_add(Long_fromInt(1), Long_fromNumber(Long_toNumber($exp) / 2.4082399653118496));
    if (Long_gt($byteArraySize, Long_fromInt(1000000)))
        $rt_throw(jl_ArithmeticException__init_($rt_s(99)));
    if (Long_le($exp, Long_fromInt(2147483647)))
        return (jm_Multiplication_bigFivePows.data[1].$pow0($intExp)).$shiftLeft0($intExp);
    $powerOfFive = jm_Multiplication_bigFivePows.data[1].$pow0(2147483647);
    $longExp = Long_sub($exp, Long_fromInt(2147483647));
    var$6 = Long_lo(Long_rem($exp, Long_fromInt(2147483647)));
    var$7 = $powerOfFive;
    var$8 = $longExp;
    while (Long_gt(var$8, Long_fromInt(2147483647))) {
        var$7 = var$7.$multiply0($powerOfFive);
        var$8 = Long_sub(var$8, Long_fromInt(2147483647));
    }
    var$7 = var$7.$multiply0(jm_Multiplication_bigFivePows.data[1].$pow0(var$6));
    var$7 = var$7.$shiftLeft0(2147483647);
    while (Long_gt($longExp, Long_fromInt(2147483647))) {
        var$7 = var$7.$shiftLeft0(2147483647);
        $longExp = Long_sub($longExp, Long_fromInt(2147483647));
    }
    var$7 = var$7.$shiftLeft0(var$6);
    return var$7;
},
jm_Multiplication_unsignedMultAddAdd = ($a, $b, $c, $d) => {
    jm_Multiplication_$callClinit();
    return Long_add(Long_add(Long_mul(Long_and(Long_fromInt($a), Long_create(4294967295, 0)), Long_and(Long_fromInt($b), Long_create(4294967295, 0))), Long_and(Long_fromInt($c), Long_create(4294967295, 0))), Long_and(Long_fromInt($d), Long_create(4294967295, 0)));
},
jm_Multiplication__clinit_ = () => {
    let $fivePow, $i, var$3, var$4, var$5;
    jm_Multiplication_tenPows = $rt_createIntArrayFromData([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]);
    jm_Multiplication_fivePows = $rt_createIntArrayFromData([1, 5, 25, 125, 625, 3125, 15625, 78125, 390625, 1953125, 9765625, 48828125, 244140625, 1220703125]);
    jm_Multiplication_bigTenPows = $rt_createArray(jm_BigInteger, 32);
    jm_Multiplication_bigFivePows = $rt_createArray(jm_BigInteger, 32);
    $fivePow = Long_fromInt(1);
    $i = 0;
    while ($i <= 18) {
        jm_Multiplication_bigFivePows.data[$i] = jm_BigInteger_valueOf($fivePow);
        jm_Multiplication_bigTenPows.data[$i] = jm_BigInteger_valueOf(Long_shl($fivePow, $i));
        $fivePow = Long_mul($fivePow, Long_fromInt(5));
        $i = $i + 1 | 0;
    }
    while ($i < jm_Multiplication_bigTenPows.data.length) {
        var$3 = jm_Multiplication_bigFivePows.data;
        var$4 = jm_Multiplication_bigFivePows.data;
        var$5 = $i - 1 | 0;
        var$3[$i] = var$4[var$5].$multiply0(jm_Multiplication_bigFivePows.data[1]);
        jm_Multiplication_bigTenPows.data[$i] = jm_Multiplication_bigTenPows.data[var$5].$multiply0(jm_BigInteger_TEN);
        $i = $i + 1 | 0;
    }
};
function jl_Double() {
    jl_Number.call(this);
    this.$value = 0.0;
}
let jl_Double_TYPE = null,
jl_Double_$callClinit = () => {
    jl_Double_$callClinit = $rt_eraseClinit(jl_Double);
    jl_Double__clinit_();
},
jl_Double__init_ = ($this, $value) => {
    jl_Double_$callClinit();
    jl_Number__init_($this);
    $this.$value = $value;
},
jl_Double__init_0 = var_0 => {
    let var_1 = new jl_Double();
    jl_Double__init_(var_1, var_0);
    return var_1;
},
jl_Double_doubleValue = $this => {
    return $this.$value;
},
jl_Double_intValue = $this => {
    return $this.$value | 0;
},
jl_Double_longValue = $this => {
    return Long_fromNumber($this.$value);
},
jl_Double_valueOf = $d => {
    jl_Double_$callClinit();
    return jl_Double__init_0($d);
},
jl_Double_toString = $d => {
    jl_Double_$callClinit();
    return ((jl_StringBuilder__init_()).$append21($d)).$toString();
},
jl_Double_toString0 = $this => {
    return jl_Double_toString($this.$value);
},
jl_Double_equals0 = ($this, $other) => {
    if ($this === $other)
        return 1;
    return $other instanceof jl_Double && jl_Double_equals($this.$value, $other.$value) ? 1 : 0;
},
jl_Double_equals = ($a, $b) => {
    jl_Double_$callClinit();
    return $rt_equalDoubles($a, $b);
},
jl_Double_hashCode = $this => {
    return jl_Double_hashCode0($this.$value);
},
jl_Double_hashCode0 = $d => {
    let $h;
    jl_Double_$callClinit();
    $h = jl_Double_doubleToLongBits($d);
    return Long_hi($h) ^ Long_lo($h);
},
jl_Double_compare = ($a, $b) => {
    let $diff, var$4, var$5, var$6;
    jl_Double_$callClinit();
    $diff = ($a <= $b ? 0 : 1) - ($b <= $a ? 0 : 1) | 0;
    if (!$diff) {
        var$4 = 1.0 / $a;
        var$5 = 1.0 / $b;
        var$6 = (var$4 <= var$5 ? 0 : 1) - (var$5 <= var$4 ? 0 : 1) | 0;
        $diff = (var$6 + ($b !== $b ? 0 : 1) | 0) - ($a !== $a ? 0 : 1) | 0;
    }
    return $diff;
},
jl_Double_compareTo0 = ($this, $other) => {
    return jl_Double_compare($this.$value, $other.$value);
},
jl_Double_doubleToLongBits = $value => {
    jl_Double_$callClinit();
    if (!(isNaN($value) ? 1 : 0))
        return $rt_doubleToRawLongBits($value);
    return Long_create(0, 2146959360);
},
jl_Double_compareTo = ($this, var$1) => {
    return $this.$compareTo5(var$1);
},
jl_Double__clinit_ = () => {
    jl_Double_TYPE = $rt_cls($rt_doublecls);
},
jm_Elementary = $rt_classWithoutFields(),
jm_Elementary_compareArrays = ($a, $b, $size) => {
    let $i, var$5, var$6, var$7;
    $i = $size - 1 | 0;
    while ($i >= 0) {
        var$5 = $b.data;
        if ($a.data[$i] != var$5[$i])
            break;
        $i = $i + (-1) | 0;
    }
    if ($i < 0)
        var$6 = 0;
    else {
        var$7 = $b.data;
        var$6 = Long_ge(Long_and(Long_fromInt($a.data[$i]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$7[$i]), Long_create(4294967295, 0))) ? 1 : (-1);
    }
    return var$6;
},
jm_Elementary_add1 = ($op1, $op2) => {
    let $op1Sign, $op2Sign, $op1Len, $op2Len, $a, $b, $res, $valueLo, $valueHi, $resDigits, var$13, $cmp, var$15, $res_0;
    $op1Sign = $op1.$sign;
    $op2Sign = $op2.$sign;
    if (!$op1Sign)
        return $op2;
    if (!$op2Sign)
        return $op1;
    $op1Len = $op1.$numberLength;
    $op2Len = $op2.$numberLength;
    if (($op1Len + $op2Len | 0) == 2) {
        $a = Long_and(Long_fromInt($op1.$digits.data[0]), Long_create(4294967295, 0));
        $b = Long_and(Long_fromInt($op2.$digits.data[0]), Long_create(4294967295, 0));
        if ($op1Sign != $op2Sign)
            return jm_BigInteger_valueOf($op1Sign >= 0 ? Long_sub($a, $b) : Long_sub($b, $a));
        $res = Long_add($a, $b);
        $valueLo = Long_lo($res);
        $valueHi = Long_hi($res);
        return !$valueHi ? jm_BigInteger__init_0($op1Sign, $valueLo) : jm_BigInteger__init_($op1Sign, 2, $rt_createIntArrayFromData([$valueLo, $valueHi]));
    }
    if ($op1Sign == $op2Sign)
        $resDigits = $op1Len < $op2Len ? jm_Elementary_add($op2.$digits, $op2Len, $op1.$digits, $op1Len) : jm_Elementary_add($op1.$digits, $op1Len, $op2.$digits, $op2Len);
    else {
        var$13 = $rt_compare($op1Len, $op2Len);
        $cmp = !var$13 ? jm_Elementary_compareArrays($op1.$digits, $op2.$digits, $op1Len) : var$13 <= 0 ? (-1) : 1;
        if (!$cmp) {
            jm_BigInteger_$callClinit();
            return jm_BigInteger_ZERO;
        }
        if ($cmp != 1) {
            $resDigits = jm_Elementary_subtract($op2.$digits, $op2Len, $op1.$digits, $op1Len);
            $op1Sign = $op2Sign;
        } else
            $resDigits = jm_Elementary_subtract($op1.$digits, $op1Len, $op2.$digits, $op2Len);
    }
    var$15 = $resDigits.data;
    $res_0 = jm_BigInteger__init_($op1Sign, var$15.length, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($res_0);
    return $res_0;
},
jm_Elementary_add0 = ($res, $a, $aSize, $b, $bSize) => {
    let var$6, var$7, var$8, $carry, var$10, $i, var$12;
    var$6 = $res.data;
    var$7 = $b.data;
    var$8 = $a.data;
    $carry = Long_add(Long_and(Long_fromInt(var$8[0]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$7[0]), Long_create(4294967295, 0)));
    var$6[0] = Long_lo($carry);
    var$10 = Long_shr($carry, 32);
    if ($aSize < $bSize) {
        $i = 1;
        while ($i < $aSize) {
            var$12 = Long_add(var$10, Long_add(Long_and(Long_fromInt(var$8[$i]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$7[$i]), Long_create(4294967295, 0))));
            var$6[$i] = Long_lo(var$12);
            var$10 = Long_shr(var$12, 32);
            $i = $i + 1 | 0;
        }
        while ($i < $bSize) {
            var$12 = Long_add(var$10, Long_and(Long_fromInt(var$7[$i]), Long_create(4294967295, 0)));
            var$6[$i] = Long_lo(var$12);
            var$10 = Long_shr(var$12, 32);
            $i = $i + 1 | 0;
        }
    } else {
        $i = 1;
        while ($i < $bSize) {
            var$12 = Long_add(var$10, Long_add(Long_and(Long_fromInt(var$8[$i]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$7[$i]), Long_create(4294967295, 0))));
            var$6[$i] = Long_lo(var$12);
            var$10 = Long_shr(var$12, 32);
            $i = $i + 1 | 0;
        }
        while ($i < $aSize) {
            var$12 = Long_add(var$10, Long_and(Long_fromInt(var$8[$i]), Long_create(4294967295, 0)));
            var$6[$i] = Long_lo(var$12);
            var$10 = Long_shr(var$12, 32);
            $i = $i + 1 | 0;
        }
    }
    if (Long_ne(var$10, Long_ZERO))
        var$6[$i] = Long_lo(var$10);
},
jm_Elementary_subtract0 = ($op1, $op2) => {
    let $op1Sign, $op2Sign, $op1Len, $op2Len, $a, $b, var$9, $cmp, $resSign, $resDigits, var$13, $res;
    $op1Sign = $op1.$sign;
    $op2Sign = $op2.$sign;
    if (!$op2Sign)
        return $op1;
    if (!$op1Sign)
        return $op2.$negate();
    $op1Len = $op1.$numberLength;
    $op2Len = $op2.$numberLength;
    if (($op1Len + $op2Len | 0) == 2) {
        $a = Long_and(Long_fromInt($op1.$digits.data[0]), Long_create(4294967295, 0));
        $b = Long_and(Long_fromInt($op2.$digits.data[0]), Long_create(4294967295, 0));
        if ($op1Sign < 0)
            $a = Long_neg($a);
        if ($op2Sign < 0)
            $b = Long_neg($b);
        return jm_BigInteger_valueOf(Long_sub($a, $b));
    }
    var$9 = $rt_compare($op1Len, $op2Len);
    $cmp = !var$9 ? jm_Elementary_compareArrays($op1.$digits, $op2.$digits, $op1Len) : var$9 <= 0 ? (-1) : 1;
    if ($cmp == (-1)) {
        $resSign =  -$op2Sign | 0;
        $resDigits = $op1Sign != $op2Sign ? jm_Elementary_add($op2.$digits, $op2Len, $op1.$digits, $op1Len) : jm_Elementary_subtract($op2.$digits, $op2Len, $op1.$digits, $op1Len);
    } else if ($op1Sign != $op2Sign) {
        $resDigits = jm_Elementary_add($op1.$digits, $op1Len, $op2.$digits, $op2Len);
        $resSign = $op1Sign;
    } else {
        if (!$cmp) {
            jm_BigInteger_$callClinit();
            return jm_BigInteger_ZERO;
        }
        $resDigits = jm_Elementary_subtract($op1.$digits, $op1Len, $op2.$digits, $op2Len);
        $resSign = $op1Sign;
    }
    var$13 = $resDigits.data;
    $res = jm_BigInteger__init_($resSign, var$13.length, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($res);
    return $res;
},
jm_Elementary_subtract1 = ($res, $a, $aSize, $b, $bSize) => {
    let $borrow, $i, var$8, var$9, var$10;
    $borrow = Long_ZERO;
    $i = 0;
    while ($i < $bSize) {
        var$8 = $res.data;
        var$9 = $b.data;
        var$10 = Long_add($borrow, Long_sub(Long_and(Long_fromInt($a.data[$i]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$9[$i]), Long_create(4294967295, 0))));
        var$8[$i] = Long_lo(var$10);
        $borrow = Long_shr(var$10, 32);
        $i = $i + 1 | 0;
    }
    while ($i < $aSize) {
        var$9 = $res.data;
        var$10 = Long_add($borrow, Long_and(Long_fromInt($a.data[$i]), Long_create(4294967295, 0)));
        var$9[$i] = Long_lo(var$10);
        $borrow = Long_shr(var$10, 32);
        $i = $i + 1 | 0;
    }
},
jm_Elementary_add = ($a, $aSize, $b, $bSize) => {
    let $res;
    $res = $rt_createIntArray($aSize + 1 | 0);
    jm_Elementary_add0($res, $a, $aSize, $b, $bSize);
    return $res;
},
jm_Elementary_subtract = ($a, $aSize, $b, $bSize) => {
    let $res;
    $res = $rt_createIntArray($aSize);
    jm_Elementary_subtract1($res, $a, $aSize, $b, $bSize);
    return $res;
},
jl_Error = $rt_classWithoutFields(jl_Throwable),
jl_Error__init_ = ($this, $message, $cause) => {
    jl_Throwable__init_1($this, $message, $cause);
},
jl_Error__init_0 = (var_0, var_1) => {
    let var_2 = new jl_Error();
    jl_Error__init_(var_2, var_0, var_1);
    return var_2;
};
function ju_FormatFlagsConversionMismatchException() {
    let a = this; ju_IllegalFormatException.call(a);
    a.$flags1 = null;
    a.$conversion0 = 0;
}
let ju_FormatFlagsConversionMismatchException__init_ = ($this, $flags, $conversion) => {
    let var$3;
    var$3 = jl_StringBuilder__init_();
    jl_StringBuilder_append1(jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append(var$3, $rt_s(100)), $flags), $rt_s(101)), $conversion);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$3));
    $this.$flags1 = $flags;
    $this.$conversion0 = $conversion;
},
ju_FormatFlagsConversionMismatchException__init_0 = (var_0, var_1) => {
    let var_2 = new ju_FormatFlagsConversionMismatchException();
    ju_FormatFlagsConversionMismatchException__init_(var_2, var_0, var_1);
    return var_2;
},
jl_AssertionError = $rt_classWithoutFields(jl_Error),
jl_AssertionError__init_ = ($this, $message, $cause) => {
    jl_Error__init_($this, $message, $cause);
},
jl_AssertionError__init_0 = (var_0, var_1) => {
    let var_2 = new jl_AssertionError();
    jl_AssertionError__init_(var_2, var_0, var_1);
    return var_2;
};
function rce_Game$launch$lambda$_36_0() {
    jl_Object.call(this);
    this.$_0 = null;
}
let rce_Game$launch$lambda$_36_0__init_ = (var$0, var$1) => {
    jl_Object__init_(var$0);
    var$0.$_0 = var$1;
},
rce_Game$launch$lambda$_36_0__init_0 = var_0 => {
    let var_1 = new rce_Game$launch$lambda$_36_0();
    rce_Game$launch$lambda$_36_0__init_(var_1, var_0);
    return var_1;
},
rce_Game$launch$lambda$_36_0_onKey = (var$0, var$1, var$2) => {
    rce_Game_lambda$launch$3(var$0.$_0, var$1, var$2);
},
rce_Game$launch$lambda$_36_0_onKey$exported$0 = (var$0, var$1, var$2) => {
    var$0.$onKey($rt_str(var$1), $rt_str(var$2));
},
ju_List = $rt_classWithoutFields(0);
function ju_AbstractList() {
    ju_AbstractCollection.call(this);
    this.$modCount = 0;
}
let ju_AbstractList__init_ = $this => {
    ju_AbstractCollection__init_($this);
},
ju_AbstractList_iterator = $this => {
    return ju_AbstractList$1__init_0($this);
},
ju_AbstractList_equals = ($this, $other) => {
    let $list, $i;
    if (!$rt_isInstance($other, ju_List))
        return 0;
    $list = $other;
    if ($this.$size() != $list.$size())
        return 0;
    $i = 0;
    while ($i < $list.$size()) {
        if (!ju_Objects_equals($this.$get0($i), $list.$get0($i)))
            return 0;
        $i = $i + 1 | 0;
    }
    return 1;
},
ju_RandomAccess = $rt_classWithoutFields(0);
function ju_ArrayList() {
    let a = this; ju_AbstractList.call(a);
    a.$array0 = null;
    a.$size0 = 0;
}
let ju_ArrayList__init_2 = $this => {
    ju_ArrayList__init_0($this, 10);
},
ju_ArrayList__init_ = () => {
    let var_0 = new ju_ArrayList();
    ju_ArrayList__init_2(var_0);
    return var_0;
},
ju_ArrayList__init_0 = ($this, $initialCapacity) => {
    ju_AbstractList__init_($this);
    if ($initialCapacity >= 0) {
        $this.$array0 = $rt_createArray(jl_Object, $initialCapacity);
        return;
    }
    $rt_throw(jl_IllegalArgumentException__init_0());
},
ju_ArrayList__init_4 = var_0 => {
    let var_1 = new ju_ArrayList();
    ju_ArrayList__init_0(var_1, var_0);
    return var_1;
},
ju_ArrayList__init_1 = ($this, $c) => {
    let $iter, $i;
    ju_ArrayList__init_0($this, $c.$size());
    $iter = $c.$iterator();
    $i = 0;
    while ($i < $this.$array0.data.length) {
        $this.$array0.data[$i] = $iter.$next();
        $i = $i + 1 | 0;
    }
    $this.$size0 = $this.$array0.data.length;
},
ju_ArrayList__init_3 = var_0 => {
    let var_1 = new ju_ArrayList();
    ju_ArrayList__init_1(var_1, var_0);
    return var_1;
},
ju_ArrayList_ensureCapacity = ($this, $minCapacity) => {
    let $newLength;
    if ($this.$array0.data.length < $minCapacity) {
        $newLength = $this.$array0.data.length >= 1073741823 ? 2147483647 : jl_Math_max($minCapacity, jl_Math_max($this.$array0.data.length * 2 | 0, 5));
        $this.$array0 = ju_Arrays_copyOf0($this.$array0, $newLength);
    }
},
ju_ArrayList_get = ($this, $index) => {
    ju_ArrayList_checkIndex($this, $index);
    return $this.$array0.data[$index];
},
ju_ArrayList_size = $this => {
    return $this.$size0;
},
ju_ArrayList_add = ($this, $element) => {
    let var$2, var$3;
    $this.$ensureCapacity($this.$size0 + 1 | 0);
    var$2 = $this.$array0.data;
    var$3 = $this.$size0;
    $this.$size0 = var$3 + 1 | 0;
    var$2[var$3] = $element;
    $this.$modCount = $this.$modCount + 1 | 0;
    return 1;
},
ju_ArrayList_remove = ($this, $i) => {
    let $old, var$3, var$4, $i_0;
    ju_ArrayList_checkIndex($this, $i);
    $old = $this.$array0.data[$i];
    $this.$size0 = $this.$size0 - 1 | 0;
    while ($i < $this.$size0) {
        var$3 = $this.$array0.data;
        var$4 = $this.$array0.data;
        $i_0 = $i + 1 | 0;
        var$3[$i] = var$4[$i_0];
        $i = $i_0;
    }
    $this.$array0.data[$this.$size0] = null;
    $this.$modCount = $this.$modCount + 1 | 0;
    return $old;
},
ju_ArrayList_clear = $this => {
    ju_Arrays_fill($this.$array0, 0, $this.$size0, null);
    $this.$size0 = 0;
    $this.$modCount = $this.$modCount + 1 | 0;
},
ju_ArrayList_checkIndex = ($this, $index) => {
    if ($index >= 0 && $index < $this.$size0)
        return;
    $rt_throw(jl_IndexOutOfBoundsException__init_());
},
ju_ArrayList_toString = $this => {
    let $length, $buffer, $i;
    if (!$this.$size0)
        return $rt_s(102);
    $length = $this.$size0 - 1 | 0;
    $buffer = jl_StringBuilder__init_0($this.$size0 * 16 | 0);
    $buffer.$append0(91);
    $i = 0;
    while ($i < $length) {
        ($buffer.$append($this.$array0.data[$i] === $this ? $rt_s(17) : $this.$array0.data[$i])).$append19($rt_s(18));
        $i = $i + 1 | 0;
    }
    $buffer.$append($this.$array0.data[$length] === $this ? $rt_s(17) : $this.$array0.data[$length]);
    return ($buffer.$append0(93)).$toString();
},
ju_ArrayList_hashCode = $this => {
    let $result, $i;
    $result = 1;
    $i = 0;
    while ($i < $this.$size0) {
        $result = (31 * $result | 0) + ju_Objects_hashCode($this.$array0.data[$i]) | 0;
        $i = $i + 1 | 0;
    }
    return $result;
},
ju_ArrayList_sort = ($this, $comp) => {
    ju_Arrays_sort($this.$array0, 0, $this.$size0, $comp);
    $this.$modCount = $this.$modCount + 1 | 0;
};
function rceh_VirtualGamepad() {
    jl_Object.call(this);
    this.$register = null;
}
let rceh_VirtualGamepad__init_ = $this => {
    jl_Object__init_($this);
    $this.$register = rceh_KeyRegister__init_0();
},
rceh_VirtualGamepad__init_0 = () => {
    let var_0 = new rceh_VirtualGamepad();
    rceh_VirtualGamepad__init_(var_0);
    return var_0;
},
rceh_VirtualGamepad_onKeyDown = ($this, $key) => {
    $this.$register.$setKeyPressed($key, 1);
},
rceh_VirtualGamepad_onKeyUp = ($this, $key) => {
    $this.$register.$setKeyPressed($key, 0);
},
rceh_VirtualGamepad_isPressed = ($this, $key) => {
    return $this.$register.$isPressed($key);
},
jl_IllegalMonitorStateException = $rt_classWithoutFields(jl_RuntimeException),
jl_IllegalMonitorStateException__init_ = $this => {
    jl_RuntimeException__init_($this);
},
jl_IllegalMonitorStateException__init_0 = () => {
    let var_0 = new jl_IllegalMonitorStateException();
    jl_IllegalMonitorStateException__init_(var_0);
    return var_0;
},
jm_Division = $rt_classWithoutFields(),
jm_Division_divide = ($quot, $quotLength, $a, $j, $b, $bLength) => {
    let var$7, $normA, $normB, var$10, $divisorShift, var$12, $firstDivisorDigit, $i, var$15, $product, $res, $rem, $rOverflowed, var$20, var$21, var$22, $longR, var$24, $borrow, $carry, $k;
    var$7 = $b.data;
    $normA = $rt_createIntArray($j + 1 | 0);
    $normB = $rt_createIntArray($bLength + 1 | 0);
    var$10 = $bLength - 1 | 0;
    $divisorShift = jl_Integer_numberOfLeadingZeros(var$7[var$10]);
    if ($divisorShift) {
        jm_BitLevel_shiftLeft($normB, $b, 0, $divisorShift);
        jm_BitLevel_shiftLeft($normA, $a, 0, $divisorShift);
    } else {
        jl_System_fastArraycopy($a, 0, $normA, 0, $j);
        jl_System_fastArraycopy($b, 0, $normB, 0, $bLength);
    }
    var$12 = $normB.data;
    $firstDivisorDigit = var$12[var$10];
    $i = $quotLength - 1 | 0;
    while ($i >= 0) {
        a: {
            var$7 = $normA.data;
            if (var$7[$j] == $firstDivisorDigit)
                var$15 = (-1);
            else {
                $product = Long_add(Long_shl(Long_and(Long_fromInt(var$7[$j]), Long_create(4294967295, 0)), 32), Long_and(Long_fromInt(var$7[$j - 1 | 0]), Long_create(4294967295, 0)));
                $res = jm_Division_divideLongByInt($product, $firstDivisorDigit);
                var$15 = Long_lo($res);
                $rem = Long_hi($res);
                if (var$15) {
                    $rOverflowed = 0;
                    var$15 = var$15 + 1 | 0;
                    while (true) {
                        var$15 = var$15 + (-1) | 0;
                        if ($rOverflowed)
                            break;
                        var$20 = Long_mul(Long_and(Long_fromInt(var$15), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$12[$bLength - 2 | 0]), Long_create(4294967295, 0)));
                        var$21 = Long_fromInt($rem);
                        var$22 = Long_add(Long_shl(var$21, 32), Long_and(Long_fromInt(var$7[$j - 2 | 0]), Long_create(4294967295, 0)));
                        $longR = Long_add(Long_and(var$21, Long_create(4294967295, 0)), Long_and(Long_fromInt($firstDivisorDigit), Long_create(4294967295, 0)));
                        if (jl_Integer_numberOfLeadingZeros(Long_hi($longR)) >= 32)
                            $rem = Long_lo($longR);
                        else
                            $rOverflowed = 1;
                        if (Long_le(Long_xor(var$20, Long_create(0, 2147483648)), Long_xor(var$22, Long_create(0, 2147483648))))
                            break a;
                    }
                }
            }
        }
        if (var$15) {
            var$24 = $j - $bLength | 0;
            $borrow = jm_Division_multiplyAndSubtract($normA, var$24, $normB, $bLength, var$15);
            if ($borrow) {
                var$15 = var$15 + (-1) | 0;
                $carry = Long_ZERO;
                $k = 0;
                while ($k < $bLength) {
                    var$10 = var$24 + $k | 0;
                    var$21 = Long_add($carry, Long_add(Long_and(Long_fromInt(var$7[var$10]), Long_create(4294967295, 0)), Long_and(Long_fromInt(var$12[$k]), Long_create(4294967295, 0))));
                    var$7[var$10] = Long_lo(var$21);
                    $carry = Long_shru(var$21, 32);
                    $k = $k + 1 | 0;
                }
            }
        }
        if ($quot !== null)
            $quot.data[$i] = var$15;
        $j = $j + (-1) | 0;
        $i = $i + (-1) | 0;
    }
    if ($divisorShift) {
        jm_BitLevel_shiftRight0($normB, $bLength, $normA, 0, $divisorShift);
        return $normB;
    }
    jl_System_fastArraycopy($normA, 0, $normB, 0, $bLength);
    return $normA;
},
jm_Division_divideArrayByInt = ($dest, $src, $srcLength, $divisor) => {
    let $rem, $bLong, $i, var$8, $temp, $quot, $aPos, $bPos, var$13;
    $rem = Long_ZERO;
    $bLong = Long_and(Long_fromInt($divisor), Long_create(4294967295, 0));
    $i = $srcLength - 1 | 0;
    while ($i >= 0) {
        var$8 = $src.data;
        $temp = Long_or(Long_shl($rem, 32), Long_and(Long_fromInt(var$8[$i]), Long_create(4294967295, 0)));
        if (Long_ge($temp, Long_ZERO)) {
            $quot = Long_div($temp, $bLong);
            $rem = Long_rem($temp, $bLong);
        } else {
            $aPos = Long_shru($temp, 1);
            $bPos = Long_fromInt($divisor >>> 1 | 0);
            $quot = Long_div($aPos, $bPos);
            var$13 = Long_rem($aPos, $bPos);
            $rem = Long_add(Long_shl(var$13, 1), Long_and($temp, Long_fromInt(1)));
            if ($divisor & 1) {
                if (Long_le($quot, $rem))
                    $rem = Long_sub($rem, $quot);
                else if (Long_le(Long_sub($quot, $rem), $bLong)) {
                    $rem = Long_add($rem, Long_sub($bLong, $quot));
                    $quot = Long_sub($quot, Long_fromInt(1));
                } else {
                    $rem = Long_add($rem, Long_sub(Long_shl($bLong, 1), $quot));
                    $quot = Long_sub($quot, Long_fromInt(2));
                }
            }
        }
        $dest.data[$i] = Long_lo(Long_and($quot, Long_create(4294967295, 0)));
        $i = $i + (-1) | 0;
    }
    return Long_lo($rem);
},
jm_Division_remainderArrayByInt = ($src, $srcLength, $divisor) => {
    let $result, $i, var$6, $temp, $res;
    $result = Long_ZERO;
    $i = $srcLength - 1 | 0;
    while ($i >= 0) {
        var$6 = $src.data;
        $temp = Long_add(Long_shl($result, 32), Long_and(Long_fromInt(var$6[$i]), Long_create(4294967295, 0)));
        $res = jm_Division_divideLongByInt($temp, $divisor);
        $result = Long_fromInt(Long_hi($res));
        $i = $i + (-1) | 0;
    }
    return Long_lo($result);
},
jm_Division_divideLongByInt = ($a, $b) => {
    let $bLong, $quot, $rem, $aPos, $bPos;
    $bLong = Long_and(Long_fromInt($b), Long_create(4294967295, 0));
    if (Long_ge($a, Long_ZERO)) {
        $quot = Long_div($a, $bLong);
        $rem = Long_rem($a, $bLong);
    } else {
        $aPos = Long_shru($a, 1);
        $bPos = Long_fromInt($b >>> 1 | 0);
        $quot = Long_div($aPos, $bPos);
        $rem = Long_rem($aPos, $bPos);
        $rem = Long_add(Long_shl($rem, 1), Long_and($a, Long_fromInt(1)));
        if ($b & 1) {
            if (Long_le($quot, $rem))
                $rem = Long_sub($rem, $quot);
            else if (Long_le(Long_sub($quot, $rem), $bLong)) {
                $rem = Long_add($rem, Long_sub($bLong, $quot));
                $quot = Long_sub($quot, Long_fromInt(1));
            } else {
                $rem = Long_add($rem, Long_sub(Long_shl($bLong, 1), $quot));
                $quot = Long_sub($quot, Long_fromInt(2));
            }
        }
    }
    return Long_or(Long_shl($rem, 32), Long_and($quot, Long_create(4294967295, 0)));
},
jm_Division_divideAndRemainderByInteger = ($val, $divisor, $divisorSign) => {
    let $valDigits, $valLen, $valSign, $quotientSign, $quotientDigits, $remainderDigits, $result0, $result1, $a, $b, $quo, $rem, var$16, var$17;
    $valDigits = $val.$digits;
    $valLen = $val.$numberLength;
    $valSign = $val.$sign;
    if ($valLen != 1) {
        $quotientSign = $valSign != $divisorSign ? (-1) : 1;
        $quotientDigits = $rt_createIntArray($valLen);
        $remainderDigits = $rt_createIntArray(1);
        $remainderDigits.data[0] = jm_Division_divideArrayByInt($quotientDigits, $valDigits, $valLen, $divisor);
        $result0 = jm_BigInteger__init_($quotientSign, $valLen, $quotientDigits);
        $result1 = jm_BigInteger__init_($valSign, 1, $remainderDigits);
        jm_BigInteger_cutOffLeadingZeroes($result0);
        jm_BigInteger_cutOffLeadingZeroes($result1);
        return $rt_wrapArray(jm_BigInteger, [$result0, $result1]);
    }
    $a = Long_and(Long_fromInt($valDigits.data[0]), Long_create(4294967295, 0));
    $b = Long_and(Long_fromInt($divisor), Long_create(4294967295, 0));
    $quo = Long_div($a, $b);
    $rem = Long_rem($a, $b);
    if ($valSign != $divisorSign)
        $quo = Long_neg($quo);
    if ($valSign < 0)
        $rem = Long_neg($rem);
    var$16 = $rt_createArray(jm_BigInteger, 2);
    var$17 = var$16.data;
    var$17[0] = jm_BigInteger_valueOf($quo);
    var$17[1] = jm_BigInteger_valueOf($rem);
    return var$16;
},
jm_Division_multiplyAndSubtract = ($a, $start, $b, $bLen, $c) => {
    let $carry0, $carry1, $i, var$9, var$10, var$11, var$12, var$13, var$14;
    $carry0 = Long_ZERO;
    $carry1 = Long_ZERO;
    $i = 0;
    while ($i < $bLen) {
        var$9 = $a.data;
        var$10 = jm_Multiplication_unsignedMultAddAdd($b.data[$i], $c, Long_lo($carry0), 0);
        var$11 = $start + $i | 0;
        var$12 = Long_add(Long_sub(Long_and(Long_fromInt(var$9[var$11]), Long_create(4294967295, 0)), Long_and(var$10, Long_create(4294967295, 0))), $carry1);
        var$9[var$11] = Long_lo(var$12);
        $carry1 = Long_shr(var$12, 32);
        $carry0 = Long_shru(var$10, 32);
        $i = $i + 1 | 0;
    }
    var$13 = $a.data;
    var$14 = $start + $bLen | 0;
    var$12 = Long_add(Long_sub(Long_and(Long_fromInt(var$13[var$14]), Long_create(4294967295, 0)), $carry0), $carry1);
    var$13[var$14] = Long_lo(var$12);
    return Long_hi(var$12);
},
jm_BitLevel = $rt_classWithoutFields(),
jm_BitLevel_bitLength = $val => {
    let $bLength, $highDigit, $i, var$5;
    if (!$val.$sign)
        return 0;
    $bLength = $val.$numberLength << 5;
    $highDigit = $val.$digits.data[$val.$numberLength - 1 | 0];
    if ($val.$sign < 0) {
        $i = $val.$getFirstNonzeroDigit();
        if ($i == ($val.$numberLength - 1 | 0))
            $highDigit = $highDigit + (-1) | 0;
    }
    var$5 = $bLength - jl_Integer_numberOfLeadingZeros($highDigit) | 0;
    return var$5;
},
jm_BitLevel_nonZeroDroppedBits = ($numberOfBits, $digits) => {
    let $intCount, $bitCount, $i, var$6;
    $intCount = $numberOfBits >> 5;
    $bitCount = $numberOfBits & 31;
    $i = 0;
    while (true) {
        var$6 = $rt_compare($i, $intCount);
        if (var$6 >= 0)
            break;
        if ($digits.data[$i])
            break;
        $i = $i + 1 | 0;
    }
    return !var$6 && !($digits.data[$i] << (32 - $bitCount | 0)) ? 0 : 1;
},
jm_BitLevel_shiftLeft0 = ($source, $count) => {
    let $intCount, var$4, $resLength, $resDigits, $result;
    $intCount = $count >> 5;
    var$4 = $count & 31;
    $resLength = ($source.$numberLength + $intCount | 0) + (var$4 ? 1 : 0) | 0;
    $resDigits = $rt_createIntArray($resLength);
    jm_BitLevel_shiftLeft($resDigits, $source.$digits, $intCount, var$4);
    $result = jm_BigInteger__init_($source.$sign, $resLength, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($result);
    return $result;
},
jm_BitLevel_shiftLeft = ($result, $source, $intCount, $count) => {
    let var$5, $rightShiftCount, $i, var$8, var$9, var$10;
    a: {
        if (!$count)
            jl_System_fastArraycopy($source, 0, $result, $intCount, $result.data.length - $intCount | 0);
        else {
            var$5 = $result.data;
            $rightShiftCount = 32 - $count | 0;
            $i = var$5.length - 1 | 0;
            var$5[$i] = 0;
            while (true) {
                if ($i <= $intCount)
                    break a;
                var$8 = $source.data;
                var$9 = var$5[$i];
                var$10 = ($i - $intCount | 0) - 1 | 0;
                var$5[$i] = var$9 | (var$8[var$10] >>> $rightShiftCount | 0);
                var$5[$i - 1 | 0] = var$8[var$10] << $count;
                $i = $i + (-1) | 0;
            }
        }
    }
    $i = 0;
    while ($i < $intCount) {
        $result.data[$i] = 0;
        $i = $i + 1 | 0;
    }
},
jm_BitLevel_shiftLeftOneBit = ($result, $source, $srcLen) => {
    let $carry, $i, var$6, $val;
    $carry = 0;
    $i = 0;
    while ($i < $srcLen) {
        var$6 = $result.data;
        $val = $source.data[$i];
        var$6[$i] = $val << 1 | $carry;
        $carry = $val >>> 31 | 0;
        $i = $i + 1 | 0;
    }
    if ($carry)
        $result.data[$srcLen] = $carry;
},
jm_BitLevel_shiftLeftOneBit0 = $source => {
    let $srcLen, $resLen, $resDigits, $result;
    $srcLen = $source.$numberLength;
    $resLen = $srcLen + 1 | 0;
    $resDigits = $rt_createIntArray($resLen);
    jm_BitLevel_shiftLeftOneBit($resDigits, $source.$digits, $srcLen);
    $result = jm_BigInteger__init_($source.$sign, $resLen, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($result);
    return $result;
},
jm_BitLevel_shiftRight = ($source, $count) => {
    let $intCount, var$4, var$5, $resLength, var$7, $resDigits, $i, var$10, var$11, var$12, $result;
    $intCount = $count >> 5;
    var$4 = $count & 31;
    if ($intCount >= $source.$numberLength) {
        if ($source.$sign >= 0) {
            jm_BigInteger_$callClinit();
            var$5 = jm_BigInteger_ZERO;
        } else {
            jm_BigInteger_$callClinit();
            var$5 = jm_BigInteger_MINUS_ONE;
        }
        return var$5;
    }
    a: {
        $resLength = $source.$numberLength - $intCount | 0;
        var$7 = $resLength + 1 | 0;
        $resDigits = $rt_createIntArray(var$7);
        jm_BitLevel_shiftRight0($resDigits, $resLength, $source.$digits, $intCount, var$4);
        if ($source.$sign >= 0)
            var$7 = $resLength;
        else {
            $i = 0;
            while (true) {
                var$10 = $rt_compare($i, $intCount);
                if (var$10 >= 0)
                    break;
                if ($source.$digits.data[$i])
                    break;
                $i = $i + 1 | 0;
            }
            if (var$10 >= 0) {
                if (var$4 <= 0) {
                    var$7 = $resLength;
                    break a;
                }
                if (!($source.$digits.data[$i] << (32 - var$4 | 0))) {
                    var$7 = $resLength;
                    break a;
                }
            }
            var$4 = 0;
            while (true) {
                var$11 = $rt_compare(var$4, $resLength);
                if (var$11 >= 0)
                    break;
                var$12 = $resDigits.data;
                if (var$12[var$4] != (-1))
                    break;
                var$12[var$4] = 0;
                var$4 = var$4 + 1 | 0;
            }
            if (var$11)
                var$7 = $resLength;
            var$12 = $resDigits.data;
            var$12[var$4] = var$12[var$4] + 1 | 0;
        }
    }
    $result = jm_BigInteger__init_($source.$sign, var$7, $resDigits);
    jm_BigInteger_cutOffLeadingZeroes($result);
    return $result;
},
jm_BitLevel_shiftRight0 = ($result, $resultLen, $source, $intCount, $count) => {
    let $allZero, $i, var$8, $leftShiftCount, var$10, var$11, var$12;
    $allZero = 1;
    $i = 0;
    while ($i < $intCount) {
        $allZero = $allZero & ($source.data[$i] ? 0 : 1);
        $i = $i + 1 | 0;
    }
    if (!$count)
        jl_System_fastArraycopy($source, $intCount, $result, 0, $resultLen);
    else {
        var$8 = $source.data;
        $leftShiftCount = 32 - $count | 0;
        $allZero = $allZero & (var$8[$i] << $leftShiftCount ? 0 : 1);
        var$10 = 0;
        while (var$10 < ($resultLen - 1 | 0)) {
            var$11 = $result.data;
            var$12 = var$10 + $intCount | 0;
            var$11[var$10] = (var$8[var$12] >>> $count | 0) | var$8[var$12 + 1 | 0] << $leftShiftCount;
            var$10 = var$10 + 1 | 0;
        }
        $result.data[var$10] = var$8[var$10 + $intCount | 0] >>> $count | 0;
    }
    return $allZero;
},
juf_BiConsumer = $rt_classWithoutFields(0);
function jl_String() {
    jl_Object.call(this);
    this.$hashCode7 = 0;
}
let jl_String_EMPTY_CHARS = null,
jl_String_EMPTY = null,
jl_String_CASE_INSENSITIVE_ORDER = null,
jl_String_$callClinit = () => {
    jl_String_$callClinit = $rt_eraseClinit(jl_String);
    jl_String__clinit_();
},
jl_String__init_3 = $this => {
    jl_String_$callClinit();
    jl_Object__init_($this);
    $this.$nativeString = "";
},
jl_String__init_6 = () => {
    let var_0 = new jl_String();
    jl_String__init_3(var_0);
    return var_0;
},
jl_String__init_1 = ($this, $characters) => {
    let var$2;
    jl_String_$callClinit();
    var$2 = $characters.data;
    jl_Object__init_($this);
    $this.$nativeString = $rt_charArrayToString($characters.data, 0, var$2.length);
},
jl_String__init_0 = var_0 => {
    let var_1 = new jl_String();
    jl_String__init_1(var_1, var_0);
    return var_1;
},
jl_String__init_4 = (var$0, var$1) => {
    var$0.$nativeString = var$1;
},
jl_String__init_2 = var_0 => {
    let var_1 = new jl_String();
    jl_String__init_4(var_1, var_0);
    return var_1;
},
jl_String__init_5 = (var$0, var$1, $offset, $count) => {
    let var$4;
    jl_String_$callClinit();
    var$4 = var$1.data;
    jl_Object__init_(var$0);
    ju_Objects_checkFromIndexSize($offset, $count, var$4.length);
    var$0.$nativeString = $rt_charArrayToString(var$1.data, $offset, $count);
},
jl_String__init_ = (var_0, var_1, var_2) => {
    let var_3 = new jl_String();
    jl_String__init_5(var_3, var_0, var_1, var_2);
    return var_3;
},
jl_String_charAt = ($this, $index) => {
    if ($index >= 0 && $index < $this.$nativeString.length)
        return $this.$nativeString.charCodeAt($index);
    $rt_throw(jl_StringIndexOutOfBoundsException__init_());
},
jl_String_length = $this => {
    return $this.$nativeString.length;
},
jl_String_isEmpty = $this => {
    return $this.$nativeString.length ? 0 : 1;
},
jl_String_compareTo0 = ($this, $anotherString) => {
    let $l, $i, $a, $b, var$6;
    if ($this === $anotherString)
        return 0;
    $l = jl_Math_min($this.$length(), $anotherString.$length());
    $i = 0;
    while (true) {
        if ($i >= $l)
            return $this.$length() - $anotherString.$length() | 0;
        $a = $this.$charAt($i);
        $b = $anotherString.$charAt($i);
        var$6 = $a - $b | 0;
        if (var$6)
            break;
        $i = $i + 1 | 0;
    }
    return var$6;
},
jl_String_compareToIgnoreCase = ($this, $anotherString) => {
    let $l, $i, $a, $b, var$6;
    if ($this === $anotherString)
        return 0;
    $l = jl_Math_min($this.$length(), $anotherString.$length());
    $i = 0;
    while (true) {
        if ($i >= $l)
            return $this.$length() - $anotherString.$length() | 0;
        $a = jl_Character_toLowerCase($this.$charAt($i));
        $b = jl_Character_toLowerCase($anotherString.$charAt($i));
        var$6 = $a - $b | 0;
        if (var$6)
            break;
        $i = $i + 1 | 0;
    }
    return var$6;
},
jl_String_indexOf = ($this, $ch, $fromIndex) => {
    let $i, $bmpChar, $hi, $lo;
    $i = jl_Math_max(0, $fromIndex);
    if ($ch < 65536) {
        $bmpChar = $ch & 65535;
        while (true) {
            if ($i >= $this.$nativeString.length)
                return (-1);
            if ($this.$nativeString.charCodeAt($i) == $bmpChar)
                break;
            $i = $i + 1 | 0;
        }
        return $i;
    }
    $hi = jl_Character_highSurrogate($ch);
    $lo = jl_Character_lowSurrogate($ch);
    while (true) {
        if ($i >= ($this.$nativeString.length - 1 | 0))
            return (-1);
        if ($this.$nativeString.charCodeAt($i) == $hi && $this.$nativeString.charCodeAt(($i + 1 | 0)) == $lo)
            break;
        $i = $i + 1 | 0;
    }
    return $i;
},
jl_String_indexOf0 = ($this, $ch) => {
    return $this.$indexOf0($ch, 0);
},
jl_String_lastIndexOf = ($this, $ch, $fromIndex) => {
    let $i, $bmpChar, $hi, $lo, var$7;
    $i = jl_Math_min($fromIndex, $this.$length() - 1 | 0);
    if ($ch < 65536) {
        $bmpChar = $ch & 65535;
        while (true) {
            if ($i < 0)
                return (-1);
            if ($this.$nativeString.charCodeAt($i) == $bmpChar)
                break;
            $i = $i + (-1) | 0;
        }
        return $i;
    }
    $hi = jl_Character_highSurrogate($ch);
    $lo = jl_Character_lowSurrogate($ch);
    while (true) {
        if ($i < 1)
            return (-1);
        if ($this.$nativeString.charCodeAt($i) == $lo) {
            var$7 = $i - 1 | 0;
            if ($this.$nativeString.charCodeAt(var$7) == $hi)
                break;
        }
        $i = $i + (-1) | 0;
    }
    return var$7;
},
jl_String_lastIndexOf0 = ($this, $ch) => {
    return $this.$lastIndexOf0($ch, $this.$length() - 1 | 0);
},
jl_String_substring = ($this, $beginIndex, $endIndex) => {
    let $length, var$4;
    $length = $this.$nativeString.length;
    var$4 = $rt_compare($beginIndex, $endIndex);
    if (!var$4)
        return jl_String_EMPTY;
    if (!$beginIndex && $endIndex == $length)
        return $this;
    if ($beginIndex >= 0 && var$4 <= 0 && $endIndex <= $length)
        return jl_String__init_2($this.$nativeString.substring($beginIndex, $endIndex));
    $rt_throw(jl_StringIndexOutOfBoundsException__init_());
},
jl_String_substring0 = ($this, $beginIndex) => {
    return $this.$substring0($beginIndex, $this.$length());
},
jl_String_trim = $this => {
    let $lower, $upper;
    $lower = 0;
    $upper = $this.$length() - 1 | 0;
    a: {
        while ($lower <= $upper) {
            if ($this.$charAt($lower) > 32)
                break a;
            $lower = $lower + 1 | 0;
        }
    }
    while ($lower <= $upper && $this.$charAt($upper) <= 32) {
        $upper = $upper + (-1) | 0;
    }
    return $this.$substring0($lower, $upper + 1 | 0);
},
jl_String_toString = $this => {
    return $this;
},
jl_String_toCharArray = $this => {
    let $array, $i, var$3;
    $array = $rt_createCharArray($this.$nativeString.length);
    $i = 0;
    while (true) {
        var$3 = $array.data;
        if ($i >= var$3.length)
            break;
        var$3[$i] = $this.$charAt($i);
        $i = $i + 1 | 0;
    }
    return $array;
},
jl_String_valueOf0 = $obj => {
    jl_String_$callClinit();
    return $obj === null ? $rt_s(7) : $obj.$toString();
},
jl_String_valueOf = $c => {
    let var$2, var$3;
    jl_String_$callClinit();
    var$2 = new jl_String;
    var$3 = $rt_createCharArray(1);
    var$3.data[0] = $c;
    jl_String__init_1(var$2, var$3);
    return var$2;
},
jl_String_equals = ($this, $other) => {
    let $str;
    if ($this === $other)
        return 1;
    if (!($other instanceof jl_String))
        return 0;
    $str = $other;
    return $this.$nativeString !== $str.$nativeString ? 0 : 1;
},
jl_String_equalsIgnoreCase = ($this, $other) => {
    let $i;
    if ($this === $other)
        return 1;
    if ($other === null)
        return 0;
    if ($this.$length() != $other.$length())
        return 0;
    $i = 0;
    while ($i < $this.$length()) {
        if (jl_Character_toLowerCase($this.$charAt($i)) != jl_Character_toLowerCase($other.$charAt($i)))
            return 0;
        $i = $i + 1 | 0;
    }
    return 1;
},
jl_String_hashCode = $this => {
    let $i;
    a: {
        if (!$this.$hashCode7) {
            $i = 0;
            while (true) {
                if ($i >= $this.$nativeString.length)
                    break a;
                $this.$hashCode7 = (31 * $this.$hashCode7 | 0) + $this.$nativeString.charCodeAt($i) | 0;
                $i = $i + 1 | 0;
            }
        }
    }
    return $this.$hashCode7;
},
jl_String_toUpperCase = $this => {
    let $upperCase;
    $upperCase = $this.$nativeString.toUpperCase();
    if ($upperCase !== $this.$nativeString)
        $this = jl_String__init_2($upperCase);
    return $this;
},
jl_String_format = ($format, $args) => {
    jl_String_$callClinit();
    return ju_Formatter_toString(ju_Formatter_format0(ju_Formatter__init_2(), $format, $args));
},
jl_String_compareTo = ($this, var$1) => {
    return $this.$compareTo6(var$1);
},
jl_String_lambda$static$0 = ($o1, $o2) => {
    jl_String_$callClinit();
    return $o1.$compareToIgnoreCase($o2);
},
jl_String__clinit_ = () => {
    jl_String_EMPTY_CHARS = $rt_createCharArray(0);
    jl_String_EMPTY = jl_String__init_6();
    jl_String_CASE_INSENSITIVE_ORDER = jl_String$_clinit_$lambda$_115_0__init_0();
},
jl_NegativeArraySizeException = $rt_classWithoutFields(jl_RuntimeException),
jl_NegativeArraySizeException__init_ = $this => {
    jl_RuntimeException__init_($this);
},
jl_NegativeArraySizeException__init_0 = () => {
    let var_0 = new jl_NegativeArraySizeException();
    jl_NegativeArraySizeException__init_(var_0);
    return var_0;
},
jl_UnsupportedOperationException = $rt_classWithoutFields(jl_RuntimeException),
jl_UnsupportedOperationException__init_ = $this => {
    jl_RuntimeException__init_($this);
},
jl_UnsupportedOperationException__init_0 = () => {
    let var_0 = new jl_UnsupportedOperationException();
    jl_UnsupportedOperationException__init_(var_0);
    return var_0;
},
jl_IllegalStateException = $rt_classWithoutFields(jl_RuntimeException),
jl_IllegalStateException__init_0 = $this => {
    jl_RuntimeException__init_($this);
},
jl_IllegalStateException__init_ = () => {
    let var_0 = new jl_IllegalStateException();
    jl_IllegalStateException__init_0(var_0);
    return var_0;
},
jl_IllegalStateException__init_1 = ($this, $message) => {
    jl_RuntimeException__init_0($this, $message);
},
jl_IllegalStateException__init_2 = var_0 => {
    let var_1 = new jl_IllegalStateException();
    jl_IllegalStateException__init_1(var_1, var_0);
    return var_1;
},
ju_FormatterClosedException = $rt_classWithoutFields(jl_IllegalStateException),
ju_FormatterClosedException__init_ = $this => {
    jl_IllegalStateException__init_0($this);
},
ju_FormatterClosedException__init_0 = () => {
    let var_0 = new ju_FormatterClosedException();
    ju_FormatterClosedException__init_(var_0);
    return var_0;
};
function jt_DecimalFormat$TextField() {
    jl_Object.call(this);
    this.$text = null;
}
let jt_DecimalFormat$TextField__init_0 = ($this, $text) => {
    jl_Object__init_($this);
    $this.$text = $text;
},
jt_DecimalFormat$TextField__init_ = var_0 => {
    let var_1 = new jt_DecimalFormat$TextField();
    jt_DecimalFormat$TextField__init_0(var_1, var_0);
    return var_1;
},
jt_DecimalFormat$TextField_render = ($this, $format, $buffer) => {
    $buffer.$append5($this.$text);
},
jt_DecimalFormat$TextField_equals = ($this, $obj) => {
    let $other;
    if ($this === $obj)
        return 1;
    if (!($obj instanceof jt_DecimalFormat$TextField))
        return 0;
    $other = $obj;
    return $this.$text.$equals($other.$text);
},
jt_DecimalFormat$TextField_hashCode = $this => {
    return $this.$text.$hashCode0();
};
function rce_Game$1() {
    jl_Object.call(this);
    this.$val$game = null;
}
let rce_Game$1__init_ = ($this, var$1) => {
    $this.$val$game = var$1;
    jl_Object__init_($this);
},
rce_Game$1__init_0 = var_0 => {
    let var_1 = new rce_Game$1();
    rce_Game$1__init_(var_1, var_0);
    return var_1;
},
rce_Game$1_onFrame = ($this, $timestamp) => {
    let $now, $delta;
    if (!$this.$val$game.$running)
        return;
    $now = Date.now();
    $delta = ($now - $this.$val$game.$lastTimestamp) / 1000.0;
    if ($delta > 0.1)
        $delta = 0.1;
    $this.$val$game.$lastTimestamp = $now;
    $this.$val$game.$step($delta);
    $this.$val$game.$renderFrame();
    rcei_JSBridge_requestAnimationFrame$js_body$_11(otji_JS_function($this, "onFrame"));
},
rce_Game$1_onFrame$exported$0 = (var$0, var$1) => {
    var$0.$onFrame(var$1);
};
function rce_Color() {
    let a = this; jl_Object.call(a);
    a.$r = 0;
    a.$g = 0;
    a.$b = 0;
    a.$a = 0.0;
}
let rce_Color_BLACK = null,
rce_Color_WHITE = null,
rce_Color_RED = null,
rce_Color_GREEN = null,
rce_Color_BLUE = null,
rce_Color_YELLOW = null,
rce_Color_CYAN = null,
rce_Color_MAGENTA = null,
rce_Color_ORANGE = null,
rce_Color_GRAY = null,
rce_Color_DARK_GRAY = null,
rce_Color_LIGHT_GRAY = null,
rce_Color_AMBER_LED = null,
rce_Color_MATRIX_GREEN = null,
rce_Color_VIRTUAL_CYBER_BLUE = null,
rce_Color_RETRO_BACKGROUND = null,
rce_Color_GRID_LINE = null,
rce_Color_$callClinit = () => {
    rce_Color_$callClinit = $rt_eraseClinit(rce_Color);
    rce_Color__clinit_();
},
rce_Color__init_2 = ($this, $r, $g, $b) => {
    rce_Color_$callClinit();
    rce_Color__init_0($this, $r, $g, $b, 1.0);
},
rce_Color__init_ = (var_0, var_1, var_2) => {
    let var_3 = new rce_Color();
    rce_Color__init_2(var_3, var_0, var_1, var_2);
    return var_3;
},
rce_Color__init_0 = ($this, $r, $g, $b, $a) => {
    rce_Color_$callClinit();
    jl_Object__init_($this);
    $this.$r = jl_Math_max(0, jl_Math_min(255, $r));
    $this.$g = jl_Math_max(0, jl_Math_min(255, $g));
    $this.$b = jl_Math_max(0, jl_Math_min(255, $b));
    $this.$a = jl_Math_max0(0.0, jl_Math_min0(1.0, $a));
},
rce_Color__init_1 = (var_0, var_1, var_2, var_3) => {
    let var_4 = new rce_Color();
    rce_Color__init_0(var_4, var_0, var_1, var_2, var_3);
    return var_4;
},
rce_Color_toCssRgba = $this => {
    let var$1, var$2, var$3, var$4, var$5;
    if ($this.$a >= 0.999)
        return jl_String_format($rt_s(103), $rt_wrapArray(jl_Object, [jl_Integer_valueOf($this.$r), jl_Integer_valueOf($this.$g), jl_Integer_valueOf($this.$b)]));
    var$1 = $this.$r;
    var$2 = $this.$g;
    var$3 = $this.$b;
    var$4 = $this.$a;
    var$5 = jl_StringBuilder__init_();
    jl_StringBuilder_append1(jl_StringBuilder_append2(jl_StringBuilder_append1(jl_StringBuilder_append0(jl_StringBuilder_append1(jl_StringBuilder_append0(jl_StringBuilder_append1(jl_StringBuilder_append0(jl_StringBuilder_append(var$5, $rt_s(104)), var$1), 44), var$2), 44), var$3), 44), var$4), 41);
    return jl_StringBuilder_toString(var$5);
},
rce_Color_toString = $this => {
    return $this.$toCssRgba();
},
rce_Color__clinit_ = () => {
    rce_Color_BLACK = rce_Color__init_(0, 0, 0);
    rce_Color_WHITE = rce_Color__init_(255, 255, 255);
    rce_Color_RED = rce_Color__init_(230, 40, 40);
    rce_Color_GREEN = rce_Color__init_(40, 220, 40);
    rce_Color_BLUE = rce_Color__init_(40, 100, 240);
    rce_Color_YELLOW = rce_Color__init_(240, 220, 30);
    rce_Color_CYAN = rce_Color__init_(30, 220, 240);
    rce_Color_MAGENTA = rce_Color__init_(220, 40, 220);
    rce_Color_ORANGE = rce_Color__init_(255, 140, 0);
    rce_Color_GRAY = rce_Color__init_(128, 128, 128);
    rce_Color_DARK_GRAY = rce_Color__init_(45, 45, 45);
    rce_Color_LIGHT_GRAY = rce_Color__init_(200, 200, 200);
    rce_Color_AMBER_LED = rce_Color__init_(255, 176, 0);
    rce_Color_MATRIX_GREEN = rce_Color__init_(0, 255, 65);
    rce_Color_VIRTUAL_CYBER_BLUE = rce_Color__init_(0, 210, 255);
    rce_Color_RETRO_BACKGROUND = rce_Color__init_(18, 20, 28);
    rce_Color_GRID_LINE = rce_Color__init_(35, 40, 55);
},
ju_Deque = $rt_classWithoutFields(0);
function ju_ArrayDeque() {
    let a = this; ju_AbstractCollection.call(a);
    a.$version = 0;
    a.$array = null;
    a.$head = 0;
    a.$tail = 0;
}
let ju_ArrayDeque__init_0 = $this => {
    ju_ArrayDeque__init_($this, 8);
},
ju_ArrayDeque__init_1 = () => {
    let var_0 = new ju_ArrayDeque();
    ju_ArrayDeque__init_0(var_0);
    return var_0;
},
ju_ArrayDeque__init_ = ($this, $numElements) => {
    ju_AbstractCollection__init_($this);
    $this.$array = $rt_createArray(jl_Object, $numElements + 1 | 0);
},
ju_ArrayDeque__init_2 = var_0 => {
    let var_1 = new ju_ArrayDeque();
    ju_ArrayDeque__init_(var_1, var_0);
    return var_1;
},
ju_ArrayDeque_addLast = ($this, $e) => {
    ju_Objects_requireNonNull($e);
    ju_ArrayDeque_ensureCapacity($this, $this.$size() + 1 | 0);
    $this.$array.data[$this.$tail] = $e;
    $this.$tail = ju_ArrayDeque_modInc($this.$tail, $this.$array.data.length);
    $this.$version = $this.$version + 1 | 0;
},
ju_ArrayDeque_add = ($this, $e) => {
    $this.$addLast($e);
    return 1;
},
ju_ArrayDeque_size = $this => {
    return $this.$tail >= $this.$head ? $this.$tail - $this.$head | 0 : ($this.$array.data.length - $this.$head | 0) + $this.$tail | 0;
},
ju_ArrayDeque_removeAt = ($this, $index) => {
    let $i, var$3, var$4, var$5;
    if ($this.$head < $this.$tail) {
        if (($this.$tail - $index | 0) >= ($index - $this.$head | 0)) {
            $i = $index - 1 | 0;
            while ($i >= $this.$head) {
                $this.$array.data[$i + 1 | 0] = $this.$array.data[$i];
                $i = $i + (-1) | 0;
            }
            var$3 = $this.$array.data;
            var$4 = $this.$head;
            $this.$head = var$4 + 1 | 0;
            var$3[var$4] = null;
            return 0;
        }
        $i = $index + 1 | 0;
        while ($i < $this.$tail) {
            $this.$array.data[$i - 1 | 0] = $this.$array.data[$i];
            $i = $i + 1 | 0;
        }
        var$3 = $this.$array.data;
        var$5 = $this.$tail - 1 | 0;
        $this.$tail = var$5;
        var$3[var$5] = null;
        return 1;
    }
    if ($index < $this.$head) {
        $i = $index + 1 | 0;
        while ($i < $this.$tail) {
            $this.$array.data[$i - 1 | 0] = $this.$array.data[$i];
            $i = $i + 1 | 0;
        }
        $this.$tail = ju_ArrayDeque_modDec($this.$tail, $this.$array.data.length);
        $this.$array.data[$this.$tail] = null;
        return 1;
    }
    $i = $index - 1 | 0;
    while ($i >= $this.$head) {
        $this.$array.data[$i + 1 | 0] = $this.$array.data[$i];
        $i = $i + (-1) | 0;
    }
    $this.$array.data[$this.$head] = null;
    $this.$head = ju_ArrayDeque_modInc($this.$head, $this.$array.data.length);
    return 0;
},
ju_ArrayDeque_modInc = ($i, $mod) => {
    let var$3;
    var$3 = $i + 1 | 0;
    if (var$3 == $mod)
        var$3 = 0;
    return var$3;
},
ju_ArrayDeque_modDec = ($i, $mod) => {
    let var$3;
    var$3 = $i + (-1) | 0;
    if (var$3 == (-1))
        var$3 = $mod - 1 | 0;
    return var$3;
},
ju_ArrayDeque_iterator = $this => {
    return ju_ArrayDeque$1__init_0($this);
},
ju_ArrayDeque_ensureCapacity = ($this, $capacity) => {
    let $newArraySize, $newArray, $j, $i, var$6, var$7, var$8;
    if ($capacity < $this.$array.data.length)
        return;
    $newArraySize = jl_Math_max($this.$array.data.length * 2 | 0, (($capacity * 3 | 0) / 2 | 0) + 1 | 0);
    if ($newArraySize < 1)
        $newArraySize = 2147483647;
    $newArray = $rt_createArray(jl_Object, $newArraySize);
    $j = 0;
    if ($this.$head <= $this.$tail) {
        $i = $this.$head;
        while ($i < $this.$tail) {
            var$6 = $newArray.data;
            var$7 = $j + 1 | 0;
            var$6[$j] = $this.$array.data[$i];
            $i = $i + 1 | 0;
            $j = var$7;
        }
    } else {
        $i = $this.$head;
        while ($i < $this.$array.data.length) {
            var$8 = $newArray.data;
            var$7 = $j + 1 | 0;
            var$8[$j] = $this.$array.data[$i];
            $i = $i + 1 | 0;
            $j = var$7;
        }
        $i = 0;
        while ($i < $this.$tail) {
            var$6 = $newArray.data;
            var$7 = $j + 1 | 0;
            var$6[$j] = $this.$array.data[$i];
            $i = $i + 1 | 0;
            $j = var$7;
        }
    }
    $this.$head = 0;
    $this.$tail = $j;
    $this.$array = $newArray;
};
function ju_Formatter$FormatWriter() {
    let a = this; jl_Object.call(a);
    a.$formatter = null;
    a.$out = null;
    a.$locale0 = null;
    a.$format8 = null;
    a.$args = null;
    a.$index0 = 0;
    a.$formatSpecifierStart = 0;
    a.$defaultArgumentIndex = 0;
    a.$argumentIndex = 0;
    a.$previousArgumentIndex = 0;
    a.$width = 0;
    a.$precision0 = 0;
    a.$flags = 0;
}
let ju_Formatter$FormatWriter__init_ = ($this, $formatter, $out, $locale, $format, $args) => {
    jl_Object__init_($this);
    $this.$formatter = $formatter;
    $this.$out = $out;
    $this.$locale0 = $locale;
    $this.$format8 = $format;
    $this.$args = $args;
},
ju_Formatter$FormatWriter__init_0 = (var_0, var_1, var_2, var_3, var_4) => {
    let var_5 = new ju_Formatter$FormatWriter();
    ju_Formatter$FormatWriter__init_(var_5, var_0, var_1, var_2, var_3, var_4);
    return var_5;
},
ju_Formatter$FormatWriter_write = $this => {
    let $next, $specifier;
    while (true) {
        $next = $this.$format8.$indexOf0(37, $this.$index0);
        if ($next < 0)
            break;
        $this.$out.$append22($this.$format8.$substring0($this.$index0, $next));
        $this.$index0 = $next + 1 | 0;
        $this.$formatSpecifierStart = $this.$index0;
        $specifier = ju_Formatter$FormatWriter_parseFormatSpecifier($this);
        ju_Formatter$FormatWriter_configureFormat($this);
        ju_Formatter$FormatWriter_formatValue($this, $specifier);
    }
    $this.$out.$append22($this.$format8.$substring($this.$index0));
},
ju_Formatter$FormatWriter_formatValue = ($this, $specifier) => {
    a: {
        b: {
            switch ($specifier) {
                case 66:
                    break;
                case 67:
                    ju_Formatter$FormatWriter_formatChar($this, $specifier, 1);
                    break a;
                case 68:
                    ju_Formatter$FormatWriter_formatDecimalInt($this, $specifier, 1);
                    break a;
                case 69:
                case 70:
                case 71:
                case 73:
                case 74:
                case 75:
                case 76:
                case 77:
                case 78:
                case 80:
                case 81:
                case 82:
                case 84:
                case 85:
                case 86:
                case 87:
                case 89:
                case 90:
                case 91:
                case 92:
                case 93:
                case 94:
                case 95:
                case 96:
                case 97:
                case 101:
                case 103:
                case 105:
                case 106:
                case 107:
                case 108:
                case 109:
                case 110:
                case 112:
                case 113:
                case 114:
                case 116:
                case 117:
                case 118:
                case 119:
                    break b;
                case 72:
                    ju_Formatter$FormatWriter_formatHex($this, $specifier, 1);
                    break a;
                case 79:
                    ju_Formatter$FormatWriter_formatRadixInt($this, $specifier, 3, 1);
                    break a;
                case 83:
                    ju_Formatter$FormatWriter_formatString($this, $specifier, 1);
                    break a;
                case 88:
                    ju_Formatter$FormatWriter_formatRadixInt($this, $specifier, 4, 1);
                    break a;
                case 98:
                    ju_Formatter$FormatWriter_formatBoolean($this, $specifier, 0);
                    break a;
                case 99:
                    ju_Formatter$FormatWriter_formatChar($this, $specifier, 0);
                    break a;
                case 100:
                    ju_Formatter$FormatWriter_formatDecimalInt($this, $specifier, 0);
                    break a;
                case 102:
                    ju_Formatter$FormatWriter_formatFloat($this, $specifier, 0);
                    break a;
                case 104:
                    ju_Formatter$FormatWriter_formatHex($this, $specifier, 0);
                    break a;
                case 111:
                    ju_Formatter$FormatWriter_formatRadixInt($this, $specifier, 3, 0);
                    break a;
                case 115:
                    ju_Formatter$FormatWriter_formatString($this, $specifier, 0);
                    break a;
                case 120:
                    ju_Formatter$FormatWriter_formatRadixInt($this, $specifier, 4, 0);
                    break a;
                default:
                    break b;
            }
            ju_Formatter$FormatWriter_formatBoolean($this, $specifier, 1);
            break a;
        }
        $rt_throw(ju_UnknownFormatConversionException__init_(jl_String_valueOf($specifier)));
    }
},
ju_Formatter$FormatWriter_formatFloat = ($this, $specifier, $upperCase) => {
    let $arg, $negative, $format, $decimalSize, $str;
    ju_Formatter$FormatWriter_verifyFlags($this, $specifier, 507);
    ju_Formatter$FormatWriter_verifyFloatFlags($this);
    if ($this.$precision0 == (-1))
        $this.$precision0 = 6;
    $arg = $this.$args.data[$this.$argumentIndex];
    if ($arg instanceof jl_Double)
        $negative = $arg.$doubleValue() >= 0.0 ? 0 : 1;
    else if ($arg instanceof jl_Float)
        $negative = $arg.$floatValue() >= 0.0 ? 0 : 1;
    else {
        if (!($arg instanceof jm_BigDecimal))
            $rt_throw(ju_IllegalFormatConversionException__init_($specifier, $arg !== null ? jl_Object_getClass($arg) : null));
        $negative = $arg.$signum() >= 0 ? 0 : 1;
    }
    $format = jt_DecimalFormat__init_3();
    $format.$setDecimalFormatSymbols(jt_DecimalFormatSymbols__init_($this.$locale0));
    if ($this.$width != (-1)) {
        $decimalSize = ju_Formatter$FormatWriter_predictDecimalSize($this, $negative, $format);
        $format.$setMaximumIntegerDigits($decimalSize);
        if ($this.$flags & 32)
            $format.$setMinimumIntegerDigits($decimalSize);
    }
    $format.$setMaximumFractionDigits($this.$precision0);
    $format.$setMinimumFractionDigits($this.$precision0);
    $format.$setGroupingUsed(!($this.$flags & 64) ? 0 : 1);
    if ($this.$flags & 128) {
        $format.$setNegativePrefix($rt_s(105));
        $format.$setNegativeSuffix($rt_s(106));
    }
    if ($this.$flags & 8)
        $format.$setPositivePrefix($rt_s(107));
    else if ($this.$flags & 16)
        $format.$setPositivePrefix($rt_s(87));
    $str = jt_Format_format($format, $arg);
    $this.$precision0 = (-1);
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $str);
},
ju_Formatter$FormatWriter_predictDecimalSize = ($this, $negative, $format) => {
    let $decimalSize;
    $decimalSize = $this.$width;
    if ($this.$precision0 > 0)
        $decimalSize = $decimalSize - ($this.$precision0 + 1 | 0) | 0;
    if (!$negative) {
        if ($this.$flags & 24)
            $decimalSize = $decimalSize + (-1) | 0;
    } else
        $decimalSize = !($this.$flags & 128) ? $decimalSize + (-1) | 0 : $decimalSize + (-2) | 0;
    if ($this.$flags & 64)
        $decimalSize = $decimalSize - ($decimalSize / ($format.$getGroupingSize() + 1 | 0) | 0) | 0;
    return $decimalSize;
},
ju_Formatter$FormatWriter_verifyFloatFlags = $this => {
    if ($this.$flags & 8 && $this.$flags & 16)
        $rt_throw(ju_IllegalFormatFlagsException__init_($rt_s(108)));
    if ($this.$flags & 32 && $this.$flags & 1)
        $rt_throw(ju_IllegalFormatFlagsException__init_($rt_s(109)));
    if ($this.$flags & 1 && $this.$width < 0)
        $rt_throw(ju_MissingFormatWidthException__init_($this.$format8.$substring0($this.$formatSpecifierStart, $this.$index0)));
},
ju_Formatter$FormatWriter_formatBoolean = ($this, $specifier, $upperCase) => {
    let $arg, $s;
    ju_Formatter$FormatWriter_verifyFlagsForGeneralFormat($this, $specifier);
    $arg = $this.$args.data[$this.$argumentIndex];
    $s = jl_Boolean_toString($arg instanceof jl_Boolean ? $arg.$booleanValue() : $arg === null ? 0 : 1);
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $s);
},
ju_Formatter$FormatWriter_formatHex = ($this, $specifier, $upperCase) => {
    let $arg, $s;
    ju_Formatter$FormatWriter_verifyFlagsForGeneralFormat($this, $specifier);
    $arg = $this.$args.data[$this.$argumentIndex];
    $s = $arg === null ? $rt_s(7) : jl_Integer_toHexString($arg.$hashCode0());
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $s);
},
ju_Formatter$FormatWriter_formatString = ($this, $specifier, $upperCase) => {
    let $arg, $flagsToPass;
    ju_Formatter$FormatWriter_verifyFlagsForGeneralFormat($this, $specifier);
    $arg = $this.$args.data[$this.$argumentIndex];
    if (!$rt_isInstance($arg, ju_Formattable))
        ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, jl_String_valueOf0($arg));
    else {
        $flagsToPass = $this.$flags & 7;
        if ($upperCase)
            $flagsToPass = $flagsToPass | 2;
        $arg.$formatTo($this.$formatter, $flagsToPass, $this.$width, $this.$precision0);
    }
},
ju_Formatter$FormatWriter_formatChar = ($this, $specifier, $upperCase) => {
    let $arg, $c;
    ju_Formatter$FormatWriter_verifyFlags($this, $specifier, 259);
    $arg = $this.$args.data[$this.$argumentIndex];
    if ($this.$precision0 >= 0)
        $rt_throw(ju_IllegalFormatPrecisionException__init_0($this.$precision0));
    if ($arg instanceof jl_Character)
        $c = $arg.$charValue();
    else if ($arg instanceof jl_Byte)
        $c = $arg.$byteValue() & 65535;
    else if ($arg instanceof jl_Short)
        $c = $arg.$shortValue() & 65535;
    else {
        if (!($arg instanceof jl_Integer)) {
            if ($arg === null) {
                ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $rt_s(7));
                return;
            }
            $rt_throw(ju_IllegalFormatConversionException__init_($specifier, jl_Object_getClass($arg)));
        }
        $c = $arg.$intValue();
        if (!jl_Character_isValidCodePoint($c))
            $rt_throw(ju_IllegalFormatCodePointException__init_0($c));
    }
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, jl_String__init_0(jl_Character_toChars($c)));
},
ju_Formatter$FormatWriter_formatDecimalInt = ($this, $specifier, $upperCase) => {
    let $arg, $value, $str, $negative, $value_0, $additionalSymbols, $sb, $valueSb, $separator, $size, $i, $prev, $i_0;
    ju_Formatter$FormatWriter_verifyFlags($this, $specifier, 507);
    ju_Formatter$FormatWriter_verifyIntFlags($this);
    $arg = $this.$args.data[$this.$argumentIndex];
    if ($arg instanceof jl_Long) {
        $value = $arg.$longValue();
        $str = jl_Long_toString(jl_Math_abs0($value));
        $negative = Long_ge($value, Long_ZERO) ? 0 : 1;
    } else {
        if (!($arg instanceof jl_Integer) && !($arg instanceof jl_Byte) && !($arg instanceof jl_Short))
            $rt_throw(ju_IllegalFormatConversionException__init_($specifier, $arg === null ? null : jl_Object_getClass($arg)));
        $value_0 = $arg.$intValue();
        $str = jl_Integer_toString(jl_Math_abs($value_0));
        $negative = $value_0 >= 0 ? 0 : 1;
    }
    $additionalSymbols = 0;
    $sb = jl_StringBuilder__init_();
    if ($negative) {
        if (!($this.$flags & 128)) {
            $sb.$append0(45);
            $additionalSymbols = 1;
        } else {
            $sb.$append0(40);
            $additionalSymbols = 2;
        }
    } else if ($this.$flags & 8) {
        $sb.$append0(43);
        $additionalSymbols = 1;
    } else if ($this.$flags & 16) {
        $sb.$append0(32);
        $additionalSymbols = 1;
    }
    $valueSb = jl_StringBuilder__init_();
    if (!($this.$flags & 64))
        $valueSb.$append19($str);
    else {
        $separator = (jt_DecimalFormatSymbols__init_($this.$locale0)).$getGroupingSeparator();
        $size = (jt_NumberFormat_getNumberInstance($this.$locale0)).$getGroupingSize();
        $i = $str.$length() % $size | 0;
        if (!$i)
            $i = $size;
        $prev = 0;
        while ($i < $str.$length()) {
            $valueSb.$append19($str.$substring0($prev, $i));
            $valueSb.$append0($separator);
            $i_0 = $i + $size | 0;
            $prev = $i;
            $i = $i_0;
        }
        $valueSb.$append19($str.$substring($prev));
    }
    a: {
        if ($this.$flags & 32) {
            $i = $valueSb.$length() + $additionalSymbols | 0;
            while (true) {
                if ($i >= $this.$width)
                    break a;
                $sb.$append0(jl_Character_forDigit(0, 10));
                $i = $i + 1 | 0;
            }
        }
    }
    $sb.$append16($valueSb);
    if ($negative && $this.$flags & 128)
        $sb.$append0(41);
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $sb.$toString());
},
ju_Formatter$FormatWriter_formatRadixInt = ($this, $specifier, $radixLog2, $upperCase) => {
    let $arg, $str, $sb, $prefix, var$8, $i;
    ju_Formatter$FormatWriter_verifyFlags($this, $specifier, 423);
    ju_Formatter$FormatWriter_verifyIntFlags($this);
    $arg = $this.$args.data[$this.$argumentIndex];
    if ($arg instanceof jl_Long)
        $str = otci_IntegerUtil_toUnsignedLogRadixString0($arg.$longValue(), $radixLog2);
    else if ($arg instanceof jl_Integer)
        $str = otci_IntegerUtil_toUnsignedLogRadixString($arg.$intValue(), $radixLog2);
    else if ($arg instanceof jl_Short)
        $str = otci_IntegerUtil_toUnsignedLogRadixString($arg.$shortValue() & 65535, $radixLog2);
    else {
        if (!($arg instanceof jl_Byte))
            $rt_throw(ju_IllegalFormatConversionException__init_($specifier, $arg === null ? null : jl_Object_getClass($arg)));
        $str = otci_IntegerUtil_toUnsignedLogRadixString($arg.$byteValue() & 255, $radixLog2);
    }
    $sb = jl_StringBuilder__init_();
    if ($this.$flags & 4) {
        $prefix = $radixLog2 != 4 ? $rt_s(19) : $rt_s(110);
        var$8 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(var$8, $prefix), $str);
        $str = jl_StringBuilder_toString(var$8);
    }
    a: {
        if ($this.$flags & 32) {
            $i = $str.$length();
            while (true) {
                if ($i >= $this.$width)
                    break a;
                $sb.$append0(jl_Character_forDigit(0, 10));
                $i = $i + 1 | 0;
            }
        }
    }
    $sb.$append19($str);
    ju_Formatter$FormatWriter_formatGivenString($this, $upperCase, $sb.$toString());
},
ju_Formatter$FormatWriter_verifyIntFlags = $this => {
    if ($this.$flags & 8 && $this.$flags & 16)
        $rt_throw(ju_IllegalFormatFlagsException__init_($rt_s(108)));
    if ($this.$flags & 32 && $this.$flags & 1)
        $rt_throw(ju_IllegalFormatFlagsException__init_($rt_s(109)));
    if ($this.$precision0 >= 0)
        $rt_throw(ju_IllegalFormatPrecisionException__init_0($this.$precision0));
    if ($this.$flags & 1 && $this.$width < 0)
        $rt_throw(ju_MissingFormatWidthException__init_($this.$format8.$substring0($this.$formatSpecifierStart, $this.$index0)));
},
ju_Formatter$FormatWriter_formatGivenString = ($this, $upperCase, $str) => {
    if ($this.$precision0 > 0 && $this.$precision0 < $str.$length())
        $str = $str.$substring0(0, $this.$precision0);
    if ($upperCase)
        $str = $str.$toUpperCase();
    if (!($this.$flags & 1)) {
        ju_Formatter$FormatWriter_mayBeAppendSpaces($this, $str);
        $this.$out.$append22($str);
    } else {
        $this.$out.$append22($str);
        ju_Formatter$FormatWriter_mayBeAppendSpaces($this, $str);
    }
},
ju_Formatter$FormatWriter_verifyFlagsForGeneralFormat = ($this, $conversion) => {
    ju_Formatter$FormatWriter_verifyFlags($this, $conversion, 263);
},
ju_Formatter$FormatWriter_verifyFlags = ($this, $conversion, $mask) => {
    if (($this.$flags | $mask) == $mask)
        return;
    $rt_throw(ju_FormatFlagsConversionMismatchException__init_0(ju_Formatter$FormatWriter_flagsToString($this, $this.$flags & ($mask ^ (-1))), $conversion));
},
ju_Formatter$FormatWriter_flagsToString = ($this, $flags) => {
    let $flagIndex;
    $flagIndex = jl_Integer_numberOfTrailingZeros($flags);
    return jl_String_valueOf($rt_s(111).$charAt($flagIndex));
},
ju_Formatter$FormatWriter_mayBeAppendSpaces = ($this, $str) => {
    let $diff, $sb, $i;
    if ($this.$width > $str.$length()) {
        $diff = $this.$width - $str.$length() | 0;
        $sb = jl_StringBuilder__init_0($diff);
        $i = 0;
        while ($i < $diff) {
            $sb.$append0(32);
            $i = $i + 1 | 0;
        }
        $this.$out.$append22($sb);
    }
},
ju_Formatter$FormatWriter_configureFormat = $this => {
    let var$1;
    if ($this.$flags & 256)
        $this.$argumentIndex = jl_Math_max(0, $this.$previousArgumentIndex);
    if ($this.$argumentIndex == (-1)) {
        var$1 = $this.$defaultArgumentIndex;
        $this.$defaultArgumentIndex = var$1 + 1 | 0;
        $this.$argumentIndex = var$1;
    }
    $this.$previousArgumentIndex = $this.$argumentIndex;
},
ju_Formatter$FormatWriter_parseFormatSpecifier = $this => {
    let $c, $n, var$3, var$4;
    $this.$flags = 0;
    $this.$argumentIndex = (-1);
    $this.$width = (-1);
    $this.$precision0 = (-1);
    $c = $this.$format8.$charAt($this.$index0);
    if ($c != 48 && ju_Formatter$FormatWriter_isDigit($c)) {
        $n = ju_Formatter$FormatWriter_readInt($this);
        if ($this.$index0 < $this.$format8.$length() && $this.$format8.$charAt($this.$index0) == 36) {
            $this.$index0 = $this.$index0 + 1 | 0;
            $this.$argumentIndex = $n - 1 | 0;
        } else
            $this.$width = $n;
    }
    ju_Formatter$FormatWriter_parseFlags($this);
    if ($this.$width < 0 && $this.$index0 < $this.$format8.$length() && ju_Formatter$FormatWriter_isDigit($this.$format8.$charAt($this.$index0)))
        $this.$width = ju_Formatter$FormatWriter_readInt($this);
    if ($this.$index0 < $this.$format8.$length() && $this.$format8.$charAt($this.$index0) == 46) {
        $this.$index0 = $this.$index0 + 1 | 0;
        if ($this.$index0 < $this.$format8.$length() && ju_Formatter$FormatWriter_isDigit($this.$format8.$charAt($this.$index0)))
            $this.$precision0 = ju_Formatter$FormatWriter_readInt($this);
        else
            $rt_throw(ju_UnknownFormatConversionException__init_(jl_String_valueOf($this.$format8.$charAt($this.$index0 - 1 | 0))));
    }
    if ($this.$index0 < $this.$format8.$length()) {
        var$3 = $this.$format8;
        var$4 = $this.$index0;
        $this.$index0 = var$4 + 1 | 0;
        return var$3.$charAt(var$4);
    }
    $rt_throw(ju_UnknownFormatConversionException__init_(jl_String_valueOf($this.$format8.$charAt($this.$format8.$length() - 1 | 0))));
},
ju_Formatter$FormatWriter_parseFlags = $this => {
    let $c, $flag;
    a: {
        while ($this.$index0 < $this.$format8.$length()) {
            b: {
                $c = $this.$format8.$charAt($this.$index0);
                switch ($c) {
                    case 32:
                        break;
                    case 33:
                    case 34:
                    case 36:
                    case 37:
                    case 38:
                    case 39:
                    case 41:
                    case 42:
                    case 46:
                    case 47:
                    case 49:
                    case 50:
                    case 51:
                    case 52:
                    case 53:
                    case 54:
                    case 55:
                    case 56:
                    case 57:
                    case 58:
                    case 59:
                        break a;
                    case 35:
                        $flag = 4;
                        break b;
                    case 40:
                        $flag = 128;
                        break b;
                    case 43:
                        $flag = 8;
                        break b;
                    case 44:
                        $flag = 64;
                        break b;
                    case 45:
                        $flag = 1;
                        break b;
                    case 48:
                        $flag = 32;
                        break b;
                    case 60:
                        $flag = 256;
                        break b;
                    default:
                        break a;
                }
                $flag = 16;
            }
            if ($this.$flags & $flag)
                $rt_throw(ju_DuplicateFormatFlagsException__init_0(jl_String_valueOf($c)));
            $this.$flags = $this.$flags | $flag;
            $this.$index0 = $this.$index0 + 1 | 0;
        }
        return;
    }
},
ju_Formatter$FormatWriter_readInt = $this => {
    let $result, var$2, var$3, var$4;
    $result = 0;
    while ($this.$index0 < $this.$format8.$length() && ju_Formatter$FormatWriter_isDigit($this.$format8.$charAt($this.$index0))) {
        var$2 = $result * 10 | 0;
        var$3 = $this.$format8;
        var$4 = $this.$index0;
        $this.$index0 = var$4 + 1 | 0;
        $result = var$2 + (var$3.$charAt(var$4) - 48 | 0) | 0;
    }
    return $result;
},
ju_Formatter$FormatWriter_isDigit = $c => {
    return $c >= 48 && $c <= 57 ? 1 : 0;
};
function jt_DecimalFormatSymbols() {
    let a = this; jl_Object.call(a);
    a.$locale = null;
    a.$zeroDigit = 0;
    a.$groupingSeparator = 0;
    a.$decimalSeparator = 0;
    a.$perMill = 0;
    a.$percent = 0;
    a.$digit = 0;
    a.$patternSeparator = 0;
    a.$nan = null;
    a.$infinity = null;
    a.$minusSign = 0;
    a.$monetaryDecimalSeparator = 0;
    a.$exponentSeparator = null;
}
let jt_DecimalFormatSymbols__init_1 = $this => {
    jt_DecimalFormatSymbols__init_0($this, ju_Locale_getDefault());
},
jt_DecimalFormatSymbols__init_2 = () => {
    let var_0 = new jt_DecimalFormatSymbols();
    jt_DecimalFormatSymbols__init_1(var_0);
    return var_0;
},
jt_DecimalFormatSymbols__init_0 = ($this, $locale) => {
    jl_Object__init_($this);
    $this.$locale = $locale;
    jt_DecimalFormatSymbols_initData($this);
},
jt_DecimalFormatSymbols__init_ = var_0 => {
    let var_1 = new jt_DecimalFormatSymbols();
    jt_DecimalFormatSymbols__init_0(var_1, var_0);
    return var_1;
},
jt_DecimalFormatSymbols_initData = $this => {
    let $data, var$2, var$3;
    $data = otciu_CLDRHelper_resolveDecimalData(ju_Locale_getLanguage($this.$locale), ju_Locale_getCountry($this.$locale));
    $this.$zeroDigit = 48;
    var$2 = $data.groupingSeparator;
    $this.$groupingSeparator = var$2 & 65535;
    var$2 = $data.decimalSeparator;
    $this.$decimalSeparator = var$2 & 65535;
    var$2 = $data.perMille;
    $this.$perMill = var$2 & 65535;
    var$2 = $data.percent;
    $this.$percent = var$2 & 65535;
    $this.$digit = 35;
    $this.$patternSeparator = 59;
    var$3 = ($data.naN !== null ? $rt_str($data.naN) : null);
    $this.$nan = var$3;
    var$3 = ($data.infinity !== null ? $rt_str($data.infinity) : null);
    $this.$infinity = var$3;
    var$2 = $data.minusSign;
    $this.$minusSign = var$2 & 65535;
    var$2 = $data.decimalSeparator;
    $this.$monetaryDecimalSeparator = var$2 & 65535;
    var$3 = ($data.exponentSeparator !== null ? $rt_str($data.exponentSeparator) : null);
    $this.$exponentSeparator = var$3;
},
jt_DecimalFormatSymbols_getZeroDigit = $this => {
    return $this.$zeroDigit;
},
jt_DecimalFormatSymbols_getGroupingSeparator = $this => {
    return $this.$groupingSeparator;
},
jt_DecimalFormatSymbols_getPerMill = $this => {
    return $this.$perMill;
},
jt_DecimalFormatSymbols_getPercent = $this => {
    return $this.$percent;
},
jt_DecimalFormatSymbols_getLocale = $this => {
    return $this.$locale;
},
jt_DecimalFormatSymbols_getDecimalSeparator = $this => {
    return $this.$decimalSeparator;
},
jt_DecimalFormatSymbols_getNaN = $this => {
    return $this.$nan;
},
jt_DecimalFormatSymbols_getInfinity = $this => {
    return $this.$infinity;
},
jt_DecimalFormatSymbols_getMinusSign = $this => {
    return $this.$minusSign;
},
jt_DecimalFormatSymbols_getExponentSeparator = $this => {
    return $this.$exponentSeparator;
},
jt_DecimalFormatSymbols_clone = $this => {
    let var$1, $e, $$je;
    a: {
        try {
            var$1 = jl_Object_clone($this);
        } catch ($$e) {
            $$je = $rt_wrapException($$e);
            if ($$je instanceof jl_CloneNotSupportedException) {
                $e = $$je;
                break a;
            } else {
                throw $$e;
            }
        }
        return var$1;
    }
    $rt_throw(jl_AssertionError__init_0($rt_s(112), $e));
};
function ju_HashMap$AbstractMapIterator() {
    let a = this; jl_Object.call(a);
    a.$position = 0;
    a.$expectedModCount = 0;
    a.$futureEntry = null;
    a.$currentEntry = null;
    a.$prevEntry = null;
    a.$associatedMap = null;
}
let ju_HashMap$AbstractMapIterator__init_ = ($this, $hm) => {
    jl_Object__init_($this);
    $this.$associatedMap = $hm;
    $this.$expectedModCount = $hm.$modCount0;
    $this.$futureEntry = null;
},
ju_HashMap$AbstractMapIterator__init_0 = var_0 => {
    let var_1 = new ju_HashMap$AbstractMapIterator();
    ju_HashMap$AbstractMapIterator__init_(var_1, var_0);
    return var_1;
},
ju_HashMap$AbstractMapIterator_hasNext = $this => {
    if ($this.$futureEntry !== null)
        return 1;
    while ($this.$position < $this.$associatedMap.$elementData.data.length) {
        if ($this.$associatedMap.$elementData.data[$this.$position] !== null)
            return 1;
        $this.$position = $this.$position + 1 | 0;
    }
    return 0;
},
ju_HashMap$AbstractMapIterator_checkConcurrentMod = $this => {
    if ($this.$expectedModCount == $this.$associatedMap.$modCount0)
        return;
    $rt_throw(ju_ConcurrentModificationException__init_());
},
ju_HashMap$AbstractMapIterator_makeNext = $this => {
    let var$1, var$2;
    ju_HashMap$AbstractMapIterator_checkConcurrentMod($this);
    if (!$this.$hasNext())
        $rt_throw(ju_NoSuchElementException__init_0());
    if ($this.$futureEntry === null) {
        var$1 = $this.$associatedMap.$elementData.data;
        var$2 = $this.$position;
        $this.$position = var$2 + 1 | 0;
        $this.$currentEntry = var$1[var$2];
        $this.$futureEntry = $this.$currentEntry.$next1;
        $this.$prevEntry = null;
    } else {
        if ($this.$currentEntry !== null)
            $this.$prevEntry = $this.$currentEntry;
        $this.$currentEntry = $this.$futureEntry;
        $this.$futureEntry = $this.$futureEntry.$next1;
    }
},
ju_HashMap$AbstractMapIterator_remove = $this => {
    let $index, var$2;
    ju_HashMap$AbstractMapIterator_checkConcurrentMod($this);
    if ($this.$currentEntry === null)
        $rt_throw(jl_IllegalStateException__init_());
    if ($this.$prevEntry !== null)
        $this.$prevEntry.$next1 = $this.$currentEntry.$next1;
    else {
        $index = $this.$currentEntry.$origKeyHash & ($this.$associatedMap.$elementData.data.length - 1 | 0);
        $this.$associatedMap.$elementData.data[$index] = $this.$associatedMap.$elementData.data[$index].$next1;
    }
    $this.$currentEntry = null;
    $this.$expectedModCount = $this.$expectedModCount + 1 | 0;
    var$2 = $this.$associatedMap;
    var$2.$modCount0 = var$2.$modCount0 + 1 | 0;
    var$2 = $this.$associatedMap;
    var$2.$elementCount = var$2.$elementCount - 1 | 0;
},
jl_AutoCloseable = $rt_classWithoutFields(0),
jl_NullPointerException = $rt_classWithoutFields(jl_RuntimeException),
jl_NullPointerException__init_2 = ($this, $message) => {
    jl_RuntimeException__init_0($this, $message);
},
jl_NullPointerException__init_1 = var_0 => {
    let var_1 = new jl_NullPointerException();
    jl_NullPointerException__init_2(var_1, var_0);
    return var_1;
},
jl_NullPointerException__init_0 = $this => {
    jl_RuntimeException__init_($this);
},
jl_NullPointerException__init_ = () => {
    let var_0 = new jl_NullPointerException();
    jl_NullPointerException__init_0(var_0);
    return var_0;
},
ji_Closeable = $rt_classWithoutFields(0);
function ju_Formatter() {
    let a = this; jl_Object.call(a);
    a.$locale1 = null;
    a.$out0 = null;
    a.$ioException = null;
}
let ju_Formatter__init_1 = $this => {
    ju_Formatter__init_($this, ju_Locale_getDefault());
},
ju_Formatter__init_2 = () => {
    let var_0 = new ju_Formatter();
    ju_Formatter__init_1(var_0);
    return var_0;
},
ju_Formatter__init_ = ($this, $l) => {
    ju_Formatter__init_0($this, jl_StringBuilder__init_(), $l);
},
ju_Formatter__init_4 = var_0 => {
    let var_1 = new ju_Formatter();
    ju_Formatter__init_(var_1, var_0);
    return var_1;
},
ju_Formatter__init_0 = ($this, $a, $l) => {
    jl_Object__init_($this);
    $this.$out0 = $a;
    $this.$locale1 = $l;
},
ju_Formatter__init_3 = (var_0, var_1) => {
    let var_2 = new ju_Formatter();
    ju_Formatter__init_0(var_2, var_0, var_1);
    return var_2;
},
ju_Formatter_requireOpen = $this => {
    if ($this.$out0 !== null)
        return;
    $rt_throw(ju_FormatterClosedException__init_0());
},
ju_Formatter_toString = $this => {
    ju_Formatter_requireOpen($this);
    return $this.$out0.$toString();
},
ju_Formatter_format0 = ($this, $format, $args) => {
    return ju_Formatter_format($this, $this.$locale1, $format, $args);
},
ju_Formatter_format = ($this, $l, $format, $args) => {
    let $e, $$je;
    ju_Formatter_requireOpen($this);
    a: {
        try {
            if ($args === null)
                $args = $rt_createArray(jl_Object, 1);
            (ju_Formatter$FormatWriter__init_0($this, $this.$out0, $l, $format, $args)).$write();
            break a;
        } catch ($$e) {
            $$je = $rt_wrapException($$e);
            if ($$je instanceof ji_IOException) {
                $e = $$je;
            } else {
                throw $$e;
            }
        }
        $this.$ioException = $e;
    }
    return $this;
};
function otpp_AsyncCallbackWrapper() {
    jl_Object.call(this);
    this.$realAsyncCallback = null;
}
let otpp_AsyncCallbackWrapper__init_ = ($this, $realAsyncCallback) => {
    jl_Object__init_($this);
    $this.$realAsyncCallback = $realAsyncCallback;
},
otpp_AsyncCallbackWrapper__init_0 = var_0 => {
    let var_1 = new otpp_AsyncCallbackWrapper();
    otpp_AsyncCallbackWrapper__init_(var_1, var_0);
    return var_1;
},
otpp_AsyncCallbackWrapper_create = $realAsyncCallback => {
    return otpp_AsyncCallbackWrapper__init_0($realAsyncCallback);
},
otpp_AsyncCallbackWrapper_complete = ($this, $result) => {
    $this.$realAsyncCallback.$complete($result);
},
otpp_AsyncCallbackWrapper_error = ($this, $e) => {
    $this.$realAsyncCallback.$error($e);
};
function ju_IllegalFormatPrecisionException() {
    ju_IllegalFormatException.call(this);
    this.$precision2 = 0;
}
let ju_IllegalFormatPrecisionException__init_ = ($this, $precision) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append0(jl_StringBuilder_append(var$2, $rt_s(113)), $precision);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$precision2 = $precision;
},
ju_IllegalFormatPrecisionException__init_0 = var_0 => {
    let var_1 = new ju_IllegalFormatPrecisionException();
    ju_IllegalFormatPrecisionException__init_(var_1, var_0);
    return var_1;
};
function jl_Object$Monitor() {
    let a = this; jl_Object.call(a);
    a.$enteringThreads = null;
    a.$notifyListeners = null;
    a.$owner = null;
    a.$count = 0;
}
let jl_Object$Monitor__init_ = $this => {
    jl_Object__init_($this);
    $this.$owner = jl_Thread_currentThread();
},
jl_Object$Monitor__init_0 = () => {
    let var_0 = new jl_Object$Monitor();
    jl_Object$Monitor__init_(var_0);
    return var_0;
},
jl_Math = $rt_classWithoutFields(),
jl_Math_pow = ($x, $y) => {
    return jl_Math_powImpl($x, $y);
},
jl_Math_powImpl = (var$1, var$2) => {
    return Math.pow(var$1, var$2);
},
jl_Math_min = (var$1, var$2) => {
    if (var$1 < var$2)
        var$2 = var$1;
    return var$2;
},
jl_Math_max = ($a, $b) => {
    if ($a > $b)
        $b = $a;
    return $b;
},
jl_Math_minImpl = (var$1, var$2) => {
    return Math.min(var$1, var$2);
},
jl_Math_min0 = (var$1, var$2) => {
    return jl_Math_minImpl(var$1, var$2);
},
jl_Math_maxImpl = (var$1, var$2) => {
    return Math.max(var$1, var$2);
},
jl_Math_max0 = (var$1, var$2) => {
    return jl_Math_maxImpl(var$1, var$2);
},
jl_Math_abs = $n => {
    if ($n < 0)
        $n =  -$n | 0;
    return $n;
},
jl_Math_abs0 = $n => {
    if (Long_lt($n, Long_ZERO))
        $n = Long_neg($n);
    return $n;
},
jl_Math_absImpl = var$1 => {
    return Math.abs(var$1);
},
jl_Math_abs1 = var$1 => {
    return jl_Math_absImpl(var$1);
},
ju_AbstractSet = $rt_classWithoutFields(ju_AbstractCollection),
ju_AbstractSet__init_ = $this => {
    ju_AbstractCollection__init_($this);
},
ju_AbstractSet_equals = ($this, $obj) => {
    let $other, $iter;
    if ($this === $obj)
        return 1;
    if (!$rt_isInstance($obj, ju_Set))
        return 0;
    $other = $obj;
    if ($this.$size() != $other.$size())
        return 0;
    $iter = $other.$iterator();
    while ($iter.$hasNext()) {
        if ($this.$contains($iter.$next()))
            continue;
        else
            return 0;
    }
    return 1;
},
ju_AbstractSet_hashCode = $this => {
    let $result, $iter, $e;
    $result = 0;
    $iter = $this.$iterator();
    while ($iter.$hasNext()) {
        $e = $iter.$next();
        if ($e !== null)
            $result = $result + $e.$hashCode0() | 0;
    }
    return $result;
};
function ju_HashMap$HashMapEntrySet() {
    ju_AbstractSet.call(this);
    this.$associatedMap0 = null;
}
let ju_HashMap$HashMapEntrySet__init_ = ($this, $hm) => {
    ju_AbstractSet__init_($this);
    $this.$associatedMap0 = $hm;
},
ju_HashMap$HashMapEntrySet__init_0 = var_0 => {
    let var_1 = new ju_HashMap$HashMapEntrySet();
    ju_HashMap$HashMapEntrySet__init_(var_1, var_0);
    return var_1;
},
ju_HashMap$HashMapEntrySet_size = $this => {
    return $this.$associatedMap0.$elementCount;
},
ju_HashMap$HashMapEntrySet_contains = ($this, $object) => {
    let $oEntry, $entry;
    if (!$rt_isInstance($object, ju_Map$Entry))
        return 0;
    $oEntry = $object;
    $entry = ju_HashMap_entryByKey($this.$associatedMap0, $oEntry.$getKey());
    return $entry !== null && ju_Objects_equals($entry.$getValue(), $oEntry.$getValue()) ? 1 : 0;
},
ju_HashMap$HashMapEntrySet_iterator = $this => {
    return ju_HashMap$EntryIterator__init_0($this.$associatedMap0);
},
jl_Byte = $rt_classWithoutFields(jl_Number);
function jm_RoundingMode() {
    jl_Enum.call(this);
    this.$bigDecimalRM = 0;
}
let jm_RoundingMode_UP = null,
jm_RoundingMode_DOWN = null,
jm_RoundingMode_CEILING = null,
jm_RoundingMode_FLOOR = null,
jm_RoundingMode_HALF_UP = null,
jm_RoundingMode_HALF_DOWN = null,
jm_RoundingMode_HALF_EVEN = null,
jm_RoundingMode_UNNECESSARY = null,
jm_RoundingMode_$VALUES = null,
jm_RoundingMode_$callClinit = () => {
    jm_RoundingMode_$callClinit = $rt_eraseClinit(jm_RoundingMode);
    jm_RoundingMode__clinit_();
},
jm_RoundingMode_values = () => {
    jm_RoundingMode_$callClinit();
    return jm_RoundingMode_$VALUES.$clone0();
},
jm_RoundingMode__init_0 = ($this, var$1, var$2, $rm) => {
    jm_RoundingMode_$callClinit();
    jl_Enum__init_($this, var$1, var$2);
    $this.$bigDecimalRM = $rm;
},
jm_RoundingMode__init_ = (var_0, var_1, var_2) => {
    let var_3 = new jm_RoundingMode();
    jm_RoundingMode__init_0(var_3, var_0, var_1, var_2);
    return var_3;
},
jm_RoundingMode_$values = () => {
    let var$1, var$2;
    jm_RoundingMode_$callClinit();
    var$1 = $rt_createArray(jm_RoundingMode, 8);
    var$2 = var$1.data;
    var$2[0] = jm_RoundingMode_UP;
    var$2[1] = jm_RoundingMode_DOWN;
    var$2[2] = jm_RoundingMode_CEILING;
    var$2[3] = jm_RoundingMode_FLOOR;
    var$2[4] = jm_RoundingMode_HALF_UP;
    var$2[5] = jm_RoundingMode_HALF_DOWN;
    var$2[6] = jm_RoundingMode_HALF_EVEN;
    var$2[7] = jm_RoundingMode_UNNECESSARY;
    return var$1;
},
jm_RoundingMode__clinit_ = () => {
    jm_RoundingMode_UP = jm_RoundingMode__init_($rt_s(114), 0, 0);
    jm_RoundingMode_DOWN = jm_RoundingMode__init_($rt_s(115), 1, 1);
    jm_RoundingMode_CEILING = jm_RoundingMode__init_($rt_s(116), 2, 2);
    jm_RoundingMode_FLOOR = jm_RoundingMode__init_($rt_s(117), 3, 3);
    jm_RoundingMode_HALF_UP = jm_RoundingMode__init_($rt_s(118), 4, 4);
    jm_RoundingMode_HALF_DOWN = jm_RoundingMode__init_($rt_s(119), 5, 5);
    jm_RoundingMode_HALF_EVEN = jm_RoundingMode__init_($rt_s(120), 6, 6);
    jm_RoundingMode_UNNECESSARY = jm_RoundingMode__init_($rt_s(121), 7, 7);
    jm_RoundingMode_$VALUES = jm_RoundingMode_$values();
};
function jt_DecimalFormatParser() {
    let a = this; jl_Object.call(a);
    a.$positivePrefix0 = null;
    a.$positiveSuffix0 = null;
    a.$negativePrefix0 = null;
    a.$negativeSuffix0 = null;
    a.$groupSize = 0;
    a.$minimumIntLength = 0;
    a.$intLength = 0;
    a.$minimumFracLength = 0;
    a.$fracLength = 0;
    a.$exponentLength = 0;
    a.$decimalSeparatorRequired = 0;
    a.$string = null;
    a.$index = 0;
    a.$multiplier0 = 0;
}
let jt_DecimalFormatParser__init_ = $this => {
    jl_Object__init_($this);
},
jt_DecimalFormatParser__init_0 = () => {
    let var_0 = new jt_DecimalFormatParser();
    jt_DecimalFormatParser__init_(var_0);
    return var_0;
},
jt_DecimalFormatParser_parse = ($this, $string) => {
    let var$2, var$3, var$4, var$5;
    $this.$groupSize = 0;
    $this.$minimumFracLength = 0;
    $this.$fracLength = 0;
    $this.$exponentLength = 0;
    $this.$decimalSeparatorRequired = 0;
    $this.$multiplier0 = 1;
    $this.$string = $string;
    $this.$index = 0;
    $this.$positivePrefix0 = $this.$parseText(0, 0);
    if ($this.$index == $string.$length()) {
        var$2 = new jl_IllegalArgumentException;
        var$3 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(var$3, $rt_s(122)), $string);
        jl_IllegalArgumentException__init_(var$2, jl_StringBuilder_toString(var$3));
        $rt_throw(var$2);
    }
    jt_DecimalFormatParser_parseNumber($this, 1);
    $this.$negativePrefix0 = null;
    $this.$negativeSuffix0 = null;
    if ($this.$index < $string.$length() && $string.$charAt($this.$index) != 59)
        $this.$positiveSuffix0 = $this.$parseText(1, 0);
    if ($this.$index < $string.$length()) {
        var$4 = $this.$index;
        $this.$index = var$4 + 1 | 0;
        if ($string.$charAt(var$4) != 59) {
            var$2 = new jl_IllegalArgumentException;
            var$5 = $this.$index;
            var$3 = jl_StringBuilder__init_();
            jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$3, $rt_s(123)), var$5), $rt_s(124)), $string);
            jl_IllegalArgumentException__init_(var$2, jl_StringBuilder_toString(var$3));
            $rt_throw(var$2);
        }
        $this.$negativePrefix0 = $this.$parseText(0, 1);
        jt_DecimalFormatParser_parseNumber($this, 0);
        $this.$negativeSuffix0 = $this.$parseText(1, 1);
    }
},
jt_DecimalFormatParser_apply = ($this, $format) => {
    $format.$positivePrefix = $this.$positivePrefix0;
    $format.$positiveSuffix = $this.$positiveSuffix0;
    if ($this.$negativePrefix0 !== null)
        $format.$negativePrefix = $this.$negativePrefix0;
    else {
        $format.$negativePrefix = $rt_createArray(jt_DecimalFormat$FormatField, $this.$positivePrefix0.data.length + 1 | 0);
        jl_System_fastArraycopy($this.$positivePrefix0, 0, $format.$negativePrefix, 1, $this.$positivePrefix0.data.length);
        $format.$negativePrefix.data[0] = jt_DecimalFormat$MinusField__init_0();
    }
    $format.$negativeSuffix = $this.$negativeSuffix0 === null ? $this.$positiveSuffix0 : $this.$negativeSuffix0;
    $format.$setGroupingSize($this.$groupSize);
    $format.$setGroupingUsed($this.$groupSize <= 0 ? 0 : 1);
    $format.$setMinimumIntegerDigits(!$this.$decimalSeparatorRequired ? $this.$minimumIntLength : jl_Math_max(1, $this.$minimumIntLength));
    $format.$setMaximumIntegerDigits($this.$intLength);
    $format.$setMinimumFractionDigits($this.$minimumFracLength);
    $format.$setMaximumFractionDigits($this.$fracLength);
    $format.$setDecimalSeparatorAlwaysShown($this.$decimalSeparatorRequired);
    $format.$exponentDigits = $this.$exponentLength;
    $format.$setMultiplier($this.$multiplier0);
},
jt_DecimalFormatParser_parseText = ($this, $suffix, $end) => {
    let $fields, $sb, $c, var$6, var$7, var$8, var$9, $next;
    $fields = ju_ArrayList__init_();
    $sb = jl_StringBuilder__init_();
    a: {
        b: {
            c: while (true) {
                if ($this.$index >= $this.$string.$length())
                    break a;
                d: {
                    $c = $this.$string.$charAt($this.$index);
                    switch ($c) {
                        case 35:
                        case 48:
                            if (!$suffix)
                                break a;
                            var$6 = new jl_IllegalArgumentException;
                            var$7 = $this.$index;
                            var$8 = $this.$string;
                            var$9 = jl_StringBuilder__init_();
                            jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(125)), var$7), $rt_s(124)), var$8);
                            jl_IllegalArgumentException__init_(var$6, jl_StringBuilder_toString(var$9));
                            $rt_throw(var$6);
                        case 37:
                            if ($sb.$length() > 0) {
                                $fields.$add0(jt_DecimalFormat$TextField__init_($sb.$toString()));
                                $sb.$setLength(0);
                            }
                            $fields.$add0(jt_DecimalFormat$PercentField__init_0());
                            $this.$index = $this.$index + 1 | 0;
                            $this.$multiplier0 = 100;
                            break d;
                        case 39:
                            $this.$index = $this.$index + 1 | 0;
                            $next = $this.$string.$indexOf0(39, $this.$index);
                            if ($next < 0) {
                                var$6 = new jl_IllegalArgumentException;
                                var$7 = $this.$index;
                                var$8 = $this.$string;
                                var$9 = jl_StringBuilder__init_();
                                jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(126)), var$7), $rt_s(127)), var$8);
                                jl_IllegalArgumentException__init_(var$6, jl_StringBuilder_toString(var$9));
                                $rt_throw(var$6);
                            }
                            if ($next == $this.$index)
                                $sb.$append0(39);
                            else
                                $sb.$append19($this.$string.$substring0($this.$index, $next));
                            $this.$index = $next + 1 | 0;
                            break d;
                        case 45:
                            if ($sb.$length() > 0) {
                                $fields.$add0(jt_DecimalFormat$TextField__init_($sb.$toString()));
                                $sb.$setLength(0);
                            }
                            $fields.$add0(jt_DecimalFormat$MinusField__init_0());
                            $this.$index = $this.$index + 1 | 0;
                            break d;
                        case 46:
                        case 69:
                            break c;
                        case 59:
                            break b;
                        case 164:
                            if ($sb.$length() > 0) {
                                $fields.$add0(jt_DecimalFormat$TextField__init_($sb.$toString()));
                                $sb.$setLength(0);
                            }
                            $fields.$add0(jt_DecimalFormat$CurrencyField__init_0());
                            $this.$index = $this.$index + 1 | 0;
                            break d;
                        case 8240:
                            if ($sb.$length() > 0) {
                                $fields.$add0(jt_DecimalFormat$TextField__init_($sb.$toString()));
                                $sb.$setLength(0);
                            }
                            $fields.$add0(jt_DecimalFormat$PerMillField__init_0());
                            $this.$index = $this.$index + 1 | 0;
                            $this.$multiplier0 = 1000;
                            break d;
                        default:
                    }
                    $sb.$append0($c);
                    $this.$index = $this.$index + 1 | 0;
                }
            }
            var$6 = new jl_IllegalArgumentException;
            var$7 = $this.$index;
            var$8 = $this.$string;
            var$9 = jl_StringBuilder__init_();
            jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(125)), var$7), $rt_s(124)), var$8);
            jl_IllegalArgumentException__init_(var$6, jl_StringBuilder_toString(var$9));
            $rt_throw(var$6);
        }
        if ($end) {
            var$6 = new jl_IllegalArgumentException;
            var$7 = $this.$index;
            var$8 = $this.$string;
            var$9 = jl_StringBuilder__init_();
            jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$9, $rt_s(125)), var$7), $rt_s(124)), var$8);
            jl_IllegalArgumentException__init_(var$6, jl_StringBuilder_toString(var$9));
            $rt_throw(var$6);
        }
    }
    if ($sb.$length() > 0)
        $fields.$add0(jt_DecimalFormat$TextField__init_($sb.$toString()));
    return $fields.$toArray($rt_createArray(jt_DecimalFormat$FormatField, $fields.$size()));
},
jt_DecimalFormatParser_parseNumber = ($this, $apply) => {
    jt_DecimalFormatParser_parseIntegerPart($this, $apply);
    if ($this.$index < $this.$string.$length() && $this.$string.$charAt($this.$index) == 46) {
        $this.$index = $this.$index + 1 | 0;
        jt_DecimalFormatParser_parseFractionalPart($this, $apply);
    }
    if ($this.$index < $this.$string.$length() && $this.$string.$charAt($this.$index) == 69) {
        $this.$index = $this.$index + 1 | 0;
        jt_DecimalFormatParser_parseExponent($this, $apply);
    }
},
jt_DecimalFormatParser_parseIntegerPart = ($this, $apply) => {
    let $start, $lastGroup, $optionalDigits, $length, $minimumLength, var$7, var$8, var$9, var$10;
    $start = $this.$index;
    $lastGroup = $this.$index;
    $optionalDigits = 1;
    $length = 0;
    $minimumLength = 0;
    a: {
        b: while (true) {
            if ($this.$index >= $this.$string.$length())
                break a;
            c: {
                d: {
                    switch ($this.$string.$charAt($this.$index)) {
                        case 35:
                            if (!$optionalDigits)
                                break b;
                            $length = $length + 1 | 0;
                            break c;
                        case 44:
                            break d;
                        case 48:
                            break;
                        default:
                            break a;
                    }
                    $optionalDigits = 0;
                    $length = $length + 1 | 0;
                    $minimumLength = $minimumLength + 1 | 0;
                    break c;
                }
                if ($lastGroup == $this.$index) {
                    var$7 = new jl_IllegalArgumentException;
                    var$8 = $this.$index;
                    var$9 = $this.$string;
                    var$10 = jl_StringBuilder__init_();
                    jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$10, $rt_s(128)), var$8), $rt_s(124)), var$9);
                    jl_IllegalArgumentException__init_(var$7, jl_StringBuilder_toString(var$10));
                    $rt_throw(var$7);
                }
                if ($apply)
                    $this.$groupSize = $this.$index - $lastGroup | 0;
                $lastGroup = $this.$index + 1 | 0;
            }
            $this.$index = $this.$index + 1 | 0;
        }
        var$7 = new jl_IllegalArgumentException;
        var$8 = $this.$index;
        var$9 = $this.$string;
        var$10 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$10, $rt_s(129)), var$8), $rt_s(124)), var$9);
        jl_IllegalArgumentException__init_(var$7, jl_StringBuilder_toString(var$10));
        $rt_throw(var$7);
    }
    if (!$length) {
        var$7 = new jl_IllegalArgumentException;
        var$8 = $this.$index;
        var$9 = $this.$string;
        var$10 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$10, $rt_s(130)), var$8), $rt_s(124)), var$9);
        jl_IllegalArgumentException__init_(var$7, jl_StringBuilder_toString(var$10));
        $rt_throw(var$7);
    }
    if ($lastGroup == $this.$index) {
        var$7 = new jl_IllegalArgumentException;
        var$8 = $this.$index;
        var$9 = $this.$string;
        var$10 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$10, $rt_s(131)), var$8), $rt_s(124)), var$9);
        jl_IllegalArgumentException__init_(var$7, jl_StringBuilder_toString(var$10));
        $rt_throw(var$7);
    }
    if ($apply && $lastGroup > $start)
        $this.$groupSize = $this.$index - $lastGroup | 0;
    if ($apply) {
        $this.$intLength = $length;
        $this.$minimumIntLength = $minimumLength;
    }
},
jt_DecimalFormatParser_parseFractionalPart = ($this, $apply) => {
    let $optionalDigits, $length, $minimumLength, var$5, var$6, var$7, var$8;
    $optionalDigits = 0;
    $length = 0;
    $minimumLength = 0;
    a: {
        b: while (true) {
            if ($this.$index >= $this.$string.$length())
                break a;
            c: {
                switch ($this.$string.$charAt($this.$index)) {
                    case 35:
                        break;
                    case 44:
                        var$5 = new jl_IllegalArgumentException;
                        var$6 = $this.$index;
                        var$7 = $this.$string;
                        var$8 = jl_StringBuilder__init_();
                        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$8, $rt_s(132)), var$6), $rt_s(124)), var$7);
                        jl_IllegalArgumentException__init_(var$5, jl_StringBuilder_toString(var$8));
                        $rt_throw(var$5);
                    case 46:
                        var$5 = new jl_IllegalArgumentException;
                        var$6 = $this.$index;
                        var$7 = $this.$string;
                        var$8 = jl_StringBuilder__init_();
                        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$8, $rt_s(133)), var$6), $rt_s(124)), var$7);
                        jl_IllegalArgumentException__init_(var$5, jl_StringBuilder_toString(var$8));
                        $rt_throw(var$5);
                    case 48:
                        if ($optionalDigits)
                            break b;
                        $length = $length + 1 | 0;
                        $minimumLength = $minimumLength + 1 | 0;
                        break c;
                    default:
                        break a;
                }
                $length = $length + 1 | 0;
                $optionalDigits = 1;
            }
            $this.$index = $this.$index + 1 | 0;
        }
        var$5 = new jl_IllegalArgumentException;
        var$6 = $this.$index;
        var$7 = $this.$string;
        var$8 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$8, $rt_s(134)), var$6), $rt_s(124)), var$7);
        jl_IllegalArgumentException__init_(var$5, jl_StringBuilder_toString(var$8));
        $rt_throw(var$5);
    }
    if ($apply) {
        $this.$fracLength = $length;
        $this.$minimumFracLength = $minimumLength;
        $this.$decimalSeparatorRequired = $length ? 0 : 1;
    }
},
jt_DecimalFormatParser_parseExponent = ($this, $apply) => {
    let $length, var$3, var$4, var$5, var$6;
    $length = 0;
    a: {
        b: while (true) {
            if ($this.$index >= $this.$string.$length())
                break a;
            switch ($this.$string.$charAt($this.$index)) {
                case 35:
                case 44:
                case 46:
                case 69:
                    break b;
                case 48:
                    break;
                default:
                    break a;
            }
            $length = $length + 1 | 0;
            $this.$index = $this.$index + 1 | 0;
        }
        var$3 = new jl_IllegalArgumentException;
        var$4 = $this.$index;
        var$5 = $this.$string;
        var$6 = jl_StringBuilder__init_();
        jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$6, $rt_s(135)), var$4), $rt_s(124)), var$5);
        jl_IllegalArgumentException__init_(var$3, jl_StringBuilder_toString(var$6));
        $rt_throw(var$3);
    }
    if ($length) {
        if ($apply)
            $this.$exponentLength = $length;
        return;
    }
    var$3 = new jl_IllegalArgumentException;
    var$4 = $this.$index;
    var$5 = $this.$string;
    var$6 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(jl_StringBuilder_append0(jl_StringBuilder_append(var$6, $rt_s(136)), var$4), $rt_s(124)), var$5);
    jl_IllegalArgumentException__init_(var$3, jl_StringBuilder_toString(var$6));
    $rt_throw(var$3);
},
ju_Formattable = $rt_classWithoutFields(0),
rce_Graphics = $rt_classWithoutFields(),
rce_Graphics__init_ = $this => {
    jl_Object__init_($this);
},
rce_Graphics__init_0 = () => {
    let var_0 = new rce_Graphics();
    rce_Graphics__init_(var_0);
    return var_0;
},
rce_Graphics_drawRect = ($this, $x, $y, $width, $height, $color) => {
    if (rcei_JSBridge_isBrowser())
        rcei_JSBridge_drawRect$js_body$_6($x, $y, $width, $height, $rt_ustr($color.$toCssRgba()), !!1);
},
rce_Graphics_drawCircle = ($this, $x, $y, $radius, $color) => {
    if (rcei_JSBridge_isBrowser())
        rcei_JSBridge_drawCircle$js_body$_7($x, $y, $radius, $rt_ustr($color.$toCssRgba()), !!1);
},
rce_Graphics_drawLine = ($this, $x1, $y1, $x2, $y2, $color, $lineWidth) => {
    if (rcei_JSBridge_isBrowser())
        rcei_JSBridge_drawLine$js_body$_8($x1, $y1, $x2, $y2, $rt_ustr($color.$toCssRgba()), $lineWidth);
},
rce_Graphics_drawText0 = ($this, $text, $x, $y, $fontSize, $color) => {
    $this.$drawText0($text, $x, $y, $fontSize, $color, $rt_s(137));
},
rce_Graphics_drawText = ($this, $text, $x, $y, $fontSize, $color, $fontFamily) => {
    if (rcei_JSBridge_isBrowser())
        rcei_JSBridge_drawText$js_body$_9($rt_ustr($text), $x, $y, $fontSize, $rt_ustr($color.$toCssRgba()), $rt_ustr($fontFamily));
},
rce_Graphics_drawGrid = ($this, $width, $height, $cellSize, $color) => {
    let $x, var$6, $y, var$8;
    $x = 0;
    while ($x <= $width) {
        var$6 = $x;
        $this.$drawLine(var$6, 0.0, var$6, $height, $color, 1.0);
        $x = $x + $cellSize | 0;
    }
    $y = 0;
    while ($y <= $height) {
        var$8 = $y;
        $this.$drawLine(0.0, var$8, $width, var$8, $color, 1.0);
        $y = $y + $cellSize | 0;
    }
};
function rceb_DataBus() {
    let a = this; jl_Object.call(a);
    a.$subscribers = null;
    a.$busSniffers = null;
    a.$history = null;
}
let rceb_DataBus__init_ = $this => {
    jl_Object__init_($this);
    $this.$subscribers = ju_HashMap__init_();
    $this.$busSniffers = ju_ArrayList__init_();
    $this.$history = ju_ArrayDeque__init_1();
},
rceb_DataBus__init_0 = () => {
    let var_0 = new rceb_DataBus();
    rceb_DataBus__init_(var_0);
    return var_0;
};
function ju_HashMap() {
    let a = this; ju_AbstractMap.call(a);
    a.$elementCount = 0;
    a.$elementData = null;
    a.$modCount0 = 0;
    a.$loadFactor = 0.0;
    a.$threshold = 0;
}
let ju_HashMap_newElementArray = ($this, $s) => {
    return $rt_createArray(ju_HashMap$HashEntry, $s);
},
ju_HashMap__init_2 = $this => {
    ju_HashMap__init_0($this, 16);
},
ju_HashMap__init_ = () => {
    let var_0 = new ju_HashMap();
    ju_HashMap__init_2(var_0);
    return var_0;
},
ju_HashMap__init_0 = ($this, $capacity) => {
    ju_HashMap__init_1($this, $capacity, 0.75);
},
ju_HashMap__init_3 = var_0 => {
    let var_1 = new ju_HashMap();
    ju_HashMap__init_0(var_1, var_0);
    return var_1;
},
ju_HashMap_calculateCapacity = $x => {
    let var$2, var$3;
    if ($x >= 1073741824)
        return 1073741824;
    if (!$x)
        return 16;
    var$2 = $x - 1 | 0;
    var$3 = var$2 | var$2 >> 1;
    var$3 = var$3 | var$3 >> 2;
    var$3 = var$3 | var$3 >> 4;
    var$3 = var$3 | var$3 >> 8;
    var$3 = var$3 | var$3 >> 16;
    return var$3 + 1 | 0;
},
ju_HashMap__init_1 = ($this, $capacity, $loadFactor) => {
    let var$3;
    ju_AbstractMap__init_($this);
    if ($capacity >= 0 && $loadFactor > 0.0) {
        var$3 = ju_HashMap_calculateCapacity($capacity);
        $this.$elementCount = 0;
        $this.$elementData = $this.$newElementArray(var$3);
        $this.$loadFactor = $loadFactor;
        ju_HashMap_computeThreshold($this);
        return;
    }
    $rt_throw(jl_IllegalArgumentException__init_0());
},
ju_HashMap__init_4 = (var_0, var_1) => {
    let var_2 = new ju_HashMap();
    ju_HashMap__init_1(var_2, var_0, var_1);
    return var_2;
},
ju_HashMap_computeThreshold = $this => {
    $this.$threshold = $this.$elementData.data.length * $this.$loadFactor | 0;
},
ju_HashMap_containsKey = ($this, $key) => {
    let $m;
    $m = ju_HashMap_entryByKey($this, $key);
    return $m === null ? 0 : 1;
},
ju_HashMap_entrySet = $this => {
    return ju_HashMap$HashMapEntrySet__init_0($this);
},
ju_HashMap_get = ($this, $key) => {
    let $m;
    $m = ju_HashMap_entryByKey($this, $key);
    if ($m === null)
        return null;
    return $m.$value1;
},
ju_HashMap_entryByKey = ($this, $key) => {
    let $m, $hash, $index;
    if ($key === null)
        $m = ju_HashMap_findNullKeyEntry($this);
    else {
        $hash = $key.$hashCode0();
        $index = $hash & ($this.$elementData.data.length - 1 | 0);
        $m = ju_HashMap_findNonNullKeyEntry($this, $key, $index, $hash);
    }
    return $m;
},
ju_HashMap_findNonNullKeyEntry = ($this, $key, $index, $keyHash) => {
    let $m;
    $m = $this.$elementData.data[$index];
    while ($m !== null && !($m.$origKeyHash == $keyHash && ju_HashMap_areEqualKeys($key, $m.$key))) {
        $m = $m.$next1;
    }
    return $m;
},
ju_HashMap_findNullKeyEntry = $this => {
    let $m;
    $m = $this.$elementData.data[0];
    while ($m !== null && $m.$key !== null) {
        $m = $m.$next1;
    }
    return $m;
},
ju_HashMap_put = ($this, $key, $value) => {
    return ju_HashMap_putImpl($this, $key, $value);
},
ju_HashMap_putImpl = ($this, $key, $value) => {
    let $entry, var$4, $hash, $index, $result;
    if ($key === null) {
        $entry = ju_HashMap_findNullKeyEntry($this);
        if ($entry === null) {
            $this.$modCount0 = $this.$modCount0 + 1 | 0;
            $entry = ju_HashMap_createHashedEntry($this, null, 0, 0);
            var$4 = $this.$elementCount + 1 | 0;
            $this.$elementCount = var$4;
            if (var$4 > $this.$threshold)
                $this.$rehash();
        }
    } else {
        $hash = $key.$hashCode0();
        $index = $hash & ($this.$elementData.data.length - 1 | 0);
        $entry = ju_HashMap_findNonNullKeyEntry($this, $key, $index, $hash);
        if ($entry === null) {
            $this.$modCount0 = $this.$modCount0 + 1 | 0;
            $entry = ju_HashMap_createHashedEntry($this, $key, $index, $hash);
            var$4 = $this.$elementCount + 1 | 0;
            $this.$elementCount = var$4;
            if (var$4 > $this.$threshold)
                $this.$rehash();
        }
    }
    $result = $entry.$value1;
    $entry.$value1 = $value;
    return $result;
},
ju_HashMap_createHashedEntry = ($this, $key, $index, $hash) => {
    let $entry;
    $entry = ju_HashMap$HashEntry__init_0($key, $hash);
    $entry.$next1 = $this.$elementData.data[$index];
    $this.$elementData.data[$index] = $entry;
    return $entry;
},
ju_HashMap_rehash0 = ($this, $capacity) => {
    let $length, $newData, $i, $entry, var$6, $index, $next;
    $length = ju_HashMap_calculateCapacity(!$capacity ? 1 : $capacity << 1);
    $newData = $this.$newElementArray($length);
    $i = 0;
    while ($i < $this.$elementData.data.length) {
        $entry = $this.$elementData.data[$i];
        $this.$elementData.data[$i] = null;
        while ($entry !== null) {
            var$6 = $newData.data;
            $index = $entry.$origKeyHash & ($length - 1 | 0);
            $next = $entry.$next1;
            $entry.$next1 = var$6[$index];
            var$6[$index] = $entry;
            $entry = $next;
        }
        $i = $i + 1 | 0;
    }
    $this.$elementData = $newData;
    ju_HashMap_computeThreshold($this);
},
ju_HashMap_rehash = $this => {
    $this.$rehash0($this.$elementData.data.length);
},
ju_HashMap_size = $this => {
    return $this.$elementCount;
},
ju_HashMap_areEqualKeys = ($key1, $key2) => {
    return $key1 !== $key2 && !$key1.$equals($key2) ? 0 : 1;
},
jt_DecimalFormat$MinusField = $rt_classWithoutFields(),
jt_DecimalFormat$MinusField__init_ = $this => {
    jl_Object__init_($this);
},
jt_DecimalFormat$MinusField__init_0 = () => {
    let var_0 = new jt_DecimalFormat$MinusField();
    jt_DecimalFormat$MinusField__init_(var_0);
    return var_0;
},
jt_DecimalFormat$MinusField_render = ($this, $format, $buffer) => {
    $buffer.$append4($format.$symbols.$getMinusSign());
},
jt_DecimalFormat$MinusField_equals = ($this, $obj) => {
    return $obj instanceof jt_DecimalFormat$MinusField;
},
jt_DecimalFormat$MinusField_hashCode = $this => {
    return 3;
};
function ju_Comparator$comparingInt$lambda$_14_0() {
    jl_Object.call(this);
    this.$_02 = null;
}
let ju_Comparator$comparingInt$lambda$_14_0__init_ = (var$0, var$1) => {
    jl_Object__init_(var$0);
    var$0.$_02 = var$1;
},
ju_Comparator$comparingInt$lambda$_14_0__init_0 = var_0 => {
    let var_1 = new ju_Comparator$comparingInt$lambda$_14_0();
    ju_Comparator$comparingInt$lambda$_14_0__init_(var_1, var_0);
    return var_1;
},
ju_Comparator$comparingInt$lambda$_14_0_compare = (var$0, var$1, var$2) => {
    return ju_Comparator_lambda$comparingInt$10(var$0.$_02, var$1, var$2);
},
rcek_KaboomBridge = $rt_classWithoutFields(),
rcek_KaboomBridge_context = null,
rcek_KaboomBridge_initialized = 0,
rcek_KaboomBridge_$callClinit = () => {
    rcek_KaboomBridge_$callClinit = $rt_eraseClinit(rcek_KaboomBridge);
    rcek_KaboomBridge__clinit_();
},
rcek_KaboomBridge_tryInit = ($width, $height) => {
    let var$3, var$4, $$je;
    jl_Object_monitorEnterSync($rt_cls(rcek_KaboomBridge));
    try {
        rcek_KaboomBridge_$callClinit();
        if (!rcei_JSBridge_isBrowser())
            return 0;
        a: {
            b: {
                try {
                    if (!(typeof kaboom === 'function' ? 1 : 0))
                        break a;
                    var$3 = $rt_createIntArrayFromData([15, 18, 26]);
                    rcek_KaboomBridge_context = rcek_Kaboom_init$js_body$_2($width, $height, 1.0, otji_JS_wrap(var$3));
                    rcek_KaboomBridge_initialized = rcek_KaboomBridge_context === null ? 0 : 1;
                    if (rcek_KaboomBridge_initialized)
                        console.log('[\u041a\u0421\u041a 09.02.01 Engine] ' + "Kaboom.js успешно инициализирован в качестве бэкенда!");
                    var$4 = rcek_KaboomBridge_initialized;
                } catch ($$e) {
                    $$je = $rt_wrapException($$e);
                    if ($$je instanceof jl_Throwable) {
                        break b;
                    } else {
                        throw $$e;
                    }
                }
                return var$4;
            }
            console.log('[\u041a\u0421\u041a 09.02.01 Engine] ' + "Kaboom.js не обнаружен, используется нативный HTML5 Canvas движок.");
        }
        return 0;
    } finally {
        jl_Object_monitorExitSync($rt_cls(rcek_KaboomBridge));
    }
},
rcek_KaboomBridge__clinit_ = () => {
    rcek_KaboomBridge_initialized = 0;
};
function rce_Key() {
    let a = this; jl_Enum.call(a);
    a.$code = null;
    a.$altCode = null;
    a.$rawKey = null;
    a.$bitIndex = 0;
}
let rce_Key_UP = null,
rce_Key_DOWN = null,
rce_Key_LEFT = null,
rce_Key_RIGHT = null,
rce_Key_SPACE = null,
rce_Key_BTN_A = null,
rce_Key_BTN_B = null,
rce_Key_ENTER = null,
rce_Key_ESCAPE = null,
rce_Key_RESET = null,
rce_Key_$VALUES = null,
rce_Key_$callClinit = () => {
    rce_Key_$callClinit = $rt_eraseClinit(rce_Key);
    rce_Key__clinit_();
},
rce_Key_values = () => {
    rce_Key_$callClinit();
    return rce_Key_$VALUES.$clone0();
},
rce_Key__init_0 = ($this, var$1, var$2, $code, $altCode, $rawKey, $bitIndex) => {
    rce_Key_$callClinit();
    jl_Enum__init_($this, var$1, var$2);
    $this.$code = $code;
    $this.$altCode = $altCode;
    $this.$rawKey = $rawKey;
    $this.$bitIndex = $bitIndex;
},
rce_Key__init_ = (var_0, var_1, var_2, var_3, var_4, var_5) => {
    let var_6 = new rce_Key();
    rce_Key__init_0(var_6, var_0, var_1, var_2, var_3, var_4, var_5);
    return var_6;
},
rce_Key_getBitMask = $this => {
    return 1 << $this.$bitIndex;
},
rce_Key_fromCodeOrKey = $input => {
    let $trimmed, var$3, var$4, var$5, $k, var$7;
    rce_Key_$callClinit();
    if ($input === null)
        return null;
    $trimmed = $input.$trim();
    var$3 = (rce_Key_values()).data;
    var$4 = var$3.length;
    var$5 = 0;
    while (true) {
        if (var$5 >= var$4)
            return null;
        $k = var$3[var$5];
        if ($k.$code.$equalsIgnoreCase($trimmed))
            break;
        var$7 = $k.$altCode;
        if (var$7.$equalsIgnoreCase($trimmed))
            break;
        var$7 = $k.$rawKey;
        if (var$7.$equalsIgnoreCase($trimmed))
            break;
        if ((jl_Enum_name($k)).$equalsIgnoreCase($trimmed))
            break;
        var$5 = var$5 + 1 | 0;
    }
    return $k;
},
rce_Key_$values = () => {
    let var$1, var$2;
    rce_Key_$callClinit();
    var$1 = $rt_createArray(rce_Key, 10);
    var$2 = var$1.data;
    var$2[0] = rce_Key_UP;
    var$2[1] = rce_Key_DOWN;
    var$2[2] = rce_Key_LEFT;
    var$2[3] = rce_Key_RIGHT;
    var$2[4] = rce_Key_SPACE;
    var$2[5] = rce_Key_BTN_A;
    var$2[6] = rce_Key_BTN_B;
    var$2[7] = rce_Key_ENTER;
    var$2[8] = rce_Key_ESCAPE;
    var$2[9] = rce_Key_RESET;
    return var$1;
},
rce_Key__clinit_ = () => {
    rce_Key_UP = rce_Key__init_($rt_s(114), 0, $rt_s(138), $rt_s(139), $rt_s(140), 0);
    rce_Key_DOWN = rce_Key__init_($rt_s(115), 1, $rt_s(141), $rt_s(142), $rt_s(143), 1);
    rce_Key_LEFT = rce_Key__init_($rt_s(144), 2, $rt_s(145), $rt_s(146), $rt_s(147), 2);
    rce_Key_RIGHT = rce_Key__init_($rt_s(148), 3, $rt_s(149), $rt_s(150), $rt_s(151), 3);
    rce_Key_SPACE = rce_Key__init_($rt_s(152), 4, $rt_s(153), $rt_s(87), $rt_s(153), 4);
    rce_Key_BTN_A = rce_Key__init_($rt_s(154), 5, $rt_s(155), $rt_s(156), $rt_s(157), 5);
    rce_Key_BTN_B = rce_Key__init_($rt_s(158), 6, $rt_s(159), $rt_s(160), $rt_s(161), 6);
    rce_Key_ENTER = rce_Key__init_($rt_s(162), 7, $rt_s(163), $rt_s(164), $rt_s(163), 7);
    rce_Key_ESCAPE = rce_Key__init_($rt_s(165), 8, $rt_s(166), $rt_s(167), $rt_s(166), 8);
    rce_Key_RESET = rce_Key__init_($rt_s(168), 9, $rt_s(169), $rt_s(170), $rt_s(169), 9);
    rce_Key_$VALUES = rce_Key_$values();
},
otcit_DoubleAnalyzer = $rt_classWithoutFields(),
otcit_DoubleAnalyzer_MAX_MANTISSA = Long_ZERO,
otcit_DoubleAnalyzer_resultForLog10 = null,
otcit_DoubleAnalyzer_mantissa10Table = null,
otcit_DoubleAnalyzer_exp10Table = null,
otcit_DoubleAnalyzer_$callClinit = () => {
    otcit_DoubleAnalyzer_$callClinit = $rt_eraseClinit(otcit_DoubleAnalyzer);
    otcit_DoubleAnalyzer__clinit_();
},
otcit_DoubleAnalyzer_fastIntLog10 = $d => {
    let $result, $exponent;
    otcit_DoubleAnalyzer_$callClinit();
    $result = otcit_DoubleAnalyzer_resultForLog10;
    otcit_DoubleAnalyzer_analyze($d, $result);
    $exponent = $result.$exponent;
    if ($exponent < 0 && Long_gt($result.$mantissa, Long_create(1569325056, 23283064)))
        $exponent = $exponent + 1 | 0;
    return $exponent;
},
otcit_DoubleAnalyzer_analyze = ($d, $result) => {
    let $bits, $mantissa, $exponent, var$6, $decExponent, var$8, var$9, $binExponentCorrection, $mantissaShift, $decMantissa, var$13, var$14, var$15, $decMantissaHi, $decMantissaLow, $lowerPos, $upperPos, $posCmp;
    otcit_DoubleAnalyzer_$callClinit();
    $bits = jl_Double_doubleToLongBits($d);
    $result.$sign0 = Long_eq(Long_and($bits, Long_create(0, 2147483648)), Long_ZERO) ? 0 : 1;
    $mantissa = Long_and($bits, Long_create(4294967295, 1048575));
    $exponent = Long_lo(Long_shr($bits, 52)) & 2047;
    if (Long_eq($mantissa, Long_ZERO) && !$exponent) {
        $result.$mantissa = Long_ZERO;
        $result.$exponent = 0;
        return;
    }
    if ($exponent)
        var$6 = Long_or($mantissa, Long_create(0, 1048576));
    else {
        var$6 = Long_shl($mantissa, 1);
        while (Long_eq(Long_and(var$6, Long_create(0, 1048576)), Long_ZERO)) {
            var$6 = Long_shl(var$6, 1);
            $exponent = $exponent + (-1) | 0;
        }
    }
    $decExponent = ju_Arrays_binarySearch(otcit_DoubleAnalyzer_exp10Table, $exponent << 16 >> 16);
    if ($decExponent < 0)
        $decExponent =  -$decExponent | 0;
    var$8 = otcit_DoubleAnalyzer_exp10Table.data;
    var$9 = $decExponent + 1 | 0;
    $binExponentCorrection = $exponent - var$8[var$9] | 0;
    $mantissaShift = 12 + $binExponentCorrection | 0;
    $decMantissa = otcit_DoubleAnalyzer_mulAndShiftRight(var$6, otcit_DoubleAnalyzer_mantissa10Table.data[var$9], $mantissaShift);
    if (Long_le($decMantissa, otcit_DoubleAnalyzer_MAX_MANTISSA)) {
        while (jl_Long_compareUnsigned($decMantissa, otcit_DoubleAnalyzer_MAX_MANTISSA) <= 0) {
            $decExponent = $decExponent + (-1) | 0;
            $decMantissa = Long_add(Long_mul($decMantissa, Long_fromInt(10)), Long_fromInt(9));
        }
        var$8 = otcit_DoubleAnalyzer_exp10Table.data;
        var$9 = $decExponent + 1 | 0;
        var$13 = $exponent - var$8[var$9] | 0;
        $mantissaShift = 12 + var$13 | 0;
        $decMantissa = otcit_DoubleAnalyzer_mulAndShiftRight(var$6, otcit_DoubleAnalyzer_mantissa10Table.data[var$9], $mantissaShift);
    }
    var$14 = Long_shl(var$6, 1);
    var$6 = Long_add(var$14, Long_fromInt(1));
    var$8 = otcit_DoubleAnalyzer_mantissa10Table.data;
    var$13 = $decExponent + 1 | 0;
    var$15 = var$8[var$13];
    var$9 = $mantissaShift - 1 | 0;
    $decMantissaHi = otcit_DoubleAnalyzer_mulAndShiftRight(var$6, var$15, var$9);
    $decMantissaLow = otcit_DoubleAnalyzer_mulAndShiftRight(Long_sub(var$14, Long_fromInt(1)), otcit_DoubleAnalyzer_mantissa10Table.data[var$13], var$9);
    $lowerPos = otcit_DoubleAnalyzer_findLowerDistance($decMantissa, $decMantissaLow);
    $upperPos = otcit_DoubleAnalyzer_findUpperDistance($decMantissa, $decMantissaHi);
    $posCmp = jl_Long_compareUnsigned($lowerPos, $upperPos);
    var$6 = $posCmp > 0 ? Long_mul(jl_Long_divideUnsigned($decMantissa, $lowerPos), $lowerPos) : $posCmp < 0 ? Long_add(Long_mul(jl_Long_divideUnsigned($decMantissa, $upperPos), $upperPos), $upperPos) : Long_mul(jl_Long_divideUnsigned(Long_add($decMantissa, Long_div($upperPos, Long_fromInt(2))), $upperPos), $upperPos);
    if (jl_Long_compareUnsigned(var$6, Long_create(2808348672, 232830643)) >= 0)
        while (true) {
            $decExponent = $decExponent + 1 | 0;
            var$6 = jl_Long_divideUnsigned(var$6, Long_fromInt(10));
            if (jl_Long_compareUnsigned(var$6, Long_create(2808348672, 232830643)) < 0)
                break;
        }
    else if (jl_Long_compareUnsigned(var$6, Long_create(1569325056, 23283064)) < 0) {
        $decExponent = $decExponent + (-1) | 0;
        var$6 = Long_mul(var$6, Long_fromInt(10));
    }
    $result.$mantissa = var$6;
    $result.$exponent = $decExponent - 330 | 0;
},
otcit_DoubleAnalyzer_findLowerDistance = ($mantissa, $lower) => {
    let $pos, $pos_0, var$5, var$6;
    otcit_DoubleAnalyzer_$callClinit();
    $pos = Long_fromInt(1);
    while (true) {
        $pos_0 = Long_mul($pos, Long_fromInt(10));
        var$5 = jl_Long_divideUnsigned($mantissa, $pos_0);
        var$6 = jl_Long_divideUnsigned($lower, $pos_0);
        if (jl_Long_compareUnsigned(var$5, var$6) <= 0)
            break;
        $pos = $pos_0;
    }
    return $pos;
},
otcit_DoubleAnalyzer_findUpperDistance = ($mantissa, $upper) => {
    let $pos, $pos_0, var$5, var$6;
    otcit_DoubleAnalyzer_$callClinit();
    $pos = Long_fromInt(1);
    while (true) {
        $pos_0 = Long_mul($pos, Long_fromInt(10));
        var$5 = jl_Long_divideUnsigned($mantissa, $pos_0);
        var$6 = jl_Long_divideUnsigned($upper, $pos_0);
        if (jl_Long_compareUnsigned(var$5, var$6) >= 0)
            break;
        $pos = $pos_0;
    }
    return $pos;
},
otcit_DoubleAnalyzer_mulAndShiftRight = ($a, $b, $shift) => {
    let $a1, $a2, $a3, $a4, $b1, $b2, $b3, $b4, $cm, $c0, $c1, $c2, $c3, $c, var$18;
    otcit_DoubleAnalyzer_$callClinit();
    $a1 = Long_and($a, Long_fromInt(65535));
    $a2 = Long_and(Long_shru($a, 16), Long_fromInt(65535));
    $a3 = Long_and(Long_shru($a, 32), Long_fromInt(65535));
    $a4 = Long_and(Long_shru($a, 48), Long_fromInt(65535));
    $b1 = Long_and($b, Long_fromInt(65535));
    $b2 = Long_and(Long_shru($b, 16), Long_fromInt(65535));
    $b3 = Long_and(Long_shru($b, 32), Long_fromInt(65535));
    $b4 = Long_and(Long_shru($b, 48), Long_fromInt(65535));
    $cm = Long_add(Long_add(Long_mul($b3, $a1), Long_mul($b2, $a2)), Long_mul($b1, $a3));
    $c0 = Long_add(Long_add(Long_add(Long_mul($b4, $a1), Long_mul($b3, $a2)), Long_mul($b2, $a3)), Long_mul($b1, $a4));
    $c1 = Long_add(Long_add(Long_mul($b4, $a2), Long_mul($b3, $a3)), Long_mul($b2, $a4));
    $c2 = Long_add(Long_mul($b4, $a3), Long_mul($b3, $a4));
    $c3 = Long_mul($b4, $a4);
    $c = Long_add(Long_add(Long_shl($c3, 32 + $shift | 0), Long_shl($c2, 16 + $shift | 0)), Long_shl($c1, $shift));
    var$18 = Long_add($cm, Long_shl($c0, 16));
    var$18 = Long_add($c, Long_shru(var$18, 32 - $shift | 0));
    return var$18;
},
otcit_DoubleAnalyzer__clinit_ = () => {
    otcit_DoubleAnalyzer_MAX_MANTISSA = jl_Long_divideUnsigned(Long_fromInt(-1), Long_fromInt(10));
    otcit_DoubleAnalyzer_resultForLog10 = otcit_DoubleAnalyzer$Result__init_();
    otcit_DoubleAnalyzer_mantissa10Table = $rt_createLongArrayFromData([Long_create(3251292512, 2194092222), Long_create(1766094183, 3510547556), Long_create(553881887, 2808438045), Long_create(443105509, 2246750436), Long_create(3285949193, 3594800697), Long_create(910772436, 2875840558), Long_create(2446604867, 2300672446), Long_create(2196580869, 3681075914), Long_create(2616258154, 2944860731), Long_create(1234013064, 2355888585), Long_create(1974420903, 3769421736), Long_create(720543263, 3015537389), Long_create(1435428070, 2412429911),
    Long_create(578697993, 3859887858), Long_create(2180945313, 3087910286), Long_create(885762791, 2470328229), Long_create(3135207384, 3952525166), Long_create(1649172448, 3162020133), Long_create(3037324877, 2529616106), Long_create(3141732885, 4047385770), Long_create(2513386308, 3237908616), Long_create(1151715587, 2590326893), Long_create(983751480, 4144523029), Long_create(1645994643, 3315618423), Long_create(3034782633, 2652494738), Long_create(3996658754, 4243991581), Long_create(2338333544, 3395193265),
    Long_create(1870666835, 2716154612), Long_create(4073513845, 2172923689), Long_create(3940641775, 3476677903), Long_create(575533043, 2781342323), Long_create(2178413352, 2225073858), Long_create(2626467905, 3560118173), Long_create(3819161242, 2848094538), Long_create(478348616, 2278475631), Long_create(3342338164, 3645561009), Long_create(3532863990, 2916448807), Long_create(1108304273, 2333159046), Long_create(55299919, 3733054474), Long_create(903233395, 2986443579), Long_create(1581580175, 2389154863),
    Long_create(1671534821, 3822647781), Long_create(478234397, 3058118225), Long_create(382587518, 2446494580), Long_create(612140029, 3914391328), Long_create(2207698941, 3131513062), Long_create(48172235, 2505210450), Long_create(77075576, 4008336720), Long_create(61660460, 3206669376), Long_create(3485302205, 2565335500), Long_create(1281516232, 4104536801), Long_create(166219527, 3283629441), Long_create(3568949458, 2626903552), Long_create(2274345296, 4203045684), Long_create(2678469696, 3362436547), Long_create(424788838, 2689949238),
    Long_create(2057817989, 2151959390), Long_create(3292508783, 3443135024), Long_create(3493000485, 2754508019), Long_create(3653393847, 2203606415), Long_create(1550462860, 3525770265), Long_create(1240370288, 2820616212), Long_create(3569276608, 2256492969), Long_create(3133862195, 3610388751), Long_create(1648096297, 2888311001), Long_create(459483578, 2310648801), Long_create(3312154103, 3697038081), Long_create(1790729823, 2957630465), Long_create(1432583858, 2366104372), Long_create(3151127633, 3785766995),
    Long_create(2520902106, 3028613596), Long_create(1157728226, 2422890877), Long_create(2711358621, 3876625403), Long_create(3887073815, 3101300322), Long_create(1391672133, 2481040258), Long_create(1367681954, 3969664413), Long_create(2812132482, 3175731530), Long_create(2249705985, 2540585224), Long_create(1022549199, 4064936359), Long_create(1677032818, 3251949087), Long_create(3918606632, 2601559269), Long_create(3692790234, 4162494831), Long_create(2095238728, 3329995865), Long_create(1676190982, 2663996692),
    Long_create(3540899031, 4262394707), Long_create(1114732307, 3409915766), Long_create(32792386, 2727932613), Long_create(1744220827, 2182346090), Long_create(2790753324, 3491753744), Long_create(3091596118, 2793402995), Long_create(2473276894, 2234722396), Long_create(2239256113, 3575555834), Long_create(2650398349, 2860444667), Long_create(402331761, 2288355734), Long_create(2361717736, 3661369174), Long_create(2748367648, 2929095339), Long_create(3057687578, 2343276271), Long_create(3174313206, 3749242034),
    Long_create(3398444024, 2999393627), Long_create(1000768301, 2399514902), Long_create(2460222741, 3839223843), Long_create(3686165111, 3071379074), Long_create(3807925548, 2457103259), Long_create(3515700499, 3931365215), Long_create(2812560399, 3145092172), Long_create(532061401, 2516073738), Long_create(4287272078, 4025717980), Long_create(3429817663, 3220574384), Long_create(3602847589, 2576459507), Long_create(2328582306, 4122335212), Long_create(144878926, 3297868170), Long_create(115903141, 2638294536),
    Long_create(2762425404, 4221271257), Long_create(491953404, 3377017006), Long_create(3829536560, 2701613604), Long_create(3922622707, 2161290883), Long_create(1122235577, 3458065414), Long_create(1756781920, 2766452331), Long_create(546432077, 2213161865), Long_create(874291324, 3541058984), Long_create(1558426518, 2832847187), Long_create(3823721592, 2266277749), Long_create(3540974170, 3626044399), Long_create(3691772795, 2900835519), Long_create(3812411695, 2320668415), Long_create(1804891416, 3713069465),
    Long_create(1443913133, 2970455572), Long_create(3732110884, 2376364457), Long_create(2535403578, 3802183132), Long_create(310335944, 3041746506), Long_create(3684242592, 2433397204), Long_create(3317807769, 3893435527), Long_create(936259297, 3114748422), Long_create(3325987815, 2491798737), Long_create(1885606668, 3986877980), Long_create(1508485334, 3189502384), Long_create(2065781726, 2551601907), Long_create(4164244222, 4082563051), Long_create(2472401918, 3266050441), Long_create(1118928075, 2612840353),
    Long_create(931291461, 4180544565), Long_create(745033169, 3344435652), Long_create(3173006913, 2675548521), Long_create(3358824142, 4280877634), Long_create(3546052773, 3424702107), Long_create(1118855300, 2739761686), Long_create(36090780, 2191809349), Long_create(1775732167, 3506894958), Long_create(3138572652, 2805515966), Long_create(1651864662, 2244412773), Long_create(1783990001, 3591060437), Long_create(4004172378, 2872848349), Long_create(4062331362, 2298278679), Long_create(3922749802, 3677245887),
    Long_create(1420212923, 2941796710), Long_create(1136170338, 2353437368), Long_create(958879082, 3765499789), Long_create(1626096725, 3012399831), Long_create(441883920, 2409919865), Long_create(707014273, 3855871784), Long_create(1424604878, 3084697427), Long_create(3716664280, 2467757941), Long_create(4228675929, 3948412706), Long_create(2523947284, 3158730165), Long_create(2019157827, 2526984132), Long_create(4089645983, 4043174611), Long_create(2412723327, 3234539689), Long_create(2789172121, 2587631751),
    Long_create(2744688475, 4140210802), Long_create(477763862, 3312168642), Long_create(2959191467, 2649734913), Long_create(3875712888, 4239575861), Long_create(2241576851, 3391660689), Long_create(2652254940, 2713328551), Long_create(1262810493, 2170662841), Long_create(302509870, 3473060546), Long_create(3677981733, 2778448436), Long_create(2083391927, 2222758749), Long_create(756446706, 3556413999), Long_create(1464150824, 2845131199), Long_create(2030314118, 2276104959), Long_create(671522212, 3641767935),
    Long_create(537217769, 2913414348), Long_create(2147761134, 2330731478), Long_create(2577424355, 3729170365), Long_create(2061939484, 2983336292), Long_create(4226531965, 2386669033), Long_create(1608490388, 3818670454), Long_create(2145785770, 3054936363), Long_create(3434615534, 2443949090), Long_create(1200417559, 3910318545), Long_create(960334047, 3128254836), Long_create(4204241074, 2502603868), Long_create(1572824964, 4004166190), Long_create(1258259971, 3203332952), Long_create(3583588354, 2562666361),
    Long_create(4015754449, 4100266178), Long_create(635623181, 3280212943), Long_create(2226485463, 2624170354), Long_create(985396364, 4198672567), Long_create(3365297469, 3358938053), Long_create(115257597, 2687150443), Long_create(1810192996, 2149720354), Long_create(319328417, 3439552567), Long_create(2832443111, 2751642053), Long_create(3983941407, 2201313642), Long_create(2938332415, 3522101828), Long_create(4068652850, 2817681462), Long_create(1536935362, 2254145170), Long_create(2459096579, 3606632272),
    Long_create(249290345, 2885305818), Long_create(1917419194, 2308244654), Long_create(490890333, 3693191447), Long_create(2969692644, 2954553157), Long_create(657767197, 2363642526), Long_create(3629407892, 3781828041), Long_create(2044532855, 3025462433), Long_create(3353613202, 2420369946), Long_create(3647794205, 3872591914), Long_create(3777228823, 3098073531), Long_create(2162789599, 2478458825), Long_create(3460463359, 3965534120), Long_create(2768370687, 3172427296), Long_create(1355703090, 2537941837),
    Long_create(3028118404, 4060706939), Long_create(3281488183, 3248565551), Long_create(1766197087, 2598852441), Long_create(1107928421, 4158163906), Long_create(27349277, 3326531125), Long_create(21879422, 2661224900), Long_create(35007075, 4257959840), Long_create(28005660, 3406367872), Long_create(2599384905, 2725094297), Long_create(361521006, 2180075438), Long_create(4014407446, 3488120700), Long_create(3211525957, 2790496560), Long_create(2569220766, 2232397248), Long_create(3251759766, 3571835597),
    Long_create(883420894, 2857468478), Long_create(2424723634, 2285974782), Long_create(443583977, 3657559652), Long_create(2931847559, 2926047721), Long_create(1486484588, 2340838177), Long_create(3237368801, 3745341083), Long_create(12914663, 2996272867), Long_create(2587312108, 2397018293), Long_create(3280705914, 3835229269), Long_create(3483558190, 3068183415), Long_create(2786846552, 2454546732), Long_create(1022980646, 3927274772), Long_create(3395364895, 3141819817), Long_create(998304997, 2513455854),
    Long_create(3315274914, 4021529366), Long_create(1793226472, 3217223493), Long_create(3152568096, 2573778794), Long_create(2467128576, 4118046071), Long_create(1114709402, 3294436857), Long_create(3468747899, 2635549485), Long_create(1255029343, 4216879177), Long_create(3581003852, 3373503341), Long_create(2005809622, 2698802673), Long_create(3322634616, 2159042138), Long_create(162254630, 3454467422), Long_create(2706784082, 2763573937), Long_create(447440347, 2210859150), Long_create(715904555, 3537374640),
    Long_create(572723644, 2829899712), Long_create(3035159293, 2263919769), Long_create(2279274491, 3622271631), Long_create(964426134, 2897817305), Long_create(771540907, 2318253844), Long_create(2952452370, 3709206150), Long_create(2361961896, 2967364920), Long_create(1889569516, 2373891936), Long_create(1305324308, 3798227098), Long_create(2762246365, 3038581678), Long_create(3927784010, 2430865342), Long_create(2848480580, 3889384548), Long_create(3996771382, 3111507638), Long_create(620436728, 2489206111),
    Long_create(3569679143, 3982729777), Long_create(1137756396, 3186183822), Long_create(3487185494, 2548947057), Long_create(2143522954, 4078315292), Long_create(4291798741, 3262652233), Long_create(856458615, 2610121787), Long_create(2229327243, 4176194859), Long_create(2642455254, 3340955887), Long_create(395977285, 2672764710), Long_create(633563656, 4276423536), Long_create(3942824761, 3421138828), Long_create(577279431, 2736911063), Long_create(2179810463, 2189528850), Long_create(3487696741, 3503246160),
    Long_create(2790157393, 2802596928), Long_create(3950112833, 2242077542), Long_create(2884206696, 3587324068), Long_create(4025352275, 2869859254), Long_create(4079275279, 2295887403), Long_create(1372879692, 3673419846), Long_create(239310294, 2938735877), Long_create(2768428613, 2350988701), Long_create(2711498862, 3761581922), Long_create(451212171, 3009265538), Long_create(2078956655, 2407412430), Long_create(3326330649, 3851859888), Long_create(84084141, 3081487911), Long_create(3503241150, 2465190328),
    Long_create(451225085, 3944304526), Long_create(3796953905, 3155443620), Long_create(3037563124, 2524354896), Long_create(3142114080, 4038967834), Long_create(3372684723, 3231174267), Long_create(980160860, 2584939414), Long_create(3286244294, 4135903062), Long_create(911008517, 3308722450), Long_create(728806813, 2646977960), Long_create(1166090902, 4235164736), Long_create(73879262, 3388131789), Long_create(918096869, 2710505431), Long_create(4170451332, 2168404344), Long_create(4095741754, 3469446951),
    Long_create(2417599944, 2775557561), Long_create(1075086496, 2220446049), Long_create(3438125312, 3552713678), Long_create(173519872, 2842170943), Long_create(1856802816, 2273736754), Long_create(393904128, 3637978807), Long_create(2892103680, 2910383045), Long_create(2313682944, 2328306436), Long_create(1983905792, 3725290298), Long_create(3305111552, 2980232238), Long_create(67108864, 2384185791), Long_create(2684354560, 3814697265), Long_create(2147483648, 3051757812), Long_create(0, 2441406250), Long_create(0, 3906250000),
    Long_create(0, 3125000000), Long_create(0, 2500000000), Long_create(0, 4000000000), Long_create(0, 3200000000), Long_create(0, 2560000000), Long_create(0, 4096000000), Long_create(0, 3276800000), Long_create(0, 2621440000), Long_create(0, 4194304000), Long_create(0, 3355443200), Long_create(0, 2684354560), Long_create(0, 2147483648), Long_create(3435973836, 3435973836), Long_create(1889785610, 2748779069), Long_create(2370821947, 2199023255), Long_create(3793315115, 3518437208), Long_create(457671715, 2814749767),
    Long_create(2943117749, 2251799813), Long_create(3849994940, 3602879701), Long_create(2221002492, 2882303761), Long_create(917808535, 2305843009), Long_create(3186480574, 3689348814), Long_create(3408177918, 2951479051), Long_create(1867548875, 2361183241), Long_create(1270091283, 3777893186), Long_create(157079567, 3022314549), Long_create(984657113, 2417851639), Long_create(3293438299, 3868562622), Long_create(916763721, 3094850098), Long_create(2451397895, 2475880078), Long_create(3063243173, 3961408125),
    Long_create(2450594538, 3169126500), Long_create(1960475630, 2535301200), Long_create(3136761009, 4056481920), Long_create(2509408807, 3245185536), Long_create(1148533586, 2596148429), Long_create(3555640657, 4153837486), Long_create(1985519066, 3323069989), Long_create(2447408712, 2658455991), Long_create(2197867021, 4253529586), Long_create(899300158, 3402823669), Long_create(1578433585, 2722258935), Long_create(1262746868, 2177807148), Long_create(1161401530, 3484491437), Long_create(3506101601, 2787593149),
    Long_create(3663874740, 2230074519), Long_create(3285219207, 3568119231), Long_create(1769181906, 2854495385), Long_create(1415345525, 2283596308), Long_create(1405559381, 3653754093), Long_create(2842434423, 2923003274), Long_create(3132940998, 2338402619), Long_create(2435725219, 3741444191), Long_create(1089586716, 2993155353), Long_create(2589656291, 2394524282), Long_create(707476229, 3831238852), Long_create(3142961361, 3064991081), Long_create(1655375629, 2451992865), Long_create(2648601007, 3923188584),
    Long_create(2977874265, 3138550867), Long_create(664312493, 2510840694), Long_create(2780886908, 4017345110), Long_create(2224709526, 3213876088), Long_create(3497754539, 2571100870), Long_create(1301439967, 4113761393), Long_create(2759138892, 3291009114), Long_create(3066304573, 2632807291), Long_create(3188100398, 4212491666), Long_create(1691486859, 3369993333), Long_create(3071176406, 2695994666), Long_create(1597947665, 2156795733), Long_create(1697722806, 3450873173), Long_create(3076165163, 2760698538),
    Long_create(4178919049, 2208558830), Long_create(2391303182, 3533694129), Long_create(2772036005, 2826955303), Long_create(3935615722, 2261564242), Long_create(2861011319, 3618502788), Long_create(4006795973, 2894802230), Long_create(3205436779, 2315841784), Long_create(2551718468, 3705346855), Long_create(2041374775, 2964277484), Long_create(2492093279, 2371421987), Long_create(551375410, 3794275180), Long_create(441100328, 3035420144), Long_create(1211873721, 2428336115), Long_create(1938997954, 3885337784),
    Long_create(2410191822, 3108270227), Long_create(210166539, 2486616182), Long_create(1195259923, 3978585891), Long_create(97214479, 3182868713), Long_create(1795758501, 2546294970), Long_create(2873213602, 4074071952), Long_create(580583963, 3259257562), Long_create(3041447548, 2607406049), Long_create(2289335700, 4171849679), Long_create(2690462019, 3337479743), Long_create(3870356534, 2669983794), Long_create(3615590076, 4271974071), Long_create(2033478602, 3417579257), Long_create(4203763259, 2734063405),
    Long_create(3363010607, 2187250724), Long_create(2803836594, 3499601159), Long_create(3102062734, 2799680927), Long_create(763663269, 2239744742), Long_create(2080854690, 3583591587), Long_create(4241664129, 2866873269), Long_create(4252324763, 2293498615), Long_create(2508752324, 3669597785), Long_create(2007001859, 2935678228), Long_create(3323588406, 2348542582), Long_create(1881767613, 3757668132), Long_create(4082394468, 3006134505), Long_create(3265915574, 2404907604), Long_create(2648484541, 3847852167),
    Long_create(400800715, 3078281734), Long_create(1179634031, 2462625387), Long_create(2746407909, 3940200619), Long_create(3056119786, 3152160495), Long_create(2444895829, 2521728396), Long_create(2193846408, 4034765434), Long_create(2614070585, 3227812347), Long_create(373269550, 2582249878), Long_create(4033205117, 4131599804), Long_create(4085557553, 3305279843), Long_create(691465664, 2644223875), Long_create(1106345063, 4230758200), Long_create(885076050, 3384606560), Long_create(708060840, 2707685248),
    Long_create(2284435591, 2166148198), Long_create(2796103486, 3465837117), Long_create(518895870, 2772669694), Long_create(1274110155, 2218135755), Long_create(2038576249, 3549017208), Long_create(3348847917, 2839213766), Long_create(1820084875, 2271371013), Long_create(2053142340, 3634193621), Long_create(783520413, 2907354897), Long_create(3203796708, 2325883917), Long_create(1690100896, 3721414268), Long_create(3070067635, 2977131414), Long_create(3315047567, 2381705131), Long_create(3586089190, 3810728210),
    Long_create(2868871352, 3048582568), Long_create(4013084000, 2438866054), Long_create(3843954022, 3902185687), Long_create(1357176299, 3121748550), Long_create(1085741039, 2497398840), Long_create(1737185663, 3995838144), Long_create(2248741989, 3196670515), Long_create(1798993591, 2557336412), Long_create(3737383206, 4091738259), Long_create(3848900024, 3273390607), Long_create(1361133101, 2618712486), Long_create(459826043, 4189939978), Long_create(2085847752, 3351951982), Long_create(4245658579, 2681561585),
    Long_create(2498086431, 4290498537), Long_create(280482227, 3432398830), Long_create(224385781, 2745919064), Long_create(1038502084, 2196735251), Long_create(4238583712, 3514776401), Long_create(2531873511, 2811821121), Long_create(1166505349, 2249456897), Long_create(2725402018, 3599131035), Long_create(2180321615, 2879304828), Long_create(3462244210, 2303443862), Long_create(2103616899, 3685510180), Long_create(1682893519, 2948408144), Long_create(2205308275, 2358726515), Long_create(3528493240, 3773962424),
    Long_create(3681788051, 3019169939), Long_create(3804423900, 2415335951), Long_create(74124026, 3864537523), Long_create(1777286139, 3091630018), Long_create(3139815829, 2473304014), Long_create(2446724950, 3957286423), Long_create(3675366878, 3165829138), Long_create(363313125, 2532663311), Long_create(3158281377, 4052261297), Long_create(808638183, 3241809038), Long_create(2364897465, 2593447230), Long_create(3783835944, 4149515568), Long_create(450088378, 3319612455), Long_create(360070702, 2655689964),
    Long_create(2294100042, 4249103942), Long_create(117293115, 3399283154), Long_create(952827951, 2719426523), Long_create(2480249279, 2175541218), Long_create(3109405388, 3480865949), Long_create(3346517769, 2784692759), Long_create(3536207675, 2227754207), Long_create(2221958443, 3564406732), Long_create(59579836, 2851525386), Long_create(3483637705, 2281220308), Long_create(419859574, 3649952494), Long_create(1194881118, 2919961995), Long_create(955904894, 2335969596), Long_create(4106428209, 3737551353),
    Long_create(708162189, 2990041083), Long_create(2284516670, 2392032866), Long_create(1937239754, 3827252586), Long_create(690798344, 3061802069), Long_create(1411632134, 2449441655), Long_create(2258611415, 3919106648), Long_create(3524876050, 3135285318), Long_create(242920462, 2508228255), Long_create(388672740, 4013165208), Long_create(2028925110, 3210532166), Long_create(764146629, 2568425733), Long_create(363641147, 4109481173), Long_create(2008899836, 3287584938), Long_create(3325106787, 2630067950),
    Long_create(1025203564, 4208108721), Long_create(4256136688, 3366486976), Long_create(2545915891, 2693189581), Long_create(1177739254, 2154551665), Long_create(1884382806, 3447282664), Long_create(2366499704, 2757826131), Long_create(1034206304, 2206260905), Long_create(1654730086, 3530017448), Long_create(3041770987, 2824013958), Long_create(4151403708, 2259211166), Long_create(629291719, 3614737867), Long_create(3080413753, 2891790293), Long_create(4182317920, 2313432234), Long_create(4114728295, 3701491575),
    Long_create(3291782636, 2961193260), Long_create(2633426109, 2368954608), Long_create(3354488315, 3790327373), Long_create(106610275, 3032261899), Long_create(944281679, 2425809519), Long_create(3228837605, 3881295230), Long_create(2583070084, 3105036184), Long_create(2925449526, 2484028947), Long_create(1244745405, 3974446316), Long_create(136802865, 3179557053), Long_create(1827429210, 2543645642), Long_create(3782880196, 4069833027), Long_create(1308317238, 3255866422), Long_create(3623634168, 2604693137),
    Long_create(2361840832, 4167509020), Long_create(1889472666, 3334007216), Long_create(652584673, 2667205773), Long_create(185142018, 4267529237), Long_create(2725093992, 3414023389), Long_create(3039068653, 2731218711), Long_create(1572261463, 2184974969), Long_create(4233605259, 3495959950), Long_create(3386884207, 2796767960), Long_create(2709507366, 2237414368), Long_create(3476218326, 3579862989), Long_create(3639968120, 2863890391), Long_create(2052981037, 2291112313), Long_create(2425776200, 3665779701),
    Long_create(1081627501, 2932623761), Long_create(6308541, 2346099009), Long_create(1728080585, 3753758414), Long_create(2241457927, 3003006731), Long_create(934172882, 2402405385), Long_create(1494676612, 3843848616), Long_create(336747830, 3075078893), Long_create(1987385183, 2460063114), Long_create(602835915, 3936100983), Long_create(2200255650, 3148880786), Long_create(901211061, 2519104629), Long_create(3159924616, 4030567406), Long_create(1668946233, 3224453925), Long_create(1335156987, 2579563140),
    Long_create(2136251179, 4127301024), Long_create(2567994402, 3301840819), Long_create(2913388981, 2641472655), Long_create(366455074, 4226356249), Long_create(1152157518, 3381084999), Long_create(1780719474, 2704867999), Long_create(2283569038, 2163894399), Long_create(1076730083, 3462231039), Long_create(1720377526, 2769784831), Long_create(517308561, 2215827865), Long_create(827693699, 3545324584), Long_create(1521148418, 2836259667), Long_create(3793899112, 2269007733), Long_create(916277824, 3630412374),
    Long_create(1592015718, 2904329899), Long_create(2132606034, 2323463919), Long_create(835189277, 3717542271), Long_create(4104125258, 2974033816), Long_create(2424306747, 2379227053), Long_create(3019897337, 3806763285), Long_create(2415917869, 3045410628), Long_create(3650721214, 2436328502), Long_create(2405180105, 3898125604), Long_create(2783137543, 3118500483), Long_create(3944496953, 2494800386), Long_create(298240911, 3991680619), Long_create(1097586188, 3193344495), Long_create(878068950, 2554675596),
    Long_create(3981890698, 4087480953), Long_create(608532181, 3269984763), Long_create(2204812663, 2615987810), Long_create(3527700261, 4185580496), Long_create(1963166749, 3348464397), Long_create(4147513777, 2678771517), Long_create(3200048207, 4286034428), Long_create(4278025484, 3428827542), Long_create(1704433468, 2743062034), Long_create(2222540234, 2194449627), Long_create(120090538, 3511119404), Long_create(955065889, 2808895523), Long_create(2482039630, 2247116418), Long_create(3112269949, 3595386269),
    Long_create(3348809418, 2876309015), Long_create(2679047534, 2301047212), Long_create(850502218, 3681675540), Long_create(680401775, 2945340432), Long_create(3121301797, 2356272345), Long_create(699115580, 3770035753), Long_create(2277279382, 3016028602), Long_create(103836587, 2412822882), Long_create(1025131999, 3860516611), Long_create(4256079436, 3088413288), Long_create(827883168, 2470730631), Long_create(3901593088, 3953169009)]);
    otcit_DoubleAnalyzer_exp10Table = $rt_createShortArrayFromData([(-70), (-66), (-63), (-60), (-56), (-53), (-50), (-46), (-43), (-40), (-36), (-33), (-30), (-26), (-23), (-20), (-16), (-13), (-10), (-6), (-3), 0, 4, 7, 10, 14, 17, 20, 23, 27, 30, 33, 37, 40, 43, 47, 50, 53, 57, 60, 63, 67, 70, 73, 77, 80, 83, 87, 90, 93, 97, 100, 103, 107, 110, 113, 116, 120, 123, 126, 130, 133, 136, 140, 143, 146, 150, 153, 156, 160, 163, 166, 170, 173, 176, 180, 183, 186, 190, 193, 196, 200, 203, 206, 210, 213, 216, 219,
    223, 226, 229, 233, 236, 239, 243, 246, 249, 253, 256, 259, 263, 266, 269, 273, 276, 279, 283, 286, 289, 293, 296, 299, 303, 306, 309, 312, 316, 319, 322, 326, 329, 332, 336, 339, 342, 346, 349, 352, 356, 359, 362, 366, 369, 372, 376, 379, 382, 386, 389, 392, 396, 399, 402, 406, 409, 412, 415, 419, 422, 425, 429, 432, 435, 439, 442, 445, 449, 452, 455, 459, 462, 465, 469, 472, 475, 479, 482, 485, 489, 492, 495, 499, 502, 505, 508, 512, 515, 518, 522, 525, 528, 532, 535, 538, 542, 545, 548, 552, 555, 558,
    562, 565, 568, 572, 575, 578, 582, 585, 588, 592, 595, 598, 601, 605, 608, 611, 615, 618, 621, 625, 628, 631, 635, 638, 641, 645, 648, 651, 655, 658, 661, 665, 668, 671, 675, 678, 681, 685, 688, 691, 695, 698, 701, 704, 708, 711, 714, 718, 721, 724, 728, 731, 734, 738, 741, 744, 748, 751, 754, 758, 761, 764, 768, 771, 774, 778, 781, 784, 788, 791, 794, 797, 801, 804, 807, 811, 814, 817, 821, 824, 827, 831, 834, 837, 841, 844, 847, 851, 854, 857, 861, 864, 867, 871, 874, 877, 881, 884, 887, 891, 894, 897,
    900, 904, 907, 910, 914, 917, 920, 924, 927, 930, 934, 937, 940, 944, 947, 950, 954, 957, 960, 964, 967, 970, 974, 977, 980, 984, 987, 990, 993, 997, 1000, 1003, 1007, 1010, 1013, 1017, 1020, 1023, 1027, 1030, 1033, 1037, 1040, 1043, 1047, 1050, 1053, 1057, 1060, 1063, 1067, 1070, 1073, 1077, 1080, 1083, 1086, 1090, 1093, 1096, 1100, 1103, 1106, 1110, 1113, 1116, 1120, 1123, 1126, 1130, 1133, 1136, 1140, 1143, 1146, 1150, 1153, 1156, 1160, 1163, 1166, 1170, 1173, 1176, 1180, 1183, 1186, 1189, 1193, 1196,
    1199, 1203, 1206, 1209, 1213, 1216, 1219, 1223, 1226, 1229, 1233, 1236, 1239, 1243, 1246, 1249, 1253, 1256, 1259, 1263, 1266, 1269, 1273, 1276, 1279, 1282, 1286, 1289, 1292, 1296, 1299, 1302, 1306, 1309, 1312, 1316, 1319, 1322, 1326, 1329, 1332, 1336, 1339, 1342, 1346, 1349, 1352, 1356, 1359, 1362, 1366, 1369, 1372, 1376, 1379, 1382, 1385, 1389, 1392, 1395, 1399, 1402, 1405, 1409, 1412, 1415, 1419, 1422, 1425, 1429, 1432, 1435, 1439, 1442, 1445, 1449, 1452, 1455, 1459, 1462, 1465, 1469, 1472, 1475, 1478,
    1482, 1485, 1488, 1492, 1495, 1498, 1502, 1505, 1508, 1512, 1515, 1518, 1522, 1525, 1528, 1532, 1535, 1538, 1542, 1545, 1548, 1552, 1555, 1558, 1562, 1565, 1568, 1572, 1575, 1578, 1581, 1585, 1588, 1591, 1595, 1598, 1601, 1605, 1608, 1611, 1615, 1618, 1621, 1625, 1628, 1631, 1635, 1638, 1641, 1645, 1648, 1651, 1655, 1658, 1661, 1665, 1668, 1671, 1674, 1678, 1681, 1684, 1688, 1691, 1694, 1698, 1701, 1704, 1708, 1711, 1714, 1718, 1721, 1724, 1728, 1731, 1734, 1738, 1741, 1744, 1748, 1751, 1754, 1758, 1761,
    1764, 1767, 1771, 1774, 1777, 1781, 1784, 1787, 1791, 1794, 1797, 1801, 1804, 1807, 1811, 1814, 1817, 1821, 1824, 1827, 1831, 1834, 1837, 1841, 1844, 1847, 1851, 1854, 1857, 1861, 1864, 1867, 1870, 1874, 1877, 1880, 1884, 1887, 1890, 1894, 1897, 1900, 1904, 1907, 1910, 1914, 1917, 1920, 1924, 1927, 1930, 1934, 1937, 1940, 1944, 1947, 1950, 1954, 1957, 1960, 1963, 1967, 1970, 1973, 1977, 1980, 1983, 1987, 1990, 1993, 1997, 2000, 2003, 2007, 2010, 2013, 2017, 2020, 2023, 2027, 2030, 2033, 2037, 2040, 2043,
    2047, 2050, 2053, 2057, 2060, 2063, 2066, 2070, 2073, 2076, 2080, 2083, 2086, 2090, 2093, 2096, 2100, 2103, 2106, 2110, 2113, 2116, 2120]);
};
function rceh_VirtualPin() {
    let a = this; jl_Object.call(a);
    a.$pinNumber = 0;
    a.$name3 = null;
    a.$mode = null;
    a.$state = null;
    a.$analogValue = 0;
    a.$listeners = null;
    a.$interruptTrigger = null;
}
let rceh_VirtualPin__init_ = ($this, $pinNumber, $name) => {
    jl_Object__init_($this);
    rceh_VirtualPin$Mode_$callClinit();
    $this.$mode = rceh_VirtualPin$Mode_INPUT;
    rceh_VirtualPin$State_$callClinit();
    $this.$state = rceh_VirtualPin$State_LOW;
    $this.$analogValue = 0;
    $this.$listeners = ju_ArrayList__init_();
    rceh_VirtualPin$InterruptTrigger_$callClinit();
    $this.$interruptTrigger = rceh_VirtualPin$InterruptTrigger_CHANGE;
    $this.$pinNumber = $pinNumber;
    $this.$name3 = $name;
},
rceh_VirtualPin__init_0 = (var_0, var_1) => {
    let var_2 = new rceh_VirtualPin();
    rceh_VirtualPin__init_(var_2, var_0, var_1);
    return var_2;
},
rceh_VirtualPin_getVoltage = $this => {
    return $this.$analogValue / 1023.0 * 5.0;
},
rceh_VirtualPin_toString = $this => {
    let var$1, var$2;
    var$1 = $rt_createArray(jl_Object, 6);
    var$2 = var$1.data;
    var$2[0] = jl_Integer_valueOf($this.$pinNumber);
    var$2[1] = $this.$name3;
    var$2[2] = $this.$mode;
    var$2[3] = $this.$state;
    var$2[4] = jl_Integer_valueOf($this.$analogValue);
    var$2[5] = jl_Double_valueOf($this.$getVoltage());
    return jl_String_format($rt_s(171), var$1);
},
rce_Audio = $rt_classWithoutFields(),
rce_Audio_playCoin = () => {
    if (rcei_JSBridge_isBrowser()) {
        rcei_JSBridge_playTone$js_body$_10(987.0, 60.0, "square");
        rcei_JSBridge_playTone$js_body$_10(1318.0, 120.0, "square");
    }
},
rce_Audio_playDamage = () => {
    if (rcei_JSBridge_isBrowser())
        rcei_JSBridge_playTone$js_body$_10(150.0, 150.0, "sawtooth");
},
rce_Audio_playGameOver = () => {
    if (rcei_JSBridge_isBrowser()) {
        rcei_JSBridge_playTone$js_body$_10(220.0, 200.0, "sawtooth");
        rcei_JSBridge_playTone$js_body$_10(165.0, 300.0, "sawtooth");
    }
};
function otciu_CharMapping() {
    let a = this; jl_Object.call(a);
    a.$binarySearchTable0 = null;
    a.$fastTable = null;
}
let otciu_CharMapping__init_ = ($this, $binarySearchTable, $fastTable) => {
    jl_Object__init_($this);
    $this.$binarySearchTable0 = $binarySearchTable;
    $this.$fastTable = $fastTable;
},
otciu_CharMapping__init_0 = (var_0, var_1) => {
    let var_2 = new otciu_CharMapping();
    otciu_CharMapping__init_(var_2, var_0, var_1);
    return var_2;
},
otjc_JSWeakRef = $rt_classWithoutFields();
function otci_CharFlow() {
    let a = this; jl_Object.call(a);
    a.$characters = null;
    a.$pointer = 0;
}
let otci_CharFlow__init_ = ($this, $characters) => {
    jl_Object__init_($this);
    $this.$characters = $characters;
},
otci_CharFlow__init_0 = var_0 => {
    let var_1 = new otci_CharFlow();
    otci_CharFlow__init_(var_1, var_0);
    return var_1;
};
function ju_IllegalFormatFlagsException() {
    ju_IllegalFormatException.call(this);
    this.$flags2 = null;
}
let ju_IllegalFormatFlagsException__init_0 = ($this, $flags) => {
    let var$2;
    var$2 = jl_StringBuilder__init_();
    jl_StringBuilder_append(jl_StringBuilder_append(var$2, $rt_s(172)), $flags);
    ju_IllegalFormatException__init_($this, jl_StringBuilder_toString(var$2));
    $this.$flags2 = $flags;
},
ju_IllegalFormatFlagsException__init_ = var_0 => {
    let var_1 = new ju_IllegalFormatFlagsException();
    ju_IllegalFormatFlagsException__init_0(var_1, var_0);
    return var_1;
},
otcit_FloatAnalyzer$Result = $rt_classWithoutFields(),
otcit_FloatAnalyzer$Result__init_ = $this => {
    jl_Object__init_($this);
},
otcit_FloatAnalyzer$Result__init_0 = () => {
    let var_0 = new otcit_FloatAnalyzer$Result();
    otcit_FloatAnalyzer$Result__init_(var_0);
    return var_0;
},
jl_String$_clinit_$lambda$_115_0 = $rt_classWithoutFields(),
jl_String$_clinit_$lambda$_115_0__init_ = var$0 => {
    jl_Object__init_(var$0);
},
jl_String$_clinit_$lambda$_115_0__init_0 = () => {
    let var_0 = new jl_String$_clinit_$lambda$_115_0();
    jl_String$_clinit_$lambda$_115_0__init_(var_0);
    return var_0;
},
jl_String$_clinit_$lambda$_115_0_compare0 = (var$0, var$1, var$2) => {
    return jl_String$_clinit_$lambda$_115_0_compare(var$0, var$1, var$2);
},
jl_String$_clinit_$lambda$_115_0_compare = (var$0, var$1, var$2) => {
    return jl_String_lambda$static$0(var$1, var$2);
},
ju_HashMap$EntryIterator = $rt_classWithoutFields(ju_HashMap$AbstractMapIterator),
ju_HashMap$EntryIterator__init_ = ($this, $map) => {
    ju_HashMap$AbstractMapIterator__init_($this, $map);
},
ju_HashMap$EntryIterator__init_0 = var_0 => {
    let var_1 = new ju_HashMap$EntryIterator();
    ju_HashMap$EntryIterator__init_(var_1, var_0);
    return var_1;
},
ju_HashMap$EntryIterator_next = $this => {
    ju_HashMap$AbstractMapIterator_makeNext($this);
    return $this.$currentEntry;
},
ju_HashMap$EntryIterator_next0 = $this => {
    return $this.$next0();
};
$rt_packages([-1, "ru", 0, "college", 1, "game", 1, "engine", 3, "bus", 3, "hardware", -1, "java", 6, "util", 6, "math", 6, "text", 6, "lang", -1, "org", 11, "teavm", 12, "jso", 13, "impl", 12, "classlib", 15, "impl", 16, "unicode", 16, "text", 12, "platform", 19, "plugin"
]);
$rt_metadata([jl_Object, "Object", 10, 0, [], 0, 3, 0, 0, ["$isEmptyMonitor", $rt_wrapFunction0(jl_Object_isEmptyMonitor), "$getClass0", $rt_wrapFunction0(jl_Object_getClass), "$hashCode0", $rt_wrapFunction0(jl_Object_hashCode), "$equals", $rt_wrapFunction1(jl_Object_equals), "$toString", $rt_wrapFunction0(jl_Object_toString), "$identity", $rt_wrapFunction0(jl_Object_identity), "$clone0", $rt_wrapFunction0(jl_Object_clone)],
jl_Throwable, "Throwable", 10, jl_Object, [], 0, 3, 0, 0, ["$fillInStackTrace", $rt_wrapFunction0(jl_Throwable_fillInStackTrace), "$getMessage", $rt_wrapFunction0(jl_Throwable_getMessage), "$getLocalizedMessage", $rt_wrapFunction0(jl_Throwable_getLocalizedMessage), "$getCause", $rt_wrapFunction0(jl_Throwable_getCause), "$toString", $rt_wrapFunction0(jl_Throwable_toString)],
jl_Exception, "Exception", 10, jl_Throwable, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_Exception__init_), "$_init_", $rt_wrapFunction1(jl_Exception__init_0)],
jl_RuntimeException, "RuntimeException", 10, jl_Exception, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_RuntimeException__init_), "$_init_", $rt_wrapFunction1(jl_RuntimeException__init_0)],
jl_IndexOutOfBoundsException, "IndexOutOfBoundsException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_IndexOutOfBoundsException__init_0)],
ji_Serializable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_Cloneable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jt_Format, "Format", 9, jl_Object, [ji_Serializable, jl_Cloneable], 1, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_Format__init_), "$format6", $rt_wrapFunction1(jt_Format_format)],
jl_Number, "Number", 10, jl_Object, [ji_Serializable], 1, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_Number__init_)],
jl_Comparable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_Integer, "Integer", 10, jl_Number, [jl_Comparable], 0, 3, 0, jl_Integer_$callClinit, ["$_init_3", $rt_wrapFunction1(jl_Integer__init_), "$intValue", $rt_wrapFunction0(jl_Integer_intValue), "$longValue", $rt_wrapFunction0(jl_Integer_longValue), "$doubleValue", $rt_wrapFunction0(jl_Integer_doubleValue), "$toString", $rt_wrapFunction0(jl_Integer_toString1), "$hashCode0", $rt_wrapFunction0(jl_Integer_hashCode), "$equals", $rt_wrapFunction1(jl_Integer_equals), "$compareTo", $rt_wrapFunction1(jl_Integer_compareTo),
"$compareTo2", $rt_wrapFunction1(jl_Integer_compareTo0)],
jl_CloneNotSupportedException, "CloneNotSupportedException", 10, jl_Exception, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_CloneNotSupportedException__init_)],
jl_AbstractStringBuilder$Constants, 0, jl_Object, [], 0, 0, 0, jl_AbstractStringBuilder$Constants_$callClinit, 0,
jl_Long, 0, jl_Number, [jl_Comparable], 0, 3, 0, jl_Long_$callClinit, 0,
rce_Sound, 0, jl_Object, [], 0, 3, 0, 0, 0,
ju_Map, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_Runnable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_Thread, "Thread", 10, jl_Object, [jl_Runnable], 0, 3, 0, jl_Thread_$callClinit, ["$_init_", $rt_wrapFunction1(jl_Thread__init_0), "$_init_4", $rt_wrapFunction2(jl_Thread__init_), "$run", $rt_wrapFunction0(jl_Thread_run)],
rceh_GpioPort, "GpioPort", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(rceh_GpioPort__init_)],
jm_BigInteger, "BigInteger", 8, jl_Number, [jl_Comparable, ji_Serializable], 0, 3, 0, jm_BigInteger_$callClinit, ["$_init_8", $rt_wrapFunction2(jm_BigInteger__init_2), "$_init_7", $rt_wrapFunction3(jm_BigInteger__init_3), "$_init_6", $rt_wrapFunction2(jm_BigInteger__init_1), "$_init_34", $rt_wrapFunction2(jm_BigInteger__init_5), "$abs1", $rt_wrapFunction0(jm_BigInteger_abs), "$negate", $rt_wrapFunction0(jm_BigInteger_negate), "$add1", $rt_wrapFunction1(jm_BigInteger_add), "$subtract0", $rt_wrapFunction1(jm_BigInteger_subtract),
"$signum", $rt_wrapFunction0(jm_BigInteger_signum), "$shiftRight0", $rt_wrapFunction1(jm_BigInteger_shiftRight), "$shiftLeft0", $rt_wrapFunction1(jm_BigInteger_shiftLeft), "$shiftLeftOneBit0", $rt_wrapFunction0(jm_BigInteger_shiftLeftOneBit), "$bitLength0", $rt_wrapFunction0(jm_BigInteger_bitLength), "$testBit", $rt_wrapFunction1(jm_BigInteger_testBit), "$getLowestSetBit", $rt_wrapFunction0(jm_BigInteger_getLowestSetBit), "$intValue", $rt_wrapFunction0(jm_BigInteger_intValue), "$longValue", $rt_wrapFunction0(jm_BigInteger_longValue),
"$doubleValue", $rt_wrapFunction0(jm_BigInteger_doubleValue), "$compareTo0", $rt_wrapFunction1(jm_BigInteger_compareTo), "$hashCode0", $rt_wrapFunction0(jm_BigInteger_hashCode), "$equals", $rt_wrapFunction1(jm_BigInteger_equals), "$equalsArrays", $rt_wrapFunction1(jm_BigInteger_equalsArrays), "$toString", $rt_wrapFunction0(jm_BigInteger_toString), "$multiply0", $rt_wrapFunction1(jm_BigInteger_multiply), "$pow0", $rt_wrapFunction1(jm_BigInteger_pow), "$divideAndRemainder", $rt_wrapFunction1(jm_BigInteger_divideAndRemainder),
"$divide0", $rt_wrapFunction1(jm_BigInteger_divide), "$remainder", $rt_wrapFunction1(jm_BigInteger_remainder), "$cutOffLeadingZeroes", $rt_wrapFunction0(jm_BigInteger_cutOffLeadingZeroes), "$isOne", $rt_wrapFunction0(jm_BigInteger_isOne), "$getFirstNonzeroDigit", $rt_wrapFunction0(jm_BigInteger_getFirstNonzeroDigit), "$compareTo2", $rt_wrapFunction1(jm_BigInteger_compareTo0)],
jl_ArithmeticException, "ArithmeticException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(jl_ArithmeticException__init_0)],
otj_JSObject, 0, jl_Object, [], 3, 3, 0, 0, 0,
otp_PlatformQueue, 0, jl_Object, [otj_JSObject], 1, 3, 0, 0, 0,
otciu_CLDRHelper, 0, jl_Object, [], 4, 3, 0, 0, 0,
jt_DecimalFormat$FormatField, "DecimalFormat$FormatField", 9, jl_Object, [], 3, 0, 0, 0, 0,
jt_DecimalFormat$CurrencyField, "DecimalFormat$CurrencyField", 9, jl_Object, [jt_DecimalFormat$FormatField], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormat$CurrencyField__init_), "$render", $rt_wrapFunction2(jt_DecimalFormat$CurrencyField_render), "$equals", $rt_wrapFunction1(jt_DecimalFormat$CurrencyField_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat$CurrencyField_hashCode)],
jl_CharSequence, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_StringIndexOutOfBoundsException, "StringIndexOutOfBoundsException", 10, jl_IndexOutOfBoundsException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_StringIndexOutOfBoundsException__init_0)],
otcic_CurrencyHelper, 0, jl_Object, [], 4, 3, 0, 0, 0,
otci_Base46, 0, jl_Object, [], 4, 3, 0, 0, 0,
rcei_JSBridge$FrameCallback, 0, jl_Object, [otj_JSObject], 3, 3, 0, 0, 0,
jl_AbstractStringBuilder, "AbstractStringBuilder", 10, jl_Object, [ji_Serializable, jl_CharSequence], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_AbstractStringBuilder__init_0), "$_init_3", $rt_wrapFunction1(jl_AbstractStringBuilder__init_), "$append7", $rt_wrapFunction1(jl_AbstractStringBuilder_append7), "$append8", $rt_wrapFunction1(jl_AbstractStringBuilder_append), "$insert0", $rt_wrapFunction2(jl_AbstractStringBuilder_insert2), "$append9", $rt_wrapFunction1(jl_AbstractStringBuilder_append3), "$append1",
$rt_wrapFunction2(jl_AbstractStringBuilder_append8), "$insert1", $rt_wrapFunction3(jl_AbstractStringBuilder_insert7), "$append10", $rt_wrapFunction1(jl_AbstractStringBuilder_append5), "$insert2", $rt_wrapFunction2(jl_AbstractStringBuilder_insert5), "$insert3", $rt_wrapFunction3(jl_AbstractStringBuilder_insert6), "$append11", $rt_wrapFunction1(jl_AbstractStringBuilder_append4), "$insert4", $rt_wrapFunction2(jl_AbstractStringBuilder_insert1), "$append12", $rt_wrapFunction1(jl_AbstractStringBuilder_append1), "$insert5",
$rt_wrapFunction2(jl_AbstractStringBuilder_insert4), "$insert", $rt_wrapFunction2(jl_AbstractStringBuilder_insert3), "$ensureCapacity", $rt_wrapFunction1(jl_AbstractStringBuilder_ensureCapacity), "$toString", $rt_wrapFunction0(jl_AbstractStringBuilder_toString), "$length", $rt_wrapFunction0(jl_AbstractStringBuilder_length), "$charAt", $rt_wrapFunction1(jl_AbstractStringBuilder_charAt), "$append6", $rt_wrapFunction3(jl_AbstractStringBuilder_append0), "$insert6", $rt_wrapFunction4(jl_AbstractStringBuilder_insert),
"$append14", $rt_wrapFunction1(jl_AbstractStringBuilder_append2), "$append13", $rt_wrapFunction3(jl_AbstractStringBuilder_append6), "$insert7", $rt_wrapFunction4(jl_AbstractStringBuilder_insert0), "$setLength", $rt_wrapFunction1(jl_AbstractStringBuilder_setLength)],
jl_Appendable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_StringBuilder, "StringBuilder", 10, jl_AbstractStringBuilder, [jl_Appendable], 0, 3, 0, 0, ["$_init_3", $rt_wrapFunction1(jl_StringBuilder__init_2), "$_init_0", $rt_wrapFunction0(jl_StringBuilder__init_1), "$append", $rt_wrapFunction1(jl_StringBuilder_append), "$append19", $rt_wrapFunction1(jl_StringBuilder_append4), "$append3", $rt_wrapFunction1(jl_StringBuilder_append0), "$append2", $rt_wrapFunction1(jl_StringBuilder_append8), "$append21", $rt_wrapFunction1(jl_StringBuilder_append2), "$append0", $rt_wrapFunction1(jl_StringBuilder_append1),
"$append20", $rt_wrapFunction3(jl_StringBuilder_append5), "$append15", $rt_wrapFunction3(jl_StringBuilder_append9), "$append16", $rt_wrapFunction1(jl_StringBuilder_append7), "$insert13", $rt_wrapFunction2(jl_StringBuilder_insert7), "$insert12", $rt_wrapFunction2(jl_StringBuilder_insert8), "$insert9", $rt_wrapFunction4(jl_StringBuilder_insert1), "$insert8", $rt_wrapFunction4(jl_StringBuilder_insert5), "$insert10", $rt_wrapFunction2(jl_StringBuilder_insert9), "$insert11", $rt_wrapFunction2(jl_StringBuilder_insert2),
"$insert14", $rt_wrapFunction2(jl_StringBuilder_insert11), "$setLength", $rt_wrapFunction1(jl_StringBuilder_setLength), "$insert7", $rt_wrapFunction4(jl_StringBuilder_insert10), "$insert6", $rt_wrapFunction4(jl_StringBuilder_insert3), "$append6", $rt_wrapFunction3(jl_StringBuilder_append6), "$charAt", $rt_wrapFunction1(jl_StringBuilder_charAt), "$length", $rt_wrapFunction0(jl_StringBuilder_length), "$toString", $rt_wrapFunction0(jl_StringBuilder_toString), "$ensureCapacity", $rt_wrapFunction1(jl_StringBuilder_ensureCapacity),
"$insert", $rt_wrapFunction2(jl_StringBuilder_insert0), "$insert5", $rt_wrapFunction2(jl_StringBuilder_insert), "$insert4", $rt_wrapFunction2(jl_StringBuilder_insert6), "$insert2", $rt_wrapFunction2(jl_StringBuilder_insert4), "$insert0", $rt_wrapFunction2(jl_StringBuilder_insert12), "$append22", $rt_wrapFunction1(jl_StringBuilder_append3)],
ju_ConcurrentModificationException, "ConcurrentModificationException", 7, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(ju_ConcurrentModificationException__init_0)],
ju_Currency, "Currency", 7, jl_Object, [ji_Serializable], 4, 3, 0, 0, ["$getCurrencyCode", $rt_wrapFunction0(ju_Currency_getCurrencyCode), "$getSymbol", $rt_wrapFunction1(ju_Currency_getSymbol), "$toString", $rt_wrapFunction0(ju_Currency_toString)],
jl_ClassCastException, 0, jl_RuntimeException, [], 0, 3, 0, 0, 0,
jt_AttributedCharacterIterator$Attribute, "AttributedCharacterIterator$Attribute", 9, jl_Object, [ji_Serializable], 0, 3, 0, jt_AttributedCharacterIterator$Attribute_$callClinit, ["$_init_", $rt_wrapFunction1(jt_AttributedCharacterIterator$Attribute__init_0), "$equals", $rt_wrapFunction1(jt_AttributedCharacterIterator$Attribute_equals), "$getName", $rt_wrapFunction0(jt_AttributedCharacterIterator$Attribute_getName), "$hashCode0", $rt_wrapFunction0(jt_AttributedCharacterIterator$Attribute_hashCode), "$toString",
$rt_wrapFunction0(jt_AttributedCharacterIterator$Attribute_toString)],
jl_StringBuffer, "StringBuffer", 10, jl_AbstractStringBuilder, [jl_Appendable], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_StringBuffer__init_), "$append5", $rt_wrapFunction1(jl_StringBuffer_append2), "$append4", $rt_wrapFunction1(jl_StringBuffer_append3), "$append17", $rt_wrapFunction3(jl_StringBuffer_append0), "$append18", $rt_wrapFunction1(jl_StringBuffer_append4), "$insert20", $rt_wrapFunction2(jl_StringBuffer_insert12), "$insert19", $rt_wrapFunction2(jl_StringBuffer_insert7), "$insert16", $rt_wrapFunction4(jl_StringBuffer_insert0),
"$insert15", $rt_wrapFunction4(jl_StringBuffer_insert2), "$insert17", $rt_wrapFunction2(jl_StringBuffer_insert4), "$insert18", $rt_wrapFunction2(jl_StringBuffer_insert10), "$insert21", $rt_wrapFunction2(jl_StringBuffer_insert3), "$insert7", $rt_wrapFunction4(jl_StringBuffer_insert6), "$insert6", $rt_wrapFunction4(jl_StringBuffer_insert8), "$append6", $rt_wrapFunction3(jl_StringBuffer_append1), "$charAt", $rt_wrapFunction1(jl_StringBuffer_charAt), "$length", $rt_wrapFunction0(jl_StringBuffer_length), "$toString",
$rt_wrapFunction0(jl_StringBuffer_toString), "$ensureCapacity", $rt_wrapFunction1(jl_StringBuffer_ensureCapacity), "$insert", $rt_wrapFunction2(jl_StringBuffer_insert11), "$insert5", $rt_wrapFunction2(jl_StringBuffer_insert5), "$insert4", $rt_wrapFunction2(jl_StringBuffer_insert), "$insert2", $rt_wrapFunction2(jl_StringBuffer_insert9), "$insert0", $rt_wrapFunction2(jl_StringBuffer_insert1), "$append22", $rt_wrapFunction1(jl_StringBuffer_append)],
rce_GameObject, "GameObject", 3, jl_Object, [], 0, 3, 0, 0, ["$_init_11", $rt_wrapFunction4(rce_GameObject__init_), "$update", $rt_wrapFunction1(rce_GameObject_update), "$collidesWith", $rt_wrapFunction1(rce_GameObject_collidesWith), "$handleCollision", $rt_wrapFunction1(rce_GameObject_handleCollision), "$isDestroyed", $rt_wrapFunction0(rce_GameObject_isDestroyed)],
rcg_Player, "Player", 2, rce_GameObject, [], 0, 3, 0, 0, ["$_init_30", $rt_wrapFunction2(rcg_Player__init_), "$takeDamage", $rt_wrapFunction0(rcg_Player_takeDamage), "$draw", $rt_wrapFunction1(rcg_Player_draw)],
ji_Flushable, 0, jl_Object, [], 3, 3, 0, 0, 0,
juf_ToIntFunction, 0, jl_Object, [], 3, 3, 0, 0, 0,
ji_IOException, 0, jl_Exception, [], 0, 3, 0, 0, 0,
rcg_Main, 0, jl_Object, [], 0, 3, 0, rcg_Main_$callClinit, 0,
juf_Predicate, 0, jl_Object, [], 3, 3, 0, 0, 0,
rce_Game$step$lambda$_31_0, "Game$step$lambda$_31_0", 3, jl_Object, [juf_Predicate], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rce_Game$step$lambda$_31_0__init_), "$test0", $rt_wrapFunction1(rce_Game$step$lambda$_31_0_test0), "$test", $rt_wrapFunction1(rce_Game$step$lambda$_31_0_test)],
ju_Iterator, 0, jl_Object, [], 3, 3, 0, 0, 0,
ju_AbstractList$1, "AbstractList$1", 7, jl_Object, [ju_Iterator], 0, 0, 0, 0, ["$_init_37", $rt_wrapFunction1(ju_AbstractList$1__init_), "$hasNext", $rt_wrapFunction0(ju_AbstractList$1_hasNext), "$next", $rt_wrapFunction0(ju_AbstractList$1_next), "$remove0", $rt_wrapFunction0(ju_AbstractList$1_remove)],
jl_Enum, "Enum", 10, jl_Object, [jl_Comparable, ji_Serializable], 1, 3, 0, 0, ["$_init_13", $rt_wrapFunction2(jl_Enum__init_), "$name", $rt_wrapFunction0(jl_Enum_name), "$ordinal", $rt_wrapFunction0(jl_Enum_ordinal), "$toString", $rt_wrapFunction0(jl_Enum_toString), "$equals", $rt_wrapFunction1(jl_Enum_equals), "$hashCode0", $rt_wrapFunction0(jl_Enum_hashCode), "$getDeclaringClass", $rt_wrapFunction0(jl_Enum_getDeclaringClass), "$compareTo1", $rt_wrapFunction1(jl_Enum_compareTo), "$compareTo2", $rt_wrapFunction1(jl_Enum_compareTo0)]]);
$rt_metadata([rceh_VirtualPin$State, "VirtualPin$State", 5, jl_Enum, [], 12, 3, 0, rceh_VirtualPin$State_$callClinit, 0,
rceh_InterruptController, "InterruptController", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rceh_InterruptController__init_), "$trigger", $rt_wrapFunction2(rceh_InterruptController_trigger0), "$trigger0", $rt_wrapFunction1(rceh_InterruptController_trigger), "$processInterrupts", $rt_wrapFunction0(rceh_InterruptController_processInterrupts)],
rceh_InterruptController$PendingInterrupt, "InterruptController$PendingInterrupt", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_15", $rt_wrapFunction3(rceh_InterruptController$PendingInterrupt__init_)],
jlr_Array, 0, jl_Object, [], 4, 3, 0, 0, 0,
otcit_DoubleAnalyzer$Result, "DoubleAnalyzer$Result", 18, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(otcit_DoubleAnalyzer$Result__init_0)],
otpp_ResourceAccessor, 0, jl_Object, [], 4, 0, 0, 0, 0,
jl_Iterable, 0, jl_Object, [], 3, 3, 0, 0, 0,
ju_Collection, 0, jl_Object, [jl_Iterable], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
ju_AbstractCollection, "AbstractCollection", 7, jl_Object, [ju_Collection], 1, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_0", $rt_wrapFunction0(ju_AbstractCollection__init_), "$isEmpty", $rt_wrapFunction0(ju_AbstractCollection_isEmpty), "$contains", $rt_wrapFunction1(ju_AbstractCollection_contains), "$toArray", $rt_wrapFunction1(ju_AbstractCollection_toArray), "$add0", $rt_wrapFunction1(ju_AbstractCollection_add), "$addAll", $rt_wrapFunction1(ju_AbstractCollection_addAll), "$removeAll",
$rt_wrapFunction1(ju_AbstractCollection_removeAll), "$toString", $rt_wrapFunction0(ju_AbstractCollection_toString)],
otci_IntegerUtil, 0, jl_Object, [], 4, 3, 0, 0, 0,
ju_Locale, "Locale", 7, jl_Object, [jl_Cloneable, ji_Serializable], 4, 3, 0, ju_Locale_$callClinit, ["$_init_19", $rt_wrapFunction2(ju_Locale__init_1), "$_init_18", $rt_wrapFunction3(ju_Locale__init_0), "$equals", $rt_wrapFunction1(ju_Locale_equals), "$getCountry", $rt_wrapFunction0(ju_Locale_getCountry), "$getLanguage", $rt_wrapFunction0(ju_Locale_getLanguage), "$hashCode0", $rt_wrapFunction0(ju_Locale_hashCode), "$toString", $rt_wrapFunction0(ju_Locale_toString)],
jl_Short, 0, jl_Number, [jl_Comparable], 0, 3, 0, 0, 0,
jl_Thread$UncaughtExceptionHandler, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_DefaultUncaughtExceptionHandler, "DefaultUncaughtExceptionHandler", 10, jl_Object, [jl_Thread$UncaughtExceptionHandler], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_DefaultUncaughtExceptionHandler__init_)],
jt_DecimalFormat$1, 0, jl_Object, [], 32, 0, 0, jt_DecimalFormat$1_$callClinit, 0,
otjc_JSObjects, 0, jl_Object, [], 4, 3, 0, 0, 0,
otji_JS, 0, jl_Object, [], 4, 0, 0, 0, 0,
otjc_JSFinalizationRegistryConsumer, 0, jl_Object, [otj_JSObject], 3, 3, 0, 0, 0,
otji_JSWrapper$_clinit_$lambda$_33_0, "JSWrapper$<clinit>$lambda$_33_0", 14, jl_Object, [otjc_JSFinalizationRegistryConsumer], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(otji_JSWrapper$_clinit_$lambda$_33_0__init_), "$accept", $rt_wrapFunction1(otji_JSWrapper$_clinit_$lambda$_33_0_accept), "$accept$exported$0", $rt_wrapFunction1(otji_JSWrapper$_clinit_$lambda$_33_0_accept$exported$0)],
otp_PlatformRunnable, 0, jl_Object, [], 3, 3, 0, 0, 0,
otciu_UnicodeHelper, 0, jl_Object, [], 4, 3, 0, 0, 0,
jl_Object$monitorEnterWait$lambda$_6_0, "Object$monitorEnterWait$lambda$_6_0", 10, jl_Object, [otp_PlatformRunnable], 0, 3, 0, 0, ["$_init_1", $rt_wrapFunction4(jl_Object$monitorEnterWait$lambda$_6_0__init_), "$run", $rt_wrapFunction0(jl_Object$monitorEnterWait$lambda$_6_0_run)],
rcei_JSBridge$MouseCallback, 0, jl_Object, [otj_JSObject], 3, 3, 0, 0, 0,
rce_Game$launch$lambda$_36_3, "Game$launch$lambda$_36_3", 3, jl_Object, [rcei_JSBridge$MouseCallback], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rce_Game$launch$lambda$_36_3__init_), "$onMouse", $rt_wrapFunction3(rce_Game$launch$lambda$_36_3_onMouse), "$onMouse$exported$0", $rt_wrapFunction3(rce_Game$launch$lambda$_36_3_onMouse$exported$0)],
ju_Objects, 0, jl_Object, [], 4, 3, 0, 0, 0,
rcei_JSBridge$KeyCallback, 0, jl_Object, [otj_JSObject], 3, 3, 0, 0, 0,
rce_Game$launch$lambda$_36_1, "Game$launch$lambda$_36_1", 3, jl_Object, [rcei_JSBridge$KeyCallback], 0, 3, 0, 0, ["$_init_29", $rt_wrapFunction1(rce_Game$launch$lambda$_36_1__init_), "$onKey", $rt_wrapFunction2(rce_Game$launch$lambda$_36_1_onKey), "$onKey$exported$0", $rt_wrapFunction2(rce_Game$launch$lambda$_36_1_onKey$exported$0)],
rce_Game$launch$lambda$_36_2, "Game$launch$lambda$_36_2", 3, jl_Object, [rcei_JSBridge$MouseCallback], 0, 3, 0, 0, ["$_init_29", $rt_wrapFunction1(rce_Game$launch$lambda$_36_2__init_), "$onMouse", $rt_wrapFunction3(rce_Game$launch$lambda$_36_2_onMouse), "$onMouse$exported$0", $rt_wrapFunction3(rce_Game$launch$lambda$_36_2_onMouse$exported$0)],
otjc_JSUndefined, 0, jl_Object, [otj_JSObject], 0, 3, 0, 0, 0,
ju_Map$Entry, 0, jl_Object, [], 3, 3, 0, 0, 0,
ju_MapEntry, "MapEntry", 7, jl_Object, [ju_Map$Entry, jl_Cloneable], 0, 0, 0, 0, ["$_init_21", $rt_wrapFunction2(ju_MapEntry__init_), "$equals", $rt_wrapFunction1(ju_MapEntry_equals), "$getKey", $rt_wrapFunction0(ju_MapEntry_getKey), "$getValue", $rt_wrapFunction0(ju_MapEntry_getValue), "$hashCode0", $rt_wrapFunction0(ju_MapEntry_hashCode), "$toString", $rt_wrapFunction0(ju_MapEntry_toString)],
ju_HashMap$HashEntry, "HashMap$HashEntry", 7, ju_MapEntry, [], 0, 0, 0, 0, ["$_init_47", $rt_wrapFunction2(ju_HashMap$HashEntry__init_)],
ju_Comparator, 0, jl_Object, [], 3, 3, 0, 0, 0,
ju_Comparator$NaturalOrder, "Comparator$NaturalOrder", 7, jl_Object, [ju_Comparator], 0, 3, 0, ju_Comparator$NaturalOrder_$callClinit, ["$_init_0", $rt_wrapFunction0(ju_Comparator$NaturalOrder__init_), "$compare1", $rt_wrapFunction2(ju_Comparator$NaturalOrder_compare)],
ju_Queue, 0, jl_Object, [ju_Collection], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
jl_ArrayStoreException, "ArrayStoreException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_ArrayStoreException__init_0)],
ju_SequencedCollection, 0, jl_Object, [ju_Collection], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
rcei_JSBridge, 0, jl_Object, [], 4, 3, 0, rcei_JSBridge_$callClinit, 0,
otji_JSWrapper, "JSWrapper", 14, jl_Object, [], 4, 3, 0, otji_JSWrapper_$callClinit, ["$hashCode0", $rt_wrapFunction0(otji_JSWrapper_hashCode), "$equals", $rt_wrapFunction1(otji_JSWrapper_equals), "$toString", $rt_wrapFunction0(otji_JSWrapper_toString)],
otp_Platform, 0, jl_Object, [], 4, 3, 0, 0, 0,
jl_Boolean, "Boolean", 10, jl_Object, [ji_Serializable, jl_Comparable], 0, 3, 0, jl_Boolean_$callClinit, ["$_init_24", $rt_wrapFunction1(jl_Boolean__init_0), "$compareTo3", $rt_wrapFunction1(jl_Boolean_compareTo), "$booleanValue", $rt_wrapFunction0(jl_Boolean_booleanValue), "$toString", $rt_wrapFunction0(jl_Boolean_toString0), "$hashCode0", $rt_wrapFunction0(jl_Boolean_hashCode), "$equals", $rt_wrapFunction1(jl_Boolean_equals), "$compareTo2", $rt_wrapFunction1(jl_Boolean_compareTo0)],
rceh_InterruptController$processInterrupts$lambda$_9_0, "InterruptController$processInterrupts$lambda$_9_0", 5, jl_Object, [juf_ToIntFunction], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rceh_InterruptController$processInterrupts$lambda$_9_0__init_), "$applyAsInt", $rt_wrapFunction1(rceh_InterruptController$processInterrupts$lambda$_9_0_applyAsInt0), "$applyAsInt0", $rt_wrapFunction1(rceh_InterruptController$processInterrupts$lambda$_9_0_applyAsInt)],
otji_JSWrapper$_clinit_$lambda$_33_1, "JSWrapper$<clinit>$lambda$_33_1", 14, jl_Object, [otjc_JSFinalizationRegistryConsumer], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(otji_JSWrapper$_clinit_$lambda$_33_1__init_), "$accept", $rt_wrapFunction1(otji_JSWrapper$_clinit_$lambda$_33_1_accept), "$accept$exported$0", $rt_wrapFunction1(otji_JSWrapper$_clinit_$lambda$_33_1_accept$exported$0)],
ju_NoSuchElementException, "NoSuchElementException", 7, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(ju_NoSuchElementException__init_)],
jt_DecimalFormat$Constants, 0, jl_Object, [], 0, 0, 0, jt_DecimalFormat$Constants_$callClinit, 0,
oti_AsyncCallback, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_IllegalArgumentException, "IllegalArgumentException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_IllegalArgumentException__init_1), "$_init_", $rt_wrapFunction1(jl_IllegalArgumentException__init_)],
ju_IllegalFormatException, "IllegalFormatException", 7, jl_IllegalArgumentException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(ju_IllegalFormatException__init_)],
ju_UnknownFormatConversionException, "UnknownFormatConversionException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(ju_UnknownFormatConversionException__init_0)],
jt_NumberFormat, "NumberFormat", 9, jt_Format, [], 1, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_NumberFormat__init_), "$getCurrency", $rt_wrapFunction0(jt_NumberFormat_getCurrency), "$equals", $rt_wrapFunction1(jt_NumberFormat_equals), "$format", $rt_wrapFunction3(jt_NumberFormat_format), "$getMaximumFractionDigits", $rt_wrapFunction0(jt_NumberFormat_getMaximumFractionDigits), "$getMaximumIntegerDigits", $rt_wrapFunction0(jt_NumberFormat_getMaximumIntegerDigits), "$getMinimumFractionDigits", $rt_wrapFunction0(jt_NumberFormat_getMinimumFractionDigits),
"$getMinimumIntegerDigits", $rt_wrapFunction0(jt_NumberFormat_getMinimumIntegerDigits), "$hashCode0", $rt_wrapFunction0(jt_NumberFormat_hashCode), "$isGroupingUsed", $rt_wrapFunction0(jt_NumberFormat_isGroupingUsed), "$setGroupingUsed", $rt_wrapFunction1(jt_NumberFormat_setGroupingUsed), "$setMaximumFractionDigits", $rt_wrapFunction1(jt_NumberFormat_setMaximumFractionDigits), "$setMaximumIntegerDigits", $rt_wrapFunction1(jt_NumberFormat_setMaximumIntegerDigits), "$setMinimumFractionDigits", $rt_wrapFunction1(jt_NumberFormat_setMinimumFractionDigits),
"$setMinimumIntegerDigits", $rt_wrapFunction1(jt_NumberFormat_setMinimumIntegerDigits), "$getRoundingMode", $rt_wrapFunction0(jt_NumberFormat_getRoundingMode)]]);
$rt_metadata([jt_DecimalFormat, "DecimalFormat", 9, jt_NumberFormat, [], 0, 3, 0, jt_DecimalFormat_$callClinit, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormat__init_1), "$_init_", $rt_wrapFunction1(jt_DecimalFormat__init_0), "$_init_25", $rt_wrapFunction2(jt_DecimalFormat__init_), "$applyPattern", $rt_wrapFunction1(jt_DecimalFormat_applyPattern), "$setDecimalFormatSymbols", $rt_wrapFunction1(jt_DecimalFormat_setDecimalFormatSymbols), "$setPositivePrefix", $rt_wrapFunction1(jt_DecimalFormat_setPositivePrefix),
"$setNegativePrefix", $rt_wrapFunction1(jt_DecimalFormat_setNegativePrefix), "$setNegativeSuffix", $rt_wrapFunction1(jt_DecimalFormat_setNegativeSuffix), "$setMultiplier", $rt_wrapFunction1(jt_DecimalFormat_setMultiplier), "$getGroupingSize", $rt_wrapFunction0(jt_DecimalFormat_getGroupingSize), "$setGroupingSize", $rt_wrapFunction1(jt_DecimalFormat_setGroupingSize), "$isDecimalSeparatorAlwaysShown", $rt_wrapFunction0(jt_DecimalFormat_isDecimalSeparatorAlwaysShown), "$setDecimalSeparatorAlwaysShown", $rt_wrapFunction1(jt_DecimalFormat_setDecimalSeparatorAlwaysShown),
"$equals", $rt_wrapFunction1(jt_DecimalFormat_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat_hashCode), "$format", $rt_wrapFunction3(jt_DecimalFormat_format3), "$format1", $rt_wrapFunction3(jt_DecimalFormat_format2), "$format0", $rt_wrapFunction3(jt_DecimalFormat_format1)],
jt_DecimalFormat$PerMillField, "DecimalFormat$PerMillField", 9, jl_Object, [jt_DecimalFormat$FormatField], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormat$PerMillField__init_), "$render", $rt_wrapFunction2(jt_DecimalFormat$PerMillField_render), "$equals", $rt_wrapFunction1(jt_DecimalFormat$PerMillField_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat$PerMillField_hashCode)],
ju_IllegalFormatConversionException, "IllegalFormatConversionException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_39", $rt_wrapFunction2(ju_IllegalFormatConversionException__init_0)],
jt_DecimalFormat$PercentField, "DecimalFormat$PercentField", 9, jl_Object, [jt_DecimalFormat$FormatField], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormat$PercentField__init_), "$render", $rt_wrapFunction2(jt_DecimalFormat$PercentField_render), "$equals", $rt_wrapFunction1(jt_DecimalFormat$PercentField_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat$PercentField_hashCode)],
rcek_Kaboom, 0, jl_Object, [], 4, 3, 0, 0, 0,
ju_AbstractMap, "AbstractMap", 7, jl_Object, [ju_Map], 1, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(ju_AbstractMap__init_), "$equals", $rt_wrapFunction1(ju_AbstractMap_equals), "$hashCode0", $rt_wrapFunction0(ju_AbstractMap_hashCode), "$toString", $rt_wrapFunction0(ju_AbstractMap_toString)],
rce_Game, "Game", 3, jl_Object, [], 1, 3, 0, 0, ["$_init_8", $rt_wrapFunction2(rce_Game__init_), "$add2", $rt_wrapFunction1(rce_Game_add), "$setBackgroundColor", $rt_wrapFunction1(rce_Game_setBackgroundColor), "$isKeyPressed", $rt_wrapFunction1(rce_Game_isKeyPressed), "$step", $rt_wrapFunction1(rce_Game_step), "$renderFrame", $rt_wrapFunction0(rce_Game_renderFrame)],
rcg_MyGame, "MyGame", 2, rce_Game, [], 0, 3, 0, rcg_MyGame_$callClinit, ["$_init_0", $rt_wrapFunction0(rcg_MyGame__init_), "$init", $rt_wrapFunction0(rcg_MyGame_init), "$update", $rt_wrapFunction1(rcg_MyGame_update), "$render0", $rt_wrapFunction1(rcg_MyGame_render)],
ju_IllegalFormatCodePointException, "IllegalFormatCodePointException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_3", $rt_wrapFunction1(ju_IllegalFormatCodePointException__init_)],
jlr_AnnotatedElement, 0, jl_Object, [], 3, 3, 0, 0, 0,
jlr_Type, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_Class, "Class", 10, jl_Object, [jlr_AnnotatedElement, jlr_Type], 0, 3, 0, 0, ["$toString", $rt_wrapFunction0(jl_Class_toString), "$getPlatformClass", $rt_wrapFunction0(jl_Class_getPlatformClass), "$isInstance0", $rt_wrapFunction1(jl_Class_isInstance), "$getName", $rt_wrapFunction0(jl_Class_getName), "$isPrimitive", $rt_wrapFunction0(jl_Class_isPrimitive), "$isInterface", $rt_wrapFunction0(jl_Class_isInterface), "$getComponentType", $rt_wrapFunction0(jl_Class_getComponentType), "$getSuperclass", $rt_wrapFunction0(jl_Class_getSuperclass)],
rceh_VirtualPin$InterruptTrigger, "VirtualPin$InterruptTrigger", 5, jl_Enum, [], 12, 3, 0, rceh_VirtualPin$InterruptTrigger_$callClinit, 0,
otji_JSWrapper$JSTransparentInt, 0, jl_Object, [otj_JSObject], 1, 0, 0, 0, 0,
jl_Float, 0, jl_Number, [jl_Comparable], 0, 3, 0, 0, 0,
rceh_VirtualPin$Mode, "VirtualPin$Mode", 5, jl_Enum, [], 12, 3, 0, rceh_VirtualPin$Mode_$callClinit, 0,
ju_Arrays, 0, jl_Object, [], 0, 3, 0, 0, 0,
jl_System, 0, jl_Object, [], 4, 3, 0, 0, 0,
jm_Conversion, 0, jl_Object, [], 0, 0, 0, jm_Conversion_$callClinit, 0,
rceh_InterruptController$IsrEntry, 0, jl_Object, [], 0, 3, 0, 0, 0,
rceh_KeyRegister, "KeyRegister", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rceh_KeyRegister__init_), "$setKeyPressed", $rt_wrapFunction2(rceh_KeyRegister_setKeyPressed), "$isPressed", $rt_wrapFunction1(rceh_KeyRegister_isPressed), "$getBinaryString", $rt_wrapFunction0(rceh_KeyRegister_getBinaryString), "$getHexDump", $rt_wrapFunction0(rceh_KeyRegister_getHexDump), "$toString", $rt_wrapFunction0(rceh_KeyRegister_toString)],
jm_BigDecimal, "BigDecimal", 8, jl_Number, [jl_Comparable, ji_Serializable], 0, 3, 0, jm_BigDecimal_$callClinit, ["$_init_27", $rt_wrapFunction1(jm_BigDecimal__init_3), "$_init_28", $rt_wrapFunction2(jm_BigDecimal__init_0), "$multiply1", $rt_wrapFunction1(jm_BigDecimal_multiply), "$signum", $rt_wrapFunction0(jm_BigDecimal_signum), "$scale", $rt_wrapFunction0(jm_BigDecimal_scale), "$precision", $rt_wrapFunction0(jm_BigDecimal_precision), "$unscaledValue", $rt_wrapFunction0(jm_BigDecimal_unscaledValue), "$compareTo4",
$rt_wrapFunction1(jm_BigDecimal_compareTo), "$equals", $rt_wrapFunction1(jm_BigDecimal_equals), "$hashCode0", $rt_wrapFunction0(jm_BigDecimal_hashCode), "$toString", $rt_wrapFunction0(jm_BigDecimal_toString), "$toBigInteger", $rt_wrapFunction0(jm_BigDecimal_toBigInteger), "$longValue", $rt_wrapFunction0(jm_BigDecimal_longValue), "$intValue", $rt_wrapFunction0(jm_BigDecimal_intValue), "$doubleValue", $rt_wrapFunction0(jm_BigDecimal_doubleValue), "$compareTo2", $rt_wrapFunction1(jm_BigDecimal_compareTo0)],
jl_Character, "Character", 10, jl_Object, [jl_Comparable], 0, 3, 0, jl_Character_$callClinit, 0,
jt_FieldPosition, "FieldPosition", 9, jl_Object, [], 0, 3, 0, 0, ["$_init_3", $rt_wrapFunction1(jt_FieldPosition__init_), "$equals", $rt_wrapFunction1(jt_FieldPosition_equals), "$hashCode0", $rt_wrapFunction0(jt_FieldPosition_hashCode), "$toString", $rt_wrapFunction0(jt_FieldPosition_toString)],
jl_Object$monitorExit$lambda$_8_0, "Object$monitorExit$lambda$_8_0", 10, jl_Object, [otp_PlatformRunnable], 0, 3, 0, 0, ["$_init_2", $rt_wrapFunction1(jl_Object$monitorExit$lambda$_8_0__init_), "$run", $rt_wrapFunction0(jl_Object$monitorExit$lambda$_8_0_run)],
otjc_JSNumber, 0, jl_Object, [otj_JSObject], 1, 3, 0, 0, 0,
ju_DuplicateFormatFlagsException, "DuplicateFormatFlagsException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(ju_DuplicateFormatFlagsException__init_)],
ju_MissingFormatWidthException, "MissingFormatWidthException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(ju_MissingFormatWidthException__init_0)],
ju_ArrayDeque$1, "ArrayDeque$1", 7, jl_Object, [ju_Iterator], 0, 0, 0, 0, ["$_init_38", $rt_wrapFunction1(ju_ArrayDeque$1__init_), "$hasNext", $rt_wrapFunction0(ju_ArrayDeque$1_hasNext), "$next", $rt_wrapFunction0(ju_ArrayDeque$1_next), "$remove0", $rt_wrapFunction0(ju_ArrayDeque$1_remove)],
ju_Set, 0, jl_Object, [ju_Collection], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
rce_Game$TimerTask, 0, jl_Object, [], 0, 0, 0, 0, 0,
otjc_JSBoolean, 0, jl_Object, [otj_JSObject], 1, 3, 0, 0, 0,
jm_Multiplication, 0, jl_Object, [], 0, 0, 0, jm_Multiplication_$callClinit, 0,
jl_Double, "Double", 10, jl_Number, [jl_Comparable], 0, 3, 0, jl_Double_$callClinit, ["$_init_35", $rt_wrapFunction1(jl_Double__init_), "$doubleValue", $rt_wrapFunction0(jl_Double_doubleValue), "$intValue", $rt_wrapFunction0(jl_Double_intValue), "$longValue", $rt_wrapFunction0(jl_Double_longValue), "$toString", $rt_wrapFunction0(jl_Double_toString0), "$equals", $rt_wrapFunction1(jl_Double_equals0), "$hashCode0", $rt_wrapFunction0(jl_Double_hashCode), "$compareTo5", $rt_wrapFunction1(jl_Double_compareTo0), "$compareTo2",
$rt_wrapFunction1(jl_Double_compareTo)],
jm_Elementary, 0, jl_Object, [], 0, 0, 0, 0, 0,
jl_Error, "Error", 10, jl_Throwable, [], 0, 3, 0, 0, ["$_init_36", $rt_wrapFunction2(jl_Error__init_)],
ju_FormatFlagsConversionMismatchException, "FormatFlagsConversionMismatchException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_40", $rt_wrapFunction2(ju_FormatFlagsConversionMismatchException__init_)],
jl_AssertionError, "AssertionError", 10, jl_Error, [], 0, 3, 0, 0, ["$_init_36", $rt_wrapFunction2(jl_AssertionError__init_)],
rce_Game$launch$lambda$_36_0, "Game$launch$lambda$_36_0", 3, jl_Object, [rcei_JSBridge$KeyCallback], 0, 3, 0, 0, ["$_init_29", $rt_wrapFunction1(rce_Game$launch$lambda$_36_0__init_), "$onKey", $rt_wrapFunction2(rce_Game$launch$lambda$_36_0_onKey), "$onKey$exported$0", $rt_wrapFunction2(rce_Game$launch$lambda$_36_0_onKey$exported$0)],
ju_List, 0, jl_Object, [ju_SequencedCollection], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
ju_AbstractList, "AbstractList", 7, ju_AbstractCollection, [ju_List], 1, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_0", $rt_wrapFunction0(ju_AbstractList__init_), "$iterator", $rt_wrapFunction0(ju_AbstractList_iterator), "$equals", $rt_wrapFunction1(ju_AbstractList_equals)],
ju_RandomAccess, 0, jl_Object, [], 3, 3, 0, 0, 0,
ju_ArrayList, "ArrayList", 7, ju_AbstractList, [jl_Cloneable, ji_Serializable, ju_RandomAccess], 0, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_0", $rt_wrapFunction0(ju_ArrayList__init_2), "$_init_3", $rt_wrapFunction1(ju_ArrayList__init_0), "$_init_16", $rt_wrapFunction1(ju_ArrayList__init_1), "$ensureCapacity", $rt_wrapFunction1(ju_ArrayList_ensureCapacity), "$get0", $rt_wrapFunction1(ju_ArrayList_get), "$size", $rt_wrapFunction0(ju_ArrayList_size), "$add0", $rt_wrapFunction1(ju_ArrayList_add),
"$remove", $rt_wrapFunction1(ju_ArrayList_remove), "$clear", $rt_wrapFunction0(ju_ArrayList_clear), "$toString", $rt_wrapFunction0(ju_ArrayList_toString), "$hashCode0", $rt_wrapFunction0(ju_ArrayList_hashCode), "$sort", $rt_wrapFunction1(ju_ArrayList_sort)],
rceh_VirtualGamepad, "VirtualGamepad", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rceh_VirtualGamepad__init_), "$onKeyDown", $rt_wrapFunction1(rceh_VirtualGamepad_onKeyDown), "$onKeyUp", $rt_wrapFunction1(rceh_VirtualGamepad_onKeyUp), "$isPressed", $rt_wrapFunction1(rceh_VirtualGamepad_isPressed)],
jl_IllegalMonitorStateException, "IllegalMonitorStateException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_IllegalMonitorStateException__init_)],
jm_Division, 0, jl_Object, [], 0, 0, 0, 0, 0,
jm_BitLevel, 0, jl_Object, [], 0, 0, 0, 0, 0,
juf_BiConsumer, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_String, "String", 10, jl_Object, [ji_Serializable, jl_Comparable, jl_CharSequence], 0, 3, 0, jl_String_$callClinit, ["$_init_0", $rt_wrapFunction0(jl_String__init_3), "$_init_17", $rt_wrapFunction1(jl_String__init_1), "$_init_2", $rt_wrapFunction1(jl_String__init_4), "$_init_9", $rt_wrapFunction3(jl_String__init_5), "$charAt", $rt_wrapFunction1(jl_String_charAt), "$length", $rt_wrapFunction0(jl_String_length), "$isEmpty", $rt_wrapFunction0(jl_String_isEmpty), "$compareTo6", $rt_wrapFunction1(jl_String_compareTo0),
"$compareToIgnoreCase", $rt_wrapFunction1(jl_String_compareToIgnoreCase), "$indexOf0", $rt_wrapFunction2(jl_String_indexOf), "$indexOf", $rt_wrapFunction1(jl_String_indexOf0), "$lastIndexOf0", $rt_wrapFunction2(jl_String_lastIndexOf), "$lastIndexOf", $rt_wrapFunction1(jl_String_lastIndexOf0), "$substring0", $rt_wrapFunction2(jl_String_substring), "$substring", $rt_wrapFunction1(jl_String_substring0), "$trim", $rt_wrapFunction0(jl_String_trim), "$toString", $rt_wrapFunction0(jl_String_toString), "$toCharArray",
$rt_wrapFunction0(jl_String_toCharArray), "$equals", $rt_wrapFunction1(jl_String_equals), "$equalsIgnoreCase", $rt_wrapFunction1(jl_String_equalsIgnoreCase), "$hashCode0", $rt_wrapFunction0(jl_String_hashCode), "$toUpperCase", $rt_wrapFunction0(jl_String_toUpperCase), "$compareTo2", $rt_wrapFunction1(jl_String_compareTo)],
jl_NegativeArraySizeException, "NegativeArraySizeException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_NegativeArraySizeException__init_)]]);
$rt_metadata([jl_UnsupportedOperationException, "UnsupportedOperationException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_UnsupportedOperationException__init_)],
jl_IllegalStateException, "IllegalStateException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_IllegalStateException__init_0), "$_init_", $rt_wrapFunction1(jl_IllegalStateException__init_1)],
ju_FormatterClosedException, "FormatterClosedException", 7, jl_IllegalStateException, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(ju_FormatterClosedException__init_)],
jt_DecimalFormat$TextField, "DecimalFormat$TextField", 9, jl_Object, [jt_DecimalFormat$FormatField], 0, 0, 0, 0, ["$_init_", $rt_wrapFunction1(jt_DecimalFormat$TextField__init_0), "$render", $rt_wrapFunction2(jt_DecimalFormat$TextField_render), "$equals", $rt_wrapFunction1(jt_DecimalFormat$TextField_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat$TextField_hashCode)],
rce_Game$1, "Game$1", 3, jl_Object, [rcei_JSBridge$FrameCallback], 0, 0, 0, 0, ["$_init_29", $rt_wrapFunction1(rce_Game$1__init_), "$onFrame", $rt_wrapFunction1(rce_Game$1_onFrame), "$onFrame$exported$0", $rt_wrapFunction1(rce_Game$1_onFrame$exported$0)],
rce_Color, "Color", 3, jl_Object, [], 0, 3, 0, rce_Color_$callClinit, ["$_init_12", $rt_wrapFunction3(rce_Color__init_2), "$_init_31", $rt_wrapFunction4(rce_Color__init_0), "$toCssRgba", $rt_wrapFunction0(rce_Color_toCssRgba), "$toString", $rt_wrapFunction0(rce_Color_toString)],
ju_Deque, 0, jl_Object, [ju_Queue, ju_SequencedCollection], 3, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf)],
ju_ArrayDeque, "ArrayDeque", 7, ju_AbstractCollection, [ju_Deque, jl_Cloneable, ji_Serializable], 0, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_0", $rt_wrapFunction0(ju_ArrayDeque__init_0), "$_init_3", $rt_wrapFunction1(ju_ArrayDeque__init_), "$addLast", $rt_wrapFunction1(ju_ArrayDeque_addLast), "$add0", $rt_wrapFunction1(ju_ArrayDeque_add), "$size", $rt_wrapFunction0(ju_ArrayDeque_size), "$iterator", $rt_wrapFunction0(ju_ArrayDeque_iterator)],
ju_Formatter$FormatWriter, "Formatter$FormatWriter", 7, jl_Object, [], 0, 0, 0, 0, ["$_init_42", function(var_1, var_2, var_3, var_4, var_5) { ju_Formatter$FormatWriter__init_(this, var_1, var_2, var_3, var_4, var_5); }, "$write", $rt_wrapFunction0(ju_Formatter$FormatWriter_write)],
jt_DecimalFormatSymbols, "DecimalFormatSymbols", 9, jl_Object, [jl_Cloneable], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormatSymbols__init_1), "$_init_26", $rt_wrapFunction1(jt_DecimalFormatSymbols__init_0), "$getZeroDigit", $rt_wrapFunction0(jt_DecimalFormatSymbols_getZeroDigit), "$getGroupingSeparator", $rt_wrapFunction0(jt_DecimalFormatSymbols_getGroupingSeparator), "$getPerMill", $rt_wrapFunction0(jt_DecimalFormatSymbols_getPerMill), "$getPercent", $rt_wrapFunction0(jt_DecimalFormatSymbols_getPercent),
"$getLocale", $rt_wrapFunction0(jt_DecimalFormatSymbols_getLocale), "$getDecimalSeparator", $rt_wrapFunction0(jt_DecimalFormatSymbols_getDecimalSeparator), "$getNaN", $rt_wrapFunction0(jt_DecimalFormatSymbols_getNaN), "$getInfinity", $rt_wrapFunction0(jt_DecimalFormatSymbols_getInfinity), "$getMinusSign", $rt_wrapFunction0(jt_DecimalFormatSymbols_getMinusSign), "$getExponentSeparator", $rt_wrapFunction0(jt_DecimalFormatSymbols_getExponentSeparator), "$clone0", $rt_wrapFunction0(jt_DecimalFormatSymbols_clone)],
ju_HashMap$AbstractMapIterator, "HashMap$AbstractMapIterator", 7, jl_Object, [], 0, 0, 0, 0, ["$_init_44", $rt_wrapFunction1(ju_HashMap$AbstractMapIterator__init_), "$hasNext", $rt_wrapFunction0(ju_HashMap$AbstractMapIterator_hasNext), "$checkConcurrentMod", $rt_wrapFunction0(ju_HashMap$AbstractMapIterator_checkConcurrentMod), "$makeNext", $rt_wrapFunction0(ju_HashMap$AbstractMapIterator_makeNext), "$remove0", $rt_wrapFunction0(ju_HashMap$AbstractMapIterator_remove)],
jl_AutoCloseable, 0, jl_Object, [], 3, 3, 0, 0, 0,
jl_NullPointerException, "NullPointerException", 10, jl_RuntimeException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(jl_NullPointerException__init_2), "$_init_0", $rt_wrapFunction0(jl_NullPointerException__init_0)],
ji_Closeable, 0, jl_Object, [jl_AutoCloseable], 3, 3, 0, 0, 0,
ju_Formatter, "Formatter", 7, jl_Object, [ji_Closeable, ji_Flushable], 4, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(ju_Formatter__init_1), "$_init_26", $rt_wrapFunction1(ju_Formatter__init_), "$_init_41", $rt_wrapFunction2(ju_Formatter__init_0), "$toString", $rt_wrapFunction0(ju_Formatter_toString), "$format5", $rt_wrapFunction2(ju_Formatter_format0), "$format7", $rt_wrapFunction3(ju_Formatter_format)],
otpp_AsyncCallbackWrapper, "AsyncCallbackWrapper", 20, jl_Object, [oti_AsyncCallback], 0, 0, 0, 0, ["$_init_43", $rt_wrapFunction1(otpp_AsyncCallbackWrapper__init_), "$complete", $rt_wrapFunction1(otpp_AsyncCallbackWrapper_complete), "$error", $rt_wrapFunction1(otpp_AsyncCallbackWrapper_error)],
ju_IllegalFormatPrecisionException, "IllegalFormatPrecisionException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_3", $rt_wrapFunction1(ju_IllegalFormatPrecisionException__init_)],
jl_Object$Monitor, "Object$Monitor", 10, jl_Object, [], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_Object$Monitor__init_)],
jl_Math, 0, jl_Object, [], 4, 3, 0, 0, 0,
ju_AbstractSet, "AbstractSet", 7, ju_AbstractCollection, [ju_Set], 1, 3, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_0", $rt_wrapFunction0(ju_AbstractSet__init_), "$equals", $rt_wrapFunction1(ju_AbstractSet_equals), "$hashCode0", $rt_wrapFunction0(ju_AbstractSet_hashCode)],
ju_HashMap$HashMapEntrySet, "HashMap$HashMapEntrySet", 7, ju_AbstractSet, [], 0, 0, 0, 0, ["$removeIf", $rt_wrapFunction1(ju_Collection_removeIf), "$_init_44", $rt_wrapFunction1(ju_HashMap$HashMapEntrySet__init_), "$size", $rt_wrapFunction0(ju_HashMap$HashMapEntrySet_size), "$contains", $rt_wrapFunction1(ju_HashMap$HashMapEntrySet_contains), "$iterator", $rt_wrapFunction0(ju_HashMap$HashMapEntrySet_iterator)],
jl_Byte, 0, jl_Number, [jl_Comparable], 0, 3, 0, 0, 0,
jm_RoundingMode, "RoundingMode", 8, jl_Enum, [], 12, 3, 0, jm_RoundingMode_$callClinit, 0,
jt_DecimalFormatParser, "DecimalFormatParser", 9, jl_Object, [], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormatParser__init_), "$parse", $rt_wrapFunction1(jt_DecimalFormatParser_parse), "$apply", $rt_wrapFunction1(jt_DecimalFormatParser_apply), "$parseText", $rt_wrapFunction2(jt_DecimalFormatParser_parseText)],
ju_Formattable, 0, jl_Object, [], 3, 3, 0, 0, 0,
rce_Graphics, "Graphics", 3, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rce_Graphics__init_), "$drawRect", function(var_1, var_2, var_3, var_4, var_5) { rce_Graphics_drawRect(this, var_1, var_2, var_3, var_4, var_5); }, "$drawCircle", $rt_wrapFunction4(rce_Graphics_drawCircle), "$drawLine", function(var_1, var_2, var_3, var_4, var_5, var_6) { rce_Graphics_drawLine(this, var_1, var_2, var_3, var_4, var_5, var_6); }, "$drawText", function(var_1, var_2, var_3, var_4, var_5) { rce_Graphics_drawText0(this,
var_1, var_2, var_3, var_4, var_5); }, "$drawText0", function(var_1, var_2, var_3, var_4, var_5, var_6) { rce_Graphics_drawText(this, var_1, var_2, var_3, var_4, var_5, var_6); }, "$drawGrid", $rt_wrapFunction4(rce_Graphics_drawGrid)],
rceb_DataBus, "DataBus", 4, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(rceb_DataBus__init_)],
ju_HashMap, "HashMap", 7, ju_AbstractMap, [jl_Cloneable, ji_Serializable], 0, 3, 0, 0, ["$newElementArray", $rt_wrapFunction1(ju_HashMap_newElementArray), "$_init_0", $rt_wrapFunction0(ju_HashMap__init_2), "$_init_3", $rt_wrapFunction1(ju_HashMap__init_0), "$_init_46", $rt_wrapFunction2(ju_HashMap__init_1), "$containsKey", $rt_wrapFunction1(ju_HashMap_containsKey), "$entrySet", $rt_wrapFunction0(ju_HashMap_entrySet), "$get", $rt_wrapFunction1(ju_HashMap_get), "$entryByKey", $rt_wrapFunction1(ju_HashMap_entryByKey),
"$findNonNullKeyEntry", $rt_wrapFunction3(ju_HashMap_findNonNullKeyEntry), "$findNullKeyEntry", $rt_wrapFunction0(ju_HashMap_findNullKeyEntry), "$put", $rt_wrapFunction2(ju_HashMap_put), "$rehash0", $rt_wrapFunction1(ju_HashMap_rehash0), "$rehash", $rt_wrapFunction0(ju_HashMap_rehash), "$size", $rt_wrapFunction0(ju_HashMap_size)],
jt_DecimalFormat$MinusField, "DecimalFormat$MinusField", 9, jl_Object, [jt_DecimalFormat$FormatField], 0, 0, 0, 0, ["$_init_0", $rt_wrapFunction0(jt_DecimalFormat$MinusField__init_), "$render", $rt_wrapFunction2(jt_DecimalFormat$MinusField_render), "$equals", $rt_wrapFunction1(jt_DecimalFormat$MinusField_equals), "$hashCode0", $rt_wrapFunction0(jt_DecimalFormat$MinusField_hashCode)],
ju_Comparator$comparingInt$lambda$_14_0, "Comparator$comparingInt$lambda$_14_0", 7, jl_Object, [ju_Comparator], 0, 3, 0, 0, ["$_init_22", $rt_wrapFunction1(ju_Comparator$comparingInt$lambda$_14_0__init_), "$compare1", $rt_wrapFunction2(ju_Comparator$comparingInt$lambda$_14_0_compare)],
rcek_KaboomBridge, 0, jl_Object, [], 4, 3, 0, rcek_KaboomBridge_$callClinit, 0,
rce_Key, "Key", 3, jl_Enum, [], 12, 3, 0, rce_Key_$callClinit, ["$getBitMask", $rt_wrapFunction0(rce_Key_getBitMask)],
otcit_DoubleAnalyzer, 0, jl_Object, [], 4, 3, 0, otcit_DoubleAnalyzer_$callClinit, 0,
rceh_VirtualPin, "VirtualPin", 5, jl_Object, [], 0, 3, 0, 0, ["$_init_5", $rt_wrapFunction2(rceh_VirtualPin__init_), "$getVoltage", $rt_wrapFunction0(rceh_VirtualPin_getVoltage), "$toString", $rt_wrapFunction0(rceh_VirtualPin_toString)],
rce_Audio, 0, jl_Object, [], 4, 3, 0, 0, 0,
otciu_CharMapping, "CharMapping", 17, jl_Object, [], 0, 3, 0, 0, ["$_init_20", $rt_wrapFunction2(otciu_CharMapping__init_)],
otjc_JSWeakRef, 0, jl_Object, [otj_JSObject], 1, 3, 0, 0, 0,
otci_CharFlow, "CharFlow", 16, jl_Object, [], 0, 3, 0, 0, ["$_init_17", $rt_wrapFunction1(otci_CharFlow__init_)],
ju_IllegalFormatFlagsException, "IllegalFormatFlagsException", 7, ju_IllegalFormatException, [], 0, 3, 0, 0, ["$_init_", $rt_wrapFunction1(ju_IllegalFormatFlagsException__init_0)],
otcit_FloatAnalyzer$Result, "FloatAnalyzer$Result", 18, jl_Object, [], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(otcit_FloatAnalyzer$Result__init_)],
jl_String$_clinit_$lambda$_115_0, "String$<clinit>$lambda$_115_0", 10, jl_Object, [ju_Comparator], 0, 3, 0, 0, ["$_init_0", $rt_wrapFunction0(jl_String$_clinit_$lambda$_115_0__init_), "$compare1", $rt_wrapFunction2(jl_String$_clinit_$lambda$_115_0_compare0), "$compare3", $rt_wrapFunction2(jl_String$_clinit_$lambda$_115_0_compare)],
ju_HashMap$EntryIterator, "HashMap$EntryIterator", 7, ju_HashMap$AbstractMapIterator, [ju_Iterator], 0, 0, 0, 0, ["$_init_44", $rt_wrapFunction1(ju_HashMap$EntryIterator__init_), "$next0", $rt_wrapFunction0(ju_HashMap$EntryIterator_next), "$next", $rt_wrapFunction0(ju_HashMap$EntryIterator_next0)]]);
let $rt_booleanArrayCls = $rt_arraycls($rt_booleancls),
$rt_charArrayCls = $rt_arraycls($rt_charcls),
$rt_shortArrayCls = $rt_arraycls($rt_shortcls),
$rt_intArrayCls = $rt_arraycls($rt_intcls),
$rt_longArrayCls = $rt_arraycls($rt_longcls);
$rt_stringPool(["Can\'t enter monitor from another thread synchronously", "", ": ", "main", "Negative bit address", "Negative exponent", "BigInteger divide by zero", "null", "Currency not found: ", "input_method_segment", "language", "reading", "default", "Can\'t compare ", " to ", "LOW", "HIGH", "(this Collection)", ", ", "0", "__", "en", "CA", "fr", "zh", "CN", "FR", "de", "DE", "it", "IT", "ja", "JP", "ko", "KR", "TW", "GB", "US", "object", "function", "string", "number", "undefined", "symbol", "bigint",
"boolean", "false", "true", "Unknown format conversion: ", "-", "Can\'t avoid rounding", "Can\'t format argument of ", " using ", " conversion", "(this Map)", "PORTA", "PA", "PORTB", "PB", "ЛАБИРИНТ", "Счет: ", "Жизни: ", "Монет: ", "ИГРА ОКОНЧЕНА!", "Закончились жизни", "ПОБЕДА!", "Все сокровища собраны!", "Can\'t convert code point ", " to char", "interface ", "class ", "RISING", "FALLING", "CHANGE", "INPUT", "OUTPUT", "PWM", "Either src or dest is null", "0.0", "0.00", "0.000", "0.0000", "0.00000", "0.000000",
"0E", "0E+", "2147483648", " ", "0x%04X", " [", "0.", "Overflow", "Underflow", "[attribute=", ", field=", ", beginIndex=", ", endIndex=", "Duplicate format flags: ", "Missing format with for specifier ", "power of ten too big", "Illegal format flags ", " for conversion ", "[]", "#%02x%02x%02x", "rgba(", "(", ")", "+", "+ ", "0-", "0x", "--#+ 0,(<", "This exception should not been thrown", "Illegal precision: ", "UP", "DOWN", "CEILING", "FLOOR", "HALF_UP", "HALF_DOWN", "HALF_EVEN", "UNNECESSARY", "Positive number pattern not found in ",
"Expected \';\' at ", " in ", "Prefix contains special character at ", "Quote opened at ", " was not closed in ", "Two group separators at ", "Unexpected \'#\' at non-optional digit part at ", "Pattern does not specify integer digits at ", "Group separator at the end of number at ", "Group separator found at fractional part at ", "Unexpected second decimal separator at ", "Unexpected \'0\' at optional digit part at ", "Unexpected char at exponent at ", "Pattern does not specify exponent digits at ", "Courier New, monospace",
"ArrowUp", "KeyW", "w", "ArrowDown", "KeyS", "s", "LEFT", "ArrowLeft", "KeyA", "a", "RIGHT", "ArrowRight", "KeyD", "d", "SPACE", "Space", "BTN_A", "KeyZ", "z", "KeyJ", "BTN_B", "KeyX", "x", "KeyK", "ENTER", "Enter", "Return", "ESCAPE", "Escape", "Esc", "RESET", "KeyR", "r", "Pin[%d:%s] Mode=%s State=%s (ADC=%d, %.2fV)", "Illegal format flags: "]);
jl_String.prototype.toString = function() {
    return $rt_ustr(this);
};
jl_String.prototype.valueOf = jl_String.prototype.toString;
jl_Object.prototype.toString = function() {
    return $rt_ustr(jl_Object_toString(this));
};
jl_Object.prototype.__teavm_class__ = function() {
    return $dbg_class(this);
};
let $rt_export_main = $rt_mainStarter(rcg_Main_main);
$rt_export_main.javaException = $rt_javaException;
let $rt_jso_marker = Symbol('jsoClass');
(() => {
    let c;
    c = otji_JSWrapper$_clinit_$lambda$_33_0.prototype;
    c[$rt_jso_marker] = true;
    c.accept = c.$accept$exported$0;
    c = rce_Game$launch$lambda$_36_3.prototype;
    c[$rt_jso_marker] = true;
    c.onMouse = c.$onMouse$exported$0;
    c = rce_Game$launch$lambda$_36_1.prototype;
    c[$rt_jso_marker] = true;
    c.onKey = c.$onKey$exported$0;
    c = rce_Game$launch$lambda$_36_2.prototype;
    c[$rt_jso_marker] = true;
    c.onMouse = c.$onMouse$exported$0;
    c = otji_JSWrapper$_clinit_$lambda$_33_1.prototype;
    c[$rt_jso_marker] = true;
    c.accept = c.$accept$exported$0;
    c = rce_Game$launch$lambda$_36_0.prototype;
    c[$rt_jso_marker] = true;
    c.onKey = c.$onKey$exported$0;
    c = rce_Game$1.prototype;
    c[$rt_jso_marker] = true;
    c.onFrame = c.$onFrame$exported$0;
})();
$rt_exports.main = $rt_export_main;
}));

//# sourceMappingURL=game.js.map