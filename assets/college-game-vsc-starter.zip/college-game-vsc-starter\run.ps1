# PowerShell запуск игры
$Host.UI.RawUI.WindowTitle = "College Game Starter"
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host " 🎮 ЗАПУСК ИГРЫ (VS Code Starter - Без установки Maven)" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Cyan

Remove-Item Env:\HTTP_PROXY, Env:\HTTPS_PROXY, Env:\ALL_PROXY -ErrorAction SilentlyContinue

if (-not (Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
}

Write-Host "[1/2] Компиляция Java классов (javac)..." -ForegroundColor Yellow
javac -encoding UTF-8 -cp "lib/*;lib" -d bin src/ru/college/game/*.java
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Ошибка компиляции Java. Проверьте код в папке src." -ForegroundColor Red
    pause
    exit $LASTEXITCODE
}

Write-Host "[2/2] Сборка JavaScript (TeaVM) и запуск DevServer..." -ForegroundColor Yellow
java "-Dfile.encoding=UTF-8" -cp "bin;lib/*;lib" ru.college.game.RunDev
