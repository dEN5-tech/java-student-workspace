package ru.college.game;

import ru.college.engine.*;

/**
 * 🎮 Шаблон игрового проекта (Специальность 09.02.01 / 09.02.07)
 * 
 * Основные методы для разработки:
 * - init() - первоначальная настройка игры, создание объектов, регистрация клавиш
 * - update(delta) - обновление игровой логики, перемещение объектов, физика, таймеры
 * - render(g) - пользовательская отрисовка фигур, текста, интерфейса (HUD)
 */
public class MyGame extends Game {

    public MyGame() {
        super(800, 600);
    }

    @Override
    public void init() {
        // Установка фонового цвета игрового поля
        setBackgroundColor(new Color(24, 28, 36));

        // TODO: Добавьте инициализацию ваших игровых объектов и слушателей событий здесь
    }

    @Override
    public void update(double delta) {
        // TODO: Добавьте расчет игровой логики, физики и движения здесь
    }

    @Override
    public void render(Graphics g) {
        // Базовый стартовый экран
        g.drawText("Java Game Starter", 280, 270, 28, Color.WHITE);
        g.drawText("Начните разработку вашей игры в MyGame.java", 230, 315, 16, Color.CYAN);

        // TODO: Добавьте вашу отрисовку игровых элементов и интерфейса здесь
    }

    public static void main(String[] args) {
        launch(new MyGame());
    }
}
