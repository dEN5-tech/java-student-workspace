package ru.college.game;

import ru.college.engine.server.DevServer;

/**
 * ⚡ Запуск встроенного веб-сервера без Maven и сторонних утилит.
 * Просто нажмите F5 в VS Code!
 */
public class RunDev {
    public static void main(String[] args) {
        DevServer.start(8080);
    }
}
