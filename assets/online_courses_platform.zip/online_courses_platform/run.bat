@echo off
chcp 65001 >nul
echo ===================================================
echo   Запуск Django Backend (Курсы + Кафе Tortotoro)
echo ===================================================

:: Очистка прокси для исключения socks5 ошибок
set HTTP_PROXY=
set HTTPS_PROXY=
set ALL_PROXY=

echo [1/3] Проверка и установка зависимостей...
python -m pip install -r requirements.txt --quiet

echo [2/3] Применение миграций базы данных...
python manage.py migrate --noinput

echo [3/3] Запуск сервера на http://127.0.0.1:8080 ...
python manage.py runserver 127.0.0.1:8080
pause
