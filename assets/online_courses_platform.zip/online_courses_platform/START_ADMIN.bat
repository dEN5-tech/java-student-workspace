@echo off
chcp 65001 > nul
echo =======================================================
echo   Платформа онлайн-обучения (Модуль В - Django SSR)
echo   Адрес админки: http://127.0.0.1:8000/course-admin
echo   Email: admin@edu.com
echo   Пароль: course2025
echo =======================================================
echo.

set HTTP_PROXY=
set HTTPS_PROXY=
set ALL_PROXY=

echo [1/3] Применение миграций базы данных SQLite...
python manage.py migrate --noinput

echo [2/3] Заполнение начальными данными (админ, курсы, уроки)...
python manage.py init_data

echo [3/3] Запуск веб-сервера Django...
python manage.py runserver 127.0.0.1:8000
pause
