#!/usr/bin/env bash
# ===================================================
#   Запуск Django Backend (Linux / macOS)
# ===================================================

unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy

echo "[1/3] Проверка и установка зависимостей..."
python3 -m pip install -r requirements.txt --quiet

echo "[2/3] Применение миграций базы данных..."
python3 manage.py migrate --noinput

echo "[3/3] Запуск сервера на http://0.0.0.0:8080 ..."
python3 manage.py runserver 0.0.0.0:8080
