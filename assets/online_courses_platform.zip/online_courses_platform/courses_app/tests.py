import json
from decimal import Decimal
from datetime import timedelta
from io import BytesIO
from PIL import Image

from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from django.core.files.uploadedfile import SimpleUploadedFile

from .models import User, Course, Lesson, Order, APIToken


class ModuleVRequirementsTestCase(TestCase):
    def setUp(self):
        self.client = Client()
        self.today = timezone.localdate()

        # Admin user as per spec
        self.admin = User.objects.create_superuser(
            email='admin@edu.com',
            password='course2025',
            name='Администратор'
        )

        # Student user
        self.student = User.objects.create_user(
            email='student@example.com',
            password='Password123!',
            name='Иван Студент'
        )
        self.student_token = APIToken.generate_token(self.student)

        # Create dummy image
        img = Image.new('RGB', (600, 400), color=(73, 109, 137))
        buf = BytesIO()
        img.save(buf, format='JPEG')
        buf.seek(0)
        self.dummy_image = SimpleUploadedFile("test_banner.jpg", buf.read(), content_type="image/jpeg")

        # Future course (can be bought)
        self.future_course = Course.objects.create(
            name='Тестовый будущий курс',
            description='Описание курса',
            hours=8,
            price=Decimal('150.00'),
            start_date=self.today + timedelta(days=10),
            end_date=self.today + timedelta(days=30),
            img=self.dummy_image
        )

        # Past course (already ended)
        img.save(buf, format='JPEG')
        buf.seek(0)
        img_past = SimpleUploadedFile("test_past.jpg", buf.read(), content_type="image/jpeg")
        self.past_course = Course.objects.create(
            name='Завершенный курс',
            description='Прошедший курс',
            hours=6,
            price=Decimal('120.00'),
            start_date=self.today - timedelta(days=20),
            end_date=self.today - timedelta(days=5),
            img=img_past
        )

    def test_image_thumbnail_and_mpic_prefix(self):
        """Проверка автоматической конвертации обложки в миниатюру 300x300 с префиксом mpic*"""
        self.assertTrue(self.future_course.img.name.startswith('courses/mpic_'))
        img_obj = Image.open(self.future_course.img.path)
        self.assertLessEqual(img_obj.width, 300)
        self.assertLessEqual(img_obj.height, 300)

    def test_course_validation(self):
        """Проверка ограничений на поля курса (название <= 30, цена >= 100, часы <= 10)"""
        # Name > 30 chars
        with self.assertRaises(Exception):
            c = Course(
                name='Очень длинное название курса превышающее тридцать символов',
                hours=5,
                price=Decimal('150.00'),
                start_date=self.today,
                end_date=self.today + timedelta(days=5),
            )
            c.full_clean()

    def test_lesson_max_5_limit(self):
        """Проверка правила: каждый курс может содержать не более 5 уроков"""
        for i in range(5):
            Lesson.objects.create(
                course=self.future_course,
                title=f'Урок {i+1}',
                content='Содержание урока',
                duration_hours=2,
                order=i+1
            )
        self.assertEqual(self.future_course.lessons.count(), 5)

        # Attempt to create 6th lesson
        sixth_lesson = Lesson(
            course=self.future_course,
            title='6-й урок',
            content='Лишний урок',
            duration_hours=2,
            order=6
        )
        with self.assertRaises(Exception):
            sixth_lesson.full_clean()

    def test_lesson_delete_blocked_on_active_enrollments(self):
        """Проверка правила: удаление уроков невозможно при активных записях студентов"""
        lesson = Lesson.objects.create(
            course=self.future_course,
            title='Урок с проверкой',
            content='Тест',
            duration_hours=2
        )
        # Create active enrollment (pending or success)
        Order.objects.create(
            student=self.student,
            course=self.future_course,
            payment_status=Order.STATUS_SUCCESS
        )

        with self.assertRaises(Exception):
            lesson.delete()

    # --- REST API Tests ---

    def test_api_registration_validation(self):
        """Проверка регистрации и валидации пароля (верхний/нижний регистр, цифра, спецсимволы _ # ! %)"""
        # Weak password: no special char
        res = self.client.post(
            '/school-api/registr',
            data=json.dumps({"email": "newuser@example.com", "password": "Password1"}),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 422)
        data = res.json()
        self.assertEqual(data.get("message"), "Invalid fields")
        self.assertIn("password", data.get("errors", {}))

        # Valid password
        res = self.client.post(
            '/school-api/registr',
            data=json.dumps({"email": "validuser@example.com", "password": "Password1#"}),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 201)
        self.assertEqual(res.json(), {"success": True})

    def test_api_auth(self):
        """Проверка авторизации: статус 200 с токеном или 422 при ошибке"""
        res_fail = self.client.post(
            '/school-api/auth',
            data=json.dumps({"email": "wrong@example.com", "password": "bad"}),
            content_type='application/json'
        )
        self.assertEqual(res_fail.status_code, 422)
        self.assertEqual(res_fail.json().get("message"), "Invalid data")

        res_ok = self.client.post(
            '/school-api/auth',
            data=json.dumps({"email": "student@example.com", "password": "Password123!"}),
            content_type='application/json'
        )
        self.assertEqual(res_ok.status_code, 200)
        self.assertIn("token", res_ok.json())

    def test_api_courses_and_pagination(self):
        """Проверка получения списка курсов с пагинацией и проверкой Bearer-токена"""
        # Without token -> 403 Forbidden
        res_forbidden = self.client.get('/school-api/courses')
        self.assertEqual(res_forbidden.status_code, 403)
        self.assertEqual(res_forbidden.json().get("message"), "Forbidden for you")

        # With valid token -> 200
        headers = {'HTTP_AUTHORIZATION': f'Bearer {self.student_token}'}
        res = self.client.get('/school-api/courses', **headers)
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertIn("data", body)
        self.assertIn("pagination", body)
        self.assertEqual(body["pagination"]["per_page"], 5)

    def test_api_buy_course_date_validation(self):
        """Проверка записи на курс: нельзя записаться на курс, который уже начался или закончился"""
        headers = {'HTTP_AUTHORIZATION': f'Bearer {self.student_token}'}

        # Buying past course -> 422
        res_past = self.client.post(f'/school-api/courses/{self.past_course.id}/buy', **headers)
        self.assertEqual(res_past.status_code, 422)

        # Buying future course -> 200 with pay_url
        res_future = self.client.post(f'/school-api/courses/{self.future_course.id}/buy', **headers)
        self.assertEqual(res_future.status_code, 200)
        self.assertIn("pay_url", res_future.json())

    def test_payment_webhook(self):
        """Проверка webhook платежной системы: статус 204 и обновление заказа"""
        order = Order.objects.create(
            student=self.student,
            course=self.future_course,
            payment_status=Order.STATUS_PENDING
        )

        res = self.client.post(
            '/school-api/payment-webhook',
            data=json.dumps({"order_id": order.id, "status": "success"}),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 204)
        order.refresh_from_db()
        self.assertEqual(order.payment_status, Order.STATUS_SUCCESS)

    def test_order_cancellation(self):
        """Проверка отмены записи: 418 если оплачен, 200 если ожидает оплаты"""
        headers = {'HTTP_AUTHORIZATION': f'Bearer {self.student_token}'}

        # Paid order -> 418
        paid_order = Order.objects.create(
            student=self.student,
            course=self.future_course,
            payment_status=Order.STATUS_SUCCESS
        )
        res_paid = self.client.get(f'/school-api/orders/{paid_order.id}', **headers)
        self.assertEqual(res_paid.status_code, 418)
        self.assertEqual(res_paid.json(), {"status": "was payed"})

        # Pending order -> 200
        pending_order = Order.objects.create(
            student=self.student,
            course=self.future_course,
            payment_status=Order.STATUS_PENDING
        )
        res_pending = self.client.get(f'/school-api/orders/{pending_order.id}', **headers)
        self.assertEqual(res_pending.status_code, 200)
        self.assertEqual(res_pending.json(), {"status": "success"})
        self.assertFalse(Order.objects.filter(id=pending_order.id).exists())

    def test_certificate_check(self):
        """Проверка сертификата: заканчивающийся на 1 - success, на 2 - failed"""
        res_valid = self.client.post(
            '/check-sertificate',
            data=json.dumps({"sertikate_number": "ABCDEF123451"}),
            content_type='application/json'
        )
        self.assertEqual(res_valid.json(), {"status": "success"})

        res_invalid = self.client.post(
            '/check-sertificate',
            data=json.dumps({"sertikate_number": "ABCDEF123452"}),
            content_type='application/json'
        )
        self.assertEqual(res_invalid.json(), {"status": "failed"})

    def test_admin_panel_auth(self):
        """Проверка доступа в панель управления /course-admin"""
        # Not logged in -> redirect to login
        res = self.client.get('/course-admin/courses/')
        self.assertEqual(res.status_code, 302)

        # Login as admin
        login_res = self.client.post(
            '/course-admin/login/',
            data={'email': 'admin@edu.com', 'password': 'course2025'}
        )
        self.assertEqual(login_res.status_code, 302)

        # Access course list
        res_list = self.client.get('/course-admin/courses/')
        self.assertEqual(res_list.status_code, 200)
        self.assertContains(res_list, 'Управление курсами')
