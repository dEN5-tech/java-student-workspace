from django.urls import path, re_path
from django.shortcuts import redirect
from . import admin_views
from . import api_views

urlpatterns = [
    # Admin Panel
    path('course-admin', lambda request: redirect('admin_course_list')),
    path('course-admin/', lambda request: redirect('admin_course_list')),
    path('course-admin/login/', admin_views.admin_login_view, name='admin_login'),
    path('course-admin/logout/', admin_views.admin_logout_view, name='admin_logout'),
    
    path('course-admin/courses/', admin_views.course_list_view, name='admin_course_list'),
    path('course-admin/courses/create/', admin_views.course_create_view, name='admin_course_create'),
    path('course-admin/courses/<int:course_id>/edit/', admin_views.course_edit_view, name='admin_course_edit'),
    path('course-admin/courses/<int:course_id>/delete/', admin_views.course_delete_view, name='admin_course_delete'),

    path('course-admin/courses/<int:course_id>/lessons/', admin_views.lesson_list_view, name='admin_lesson_list'),
    path('course-admin/courses/<int:course_id>/lessons/create/', admin_views.lesson_create_view, name='admin_lesson_create'),
    path('course-admin/lessons/<int:lesson_id>/edit/', admin_views.lesson_edit_view, name='admin_lesson_edit'),
    path('course-admin/lessons/<int:lesson_id>/delete/', admin_views.lesson_delete_view, name='admin_lesson_delete'),

    path('course-admin/students/', admin_views.student_enrollments_view, name='admin_student_list'),
    path('course-admin/orders/<int:order_id>/certificate/', admin_views.certificate_print_view, name='admin_certificate_print'),

    # Payment page simulator
    path('payment', admin_views.payment_page_view),
    path('payment/', admin_views.payment_page_view, name='payment_page'),

    # REST API endpoints (both with and without trailing slash to support strict clients)
    re_path(r'^school-api/registr/?$', api_views.api_registr, name='api_registr'),
    re_path(r'^school-api/auth/?$', api_views.api_auth, name='api_auth'),
    re_path(r'^school-api/courses/?$', api_views.api_courses, name='api_courses'),
    re_path(r'^school-api/courses/(?P<course_id>\d+)/?$', api_views.api_course_lessons, name='api_course_lessons'),
    re_path(r'^school-api/courses/(?P<course_id>\d+)/buy/?$', api_views.api_course_buy, name='api_course_buy'),
    re_path(r'^school-api/payment-webhook/?$', api_views.api_payment_webhook, name='api_payment_webhook'),
    re_path(r'^school-api/orders/?$', api_views.api_orders, name='api_orders'),
    re_path(r'^school-api/orders/(?P<order_id>\d+)/?$', api_views.api_order_cancel, name='api_order_cancel'),

    # Certification endpoints
    re_path(r'^check-sertificate/?$', api_views.api_check_sertificate, name='api_check_sertificate_root'),
    re_path(r'^school-api/check-sertificate/?$', api_views.api_check_sertificate, name='api_check_sertificate'),
    re_path(r'^create-sertificate/?$', api_views.api_create_sertificate, name='api_create_sertificate_root'),
    re_path(r'^school-api/create-sertificate/?$', api_views.api_create_sertificate, name='api_create_sertificate'),
]
