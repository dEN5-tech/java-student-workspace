import json
import re
import secrets
from decimal import Decimal
from datetime import datetime

from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.core.paginator import Paginator
from django.urls import reverse

from .models import User, Course, Lesson, Order, APIToken


def get_authenticated_user(request):
    auth_header = request.headers.get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        return None
    token_key = auth_header.split('Bearer ', 1)[1].strip()
    try:
        token = APIToken.objects.select_related('user').get(key=token_key)
        return token.user
    except APIToken.DoesNotExist:
        return None


def forbidden_response():
    return JsonResponse({"message": "Forbidden for you"}, status=403)


def validation_error_response(errors, message="Invalid fields"):
    return JsonResponse({
        "message": message,
        "errors": errors
    }, status=422)


@csrf_exempt
def api_registr(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return validation_error_response({"body": ["Invalid JSON format"]})

    email = str(data.get('email', '')).strip()
    password = str(data.get('password', ''))

    errors = {}
    if not email:
        errors['email'] = ["Email is required"]
    elif not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
        errors['email'] = ["Invalid email format"]
    elif User.objects.filter(email=email).exists():
        errors['email'] = ["User with this email already exists"]

    if not password:
        errors['password'] = ["Password is required"]
    else:
        # Minimum 3 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special char (_ # ! %)
        if len(password) < 3:
            errors['password'] = ["Password must be at least 3 characters"]
        elif not any(c.isupper() for c in password):
            errors['password'] = ["Password must contain at least one uppercase letter"]
        elif not any(c.islower() for c in password):
            errors['password'] = ["Password must contain at least one lowercase letter"]
        elif not any(c.isdigit() for c in password):
            errors['password'] = ["Password must contain at least one digit"]
        elif not any(c in '_#!%' for c in password):
            errors['password'] = ["Password must contain at least one of '_', '#', '!', '%'"]

    if errors:
        return validation_error_response(errors)

    user = User.objects.create_user(email=email, password=password)
    return JsonResponse({"success": True}, status=201)


@csrf_exempt
def api_auth(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({"message": "Invalid data", "errors": {"email": ["Invalid data"]}}, status=422)

    email = str(data.get('email', '')).strip()
    password = str(data.get('password', ''))

    if not email or not password:
        return JsonResponse({"message": "Invalid data", "errors": {"email": ["Invalid data"]}}, status=422)

    try:
        user = User.objects.get(email=email)
        if not user.check_password(password):
            return JsonResponse({"message": "Invalid data", "errors": {"email": ["Invalid data"]}}, status=422)
    except User.DoesNotExist:
        return JsonResponse({"message": "Invalid data", "errors": {"email": ["Invalid data"]}}, status=422)

    token_key = APIToken.generate_token(user)
    return JsonResponse({"token": token_key}, status=200)


def format_course_dict(course, request):
    img_url = ""
    if course.img:
        img_url = request.build_absolute_uri(course.img.url)
    return {
        "id": course.id,
        "name": course.name,
        "description": course.description or "",
        "hours": course.hours,
        "img": img_url,
        "start_date": course.start_date.strftime('%d-%m-%Y'),
        "end_date": course.end_date.strftime('%d-%m-%Y'),
        "price": f"{course.price:.2f}"
    }


def api_courses(request):
    user = get_authenticated_user(request)
    if not user:
        return forbidden_response()

    if request.method != 'GET':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    courses_qs = Course.objects.all().order_by('id')
    page_number = request.GET.get('page', 1)
    paginator = Paginator(courses_qs, 5)

    try:
        page_obj = paginator.get_page(page_number)
    except Exception:
        page_obj = paginator.get_page(1)

    courses_data = [format_course_dict(c, request) for c in page_obj]

    return JsonResponse({
        "data": courses_data,
        "pagination": {
            "total": paginator.num_pages,
            "current": page_obj.number,
            "per_page": 5
        }
    }, status=200)


def api_course_lessons(request, course_id):
    user = get_authenticated_user(request)
    if not user:
        return forbidden_response()

    if request.method != 'GET':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        course = Course.objects.get(id=course_id)
    except Course.DoesNotExist:
        return JsonResponse({"message": "Course not found"}, status=404)

    lessons = course.lessons.all().order_by('order', 'id')
    lessons_data = []
    for l in lessons:
        lessons_data.append({
            "id": l.id,
            "name": l.title,
            "description": l.content,
            "video_link": l.video_link,
            "hours": l.duration_hours
        })

    return JsonResponse({"data": lessons_data}, status=200)


@csrf_exempt
def api_course_buy(request, course_id):
    user = get_authenticated_user(request)
    if not user:
        return forbidden_response()

    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        course = Course.objects.get(id=course_id)
    except Course.DoesNotExist:
        return JsonResponse({"message": "Course not found"}, status=404)

    today = timezone.localdate()
    if today >= course.start_date:
        return validation_error_response({
            "course": ["Запись на курс должна производиться до его начала."]
        })

    # Create order in pending status
    order = Order.objects.create(
        student=user,
        course=course,
        payment_status=Order.STATUS_PENDING
    )

    pay_url = request.build_absolute_uri(reverse('payment_page')) + f"?order_id={order.id}"
    return JsonResponse({"pay_url": pay_url}, status=200)


@csrf_exempt
def api_payment_webhook(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({"message": "Invalid JSON"}, status=400)

    order_id = data.get('order_id')
    status_str = str(data.get('status', '')).lower()

    if not order_id or status_str not in ['success', 'failed']:
        return JsonResponse({"message": "Invalid parameters"}, status=400)

    try:
        order = Order.objects.get(id=order_id)
        if status_str == 'success':
            order.payment_status = Order.STATUS_SUCCESS
        else:
            order.payment_status = Order.STATUS_FAILED
        order.save()
        return HttpResponse(status=204)
    except Order.DoesNotExist:
        return JsonResponse({"message": "Order not found"}, status=404)


def api_orders(request):
    user = get_authenticated_user(request)
    if not user:
        return forbidden_response()

    if request.method != 'GET':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    orders = Order.objects.filter(student=user).select_related('course').order_by('-id')
    orders_data = []
    for o in orders:
        orders_data.append({
            "id": o.id,
            "payment_status": o.payment_status,
            "course": format_course_dict(o.course, request)
        })

    return JsonResponse({"data": orders_data}, status=200)


def api_order_cancel(request, order_id):
    user = get_authenticated_user(request)
    if not user:
        return forbidden_response()

    if request.method != 'GET':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        order = Order.objects.get(id=order_id, student=user)
    except Order.DoesNotExist:
        return JsonResponse({"message": "Order not found"}, status=404)

    if order.payment_status == Order.STATUS_SUCCESS:
        return JsonResponse({"status": "was payed"}, status=418)

    order.delete()
    return JsonResponse({"status": "success"}, status=200)


@csrf_exempt
def api_check_sertificate(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({"status": "failed"}, status=200)

    sert_num = str(data.get('sertikate_number', data.get('certificate_number', ''))).strip()

    if sert_num.endswith('1'):
        return JsonResponse({"status": "success"}, status=200)
    else:
        return JsonResponse({"status": "failed"}, status=200)


@csrf_exempt
def api_create_sertificate(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    # 6 characters returned by certification server
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    course_number = "".join(secrets.choice(alphabet) for _ in range(6))
    return JsonResponse({"course_number": course_number}, status=200)
