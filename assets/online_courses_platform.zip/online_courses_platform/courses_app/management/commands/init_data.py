import os
from decimal import Decimal
from datetime import date, timedelta
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

from django.core.management.base import BaseCommand
from django.core.files.base import ContentFile
from django.utils import timezone
from courses_app.models import User, Course, Lesson, Order, APIToken


class Command(BaseCommand):
    help = 'Инициализация начальных данных: администратор и демонстрационные курсы'

    def handle(self, *args, **options):
        # 1. Create or update Default Admin
        admin_email = 'admin@edu.com'
        admin_pass = 'course2025'
        admin_user, created = User.objects.get_or_create(
            email=admin_email,
            defaults={
                'name': 'Главный Администратор',
                'is_staff': True,
                'is_superuser': True,
                'is_active': True,
            }
        )
        admin_user.set_password(admin_pass)
        admin_user.is_staff = True
        admin_user.is_superuser = True
        admin_user.save()
        APIToken.generate_token(admin_user)

        self.stdout.write(self.style.SUCCESS(f'Администратор настроен: {admin_email} / {admin_pass}'))

        # Helper to generate a placeholder course image (300x300, JPEG)
        def create_placeholder_image(text, bg_color):
            img = Image.new('RGB', (300, 300), color=bg_color)
            d = ImageDraw.Draw(img)
            d.rectangle([(10, 10), (290, 290)], outline=(255, 255, 255), width=3)
            d.text((30, 130), text, fill=(255, 255, 255))
            buf = BytesIO()
            img.save(buf, format='JPEG', quality=90)
            buf.seek(0)
            return ContentFile(buf.read())

        # 2. Sample Courses
        today = timezone.localdate()

        courses_data = [
            {
                'name': 'Веб-разработка с нуля',
                'description': 'Основы HTML5, современного CSS и базового JavaScript для начинающих разработчиков.',
                'hours': 8,
                'price': Decimal('150.00'),
                'start_date': today + timedelta(days=10),
                'end_date': today + timedelta(days=30),
                'color': (30, 58, 138),
                'lessons': [
                    ('Введение в Web и архитектура клиента', 'Обзор протоколов HTTP, структуры DOM и инструментов браузера.', 'https://super-tube.cc/video/v23189', 2),
                    ('Семантическая верстка HTML5', 'Изучение основных семантических тегов, доступности и валидации.', 'https://super-tube.cc/video/v1002', 2),
                    ('Стилизация с помощью Flexbox и Grid', 'Современные методы компоновки интерфейсов и адаптивный дизайн.', 'https://super-tube.cc/video/v1003', 2),
                    ('Основы JavaScript и события', 'Синтаксис ES6+, работа с событиями пользователя и манипуляция элементами DOM.', 'https://super-tube.cc/video/v1004', 2),
                ]
            },
            {
                'name': 'Разработка REST API на Python',
                'description': 'Проектирование безопасных RESTful сервисов, работа с СУБД и авторизация по токенам.',
                'hours': 10,
                'price': Decimal('220.00'),
                'start_date': today + timedelta(days=5),
                'end_date': today + timedelta(days=25),
                'color': (13, 148, 136),
                'lessons': [
                    ('Архитектурные принципы REST', 'Методы HTTP, коды состояния и организация конечных точек API.', 'https://super-tube.cc/video/v2001', 2),
                    ('Модели данных и миграции', 'Проектирование схемы БД, реляционные связи и валидация данных.', 'https://super-tube.cc/video/v2002', 3),
                    ('Аутентификация по Bearer Token', 'Безопасное хранение паролей, генерация и проверка токенов доступа.', 'https://super-tube.cc/video/v2003', 3),
                    ('Тестирование и обработка ошибок', 'Автоматические тесты, структурированные ответы 422 и 403.', 'https://super-tube.cc/video/v2004', 2),
                ]
            },
            {
                'name': 'Базовый курс по СУБД SQL',
                'description': 'Реляционные базы данных, запросы SELECT, JOIN, агрегация и транзакции.',
                'hours': 6,
                'price': Decimal('110.00'),
                'start_date': today - timedelta(days=40),
                'end_date': today - timedelta(days=10), # Completed course!
                'color': (190, 24, 93),
                'lessons': [
                    ('Основы реляционной модели', 'Таблицы, первичные и внешние ключи, типы данных.', 'https://super-tube.cc/video/v3001', 2),
                    ('Сложные запросы и объединения', 'Использование JOIN, GROUP BY, HAVING и оконных функций.', 'https://super-tube.cc/video/v3002', 2),
                    ('Индексы и оптимизация', 'Планы выполнения запросов и транзакционная целостность ACID.', 'https://super-tube.cc/video/v3003', 2),
                ]
            },
            {
                'name': 'Frontend на Vue и React',
                'description': 'Создание реактивных пользовательских интерфейсов и SPA приложений.',
                'hours': 9,
                'price': Decimal('180.00'),
                'start_date': today + timedelta(days=15),
                'end_date': today + timedelta(days=45),
                'color': (217, 119, 6),
                'lessons': [
                    ('Компонентный подход', 'Жизненный цикл компонентов, props и состояние.', 'https://super-tube.cc/video/v4001', 3),
                    ('Интеграция с REST API', 'Асинхронные запросы fetch, стейт-менеджмент и кэширование.', 'https://super-tube.cc/video/v4002', 3),
                ]
            },
            {
                'name': 'Безопасность веб-приложений',
                'description': 'Защита от XSS, CSRF, SQL Injection и обеспечение безопасного обмена данными.',
                'hours': 5,
                'price': Decimal('130.00'),
                'start_date': today + timedelta(days=20),
                'end_date': today + timedelta(days=50),
                'color': (88, 28, 135),
                'lessons': [
                    ('Уязвимости OWASP Top-10', 'Анализ векторов атак и методы их нейтрализации.', 'https://super-tube.cc/video/v5001', 3),
                ]
            },
            {
                'name': 'CMS WordPress для бизнеса',
                'description': 'Создание и кастомизация тем, настройка плагинов и оптимизация загрузки.',
                'hours': 7,
                'price': Decimal('140.00'),
                'start_date': today + timedelta(days=8),
                'end_date': today + timedelta(days=28),
                'color': (3, 105, 161),
                'lessons': [
                    ('Структура темы WordPress', 'Иерархия шаблонов, functions.php и хуки.', 'https://super-tube.cc/video/v6001', 3),
                ]
            }
        ]

        for cdata in courses_data:
            course, c_created = Course.objects.get_or_create(
                name=cdata['name'],
                defaults={
                    'description': cdata['description'],
                    'hours': cdata['hours'],
                    'price': cdata['price'],
                    'start_date': cdata['start_date'],
                    'end_date': cdata['end_date'],
                }
            )
            if c_created or not course.img:
                img_file = create_placeholder_image(cdata['name'][:18], cdata['color'])
                course.img.save(f"mpic_{course.id}.jpg", img_file, save=True)

            # Create lessons up to 5
            for idx, (ltitle, ldesc, lvideo, ldur) in enumerate(cdata['lessons'], 1):
                Lesson.objects.get_or_create(
                    course=course,
                    title=ltitle,
                    defaults={
                        'content': ldesc,
                        'video_link': lvideo,
                        'duration_hours': ldur,
                        'order': idx
                    }
                )

        # 3. Create Sample Students and Orders
        student1, _ = User.objects.get_or_create(
            email='ivanov@example.com',
            defaults={'name': 'Иван Иванов', 'is_active': True}
        )
        student1.set_password('Pass123_!')
        student1.save()
        APIToken.generate_token(student1)

        student2, _ = User.objects.get_or_create(
            email='petrova@example.com',
            defaults={'name': 'Анна Петрова', 'is_active': True}
        )
        student2.set_password('Secret99#')
        student2.save()
        APIToken.generate_token(student2)

        # Enrollments
        completed_course = Course.objects.get(name='Базовый курс по СУБД SQL')
        Order.objects.get_or_create(
            student=student1,
            course=completed_course,
            defaults={
                'payment_status': Order.STATUS_SUCCESS,
                'certificate_number': 'A9X7K2104521'
            }
        )

        active_course = Course.objects.get(name='Веб-разработка с нуля')
        Order.objects.get_or_create(
            student=student1,
            course=active_course,
            defaults={'payment_status': Order.STATUS_SUCCESS}
        )
        Order.objects.get_or_create(
            student=student2,
            course=active_course,
            defaults={'payment_status': Order.STATUS_PENDING}
        )

        self.stdout.write(self.style.SUCCESS('Начальные данные успешно созданы!'))
