# -*- coding: utf-8 -*-
from django.contrib import admin
from .models import User, APIToken, Course, Lesson, Order

admin.site.register(User)
admin.site.register(APIToken)
admin.site.register(Course)
admin.site.register(Lesson)
admin.site.register(Order)
