# -*- coding: utf-8 -*-
"""
Формы Django для валидации данных админ-панели (Модуль В).
Написано просто, наглядно и понятно для студентов.
"""

import re
from decimal import Decimal
from django import forms
from django.core.exceptions import ValidationError
from .models import Course, Lesson


# -------------------------------------------------------------
# 1. Форма входа в админ-панель
# -------------------------------------------------------------
class AdminLoginForm(forms.Form):
    email = forms.EmailField(
        label="Email администратора",
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'admin@edu.com'})
    )
    password = forms.CharField(
        label="Пароль",
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'course2025'})
    )


# -------------------------------------------------------------
# 2. Форма создания / редактирования Курса
# -------------------------------------------------------------
class CourseForm(forms.ModelForm):
    start_date = forms.DateField(
        label="Дата начала",
        input_formats=['%d-%m-%Y', '%Y-%m-%d'],
        widget=forms.DateInput(format='%d-%m-%Y', attrs={'class': 'form-control', 'placeholder': 'дд-мм-гггг', 'type': 'date'})
    )
    end_date = forms.DateField(
        label="Дата окончания",
        input_formats=['%d-%m-%Y', '%Y-%m-%d'],
        widget=forms.DateInput(format='%d-%m-%Y', attrs={'class': 'form-control', 'placeholder': 'дд-мм-гггг', 'type': 'date'})
    )

    class Meta:
        model = Course
        fields = ['name', 'description', 'hours', 'price', 'start_date', 'end_date', 'img']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'maxlength': '30', 'placeholder': 'Название курса (до 30 символов)'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'maxlength': '100', 'rows': 3, 'placeholder': 'Краткое описание (до 100 символов)'}),
            'hours': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 10}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '100.00', 'placeholder': '100.00'}),
            'img': forms.FileInput(attrs={'class': 'form-control', 'accept': '.jpg,.jpeg,image/jpeg'}),
        }

    # Валидация названия: обязательно, до 30 символов
    def clean_name(self):
        name = self.cleaned_data.get('name', '').strip()
        if not name:
            raise ValidationError('Название курса обязательно для заполнения.')
        if len(name) > 30:
            raise ValidationError('Название курса не должно превышать 30 символов.')
        return name

    # Валидация описания: необязательно, до 100 символов
    def clean_description(self):
        desc = self.cleaned_data.get('description', '').strip()
        if len(desc) > 100:
            raise ValidationError('Описание курса не должно превышать 100 символов.')
        return desc

    # Валидация продолжительности: целое число от 1 до 10
    def clean_hours(self):
        hours = self.cleaned_data.get('hours')
        if hours is None:
            raise ValidationError('Укажите продолжительность курса.')
        if hours < 1 or hours > 10:
            raise ValidationError('Продолжительность должна быть целым числом не больше 10 часов.')
        return hours

    # Валидация цены: число не менее 100.00
    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price is None:
            raise ValidationError('Укажите цену курса.')
        if price < Decimal('100.00'):
            raise ValidationError('Цена курса должна быть числом не менее 100 рублей.')
        return price

    # Валидация файла изображения: обязателен при создании, только JPG/JPEG, до 2000 Кб
    def clean_img(self):
        img = self.cleaned_data.get('img')
        if not img and not self.instance.pk:
            raise ValidationError('Обложка курса обязательна при создании.')
        if img and hasattr(img, 'size'):
            # 2000 Кб = 2000 * 1024 байт
            if img.size > 2000 * 1024:
                raise ValidationError('Размер изображения не должен превышать 2000 Кб (2 Мб).')
            ext = img.name.split('.')[-1].lower()
            if ext not in ['jpg', 'jpeg']:
                raise ValidationError('Разрешены только изображения формата JPG (JPEG).')
        return img

    # Общая валидация дат: дата окончания >= дата начала
    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get('start_date')
        end = cleaned_data.get('end_date')
        if start and end and start > end:
            self.add_error('end_date', 'Дата окончания не может быть раньше даты начала.')
        return cleaned_data


# -------------------------------------------------------------
# 3. Форма создания / редактирования Урока
# -------------------------------------------------------------
class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ['title', 'content', 'video_link', 'duration_hours']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'maxlength': '50', 'placeholder': 'Заголовок урока (до 50 символов)'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Текстовое содержание урока'}),
            'video_link': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'https://super-tube.cc/video/v23189'}),
            'duration_hours': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 4}),
        }

    # Валидация заголовка: обязательно, до 50 символов
    def clean_title(self):
        title = self.cleaned_data.get('title', '').strip()
        if not title:
            raise ValidationError('Заголовок урока обязателен для заполнения.')
        if len(title) > 50:
            raise ValidationError('Заголовок урока не должен превышать 50 символов.')
        return title

    # Валидация содержания: обязательно
    def clean_content(self):
        content = self.cleaned_data.get('content', '').strip()
        if not content:
            raise ValidationError('Текстовое содержание урока обязательно.')
        return content

    # Валидация длительности: от 1 до 4 часов
    def clean_duration_hours(self):
        duration = self.cleaned_data.get('duration_hours')
        if duration is None:
            raise ValidationError('Укажите длительность урока.')
        if duration < 1 or duration > 4:
            raise ValidationError('Длительность урока должна быть целым числом не более 4 часов.')
        return duration

    # Валидация ссылки на видео: формат https://super-tube.cc/video/...
    def clean_video_link(self):
        link = self.cleaned_data.get('video_link', '').strip()
        if link:
            pattern = r'^https:\/\/super-tube\.cc\/video\/[a-zA-Z0-9_\-]+$'
            if not re.match(pattern, link):
                raise ValidationError('Некорректная ссылка SuperTube. Пример: https://super-tube.cc/video/v23189')
        return link
