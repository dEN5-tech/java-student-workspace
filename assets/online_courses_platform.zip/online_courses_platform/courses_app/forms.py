import re
from decimal import Decimal
from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from .models import Course, Lesson, User


class AdminLoginForm(forms.Form):
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'admin@edu.com'})
    )
    password = forms.CharField(
        label="Пароль",
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': '••••••••'})
    )


class CourseForm(forms.ModelForm):
    start_date = forms.DateField(
        label="Дата начала",
        input_formats=['%d-%m-%Y', '%Y-%m-%d'],
        widget=forms.DateInput(format='%d-%m-%Y', attrs={'class': 'form-control', 'placeholder': 'дд-мм-гггг', 'type': 'date'})
    )
    end_date = forms.DateField(
        label="Дата окончания",
        input_formats=['%d-%m-%Y', '%Y-%m-%d'],
        widget=forms.DateInput(format='%d-%m-%Y', attrs={'class': 'form-control', 'placeholder': 'дд-мм-гггг', 'type': 'date'})
    )

    class Meta:
        model = Course
        fields = ['name', 'description', 'hours', 'price', 'start_date', 'end_date', 'img']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'maxlength': '30', 'placeholder': 'Название курса (до 30 символов)'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'maxlength': '100', 'rows': 3, 'placeholder': 'Краткое описание (до 100 символов)'}),
            'hours': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 10}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '100.00', 'placeholder': '100.00'}),
            'img': forms.FileInput(attrs={'class': 'form-control', 'accept': '.jpg,.jpeg,image/jpeg'}),
        }

    def clean_name(self):
        name = self.cleaned_data.get('name', '').strip()
        if not name:
            raise ValidationError('Название курса обязательно.')
        if len(name) > 30:
            raise ValidationError('Название курса не должно превышать 30 символов.')
        return name

    def clean_description(self):
        desc = self.cleaned_data.get('description', '').strip()
        if len(desc) > 100:
            raise ValidationError('Описание курса не должно превышать 100 символов.')
        return desc

    def clean_hours(self):
        hours = self.cleaned_data.get('hours')
        if hours is None:
            raise ValidationError('Продолжительность обязательна.')
        if hours < 1 or hours > 10:
            raise ValidationError('Продолжительность должна быть целым числом не больше 10.')
        return hours

    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price is None:
            raise ValidationError('Цена обязательна.')
        if price < Decimal('100.00'):
            raise ValidationError('Цена должна быть числом не менее 100.')
        return price

    def clean_img(self):
        img = self.cleaned_data.get('img')
        if not img and not self.instance.pk:
            raise ValidationError('Обложка курса обязательна при создании.')
        if img and hasattr(img, 'size'):
            # Max 2000 KB = 2000 * 1024 bytes
            if img.size > 2000 * 1024:
                raise ValidationError('Размер файла изображения не должен превышать 2000 Кб.')
            # Extension check
            ext = img.name.split('.')[-1].lower()
            if ext not in ['jpg', 'jpeg']:
                raise ValidationError('Разрешены только изображения формата JPG (JPEG).')
        return img

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get('start_date')
        end = cleaned_data.get('end_date')
        if start and end and start > end:
            self.add_error('end_date', 'Дата окончания не может быть раньше даты начала.')
        return cleaned_data


class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ['title', 'content', 'video_link', 'duration_hours']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'maxlength': '50', 'placeholder': 'Заголовок урока (до 50 символов)'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Текстовое содержание урока'}),
            'video_link': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'https://super-tube.cc/video/v23189'}),
            'duration_hours': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 4}),
        }

    def clean_title(self):
        title = self.cleaned_data.get('title', '').strip()
        if not title:
            raise ValidationError('Заголовок урока обязателен.')
        if len(title) > 50:
            raise ValidationError('Заголовок урока не должен превышать 50 символов.')
        return title

    def clean_content(self):
        content = self.cleaned_data.get('content', '').strip()
        if not content:
            raise ValidationError('Текстовое содержание обязательно.')
        return content

    def clean_duration_hours(self):
        duration = self.cleaned_data.get('duration_hours')
        if duration is None:
            raise ValidationError('Длительность обязательна.')
        if duration < 1 or duration > 4:
            raise ValidationError('Длительность должна быть целым числом не более 4 часов.')
        return duration

    def clean_video_link(self):
        link = self.cleaned_data.get('video_link', '').strip()
        if link:
            # Must be valid SuperTube link: https://super-tube.cc/video/...
            pattern = r'^https:\/\/super-tube\.cc\/video\/[a-zA-Z0-9_\-]+$'
            if not re.match(pattern, link):
                raise ValidationError('Некорректная ссылка SuperTube. Пример: https://super-tube.cc/video/v23189')
        return link
