import secrets
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.core.paginator import Paginator
from django.utils import timezone
from django.urls import reverse
from django.http import HttpResponseForbidden

from .models import Course, Lesson, Order, User
from .forms import AdminLoginForm, CourseForm, LessonForm


def is_admin_user(user):
    return user.is_authenticated and (user.is_staff or user.is_superuser)


def admin_login_view(request):
    if request.user.is_authenticated and is_admin_user(request.user):
        return redirect('admin_course_list')

    form = AdminLoginForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, username=email, password=password)
            if user is not None and is_admin_user(user):
                login(request, user)
                return redirect('admin_course_list')
            else:
                form.add_error(None, 'Неверный email или пароль, либо недостаточно прав администратора.')
    return render(request, 'admin/login.html', {'form': form})


def admin_logout_view(request):
    logout(request)
    return redirect('admin_login')


@login_required(login_url='admin_login')
def course_list_view(request):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    courses_qs = Course.objects.all().order_by('-id')
    paginator = Paginator(courses_qs, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'admin/course_list.html', {
        'page_obj': page_obj,
        'now_date': timezone.localdate(),
    })


@login_required(login_url='admin_login')
def course_create_view(request):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    form = CourseForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            course = form.save()
            messages.success(request, f'Курс «{course.name}» успешно создан.')
            return redirect('admin_course_list')

    return render(request, 'admin/course_form.html', {
        'form': form,
        'title': 'Создание нового курса',
    })


@login_required(login_url='admin_login')
def course_edit_view(request, course_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    course = get_object_or_404(Course, id=course_id)
    form = CourseForm(request.POST or None, request.FILES or None, instance=course)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, f'Курс «{course.name}» успешно обновлен.')
            return redirect('admin_course_list')

    return render(request, 'admin/course_form.html', {
        'form': form,
        'course': course,
        'title': f'Редактирование курса: {course.name}',
    })


@login_required(login_url='admin_login')
def course_delete_view(request, course_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    course = get_object_or_404(Course, id=course_id)
    if request.method == 'POST':
        name = course.name
        course.delete()
        messages.success(request, f'Курс «{name}» успешно удален.')
        return redirect('admin_course_list')

    return render(request, 'admin/course_confirm_delete.html', {'course': course})


@login_required(login_url='admin_login')
def lesson_list_view(request, course_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    course = get_object_or_404(Course, id=course_id)
    lessons = course.lessons.all().order_by('order', 'id')
    active_enrollments = course.orders.filter(payment_status__in=['pending', 'success']).exists()

    return render(request, 'admin/lesson_list.html', {
        'course': course,
        'lessons': lessons,
        'can_add_lesson': lessons.count() < 5,
        'has_active_enrollments': active_enrollments,
    })


@login_required(login_url='admin_login')
def lesson_create_view(request, course_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    course = get_object_or_404(Course, id=course_id)
    if course.lessons.count() >= 5:
        messages.error(request, 'Каждый курс может содержать не более 5 уроков.')
        return redirect('admin_lesson_list', course_id=course.id)

    form = LessonForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            lesson = form.save(commit=False)
            lesson.course = course
            lesson.order = course.lessons.count() + 1
            lesson.save()
            messages.success(request, f'Урок «{lesson.title}» успешно добавлен.')
            return redirect('admin_lesson_list', course_id=course.id)

    return render(request, 'admin/lesson_form.html', {
        'form': form,
        'course': course,
        'title': f'Добавление урока в курс «{course.name}»',
    })


@login_required(login_url='admin_login')
def lesson_edit_view(request, lesson_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    lesson = get_object_or_404(Lesson, id=lesson_id)
    form = LessonForm(request.POST or None, instance=lesson)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, f'Урок «{lesson.title}» успешно сохранен.')
            return redirect('admin_lesson_list', course_id=lesson.course.id)

    return render(request, 'admin/lesson_form.html', {
        'form': form,
        'course': lesson.course,
        'lesson': lesson,
        'title': f'Редактирование урока: {lesson.title}',
    })


@login_required(login_url='admin_login')
def lesson_delete_view(request, lesson_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    lesson = get_object_or_404(Lesson, id=lesson_id)
    course_id = lesson.course.id

    # Check active student enrollments
    active_enrollments = lesson.course.orders.filter(payment_status__in=['pending', 'success']).exists()
    if active_enrollments:
        messages.error(request, 'Удаление уроков невозможно при наличии активных записей студентов на курс.')
        return redirect('admin_lesson_list', course_id=course_id)

    if request.method == 'POST':
        title = lesson.title
        lesson.delete()
        messages.success(request, f'Урок «{title}» успешно удален.')
        return redirect('admin_lesson_list', course_id=course_id)

    return render(request, 'admin/lesson_confirm_delete.html', {'lesson': lesson})


@login_required(login_url='admin_login')
def student_enrollments_view(request):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    courses = Course.objects.all().order_by('name')
    selected_course_id = request.GET.get('course_id')

    orders_qs = Order.objects.select_related('student', 'course').order_by('-created_at')
    if selected_course_id:
        orders_qs = orders_qs.filter(course_id=selected_course_id)

    today = timezone.localdate()

    return render(request, 'admin/students_list.html', {
        'courses': courses,
        'selected_course_id': selected_course_id,
        'orders': orders_qs,
        'today': today,
    })


@login_required(login_url='admin_login')
def certificate_print_view(request, order_id):
    if not is_admin_user(request.user):
        return HttpResponseForbidden('Доступ только для администраторов')

    order = get_object_or_404(Order.objects.select_related('student', 'course'), id=order_id)

    # Generate certificate number if not generated yet:
    # 6 symbols from certification logic + 6 digits system generated, ending with '1' (valid) = 12 symbols total
    if not order.certificate_number:
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        prefix = "".join(secrets.choice(alphabet) for _ in range(6))
        # 5 random digits + '1'
        digits_body = "".join(secrets.choice("0123456789") for _ in range(5))
        order.certificate_number = f"{prefix}{digits_body}1"
        order.save(update_fields=['certificate_number'])

    return render(request, 'admin/certificate.html', {
        'order': order,
        'student': order.student,
        'course': order.course,
        'cert_number': order.certificate_number,
        'print_date': timezone.localdate(),
    })


def payment_page_view(request):
    order_id = request.GET.get('order_id')
    order = None
    if order_id:
        try:
            order = Order.objects.select_related('course', 'student').get(id=order_id)
        except Order.DoesNotExist:
            pass

    return render(request, 'payment/pay.html', {
        'order': order,
        'order_id': order_id,
    })
