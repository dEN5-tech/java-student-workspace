import os
import secrets
from decimal import Decimal
from io import BytesIO
from PIL import Image

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Email обязателен')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True, max_length=255)
    name = models.CharField(max_length=150, blank=True, default='')
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.email


class APIToken(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='api_token')
    key = models.CharField(max_length=64, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def generate_token(cls, user):
        token_key = secrets.token_hex(24)
        token, _ = cls.objects.update_or_create(user=user, defaults={'key': token_key})
        return token.key

    def __str__(self):
        return f"{self.user.email} -> {self.key}"


def course_image_upload_to(instance, filename):
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ['.jpg', '.jpeg']:
        ext = '.jpg'
    random_str = secrets.token_hex(6)
    return f"courses/mpic_{random_str}{ext}"


class Course(models.Model):
    name = models.CharField(max_length=30, verbose_name="Название курса")
    description = models.CharField(max_length=100, blank=True, default='', verbose_name="Описание")
    hours = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        verbose_name="Продолжительность (в часах)"
    )
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('100.00'))],
        verbose_name="Цена"
    )
    start_date = models.DateField(verbose_name="Дата начала")
    end_date = models.DateField(verbose_name="Дата окончания")
    img = models.ImageField(upload_to=course_image_upload_to, verbose_name="Обложка курса")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-id']

    def clean(self):
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValidationError({'end_date': 'Дата окончания не может быть раньше даты начала.'})

    def save(self, *args, **kwargs):
        # Process and thumbnail image if new image uploaded
        if self.img and hasattr(self.img, 'file') and not self.img.name.startswith('courses/mpic_'):
            try:
                img_obj = Image.open(self.img)
                if img_obj.format not in ['JPEG', 'JPG']:
                    img_obj = img_obj.convert('RGB')
                
                # Resize with aspect ratio preserved to max 300x300
                img_obj.thumbnail((300, 300), Image.Resampling.LANCZOS)
                
                output = BytesIO()
                img_obj.save(output, format='JPEG', quality=90)
                output.seek(0)
                
                ext = '.jpg'
                random_str = secrets.token_hex(6)
                new_filename = f"mpic_{random_str}{ext}"
                self.img.save(new_filename, ContentFile(output.read()), save=False)
            except Exception:
                pass
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Lesson(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=50, verbose_name="Заголовок урока")
    content = models.TextField(verbose_name="Текстовое содержание")
    video_link = models.CharField(
        max_length=255,
        blank=True,
        default='',
        verbose_name="Видеоссылка SuperTube"
    )
    duration_hours = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)],
        verbose_name="Длительность (часы)"
    )
    order = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ['order', 'id']

    def clean(self):
        if not self.pk:
            count = self.course.lessons.count()
            if count >= 5:
                raise ValidationError('Каждый курс может содержать не более 5 уроков.')

    def delete(self, *args, **kwargs):
        # Check active student enrollments
        active_enrollments = self.course.orders.filter(payment_status__in=['pending', 'success']).exists()
        if active_enrollments:
            raise ValidationError('Удаление уроков невозможно при наличии активных записей студентов на курс.')
        super().delete(*args, **kwargs)

    def __str__(self):
        return f"{self.course.name} - {self.title}"


class Order(models.Model):
    STATUS_PENDING = 'pending'
    STATUS_SUCCESS = 'success'
    STATUS_FAILED = 'failed'

    STATUS_CHOICES = [
        (STATUS_PENDING, 'Ожидает оплаты'),
        (STATUS_SUCCESS, 'Оплачено'),
        (STATUS_FAILED, 'Ошибка оплаты'),
    ]

    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='orders')
    payment_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    certificate_number = models.CharField(max_length=30, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return f"Order #{self.id} - {self.student.email} - {self.course.name} ({self.payment_status})"
