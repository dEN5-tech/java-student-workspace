# -*- coding: utf-8 -*-
"""
Модели данных для платформы онлайн-обучения (Модуль В).
Написано максимально просто, понятно и линейно для студентов.
"""

import os
import secrets
from decimal import Decimal
from io import BytesIO
from PIL import Image

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


# -------------------------------------------------------------
# 1. Менеджер пользователей (создание обычного юзера и админа)
# -------------------------------------------------------------
class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        """Создание стандартного пользователя (студента)"""
        if not email:
            raise ValueError('Email обязателен для регистрации')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """Создание суперпользователя / администратора системы"""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        return self.create_user(email, password, **extra_fields)


# -------------------------------------------------------------
# 2. Модель Пользователя (Администратор и Студенты)
# -------------------------------------------------------------
class User(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True, max_length=255, verbose_name="Email пользователя")
    name = models.CharField(max_length=150, blank=True, default='', verbose_name="Имя пользователя")
    is_active = models.BooleanField(default=True, verbose_name="Активен")
    is_staff = models.BooleanField(default=False, verbose_name="Доступ в админку")
    date_joined = models.DateTimeField(default=timezone.now, verbose_name="Дата регистрации")

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return f"{self.email} ({self.name or 'Без имени'})"


# -------------------------------------------------------------
# 3. Модель Токена авторизации (для REST API)
# -------------------------------------------------------------
class APIToken(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='api_token')
    key = models.CharField(max_length=64, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def generate_token(cls, user):
        """Генерирует случайный токен доступа для пользователя"""
        token_key = secrets.token_hex(24)
        token, _ = cls.objects.update_or_create(user=user, defaults={'key': token_key})
        return token.key

    def __str__(self):
        return f"Токен для {self.user.email}"


# -------------------------------------------------------------
# 4. Функция генерации пути для обложки курса (префикс mpic*)
# -------------------------------------------------------------
def course_image_upload_to(instance, filename):
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ['.jpg', '.jpeg']:
        ext = '.jpg'
    random_str = secrets.token_hex(6)
    return f"courses/mpic_{random_str}{ext}"


# -------------------------------------------------------------
# 5. Модель Курса
# -------------------------------------------------------------
class Course(models.Model):
    name = models.CharField(max_length=30, verbose_name="Название курса (до 30 симв.)")
    description = models.CharField(max_length=100, blank=True, default='', verbose_name="Описание курса (до 100 симв.)")
    hours = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        verbose_name="Продолжительность в часах (1-10)"
    )
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('100.00'))],
        verbose_name="Цена (число от 100.00)"
    )
    start_date = models.DateField(verbose_name="Дата начала")
    end_date = models.DateField(verbose_name="Дата окончания")
    img = models.ImageField(upload_to=course_image_upload_to, verbose_name="Обложка курса (JPG)")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-id']

    def clean(self):
        # Проверка, что дата окончания не раньше даты начала
        if self.start_date and self.end_date and self.start_date > self.end_date:
            raise ValidationError({'end_date': 'Дата окончания не может быть раньше даты начала.'})

    def save(self, *args, **kwargs):
        # Автоматическое сжатие обложки до миниатюры 300x300 с сохранением пропорций
        if self.img and hasattr(self.img, 'file') and not self.img.name.startswith('courses/mpic_'):
            try:
                img_obj = Image.open(self.img)
                if img_obj.format not in ['JPEG', 'JPG']:
                    img_obj = img_obj.convert('RGB')
                
                # Масштабируем до 300x300
                img_obj.thumbnail((300, 300), Image.Resampling.LANCZOS)
                
                output = BytesIO()
                img_obj.save(output, format='JPEG', quality=90)
                output.seek(0)
                
                ext = '.jpg'
                random_str = secrets.token_hex(6)
                new_filename = f"mpic_{random_str}{ext}"
                self.img.save(new_filename, ContentFile(output.read()), save=False)
            except Exception:
                pass
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


# -------------------------------------------------------------
# 6. Модель Урока (до 5 уроков на курс)
# -------------------------------------------------------------
class Lesson(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons', verbose_name="Курс")
    title = models.CharField(max_length=50, verbose_name="Заголовок урока (до 50 симв.)")
    content = models.TextField(verbose_name="Текстовое содержание урока")
    video_link = models.CharField(
        max_length=255,
        blank=True,
        default='',
        verbose_name="Видеоссылка SuperTube"
    )
    duration_hours = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)],
        verbose_name="Длительность урока (1-4 ч)"
    )
    order = models.PositiveIntegerField(default=1, verbose_name="Порядковый номер")

    class Meta:
        ordering = ['order', 'id']

    def clean(self):
        # Проверка лимита: не более 5 уроков на один курс
        if not self.pk:
            count = self.course.lessons.count()
            if count >= 5:
                raise ValidationError('Каждый курс может содержать не более 5 уроков.')

    def delete(self, *args, **kwargs):
        # Защита: нельзя удалять урок, если на курс есть активные записи студентов
        has_students = self.course.orders.filter(payment_status__in=['pending', 'success']).exists()
        if has_students:
            raise ValidationError('Удаление уроков невозможно при наличии активных записей студентов на курс.')
        super().delete(*args, **kwargs)

    def __str__(self):
        return f"{self.course.name} - {self.title}"


# -------------------------------------------------------------
# 7. Модель Заказа / Записи студента на курс
# -------------------------------------------------------------
class Order(models.Model):
    STATUS_PENDING = 'pending'
    STATUS_SUCCESS = 'success'
    STATUS_FAILED = 'failed'

    STATUS_CHOICES = [
        (STATUS_PENDING, 'Ожидает оплаты'),
        (STATUS_SUCCESS, 'Оплачено'),
        (STATUS_FAILED, 'Ошибка оплаты'),
    ]

    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders', verbose_name="Студент")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='orders', verbose_name="Курс")
    payment_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING, verbose_name="Статус оплаты")
    certificate_number = models.CharField(max_length=30, blank=True, null=True, verbose_name="Номер сертификата")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата записи")

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return f"Запись #{self.id}: {self.student.email} на «{self.course.name}» [{self.payment_status}]"
