# ==============================================================================
# Скрипт быстрого запуска Django-сервера на Windows (PowerShell)
# ==============================================================================

# 1. Очистка переменных прокси (защита от ошибок socks5 / UnsupportedProxyProtocol)
Remove-Item Env:\HTTP_PROXY, Env:\HTTPS_PROXY, Env:\ALL_PROXY -ErrorAction SilentlyContinue

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   Запуск Django Backend (Курсы + Кафе) на Windows       " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 2. Проверка и создание виртуального окружения venv при необходимости
if (-not (Test-Path ".\venv")) {
    Write-Host "[1/4] Создание виртуального окружения venv..." -ForegroundColor Yellow
    python -m venv venv
}

# 3. Активация окружения (если существует)
if (Test-Path ".\venv\Scripts\Activate.ps1") {
    Write-Host "[2/4] Активация виртуального окружения venv..." -ForegroundColor Green
    & ".\venv\Scripts\Activate.ps1"
}

# 4. Установка зависимостей
Write-Host "[3/4] Проверка и установка зависимостей из requirements.txt..." -ForegroundColor Yellow
python -m pip install -r requirements.txt --quiet

# 5. Применение миграций базы данных SQLite
Write-Host "[4/4] Применение миграций базы данных..." -ForegroundColor Green
python manage.py migrate --noinput

# 6. Запуск сервера на порту 8080
Write-Host "`nСервер успешно запущен!" -ForegroundColor Green
Write-Host "Админка курсов: http://127.0.0.1:8080/course-admin" -ForegroundColor Cyan
Write-Host "API курсов:     http://127.0.0.1:8080/school-api/" -ForegroundColor Cyan
Write-Host "API кафе:       http://127.0.0.1:8080/api/" -ForegroundColor Cyan
Write-Host "Для остановки нажмите Ctrl + C`n" -ForegroundColor Gray

python manage.py runserver 127.0.0.1:8080
