# Cross-platform MySQL support without requiring C compilers
try:
    import pymysql
    pymysql.install_as_MySQLdb()
except ImportError:
    pass
