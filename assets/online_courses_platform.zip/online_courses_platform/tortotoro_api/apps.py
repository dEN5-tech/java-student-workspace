from django.apps import AppConfig


class TortotoroApiConfig(AppConfig):
    name = 'tortotoro_api'
