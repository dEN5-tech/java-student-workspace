import json
from decimal import Decimal
from django.test import TestCase, Client
from .models import Employee, EmployeeToken, WorkShift, CafeOrder, CafeOrderPosition


class TortotoroApiTestCase(TestCase):
    def setUp(self):
        self.client = Client()

        # Admin
        self.admin = Employee(name='Менеджер', login='admin', role_id=1)
        self.admin.set_password('admin123')
        self.admin.save()
        self.admin_token = EmployeeToken.generate_token(self.admin)

        # Waiter
        self.waiter = Employee(name='Официант', login='waiter', role_id=2)
        self.waiter.set_password('waiter123')
        self.waiter.save()
        self.waiter_token = EmployeeToken.generate_token(self.waiter)

        # Cook
        self.cook = Employee(name='Повар', login='cook', role_id=3)
        self.cook.set_password('cook123')
        self.cook.save()
        self.cook_token = EmployeeToken.generate_token(self.cook)

        # Shift
        self.shift = WorkShift.objects.create(start='09:00', end='21:00', active=True)
        self.shift.employees.add(self.admin, self.waiter, self.cook)

    def test_login_and_cors(self):
        """Проверка авторизации и наличия CORS заголовков"""
        res = self.client.post(
            '/api/login',
            data=json.dumps({"login": "waiter", "password": "waiter123"}),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("token", data["data"])
        self.assertEqual(data["data"]["user"]["role_id"], 2)
        self.assertEqual(res.headers.get("Access-Control-Allow-Origin"), "*")

    def test_admin_shifts_cannot_reopen_closed(self):
        """Проверка правила: закрытую смену нельзя открыть повторно"""
        headers = {'HTTP_AUTHORIZATION': f'Bearer {self.admin_token}'}

        # Close shift
        res_close = self.client.get(f'/api/work-shifts/{self.shift.id}/close', **headers)
        self.assertEqual(res_close.status_code, 200)
        self.assertTrue(res_close.json()["data"]["closed"])

        # Try to reopen -> 422
        res_reopen = self.client.get(f'/api/work-shifts/{self.shift.id}/open', **headers)
        self.assertEqual(res_reopen.status_code, 422)

    def test_waiter_cannot_pay_before_ready(self):
        """Проверка правила: статус Оплачен можно выставить ТОЛЬКО ПОСЛЕ Готов"""
        headers = {'HTTP_AUTHORIZATION': f'Bearer {self.waiter_token}'}

        # Create order -> status 1 (Принят)
        order = CafeOrder.objects.create(shift=self.shift, waiter=self.waiter, status=1)

        # Try to set status 4 (Оплачен) -> forbidden 403
        res = self.client.patch(
            f'/api/orders/{order.id}/status',
            data=json.dumps({"status": 4}),
            content_type='application/json',
            **headers
        )
        self.assertEqual(res.status_code, 403)

        # Cook prepares order -> status 3 (Готов)
        cook_headers = {'HTTP_AUTHORIZATION': f'Bearer {self.cook_token}'}
        self.client.patch(
            f'/api/orders/{order.id}/status',
            data=json.dumps({"status": 3}),
            content_type='application/json',
            **cook_headers
        )

        # Now Waiter can pay -> status 4
        res_pay = self.client.patch(
            f'/api/orders/{order.id}/status',
            data=json.dumps({"status": 4}),
            content_type='application/json',
            **headers
        )
        self.assertEqual(res_pay.status_code, 200)
        self.assertEqual(res_pay.json()["data"]["status"], 4)

    def test_cook_limited_statuses(self):
        """Проверка: повар может менять статус только на 2 (Готовится) и 3 (Готов)"""
        cook_headers = {'HTTP_AUTHORIZATION': f'Bearer {self.cook_token}'}
        order = CafeOrder.objects.create(shift=self.shift, waiter=self.waiter, status=1)

        # Cook tries to set status 4 (Оплачен) -> 403
        res = self.client.patch(
            f'/api/orders/{order.id}/status',
            data=json.dumps({"status": 4}),
            content_type='application/json',
            **cook_headers
        )
        self.assertEqual(res.status_code, 403)

        # Cook sets 2 (Готовится) -> 200
        res2 = self.client.patch(
            f'/api/orders/{order.id}/status',
            data=json.dumps({"status": 2}),
            content_type='application/json',
            **cook_headers
        )
        self.assertEqual(res2.status_code, 200)
