from django.urls import path, re_path
from . import views

urlpatterns = [
    # Auth
    re_path(r'^login/?$', views.api_login, name='tortotoro_login'),
    re_path(r'^logout/?$', views.api_logout, name='tortotoro_logout'),
    re_path(r'^user/?$', views.api_current_user, name='tortotoro_current_user'),

    # Admin: Employees
    re_path(r'^users/?$', views.api_employees, name='tortotoro_employees'),
    re_path(r'^users/(?P<user_id>\d+)/?$', views.api_employees, name='tortotoro_employee_detail'),

    # Admin: Work Shifts
    re_path(r'^work-shifts/?$', views.api_work_shifts, name='tortotoro_shifts'),
    re_path(r'^work-shifts/(?P<shift_id>\d+)/open/?$', views.api_work_shift_open, name='tortotoro_shift_open'),
    re_path(r'^work-shifts/(?P<shift_id>\d+)/close/?$', views.api_work_shift_close, name='tortotoro_shift_close'),
    re_path(r'^work-shifts/(?P<shift_id>\d+)/user/?$', views.api_work_shift_user, name='tortotoro_shift_add_user'),
    re_path(r'^work-shifts/(?P<shift_id>\d+)/user/(?P<user_id>\d+)/?$', views.api_work_shift_user, name='tortotoro_shift_del_user'),

    # Orders (Waiter / Cook / Admin)
    re_path(r'^orders/?$', views.api_orders, name='tortotoro_orders'),
    re_path(r'^orders/(?P<order_id>\d+)/?$', views.api_orders, name='tortotoro_order_detail'),
    re_path(r'^orders/(?P<order_id>\d+)/position/?$', views.api_order_position, name='tortotoro_order_add_pos'),
    re_path(r'^orders/(?P<order_id>\d+)/position/(?P<pos_id>\d+)/?$', views.api_order_position, name='tortotoro_order_del_pos'),
    re_path(r'^orders/(?P<order_id>\d+)/status/?$', views.api_order_status, name='tortotoro_order_status'),
]
