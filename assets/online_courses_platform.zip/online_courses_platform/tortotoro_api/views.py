import json
from decimal import Decimal
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Employee, EmployeeToken, WorkShift, CafeOrder, CafeOrderPosition


def parse_json(request):
    try:
        return json.loads(request.body.decode('utf-8'))
    except Exception:
        return {}


def get_auth_employee(request):
    header = request.headers.get('Authorization', '')
    if not header.startswith('Bearer '):
        return None
    token_key = header.split('Bearer ', 1)[1].strip()
    try:
        token = EmployeeToken.objects.select_related('employee').get(key=token_key)
        if token.employee.status == Employee.STATUS_DISMISSED:
            return None
        return token.employee
    except EmployeeToken.DoesNotExist:
        return None


def error_response(message, status=422, errors=None):
    resp = {"message": message}
    if errors:
        resp["errors"] = errors
    return JsonResponse(resp, status=status)


def unauthorized_response():
    return JsonResponse({"message": "Login failed", "errors": {"auth": ["Unauthorized access"]}}, status=403)


# --- 1. АУТЕНТИФИКАЦИЯ ---

@csrf_exempt
def api_login(request):
    if request.method != 'POST':
        return JsonResponse({"message": "Method not allowed"}, status=405)

    data = parse_json(request)
    login_str = str(data.get('login', '')).strip()
    password_str = str(data.get('password', ''))

    errors = {}
    if not login_str:
        errors['login'] = ['Login is required']
    if not password_str:
        errors['password'] = ['Password is required']

    if errors:
        return error_response('Invalid fields', 422, errors)

    try:
        emp = Employee.objects.get(login=login_str)
        if emp.status == Employee.STATUS_DISMISSED:
            return error_response('Сотрудник уволен', 403, {'login': ['Сотрудник деактивирован']})
        if not emp.check_password(password_str):
            return error_response('Неверный логин или пароль', 422, {'auth': ['Invalid credentials']})
    except Employee.DoesNotExist:
        return error_response('Неверный логин или пароль', 422, {'auth': ['Invalid credentials']})

    token_key = EmployeeToken.generate_token(emp)
    return JsonResponse({
        "data": {
            "token": token_key,
            "user": emp.to_dict()
        }
    }, status=200)


@csrf_exempt
def api_logout(request):
    emp = get_auth_employee(request)
    if emp:
        EmployeeToken.objects.filter(employee=emp).delete()
    return JsonResponse({"data": {"message": "logout"}}, status=200)


def api_current_user(request):
    emp = get_auth_employee(request)
    if not emp:
        return unauthorized_response()
    return JsonResponse({"data": emp.to_dict()}, status=200)


# --- 2. ФУНКЦИИ АДМИНИСТРАТОРА (ROLE 1) ---

@csrf_exempt
def api_employees(request, user_id=None):
    emp = get_auth_employee(request)
    if not emp or emp.role_id != Employee.ROLE_ADMIN:
        return unauthorized_response()

    if request.method == 'GET':
        if user_id:
            try:
                target = Employee.objects.get(id=user_id)
                return JsonResponse({"data": target.to_dict()}, status=200)
            except Employee.DoesNotExist:
                return JsonResponse({"message": "User not found"}, status=404)
        else:
            employees = Employee.objects.all().order_by('-id')
            return JsonResponse({"data": [e.to_dict() for e in employees]}, status=200)

    elif request.method == 'POST':
        # Создание сотрудника
        data = parse_json(request)
        name = str(data.get('name', '')).strip()
        login_str = str(data.get('login', '')).strip()
        password_str = str(data.get('password', ''))
        role_id = data.get('role_id')
        photo_file = str(data.get('photo_file', ''))

        errors = {}
        if not name:
            errors['name'] = ['Name is required']
        if not login_str:
            errors['login'] = ['Login is required']
        elif Employee.objects.filter(login=login_str).exists():
            errors['login'] = ['Login must be unique']
        if not password_str:
            errors['password'] = ['Password is required']
        if role_id not in [1, 2, 3]:
            errors['role_id'] = ['Invalid role_id (1: Admin, 2: Waiter, 3: Cook)']

        if errors:
            return error_response('Invalid fields', 422, errors)

        new_emp = Employee(name=name, login=login_str, role_id=role_id, photo_file=photo_file)
        new_emp.set_password(password_str)
        new_emp.save()
        return JsonResponse({"data": new_emp.to_dict()}, status=201)

    elif request.method == 'DELETE':
        # Увольнение сотрудника (статус = dismissed)
        if not user_id:
            return JsonResponse({"message": "User id required"}, status=400)
        try:
            target = Employee.objects.get(id=user_id)
            target.status = Employee.STATUS_DISMISSED
            target.save()
            EmployeeToken.objects.filter(employee=target).delete()
            return JsonResponse({"data": {"message": f"Сотрудник {target.name} уволен", "status": "dismissed"}}, status=200)
        except Employee.DoesNotExist:
            return JsonResponse({"message": "User not found"}, status=404)


# --- 3. СМЕНЫ (WORK-SHIFTS) ---

@csrf_exempt
def api_work_shifts(request):
    emp = get_auth_employee(request)
    if not emp:
        return unauthorized_response()

    if request.method == 'GET':
        shifts = WorkShift.objects.prefetch_related('employees').order_by('-id')
        return JsonResponse({"data": [s.to_dict() for s in shifts]}, status=200)

    elif request.method == 'POST':
        # Только администратор
        if emp.role_id != Employee.ROLE_ADMIN:
            return unauthorized_response()

        data = parse_json(request)
        start = data.get('start', '')
        end = data.get('end', '')
        if not start or not end:
            return error_response('Invalid fields', 422, {'start': ['Start & end are required']})

        shift = WorkShift.objects.create(start=start, end=end)
        return JsonResponse({"data": shift.to_dict()}, status=201)


@csrf_exempt
def api_work_shift_open(request, shift_id):
    emp = get_auth_employee(request)
    if not emp or emp.role_id != Employee.ROLE_ADMIN:
        return unauthorized_response()

    try:
        shift = WorkShift.objects.get(id=shift_id)
        if shift.closed:
            return error_response('Закрытую смену нельзя открыть повторно', 422)
        shift.active = True
        shift.save()
        return JsonResponse({"data": shift.to_dict()}, status=200)
    except WorkShift.DoesNotExist:
        return JsonResponse({"message": "Shift not found"}, status=404)


@csrf_exempt
def api_work_shift_close(request, shift_id):
    emp = get_auth_employee(request)
    if not emp or emp.role_id != Employee.ROLE_ADMIN:
        return unauthorized_response()

    try:
        shift = WorkShift.objects.get(id=shift_id)
        shift.active = False
        shift.closed = True
        shift.save()
        return JsonResponse({"data": shift.to_dict()}, status=200)
    except WorkShift.DoesNotExist:
        return JsonResponse({"message": "Shift not found"}, status=404)


@csrf_exempt
def api_work_shift_user(request, shift_id, user_id=None):
    emp = get_auth_employee(request)
    if not emp or emp.role_id != Employee.ROLE_ADMIN:
        return unauthorized_response()

    try:
        shift = WorkShift.objects.get(id=shift_id)
    except WorkShift.DoesNotExist:
        return JsonResponse({"message": "Shift not found"}, status=404)

    if request.method == 'POST':
        data = parse_json(request)
        target_uid = data.get('user_id', user_id)
        try:
            target_emp = Employee.objects.get(id=target_uid, status=Employee.STATUS_ACTIVE)
            shift.employees.add(target_emp)
            return JsonResponse({"data": shift.to_dict()}, status=200)
        except Employee.DoesNotExist:
            return error_response('Сотрудник не найден или уволен', 404)

    elif request.method == 'DELETE':
        if not user_id:
            return JsonResponse({"message": "user_id required"}, status=400)
        try:
            target_emp = Employee.objects.get(id=user_id)
            shift.employees.remove(target_emp)
            return JsonResponse({"data": shift.to_dict()}, status=200)
        except Employee.DoesNotExist:
            return error_response('Сотрудник не найден', 404)


# --- 4. ЗАКАЗЫ (ORDERS) ---

@csrf_exempt
def api_orders(request, order_id=None):
    emp = get_auth_employee(request)
    if not emp:
        return unauthorized_response()

    if request.method == 'GET':
        if order_id:
            try:
                order = CafeOrder.objects.get(id=order_id)
                return JsonResponse({"data": order.to_dict()}, status=200)
            except CafeOrder.DoesNotExist:
                return JsonResponse({"message": "Order not found"}, status=404)

        # Список заказов в зависимости от роли
        qs = CafeOrder.objects.select_related('shift', 'waiter').prefetch_related('positions').order_by('-id')

        # Официант видит свои заказы
        if emp.role_id == Employee.ROLE_WAITER:
            qs = qs.filter(waiter=emp)
        # Повар видит принятые/готовящиеся
        elif emp.role_id == Employee.ROLE_COOK:
            qs = qs.filter(status__in=[CafeOrder.STATUS_ACCEPTED, CafeOrder.STATUS_COOKING])

        return JsonResponse({"data": [o.to_dict() for o in qs]}, status=200)

    elif request.method == 'POST':
        # Создание заказа (только Официант)
        if emp.role_id != Employee.ROLE_WAITER and emp.role_id != Employee.ROLE_ADMIN:
            return error_response('Только официант может создавать заказы', 403)

        data = parse_json(request)
        table = data.get('table', 'Столик №1')
        shift_id = data.get('shift_id')

        if shift_id:
            shift = WorkShift.objects.filter(id=shift_id, active=True).first()
        else:
            shift = WorkShift.objects.filter(active=True).first()

        if not shift:
            return error_response('Нет открытой рабочей смены для создания заказа', 422)

        order = CafeOrder.objects.create(
            shift=shift,
            waiter=emp,
            table=table,
            status=CafeOrder.STATUS_ACCEPTED
        )

        # Опционально добавление стартовых позиций
        items = data.get('items', [])
        for item in items:
            CafeOrderPosition.objects.create(
                order=order,
                name=item.get('name', 'Позиция'),
                price=Decimal(str(item.get('price', '100.00'))),
                count=int(item.get('count', 1))
            )

        return JsonResponse({"data": order.to_dict()}, status=201)


@csrf_exempt
def api_order_position(request, order_id, pos_id=None):
    emp = get_auth_employee(request)
    if not emp or (emp.role_id != Employee.ROLE_WAITER and emp.role_id != Employee.ROLE_ADMIN):
        return unauthorized_response()

    try:
        order = CafeOrder.objects.get(id=order_id)
    except CafeOrder.DoesNotExist:
        return JsonResponse({"message": "Order not found"}, status=404)

    if request.method == 'POST':
        data = parse_json(request)
        name = data.get('name', '').strip()
        price = data.get('price', 100)
        count = int(data.get('count', 1))

        if not name:
            return error_response('Name is required', 422)

        pos = CafeOrderPosition.objects.create(
            order=order,
            name=name,
            price=Decimal(str(price)),
            count=count
        )
        return JsonResponse({"data": order.to_dict()}, status=201)

    elif request.method == 'DELETE':
        if not pos_id:
            return JsonResponse({"message": "pos_id required"}, status=400)
        CafeOrderPosition.objects.filter(id=pos_id, order=order).delete()
        return JsonResponse({"data": order.to_dict()}, status=200)


@csrf_exempt
def api_order_status(request, order_id):
    emp = get_auth_employee(request)
    if not emp:
        return unauthorized_response()

    if request.method not in ['PATCH', 'POST']:
        return JsonResponse({"message": "Method not allowed"}, status=405)

    try:
        order = CafeOrder.objects.get(id=order_id)
    except CafeOrder.DoesNotExist:
        return JsonResponse({"message": "Order not found"}, status=404)

    data = parse_json(request)
    new_status = data.get('status')
    try:
        new_status = int(new_status)
    except (ValueError, TypeError):
        return error_response('Invalid status', 422)

    # 1: Принят, 2: Готовится, 3: Готов, 4: Оплачен, 5: Отменен

    # --- ПРАВИЛА ДЛЯ ПОВАРА (ROLE 3) ---
    if emp.role_id == Employee.ROLE_COOK:
        if new_status not in [CafeOrder.STATUS_COOKING, CafeOrder.STATUS_READY]:
            return error_response('Повар может менять статус только на "Готовится" (2) или "Готов" (3)', 403)
        order.status = new_status
        order.save()
        return JsonResponse({"data": order.to_dict()}, status=200)

    # --- ПРАВИЛА ДЛЯ ОФИЦИАНТА (ROLE 2) ---
    elif emp.role_id == Employee.ROLE_WAITER:
        if new_status == CafeOrder.STATUS_PAID: # 4
            # Статус оплачен разрешено выставить ТОЛЬКО ПОСЛЕ статуса ГОТОВ (3)!
            if order.status != CafeOrder.STATUS_READY:
                return error_response(
                    'Статус "Оплачен" можно выставить только после того, как повар приготовит блюда (статус: Готов)',
                    403
                )
            order.status = CafeOrder.STATUS_PAID
            order.save()
            return JsonResponse({"data": order.to_dict()}, status=200)

        elif new_status == CafeOrder.STATUS_CANCELLED: # 5
            order.status = CafeOrder.STATUS_CANCELLED
            order.save()
            return JsonResponse({"data": order.to_dict()}, status=200)

        else:
            return error_response('Официант может менять статус только на "Оплачен" (4) или "Отменен" (5)', 403)

    # --- ДЛЯ АДМИНИСТРАТОРА (ROLE 1) ---
    elif emp.role_id == Employee.ROLE_ADMIN:
        order.status = new_status
        order.save()
        return JsonResponse({"data": order.to_dict()}, status=200)
