import secrets
from decimal import Decimal
from django.db import models
from django.contrib.auth.hashers import make_password, check_password


class Employee(models.Model):
    ROLE_ADMIN = 1
    ROLE_WAITER = 2
    ROLE_COOK = 3

    ROLE_CHOICES = [
        (ROLE_ADMIN, 'Администратор'),
        (ROLE_WAITER, 'Официант'),
        (ROLE_COOK, 'Повар'),
    ]

    STATUS_ACTIVE = 'active'
    STATUS_DISMISSED = 'dismissed'

    STATUS_CHOICES = [
        (STATUS_ACTIVE, 'Активен'),
        (STATUS_DISMISSED, 'Уволен'),
    ]

    name = models.CharField(max_length=150, verbose_name="Имя сотрудника")
    login = models.CharField(max_length=100, unique=True, verbose_name="Логин")
    password = models.CharField(max_length=255, verbose_name="Пароль")
    photo_file = models.CharField(max_length=255, blank=True, default='', verbose_name="Фото сотрудника")
    role_id = models.IntegerField(choices=ROLE_CHOICES, verbose_name="Роль")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE, verbose_name="Статус")
    created_at = models.DateTimeField(auto_now_add=True)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'login': self.login,
            'status': self.status,
            'role_id': self.role_id,
            'role': self.get_role_id_display(),
            'photo_file': self.photo_file,
        }

    def __str__(self):
        return f"{self.name} ({self.login}) - {self.get_role_id_display()} [{self.status}]"


class EmployeeToken(models.Model):
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE, related_name='token')
    key = models.CharField(max_length=64, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def generate_token(cls, employee):
        new_key = secrets.token_hex(24)
        token, _ = cls.objects.update_or_create(employee=employee, defaults={'key': new_key})
        return token.key


class WorkShift(models.Model):
    start = models.CharField(max_length=50, verbose_name="Начало смены")
    end = models.CharField(max_length=50, verbose_name="Конец смены")
    active = models.BooleanField(default=False, verbose_name="Смена открыта")
    closed = models.BooleanField(default=False, verbose_name="Смена закрыта")
    employees = models.ManyToManyField(Employee, related_name='shifts', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def to_dict(self):
        status_str = 'closed' if self.closed else ('open' if self.active else 'created')
        users_list = [emp.to_dict() for emp in self.employees.all()]
        return {
            'id': self.id,
            'start': self.start,
            'end': self.end,
            'active': self.active,
            'closed': self.closed,
            'status': status_str,
            'users': users_list,
            'employees': users_list
        }

    def __str__(self):
        status = "Закрыта" if self.closed else ("Открыта" if self.active else "Создана")
        return f"Смена #{self.id} ({self.start} - {self.end}) [{status}]"


class CafeOrder(models.Model):
    STATUS_ACCEPTED = 1   # Принят
    STATUS_COOKING = 2    # Готовится
    STATUS_READY = 3      # Готов
    STATUS_PAID = 4       # Оплачен
    STATUS_CANCELLED = 5  # Отменен

    STATUS_CHOICES = [
        (STATUS_ACCEPTED, 'Принят'),
        (STATUS_COOKING, 'Готовится'),
        (STATUS_READY, 'Готов'),
        (STATUS_PAID, 'Оплачен'),
        (STATUS_CANCELLED, 'Отменен'),
    ]

    shift = models.ForeignKey(WorkShift, on_delete=models.CASCADE, related_name='orders')
    waiter = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='orders')
    table = models.CharField(max_length=50, default='Столик №1', verbose_name="Столик")
    status = models.IntegerField(choices=STATUS_CHOICES, default=STATUS_ACCEPTED)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_total_price(self):
        return sum(pos.price * pos.count for pos in self.positions.all())

    def to_dict(self):
        return {
            'id': self.id,
            'shift_id': self.shift.id,
            'waiter_id': self.waiter.id,
            'waiter_name': self.waiter.name,
            'table': self.table,
            'status': self.status,
            'status_text': self.get_status_display(),
            'positions': [pos.to_dict() for pos in self.positions.all()],
            'total_price': f"{self.get_total_price():.2f}",
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        }

    def __str__(self):
        return f"Заказ #{self.id} ({self.table}) - {self.get_status_display()}"


class CafeOrderPosition(models.Model):
    order = models.ForeignKey(CafeOrder, on_delete=models.CASCADE, related_name='positions')
    name = models.CharField(max_length=150, verbose_name="Наименование позиции")
    price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('100.00'))
    count = models.PositiveIntegerField(default=1)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'price': f"{self.price:.2f}",
            'count': self.count,
        }

    def __str__(self):
        return f"{self.name} x{self.count} ({self.price} руб)"
