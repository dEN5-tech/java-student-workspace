from decimal import Decimal
from django.core.management.base import BaseCommand
from tortotoro_api.models import Employee, EmployeeToken, WorkShift, CafeOrder, CafeOrderPosition


class Command(BaseCommand):
    help = 'Создание тестовых сотрудников и смены для кафе Tortotoro'

    def handle(self, *args, **options):
        # 1. Admin (role_id = 1)
        admin_emp, _ = Employee.objects.get_or_create(
            login='admin',
            defaults={
                'name': 'Менеджер Кафе',
                'role_id': Employee.ROLE_ADMIN,
                'status': Employee.STATUS_ACTIVE,
            }
        )
        admin_emp.set_password('admin123')
        admin_emp.save()
        EmployeeToken.generate_token(admin_emp)

        # 2. Waiter (role_id = 2)
        waiter_emp, _ = Employee.objects.get_or_create(
            login='waiter1',
            defaults={
                'name': 'Алексей Официант',
                'role_id': Employee.ROLE_WAITER,
                'status': Employee.STATUS_ACTIVE,
            }
        )
        waiter_emp.set_password('waiter123')
        waiter_emp.save()
        EmployeeToken.generate_token(waiter_emp)

        # 3. Cook (role_id = 3)
        cook_emp, _ = Employee.objects.get_or_create(
            login='cook1',
            defaults={
                'name': 'Дмитрий Шеф-Повар',
                'role_id': Employee.ROLE_COOK,
                'status': Employee.STATUS_ACTIVE,
            }
        )
        cook_emp.set_password('cook123')
        cook_emp.save()
        EmployeeToken.generate_token(cook_emp)

        # 4. Open Work Shift
        shift, _ = WorkShift.objects.get_or_create(
            start='2026-09-30 08:00',
            end='2026-09-30 20:00',
            defaults={'active': True, 'closed': False}
        )
        shift.active = True
        shift.employees.add(admin_emp, waiter_emp, cook_emp)
        shift.save()

        # 5. Sample Orders
        order1, _ = CafeOrder.objects.get_or_create(
            shift=shift,
            waiter=waiter_emp,
            table='Столик №1',
            defaults={'status': CafeOrder.STATUS_READY} # Готов
        )
        if not order1.positions.exists():
            CafeOrderPosition.objects.create(order=order1, name='Торт Чизкейк Нью-Йорк', price=Decimal('280.00'), count=1)
            CafeOrderPosition.objects.create(order=order1, name='Капучино Большой', price=Decimal('180.00'), count=2)

        order2, _ = CafeOrder.objects.get_or_create(
            shift=shift,
            waiter=waiter_emp,
            table='Столик №3',
            defaults={'status': CafeOrder.STATUS_ACCEPTED} # Принят
        )
        if not order2.positions.exists():
            CafeOrderPosition.objects.create(order=order2, name='Круассан с миндалем', price=Decimal('160.00'), count=2)
            CafeOrderPosition.objects.create(order=order2, name='Латте Макиато', price=Decimal('210.00'), count=1)

        self.stdout.write(self.style.SUCCESS('Сотрудники и смена кафе Tortotoro успешно созданы!'))
        self.stdout.write(self.style.SUCCESS('  Админ: login=admin, password=admin123 (role_id=1)'))
        self.stdout.write(self.style.SUCCESS('  Официант: login=waiter1, password=waiter123 (role_id=2)'))
        self.stdout.write(self.style.SUCCESS('  Повар: login=cook1, password=cook123 (role_id=3)'))
