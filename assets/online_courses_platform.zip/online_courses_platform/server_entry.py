import os
import sys
from pathlib import Path

# Определяем базовую директорию
if getattr(sys, 'frozen', False):
    app_dir = Path(sys.executable).resolve().parent
    sys.path.insert(0, str(app_dir))
else:
    app_dir = Path(__file__).resolve().parent
    sys.path.insert(0, str(app_dir))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

import django
django.setup()

from django.core.management import call_command
from config.wsgi import application
from waitress import serve

def main():
    print("=" * 60)
    print("  БЭКЕНД КАФЕ «TORTOTORO» (DJANGO REST API)")
    print("=" * 60)
    print("Применение миграций БД (SQLite)...")
    try:
        call_command('migrate', interactive=False)
    except Exception as e:
        print(f"Предупреждение миграции: {e}")

    print("Сервер API успешно запущен!")
    print("Адрес API: http://127.0.0.1:8080/api/")
    print("Для остановки сервера закройте это окно или нажмите Ctrl+C.")
    print("=" * 60)

    serve(application, host='127.0.0.1', port=8080)

if __name__ == '__main__':
    main()
