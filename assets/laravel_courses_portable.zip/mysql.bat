@echo off
setlocal
cd /d "%~dp0"
"%~dp0mysql\bin\mysql.exe" -u root laravel %*
