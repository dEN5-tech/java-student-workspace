<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Сертификат <?php echo e($enrollment->certificate_number); ?></title>
    <style>
        body { font-family: serif; text-align: center; margin: 40px; }
        .box { border: 3px double #000; padding: 30px; max-width: 650px; margin: auto; }
        @media print {
            .no-print { display: none; }
            body { margin: 0; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.print()">Распечатать</button>
    </div>

    <div class="box">
        <h1>СЕРТИФИКАТ</h1>
        <p>Настоящим подтверждается, что</p>
        <h2><?php echo e($enrollment->first_name); ?> <?php echo e($enrollment->last_name); ?></h2>
        <p>успешно освоил(а) программу курса:</p>
        <h3>«<?php echo e($enrollment->course?->title); ?>»</h3>
        <p>Объем: <?php echo e($enrollment->course?->hours); ?> ак. ч.</p>
        <hr>
        <p style="text-align: left;">
            Номер: <strong><?php echo e($enrollment->certificate_number); ?></strong> (<?php echo e($enrollment->isCertificateValid() ? 'Действителен' : 'Недействителен'); ?>)<br>
            Дата: <?php echo e($enrollment->created_at->format('d.m.Y')); ?>

        </p>
    </div>
</body>
</html>
<?php /**PATH C:\laravel-courses-portable\app\resources\views/admin/students/certificate.blade.php ENDPATH**/ ?>