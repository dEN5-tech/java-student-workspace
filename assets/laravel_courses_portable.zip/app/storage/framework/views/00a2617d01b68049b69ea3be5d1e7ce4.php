<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Оплата #<?php echo e($orderId); ?></title>
</head>
<body style="font-family: sans-serif; max-width: 400px; margin: 30px auto;">
    <h2>Оплата заказа #<?php echo e($orderId); ?></h2>
    <?php if($enrollment): ?>
        <p>Курс: <?php echo e($enrollment->course?->title); ?> | <?php echo e($enrollment->course?->price); ?> ₽</p>
    <?php endif; ?>

    <form action="<?php echo e(route('payment.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="order_id" value="<?php echo e($orderId); ?>">
        <p>Номер карты: <input type="text" name="card_number" value="4000 0000 0000 0002" required></p>
        <p>Срок: <input type="text" value="12/28" size="5" required> CVV: <input type="password" value="123" size="3" required></p>
        <button type="submit">Оплатить</button>
    </form>
</body>
</html>
<?php /**PATH /mnt/c/Users/dEN5/laravel-app/resources/views/payment/simulator.blade.php ENDPATH**/ ?>