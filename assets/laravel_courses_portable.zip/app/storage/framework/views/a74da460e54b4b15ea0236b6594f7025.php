<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Админ-панель'); ?></title>
    <style>
        body { font-family: sans-serif; margin: 20px; }
        table, th, td { border: 1px solid #999; border-collapse: collapse; padding: 6px; }
        th { background: #eee; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: block; font-weight: bold; }
        .is-invalid { border: 2px solid red !important; background: #ffe6e6 !important; }
        .error-msg { color: red; font-size: 12px; }
    </style>
</head>
<body>
    <nav>
        <strong>Админка</strong> | 
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('admin.courses.index')); ?>">Курсы</a> | 
            <a href="<?php echo e(route('admin.students.index')); ?>">Студенты</a> | 
            <form action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <button type="submit">Выйти</button>
            </form>
        <?php endif; ?>
    </nav>
    <hr>

    <?php if(session('success')): ?> <div style="color:green; margin-bottom:10px;"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?> <div style="color:red; margin-bottom:10px;"><?php echo e(session('error')); ?></div> <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH /mnt/c/Users/dEN5/laravel-app/resources/views/layouts/admin.blade.php ENDPATH**/ ?>