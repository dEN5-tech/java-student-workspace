<?php $__env->startSection('title', 'Студенты'); ?>

<?php $__env->startSection('content'); ?>
<h2>Студенты и сертификаты</h2>

<form action="<?php echo e(route('admin.students.index')); ?>" method="GET" style="margin-bottom:15px;">
    <label>Курс: </label>
    <select name="course_id" onchange="this.form.submit()">
        <option value="">Все курсы</option>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php echo e(request('course_id') == $c->id ? 'selected' : ''); ?>><?php echo e($c->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Студент</th>
            <th>Email</th>
            <th>Курс</th>
            <th>Статус</th>
            <th>Сертификат</th>
            <th>Печать</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->course?->title ?? '—'); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td><?php echo e($item->certificate_number ?? '—'); ?></td>
                <td>
                    <?php if($item->certificate_number): ?>
                        <a href="<?php echo e(route('admin.students.certificate', $item)); ?>" target="_blank">Печать</a>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7">Студентов нет</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div style="margin-top:15px;"><?php echo e($enrollments->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /mnt/c/Users/dEN5/laravel-app/resources/views/admin/students/index.blade.php ENDPATH**/ ?>