<?php $__env->startSection('title', 'Курсы'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex; justify-content:space-between; align-items:center;">
    <h2>Курсы</h2>
    <a href="<?php echo e(route('admin.courses.create')); ?>">+ Добавить курс</a>
</div>

<table>
    <thead>
        <tr>
            <th>Превью</th>
            <th>Название</th>
            <th>Часы</th>
            <th>Цена</th>
            <th>Даты</th>
            <th>Уроки (до 5)</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($course->cover_thumbnail): ?>
                        <img src="<?php echo e(asset('storage/' . $course->cover_thumbnail)); ?>" width="40" height="40" style="object-fit:cover;">
                    <?php elseif($course->cover): ?>
                        <img src="<?php echo e(asset('storage/' . $course->cover)); ?>" width="40" height="40" style="object-fit:cover;">
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
                <td><strong><?php echo e($course->title); ?></strong></td>
                <td><?php echo e($course->hours); ?> ч.</td>
                <td><?php echo e($course->price); ?> ₽</td>
                <td><?php echo e($course->start_date?->format('d.m.Y')); ?> — <?php echo e($course->end_date?->format('d.m.Y')); ?></td>
                <td>
                    <?php echo e($course->lessons_count); ?> / 5
                    <?php if($course->lessons_count < 5): ?>
                        <a href="<?php echo e(route('admin.lessons.create', $course)); ?>">[+ урок]</a>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.courses.edit', $course)); ?>">Редактировать</a> | 
                    <form action="<?php echo e(route('admin.courses.destroy', $course)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Удалить?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="color:red; background:none; border:none; cursor:pointer;">Удалить</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7">Нет курсов</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div style="margin-top:15px;"><?php echo e($courses->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /mnt/c/Users/dEN5/laravel-app/resources/views/admin/courses/index.blade.php ENDPATH**/ ?>