@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===================================================
echo   Запуск Laravel (через WSL)
echo ===================================================
echo Адрес в браузере: http://localhost:8001
echo Админка: http://localhost:8001/course-admin (admin@edu.com / course2025)
echo.
echo Для остановки нажмите Ctrl + C
echo.
wsl -d Ubuntu-22.04 -- bash -c "sudo service mysql start 2>/dev/null; php artisan serve --host=0.0.0.0 --port=8001"
if %errorlevel% neq 0 (
    wsl -- bash -c "sudo service mysql start 2>/dev/null; php artisan serve --host=0.0.0.0 --port=8001"
)
pause
