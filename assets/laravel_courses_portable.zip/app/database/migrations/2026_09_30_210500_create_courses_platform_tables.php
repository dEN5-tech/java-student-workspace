<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Добавляем роль в таблицу пользователей (если еще нет)
        if (!Schema::hasColumn('users', 'role')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('role')->default('user')->after('password');
            });
        }

        // 2. Таблица курсов
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('title', 30);
            $table->string('description', 100)->nullable();
            $table->unsignedTinyInteger('hours'); // от 1 до 10
            $table->decimal('price', 8, 2); // >= 100
            $table->date('start_date');
            $table->date('end_date');
            $table->string('cover')->nullable();
            $table->string('cover_thumbnail')->nullable();
            $table->timestamps();
        });

        // 3. Таблица уроков
        Schema::create('lessons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained()->cascadeOnDelete();
            $table->string('title', 50);
            $table->text('content');
            $table->string('video_url');
            $table->decimal('duration_hours', 4, 2); // <= 4
            $table->timestamps();
        });

        // 4. Таблица записей студентов и сертификатов
        Schema::create('enrollments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained()->cascadeOnDelete();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email');
            $table->enum('status', ['pending', 'success', 'canceled'])->default('pending');
            $table->string('certificate_number')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('enrollments');
        Schema::dropIfExists('lessons');
        Schema::dropIfExists('courses');
        if (Schema::hasColumn('users', 'role')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('role');
            });
        }
    }
};
