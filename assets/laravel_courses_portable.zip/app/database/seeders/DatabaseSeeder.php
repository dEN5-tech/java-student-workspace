<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\Enrollment;
use App\Models\Lesson;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Учетная запись администратора по регламенту чемпионата
        User::updateOrCreate(
            ['email' => 'admin@edu.com'],
            [
                'name' => 'Администратор платформы',
                'password' => Hash::make('course2025'),
                'role' => 'admin',
            ]
        );

        // 2. Тестовый курс 1
        $course1 = Course::create([
            'title' => 'Основы веб-разработки',
            'description' => 'Изучение HTML, CSS, JavaScript и современных веб-технологий.',
            'hours' => 6,
            'price' => 1990.00,
            'start_date' => now()->addDays(5)->format('Y-m-d'),
            'end_date' => now()->addDays(35)->format('Y-m-d'),
            'cover' => null,
            'cover_thumbnail' => null,
        ]);

        Lesson::create([
            'course_id' => $course1->id,
            'title' => 'Введение в HTML5 и структуру документа',
            'content' => 'Подробный разбор семантической верстки, тегов и атрибутов.',
            'video_url' => 'https://super-tube.cc/video/html5-intro',
            'duration_hours' => 1.5,
        ]);

        Lesson::create([
            'course_id' => $course1->id,
            'title' => 'Современный CSS3 и Flexbox',
            'content' => 'Построение гибких сеток и адаптивных макетов интерфейса.',
            'video_url' => 'https://super-tube.cc/video/css3-flexbox',
            'duration_hours' => 2.0,
        ]);

        Enrollment::create([
            'course_id' => $course1->id,
            'first_name' => 'Алексей',
            'last_name' => 'Смирнов',
            'email' => 'alex@example.com',
            'status' => 'success',
            'certificate_number' => 'CERT-2026-0001', // Заканчивается на 1 -> действительный
        ]);

        Enrollment::create([
            'course_id' => $course1->id,
            'first_name' => 'Екатерина',
            'last_name' => 'Иванова',
            'email' => 'kate@example.com',
            'status' => 'pending',
            'certificate_number' => 'CERT-2026-0002', // Заканчивается на 2 -> недействительный
        ]);

        // 3. Тестовый курс 2
        $course2 = Course::create([
            'title' => 'Разработка REST API на Laravel',
            'description' => 'Архитектура веб-сервисов, роутинг, Eloquent ORM и безопасность.',
            'hours' => 8,
            'price' => 3490.00,
            'start_date' => now()->addDays(10)->format('Y-m-d'),
            'end_date' => now()->addDays(40)->format('Y-m-d'),
            'cover' => null,
            'cover_thumbnail' => null,
        ]);

        Lesson::create([
            'course_id' => $course2->id,
            'title' => 'Введение в контроллеры и миграции',
            'content' => 'Настройка базы данных MySQL и структуры таблиц.',
            'video_url' => 'https://super-tube.cc/video/laravel-basics',
            'duration_hours' => 2.5,
        ]);
    }
}
