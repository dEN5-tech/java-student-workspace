# Онлайн-платформа курсов (Модуль В — Чемпионат «Профессионалы»)
**Фреймворк:** Laravel 12 (PHP 8.2+)  
**СУБД:** MySQL 8.0 (База: `course_platform`)  
**Порт:** `8001` (http://localhost:8001)

---

## 🔑 Учётные данные и быстрый старт
- **Администратор:**
  - URL: `http://localhost:8001/course-admin`
  - Email: `admin@edu.com`
  - Пароль: `course2025`
- **REST API:**
  - Каталог курсов: `GET http://localhost:8001/school-api/courses`
  - Детали курса: `GET http://localhost:8001/school-api/courses/1`
  - Регистрация: `POST http://localhost:8001/school-api/register`
  - Проверка сертификатов:
    - `GET http://localhost:8001/school-api/certificates/CERT-2026-0001` (Действителен, оканчивается на 1)
    - `GET http://localhost:8001/school-api/certificates/CERT-2026-0002` (Недействителен, оканчивается на 2)
- **Симулятор оплаты:**
  - URL: `http://localhost:8001/payment?order_id=1`

---

## 🚀 Запуск на компьютере с WSL (Ubuntu):
1. Убедитесь, что служба MySQL запущена:
   ```bash
   sudo service mysql start
   ```
2. Импортируйте базу данных (если запускаете с нуля):
   ```bash
   mysql -u root -proot -e "CREATE DATABASE IF NOT EXISTS course_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   mysql -u root -proot course_platform < database/dump.sql
   ```
3. Запустите сервер (через готовый файл `run_wsl.bat` на Windows или в терминале WSL):
   ```bash
   php artisan serve --host=0.0.0.0 --port=8001
   ```

---

## 📦 Быстрый запуск на стандартном Windows (OpenServer / XAMPP / Native PHP & MySQL):
1. Создайте БД `course_platform` в MySQL / phpMyAdmin.
2. Импортируйте `database/dump.sql`.
3. Укажите параметры подключения в файле `.env` (`DB_HOST`, `DB_PORT`, `DB_USERNAME`, `DB_PASSWORD`).
4. Выполните:
   ```cmd
   php artisan serve --port=8001
   ```

---

## 🛠 Выполненные требования регламента:
1. **Управление курсами:**
   - Добавление, редактирование, удаление, просмотр списка с поиском и пагинацией.
   - Автоматическая генерация уменьшенных миниатюр превью `mpic*` (не более 300x300 px) через GD.
2. **Управление уроками:**
   - Ограничение: максимум 5 уроков на курс.
   - Валидация ссылки видео: строго хостинг `SuperTube`.
   - Защита целостности: запрет удаления урока, если на курс уже записаны активные студенты.
3. **Студенты и сертификаты:**
   - Список студентов с фильтрацией по курсам.
   - Страница предпросмотра сертификата с кнопкой «Распечатать» (`window.print()`).
4. **Валидация:**
   - Все поля подсвечиваются красной рамкой (`.is-invalid`) и текстом ошибки при некорректном вводе.
5. **REST API:**
   - `/school-api/courses` — список курсов.
   - `/school-api/courses/{id}` — данные курса и уроков.
   - `/school-api/register` — запись студента на курс.
   - `/school-api/certificates/{number}` — валидация сертификата (правило: оканчивается на 1 — валиден, на 2 — недействителен).
