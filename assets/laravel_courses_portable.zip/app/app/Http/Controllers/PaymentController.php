<?php

namespace App\Http\Controllers;

use App\Models\Enrollment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function show(Request $request)
    {
        $orderId = $request->query('order_id', 1);
        $enrollment = Enrollment::with('course')->find($orderId);

        return view('payment.simulator', [
            'orderId' => $orderId,
            'enrollment' => $enrollment,
        ]);
    }

    public function process(Request $request)
    {
        $orderId = $request->input('order_id');
        $cardNumber = preg_replace('/\s+/', '', $request->input('card_number', ''));

        $enrollment = Enrollment::find($orderId);

        // Симуляция: если номер карты заканчивается на четную цифру - успех, нечетная - ошибка
        $lastDigit = (int)substr($cardNumber, -1);
        $isSuccess = ($lastDigit % 2 === 0);

        if ($enrollment) {
            $enrollment->status = $isSuccess ? 'success' : 'canceled';
            if ($isSuccess && empty($enrollment->certificate_number)) {
                $enrollment->certificate_number = 'CERT-' . date('Y') . '-' . sprintf('%04d', rand(100, 999)) . '1';
            }
            $enrollment->save();
        }

        return view('payment.result', [
            'isSuccess' => $isSuccess,
            'enrollment' => $enrollment,
            'orderId' => $orderId,
        ]);
    }
}
