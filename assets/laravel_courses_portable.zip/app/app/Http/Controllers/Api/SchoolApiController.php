<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Enrollment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SchoolApiController extends Controller
{
    public function getCourses(): JsonResponse
    {
        $courses = Course::latest()->get()->map(function ($c) {
            return [
                'id' => $c->id,
                'title' => $c->title,
                'description' => $c->description,
                'hours' => $c->hours,
                'price' => (float)$c->price,
                'start_date' => $c->start_date?->format('d-m-Y'),
                'end_date' => $c->end_date?->format('d-m-Y'),
                'cover_url' => $c->cover ? asset('storage/' . $c->cover) : null,
                'thumbnail_url' => $c->cover_thumbnail ? asset('storage/' . $c->cover_thumbnail) : null,
                'lessons_count' => $c->lessons()->count(),
            ];
        });

        return response()->json(['status' => 'success', 'data' => $courses]);
    }

    public function getCourseDetail($id): JsonResponse
    {
        $course = Course::with('lessons')->find($id);
        if (!$course) {
            return response()->json(['status' => 'error', 'message' => 'Курс не найден'], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => [
                'id' => $course->id,
                'title' => $course->title,
                'description' => $course->description,
                'hours' => $course->hours,
                'price' => (float)$course->price,
                'start_date' => $course->start_date?->format('d-m-Y'),
                'end_date' => $course->end_date?->format('d-m-Y'),
                'cover_url' => $course->cover ? asset('storage/' . $course->cover) : null,
                'thumbnail_url' => $course->cover_thumbnail ? asset('storage/' . $course->cover_thumbnail) : null,
                'lessons' => $course->lessons->map(fn($l) => [
                    'id' => $l->id,
                    'title' => $l->title,
                    'content' => $l->content,
                    'video_url' => $l->video_url,
                    'duration_hours' => (float)$l->duration_hours,
                ]),
            ],
        ]);
    }

    public function register(Request $request): JsonResponse
    {
        $data = $request->validate([
            'course_id' => 'required|exists:courses,id',
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'email' => 'required|email|max:150',
        ]);

        $enrollment = Enrollment::create(array_merge($data, [
            'status' => 'pending',
            'certificate_number' => null,
        ]));

        return response()->json([
            'status' => 'success',
            'message' => 'Заявка создана',
            'data' => [
                'order_id' => $enrollment->id,
                'payment_url' => url('/payment?order_id=' . $enrollment->id),
            ],
        ], 201);
    }

    public function checkCertificate($number): JsonResponse
    {
        $isValid = str_ends_with(trim($number), '1');
        $enrollment = Enrollment::where('certificate_number', $number)->first();

        return response()->json([
            'status' => 'success',
            'certificate_number' => $number,
            'is_valid' => $isValid,
            'message' => $isValid ? 'Сертификат действителен' : 'Сертификат недействителен',
            'data' => $enrollment,
        ]);
    }
}
