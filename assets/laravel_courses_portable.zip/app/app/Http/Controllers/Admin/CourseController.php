<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;

/**
 * Контроллер управления курсами (CRUD + пагинация по 5 + обложки mpic*).
 * Написано просто и понятно для студентов.
 */
class CourseController extends Controller
{
    /**
     * 1. Список курсов с обязательной пагинацией по 5 курсов на страницу
     */
    public function index()
    {
        $courses = Course::withCount('lessons')->latest()->paginate(5);
        return view('admin.courses.index', compact('courses'));
    }

    /**
     * 2. Форма создания нового курса
     */
    public function create()
    {
        return view('admin.courses.form', ['course' => new Course()]);
    }

    /**
     * 3. Сохранение нового курса с валидацией и созданием миниатюры 300x300 mpic*
     */
    public function store(Request $request)
    {
        $data = $this->validateCourse($request, true);

        // Обработка загружаемого файла обложки (JPG, макс 2000 Кб)
        if ($request->hasFile('cover')) {
            $data['cover'] = $request->file('cover')->store('courses', 'public');
            $data['cover_thumbnail'] = $this->makeThumbnail($request->file('cover'));
        }

        Course::create($data);
        return redirect()->route('admin.courses.index')->with('success', 'Курс успешно создан!');
    }

    /**
     * 4. Форма редактирования курса
     */
    public function edit(Course $course)
    {
        return view('admin.courses.form', compact('course'));
    }

    /**
     * 5. Обновление существующего курса
     */
    public function update(Request $request, Course $course)
    {
        $data = $this->validateCourse($request, false);

        if ($request->hasFile('cover')) {
            $data['cover'] = $request->file('cover')->store('courses', 'public');
            $data['cover_thumbnail'] = $this->makeThumbnail($request->file('cover'));
        }

        $course->update($data);
        return redirect()->route('admin.courses.index')->with('success', 'Курс успешно обновлен!');
    }

    /**
     * 6. Удаление курса
     */
    public function destroy(Course $course)
    {
        $course->delete();
        return redirect()->route('admin.courses.index')->with('success', 'Курс успешно удален.');
    }

    /**
     * Валидация полей курса по регламенту конкурса
     */
    private function validateCourse(Request $request, bool $isCreate = true): array
    {
        $coverRule = $isCreate ? 'required|image|mimes:jpg,jpeg|max:2048' : 'nullable|image|mimes:jpg,jpeg|max:2048';

        return $request->validate([
            'title' => 'required|string|max:30',
            'description' => 'nullable|string|max:100',
            'hours' => 'required|integer|min:1|max:10',
            'price' => 'required|numeric|min:100',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'cover' => $coverRule,
        ], [
            'title.required' => 'Название курса обязательно.',
            'title.max' => 'Название курса не должно превышать 30 символов.',
            'description.max' => 'Описание курса не должно превышать 100 символов.',
            'hours.required' => 'Укажите продолжительность в часах.',
            'hours.max' => 'Продолжительность должна быть не более 10 часов.',
            'price.required' => 'Укажите стоимость курса.',
            'price.min' => 'Цена курса должна быть не менее 100 рублей.',
            'start_date.required' => 'Дата начала обязательна.',
            'end_date.required' => 'Дата окончания обязательна.',
            'end_date.after_or_equal' => 'Дата окончания не может быть раньше даты начала.',
            'cover.required' => 'Обложка курса обязательна при создании.',
            'cover.image' => 'Файл должен быть изображением формата JPG (JPEG).',
            'cover.mimes' => 'Разрешены только изображения формата JPG или JPEG.',
            'cover.max' => 'Размер файла изображения не должен превышать 2000 Кб.',
        ]);
    }

    /**
     * Создание миниатюры 300x300 px с префиксом mpic*
     */
    private function makeThumbnail($file): string
    {
        $src = @imagecreatefromjpeg($file->getRealPath());
        if (!$src) {
            return $file->store('courses', 'public');
        }

        $w = imagesx($src);
        $h = imagesy($src);
        $max = 300;

        $scale = min($max / $w, $max / $h, 1.0);
        $nw = (int)($w * $scale);
        $nh = (int)($h * $scale);

        $dst = imagecreatetruecolor($nw, $nh);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);

        $filename = 'mpic_' . uniqid() . '.jpg';
        $path = storage_path('app/public/courses/' . $filename);
        
        if (!file_exists(dirname($path))) {
            mkdir(dirname($path), 0755, true);
        }
        imagejpeg($dst, $path, 90);
        imagedestroy($src);
        imagedestroy($dst);

        return 'courses/' . $filename;
    }
}
