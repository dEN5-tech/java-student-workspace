<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use Illuminate\Http\Request;

/**
 * Контроллер управления уроками курса (максимум 5 уроков + защита от удаления).
 * Написано просто и понятно для студентов.
 */
class LessonController extends Controller
{
    /**
     * Форма создания урока
     */
    public function create(Course $course)
    {
        // Проверка лимита: не более 5 уроков на курс
        if ($course->lessons()->count() >= 5) {
            return back()->with('error', 'В курсе не может быть более 5 уроков.');
        }
        return view('admin.lessons.form', [
            'course' => $course,
            'lesson' => new Lesson(['course_id' => $course->id]),
        ]);
    }

    /**
     * Сохранение нового урока
     */
    public function store(Request $request, Course $course)
    {
        if ($course->lessons()->count() >= 5) {
            return redirect()->route('admin.courses.edit', $course)->with('error', 'Лимит 5 уроков исчерпан.');
        }

        $data = $this->validateLesson($request);
        $course->lessons()->create($data);

        return redirect()->route('admin.courses.edit', $course)->with('success', 'Урок успешно добавлен!');
    }

    /**
     * Форма редактирования урока
     */
    public function edit(Course $course, Lesson $lesson)
    {
        return view('admin.lessons.form', compact('course', 'lesson'));
    }

    /**
     * Обновление урока
     */
    public function update(Request $request, Course $course, Lesson $lesson)
    {
        $data = $this->validateLesson($request);
        $lesson->update($data);

        return redirect()->route('admin.courses.edit', $course)->with('success', 'Урок успешно сохранен!');
    }

    /**
     * Удаление урока с бизнес-защитой
     */
    public function destroy(Course $course, Lesson $lesson)
    {
        // Бизнес-правило защиты:
        // Удаление уроков возможно ТОЛЬКО при отсутствии активных записей студентов на данный курс
        $hasStudents = $course->enrollments()->whereIn('status', ['pending', 'success'])->exists();
        if ($hasStudents) {
            return back()->with('error', 'Удаление уроков невозможно при наличии активных записей студентов на курс.');
        }

        $lesson->delete();
        return back()->with('success', 'Урок успешно удален.');
    }

    /**
     * Валидация полей урока
     */
    private function validateLesson(Request $request): array
    {
        return $request->validate([
            'title' => 'required|string|max:50',
            'content' => 'required|string',
            'video_url' => [
                'nullable',
                'url',
                function ($attribute, $value, $fail) {
                    if ($value && !str_starts_with($value, 'https://super-tube.cc/video/')) {
                        $fail('Ссылка должна начинаться с https://super-tube.cc/video/');
                    }
                }
            ],
            'duration_hours' => 'required|numeric|min:0.1|max:4.0',
        ], [
            'title.required' => 'Заголовок урока обязателен.',
            'title.max' => 'Заголовок урока не должен превышать 50 символов.',
            'content.required' => 'Текстовое содержание урока обязательно.',
            'duration_hours.required' => 'Укажите длительность урока.',
            'duration_hours.max' => 'Длительность урока не может превышать 4 часов.',
        ]);
    }
}
