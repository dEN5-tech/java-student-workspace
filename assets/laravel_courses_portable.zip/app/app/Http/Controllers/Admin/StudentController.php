<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Enrollment;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Контроллер для просмотра списка студентов и печати сертификатов.
 * Написано просто и понятно для студентов.
 */
class StudentController extends Controller
{
    /**
     * Список студентов с серверной фильтрацией по курсу
     */
    public function index(Request $request)
    {
        // 1. Получаем список всех курсов для выпадающего меню фильтрации
        $courses = Course::orderBy('title')->get();

        // 2. Базовый запрос на получение всех записей студентов
        $query = Enrollment::with('course')->latest();

        // 3. Если выбран фильтр по курсу, фильтруем записи
        if ($request->filled('course_id')) {
            $query->where('course_id', $request->input('course_id'));
        }

        // 4. Пагинация по 10 записей на страницу
        $enrollments = $query->paginate(10)->withQueryString();

        return view('admin.students.index', compact('enrollments', 'courses'));
    }

    /**
     * Печать фирменного сертификата об окончании курса
     */
    public function certificate(Enrollment $enrollment)
    {
        // Если номер сертификата еще не сформирован, генерируем по правилам конкурса (12 символов, оканчивается на 1)
        if (empty($enrollment->certificate_number)) {
            // 6 символов сервиса
            $prefix = strtoupper(Str::random(6));
            // 5 случайных цифр + цифра '1' (действительный сертификат)
            $digits = str_pad((string)rand(10000, 99999), 5, '0', STR_PAD_LEFT) . '1';
            
            $enrollment->certificate_number = $prefix . $digits;
            $enrollment->save();
        }

        return view('admin.students.certificate', compact('enrollment'));
    }
}
