<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Enrollment extends Model
{
    use HasFactory;

    protected $fillable = [
        'course_id',
        'first_name',
        'last_name',
        'email',
        'status',
        'certificate_number',
    ];

    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    public function isCertificateValid(): bool
    {
        if (!$this->certificate_number) {
            return false;
        }
        $lastChar = substr($this->certificate_number, -1);
        return $lastChar === '1';
    }
}
