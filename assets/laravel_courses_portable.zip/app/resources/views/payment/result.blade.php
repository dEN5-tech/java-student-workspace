<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Результат оплаты</title>
</head>
<body style="font-family: sans-serif; text-align: center; margin-top: 50px;">
    @if($isSuccess)
        <h2 style="color: green;">Оплата успешна!</h2>
        <p>Заказ #{{ $orderId }} оплачен.</p>
        @if($enrollment && $enrollment->certificate_number)
            <p>Сертификат: {{ $enrollment->certificate_number }}</p>
        @endif
    @else
        <h2 style="color: red;">Оплата не прошла</h2>
        <p><a href="{{ route('payment.show', ['order_id' => $orderId]) }}">Повторить</a></p>
    @endif
    <p><a href="{{ route('admin.courses.index') }}">В админку</a></p>
</body>
</html>
