<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Оплата #{{ $orderId }}</title>
</head>
<body style="font-family: sans-serif; max-width: 400px; margin: 30px auto;">
    <h2>Оплата заказа #{{ $orderId }}</h2>
    @if($enrollment)
        <p>Курс: {{ $enrollment->course?->title }} | {{ $enrollment->course?->price }} ₽</p>
    @endif

    <form action="{{ route('payment.process') }}" method="POST">
        @csrf
        <input type="hidden" name="order_id" value="{{ $orderId }}">
        <p>Номер карты: <input type="text" name="card_number" value="4000 0000 0000 0002" required></p>
        <p>Срок: <input type="text" value="12/28" size="5" required> CVV: <input type="password" value="123" size="3" required></p>
        <button type="submit">Оплатить</button>
    </form>
</body>
</html>
