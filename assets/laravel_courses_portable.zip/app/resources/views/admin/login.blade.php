@extends('layouts.admin')

@section('title', 'Вход')

@section('content')
<h2>Вход в систему</h2>
<form action="{{ route('admin.login.submit') }}" method="POST" novalidate style="max-width: 320px;">
    @csrf
    <div class="form-group">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" class="@error('email') is-invalid @enderror" value="{{ old('email', 'admin@edu.com') }}" style="width: 100%;">
        @error('email') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label for="password">Пароль</label>
        <input type="password" id="password" name="password" class="@error('password') is-invalid @enderror" value="course2025" style="width: 100%;">
        @error('password') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <button type="submit">Войти</button>
</form>
@endsection
