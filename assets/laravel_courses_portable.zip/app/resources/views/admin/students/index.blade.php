@extends('layouts.admin')

@section('title', 'Студенты')

@section('content')
<h2>Студенты и сертификаты</h2>

<form action="{{ route('admin.students.index') }}" method="GET" style="margin-bottom:15px;">
    <label>Курс: </label>
    <select name="course_id" onchange="this.form.submit()">
        <option value="">Все курсы</option>
        @foreach($courses as $c)
            <option value="{{ $c->id }}" {{ request('course_id') == $c->id ? 'selected' : '' }}>{{ $c->title }}</option>
        @endforeach
    </select>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Студент</th>
            <th>Email</th>
            <th>Курс</th>
            <th>Статус</th>
            <th>Сертификат</th>
            <th>Печать</th>
        </tr>
    </thead>
    <tbody>
        @forelse($enrollments as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->first_name }} {{ $item->last_name }}</td>
                <td>{{ $item->email }}</td>
                <td>{{ $item->course?->title ?? '—' }}</td>
                <td>{{ $item->status }}</td>
                <td>{{ $item->certificate_number ?? '—' }}</td>
                <td>
                    @if($item->certificate_number)
                        <a href="{{ route('admin.students.certificate', $item) }}" target="_blank">Печать</a>
                    @else
                        —
                    @endif
                </td>
            </tr>
        @empty
            <tr><td colspan="7">Студентов нет</td></tr>
        @endforelse
    </tbody>
</table>

<div style="margin-top:15px;">{{ $enrollments->links() }}</div>
@endsection
