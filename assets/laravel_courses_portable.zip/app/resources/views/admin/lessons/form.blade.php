@extends('layouts.admin')

@section('title', $lesson->exists ? 'Редактировать урок' : 'Добавить урок')

@section('content')
<h2>{{ $lesson->exists ? 'Редактирование урока' : 'Новый урок' }}</h2>
<p>Курс: <strong>{{ $course->title }}</strong></p>
<a href="{{ route('admin.courses.edit', $course) }}">‹ Назад</a>
<br><br>

<form action="{{ $lesson->exists ? route('admin.lessons.update', [$course, $lesson]) : route('admin.lessons.store', $course) }}" method="POST" novalidate style="max-width:500px;">
    @csrf
    @if($lesson->exists) @method('PUT') @endif

    <div class="form-group">
        <label>Название урока (до 50 симв.) *</label>
        <input type="text" name="title" maxlength="50" class="@error('title') is-invalid @enderror" value="{{ old('title', $lesson->title) }}" style="width:100%;">
        @error('title') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Текст урока *</label>
        <textarea name="content" rows="4" class="@error('content') is-invalid @enderror" style="width:100%;">{{ old('content', $lesson->content) }}</textarea>
        @error('content') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Ссылка на видео (SuperTube) *</label>
        <input type="url" name="video_url" class="@error('video_url') is-invalid @enderror" value="{{ old('video_url', $lesson->video_url ?? 'https://super-tube.cc/video/') }}" style="width:100%;">
        @error('video_url') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Длительность (макс 4.0 ч.) *</label>
        <input type="number" step="0.1" min="0.1" max="4.0" name="duration_hours" class="@error('duration_hours') is-invalid @enderror" value="{{ old('duration_hours', $lesson->duration_hours ?? 1.0) }}">
        @error('duration_hours') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <button type="submit">Сохранить</button>
</form>
@endsection
