@extends('layouts.admin')

@section('title', 'Курсы')

@section('content')
<div style="display:flex; justify-content:space-between; align-items:center;">
    <h2>Курсы</h2>
    <a href="{{ route('admin.courses.create') }}">+ Добавить курс</a>
</div>

<table>
    <thead>
        <tr>
            <th>Превью</th>
            <th>Название</th>
            <th>Часы</th>
            <th>Цена</th>
            <th>Даты</th>
            <th>Уроки (до 5)</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        @forelse($courses as $course)
            <tr>
                <td>
                    @if($course->cover_thumbnail)
                        <img src="{{ asset('storage/' . $course->cover_thumbnail) }}" width="40" height="40" style="object-fit:cover;">
                    @elseif($course->cover)
                        <img src="{{ asset('storage/' . $course->cover) }}" width="40" height="40" style="object-fit:cover;">
                    @else
                        —
                    @endif
                </td>
                <td><strong>{{ $course->title }}</strong></td>
                <td>{{ $course->hours }} ч.</td>
                <td>{{ $course->price }} ₽</td>
                <td>{{ $course->start_date?->format('d.m.Y') }} — {{ $course->end_date?->format('d.m.Y') }}</td>
                <td>
                    {{ $course->lessons_count }} / 5
                    @if($course->lessons_count < 5)
                        <a href="{{ route('admin.lessons.create', $course) }}">[+ урок]</a>
                    @endif
                </td>
                <td>
                    <a href="{{ route('admin.courses.edit', $course) }}">Редактировать</a> | 
                    <form action="{{ route('admin.courses.destroy', $course) }}" method="POST" style="display:inline;" onsubmit="return confirm('Удалить?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" style="color:red; background:none; border:none; cursor:pointer;">Удалить</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="7">Нет курсов</td></tr>
        @endforelse
    </tbody>
</table>

<div style="margin-top:15px;">{{ $courses->links() }}</div>
@endsection
