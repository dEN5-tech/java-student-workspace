@extends('layouts.admin')

@section('title', $course->exists ? 'Редактировать курс' : 'Создать курс')

@section('content')
<h2>{{ $course->exists ? 'Редактирование курса' : 'Новый курс' }}</h2>
<a href="{{ route('admin.courses.index') }}">‹ Назад</a>
<br><br>

<form action="{{ $course->exists ? route('admin.courses.update', $course) : route('admin.courses.store') }}" method="POST" enctype="multipart/form-data" novalidate style="max-width:500px;">
    @csrf
    @if($course->exists) @method('PUT') @endif

    <div class="form-group">
        <label>Название (до 30 симв.) *</label>
        <input type="text" name="title" maxlength="30" class="@error('title') is-invalid @enderror" value="{{ old('title', $course->title) }}" style="width:100%;">
        @error('title') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Описание (до 100 симв.)</label>
        <textarea name="description" maxlength="100" class="@error('description') is-invalid @enderror" style="width:100%;">{{ old('description', $course->description) }}</textarea>
        @error('description') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Часы (1-10) *</label>
        <input type="number" name="hours" min="1" max="10" class="@error('hours') is-invalid @enderror" value="{{ old('hours', $course->hours) }}">
        @error('hours') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Цена (мин. 100 руб.) *</label>
        <input type="number" step="0.01" name="price" min="100" class="@error('price') is-invalid @enderror" value="{{ old('price', $course->price) }}">
        @error('price') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Дата начала *</label>
        <input type="date" name="start_date" class="@error('start_date') is-invalid @enderror" value="{{ old('start_date', $course->start_date?->format('Y-m-d')) }}">
        @error('start_date') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Дата окончания *</label>
        <input type="date" name="end_date" class="@error('end_date') is-invalid @enderror" value="{{ old('end_date', $course->end_date?->format('Y-m-d')) }}">
        @error('end_date') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label>Обложка (JPG/JPEG)</label>
        <input type="file" name="cover" accept=".jpg,.jpeg" class="@error('cover') is-invalid @enderror">
        @error('cover') <div class="error-msg">{{ $message }}</div> @enderror
    </div>

    <button type="submit">Сохранить</button>
</form>

@if($course->exists)
    <hr>
    <h3>Уроки ({{ $course->lessons->count() }} из 5)</h3>
    @if($course->lessons->count() < 5)
        <a href="{{ route('admin.lessons.create', $course) }}">+ Добавить урок</a>
    @endif
    <table>
        <thead>
            <tr><th>Название</th><th>Часы</th><th>Действия</th></tr>
        </thead>
        <tbody>
            @forelse($course->lessons as $lesson)
                <tr>
                    <td>{{ $lesson->title }}</td>
                    <td>{{ $lesson->duration_hours }} ч.</td>
                    <td>
                        <a href="{{ route('admin.lessons.edit', [$course, $lesson]) }}">Изменить</a> | 
                        <form action="{{ route('admin.lessons.destroy', [$course, $lesson]) }}" method="POST" style="display:inline;" onsubmit="return confirm('Удалить?');">
                            @csrf @method('DELETE')
                            <button type="submit" style="color:red; background:none; border:none; cursor:pointer;">Удалить</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="3">Уроков нет</td></tr>
            @endforelse
        </tbody>
    </table>
@endif
@endsection
