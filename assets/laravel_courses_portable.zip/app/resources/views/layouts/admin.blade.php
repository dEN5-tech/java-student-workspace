<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Админ-панель')</title>
    <style>
        body { font-family: sans-serif; margin: 20px; }
        table, th, td { border: 1px solid #999; border-collapse: collapse; padding: 6px; }
        th { background: #eee; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: block; font-weight: bold; }
        .is-invalid { border: 2px solid red !important; background: #ffe6e6 !important; }
        .error-msg { color: red; font-size: 12px; }
    </style>
</head>
<body>
    <nav>
        <strong>Админка</strong> | 
        @auth
            <a href="{{ route('admin.courses.index') }}">Курсы</a> | 
            <a href="{{ route('admin.students.index') }}">Студенты</a> | 
            <form action="{{ route('admin.logout') }}" method="POST" style="display:inline;">
                @csrf
                <button type="submit">Выйти</button>
            </form>
        @endauth
    </nav>
    <hr>

    @if(session('success')) <div style="color:green; margin-bottom:10px;">{{ session('success') }}</div> @endif
    @if(session('error')) <div style="color:red; margin-bottom:10px;">{{ session('error') }}</div> @endif

    @yield('content')
</body>
</html>
