@echo off
cd /d "%~dp0"
wsl -- php artisan %*
