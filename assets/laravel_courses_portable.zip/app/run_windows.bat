@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===================================================
echo   Запуск Laravel (локальный PHP на Windows)
echo ===================================================
echo Адрес в браузере: http://localhost:8001
echo Админка: http://localhost:8001/course-admin (admin@edu.com / course2025)
echo.
echo Для остановки нажмите Ctrl + C
echo.
php artisan serve --port=8001
pause
