<?php

use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\CourseController as AdminCourseController;
use App\Http\Controllers\Admin\LessonController as AdminLessonController;
use App\Http\Controllers\Admin\StudentController as AdminStudentController;
use App\Http\Controllers\Api\SchoolApiController;
use App\Http\Controllers\PaymentController;
use Illuminate\Support\Facades\Route;

// Главная страница перенаправляет в админку курсов
Route::get('/', function () {
    return redirect('/course-admin');
});

// ==================== АДМИН-ПАНЕЛЬ КУРСОВ (/course-admin) ====================
Route::prefix('course-admin')->group(function () {
    // Авторизация администратора
    Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');

    // Защищенные разделы админки
    Route::middleware('auth')->group(function () {
        Route::get('/', function () {
            return redirect()->route('admin.courses.index');
        });

        // Управление курсами
        Route::resource('courses', AdminCourseController::class, [
            'as' => 'admin',
        ]);

        // Управление уроками курса
        Route::prefix('courses/{course}')->group(function () {
            Route::get('/lessons/create', [AdminLessonController::class, 'create'])->name('admin.lessons.create');
            Route::post('/lessons', [AdminLessonController::class, 'store'])->name('admin.lessons.store');
            Route::get('/lessons/{lesson}/edit', [AdminLessonController::class, 'edit'])->name('admin.lessons.edit');
            Route::put('/lessons/{lesson}', [AdminLessonController::class, 'update'])->name('admin.lessons.update');
            Route::delete('/lessons/{lesson}', [AdminLessonController::class, 'destroy'])->name('admin.lessons.destroy');
        });

        // Студенты и сертификаты
        Route::get('/students', [AdminStudentController::class, 'index'])->name('admin.students.index');
        Route::get('/students/{enrollment}/certificate', [AdminStudentController::class, 'certificate'])->name('admin.students.certificate');
    });
});

// ==================== REST API КУРСОВ (/school-api) ====================
Route::prefix('school-api')->group(function () {
    Route::get('/courses', [SchoolApiController::class, 'getCourses']);
    Route::get('/courses/{id}', [SchoolApiController::class, 'getCourseDetail']);
    Route::post('/register', [SchoolApiController::class, 'register']);
    Route::get('/certificates/{number}', [SchoolApiController::class, 'checkCertificate']);
});

// ==================== СИМУЛЯТОР ПЛАТЕЖНОГО ШЛЮЗА ====================
Route::get('/payment', [PaymentController::class, 'show'])->name('payment.show');
Route::post('/payment/process', [PaymentController::class, 'process'])->name('payment.process');
