<?php

use App\Http\Controllers\Api\SchoolApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Дублирующие маршруты под префиксом /api/
Route::get('/courses', [SchoolApiController::class, 'getCourses']);
Route::get('/courses/{id}', [SchoolApiController::class, 'getCourseDetail']);
Route::post('/register', [SchoolApiController::class, 'register']);
Route::get('/certificates/{number}', [SchoolApiController::class, 'checkCertificate']);
