@echo off
setlocal
cd /d "%~dp0app"
"%~dp0php\php.exe" "%~dp0app\artisan" %*
