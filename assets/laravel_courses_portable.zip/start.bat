@echo off
chcp 65001 > nul
setlocal

set "BASE_DIR=%~dp0"
set "PHP_DIR=%BASE_DIR%php"
set "MYSQL_DIR=%BASE_DIR%mysql"
set "APP_DIR=%BASE_DIR%app"

set "PATH=%PHP_DIR%;%MYSQL_DIR%\bin;%PATH%"
set HTTP_PROXY=
set HTTPS_PROXY=
set ALL_PROXY=

echo ================================================================
echo   Платформа онлайн-обучения (Модуль В - Laravel Portable)
echo   Адрес админки: http://127.0.0.1:8000/course-admin
echo   Email администратора: admin@edu.com
echo   Пароль администратора: course2025
echo ================================================================
echo.

:: 1. Проверка и запуск MySQL
echo [1/4] Запуск портативного MySQL сервера...
tasklist /FI "IMAGENAME eq mysqld.exe" 2>NUL | find /I /N "mysqld.exe">NUL
if "%ERRORLEVEL%"=="0" (
    echo [OK] MySQL сервер уже запущен.
) else (
    start "MariaDB Server" /B "%MYSQL_DIR%\bin\mysqld.exe" --defaults-file="%MYSQL_DIR%\my.ini" --standalone
    echo Ожидание инициализации MySQL (3 сек)...
    timeout /t 3 /nobreak > nul
)

:: 2. Создание базы данных
echo [2/4] Проверка базы данных course_platform...
"%MYSQL_DIR%\bin\mysql.exe" -u root -e "CREATE DATABASE IF NOT EXISTS course_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>NUL

:: 3. Применение миграций и сидов
echo [3/4] Применение миграций и сидеров Laravel...
cd /d "%APP_DIR%"
"%PHP_DIR%\php.exe" artisan migrate --force --no-interaction
"%PHP_DIR%\php.exe" artisan db:seed --force --no-interaction
"%PHP_DIR%\php.exe" artisan storage:link 2>NUL

:: 4. Запуск веб-сервера
echo [4/4] Запуск веб-сервера Laravel на http://127.0.0.1:8000/course-admin ...
start http://127.0.0.1:8000/course-admin
"%PHP_DIR%\php.exe" artisan serve --host=127.0.0.1 --port=8000

pause
