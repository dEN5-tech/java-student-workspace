@echo off
cd /d "%~dp0app"
set "PATH=%~dp0php;%~dp0mysql\bin;%PATH%"
doskey artisan="%~dp0php\php.exe" "%~dp0app\artisan" $*
doskey composer="%~dp0php\php.exe" "%~dp0composer.phar" $*
doskey mysql="%~dp0mysql\bin\mysql.exe" -u root $*
echo ========================================================
echo   Laravel Portable Console Environment
echo   Current dir: %CD%
echo   Available commands: php, composer, artisan, mysql
echo ========================================================
cmd /k
