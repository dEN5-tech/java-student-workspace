@echo off
chcp 65001 > nul
echo Остановка серверов...
taskkill /F /IM php.exe /T 2>nul
taskkill /F /IM mysqld.exe /T 2>nul
taskkill /F /IM mariadbd.exe /T 2>nul
echo Серверы Laravel и MySQL успешно остановлены.
timeout /t 2 > nul
